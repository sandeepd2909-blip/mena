# Deploy MENA Global to Vercel (Container Runtime)

This package fixes the Vercel CLI error `Service "mena-global" detected framework "python" ... must specify an "entrypoint" for runtime "python"`.

It uses Vercel's **Container Runtime** instead of trying to run the existing long-lived `ThreadingHTTPServer` as a Python Function handler:

- `Dockerfile.vercel` installs Python dependencies and starts `main.py --ui` on `0.0.0.0:80` (or `$PORT`).
- `vercel.json` explicitly sets service runtime to `container` and points its entrypoint at `Dockerfile.vercel`.
- All UI and API paths are routed to the same service.
- `.vercelignore` and `.dockerignore` exclude secrets, tests, caches, and local job state from uploads/build context.

## Update the folder you already linked

1. Extract this ZIP.
2. Copy the **contents of the inner `MENA_GLOBAL_V7_9_7_DECISION_MAKER_FIX` folder** into the folder you already linked with `vercel link`. Allow overwriting files, especially `vercel.json`. Do not delete the existing `.vercel` directory; it keeps the selected Vercel project linked. Do not copy a `.env` file into the ZIP/project.
3. In PowerShell at the linked project root, update the CLI:

   ```powershell
   npm install -g vercel@latest
   vercel --version
   ```

4. Add all needed provider credentials in **Vercel Dashboard → Project → Settings → Environment Variables** for Production (and Preview if needed). The local `.env` is deliberately not uploaded. Required for the core workflow: `OPENAI_API_KEY`, `TAVILY_API_KEY` (or configure your selected search provider), `SERPER_API_KEY` where used, `COMPANIES_HOUSE_API_KEY`, and `SEC_USER_AGENT`. Add the optional enrichment keys only when you want those providers.
5. Deploy from the same linked folder:

   ```powershell
   vercel --prod
   ```

6. When deployment finishes, visit the production URL and check `/health`. Then select UK and use **Test directory connection** before starting discovery. Canada discovery uses the configured web-search provider; click **Open registry verification** to check a candidate manually in Canada's Business Registries. Automated searching/scraping of CBR is prohibited by that portal's rules.

## Important operational limitation

The existing app's workflow was originally built around background threads, an in-memory job cache, and file-based JSON state. The container runtime resolves the build/runtime entrypoint issue and can run the existing HTTP UI, but Vercel container instances can scale down or scale out and their local filesystem is not durable/shared storage. For dependable long-running discovery and enrichment, move job/state persistence to a shared database and use a durable worker/queue. Test real discovery on the deployed URL; a successful deployment/health endpoint alone does not prove long-running jobs survive instance recycling.

Do not put API keys in `vercel.json`, Dockerfile, source code, or Git. Rotate keys previously pasted in chat before production use.


## UAE (MoIAT) on Vercel — browser required (V7.9.8)

MoIAT's directory only answers a real browser session. The app already handles this by driving Chrome, which exists on your PC
but not in a bare Python image. `Dockerfile.vercel` now installs Chromium and points `MOIAT_BROWSER_BINARY` at it, so UAE discovery
works the same way as locally with no manual file uploads.

If UAE still returns nothing after this deploy, MoIAT is probably refusing Vercel's network itself. Click **Test directory connection**
for the UAE and read the message. Then the options are: host the app where MoIAT is reachable, or ship a snapshot
(`data/moiat/directory_all_v2.json`) with the deploy.


## UAE blocked on Vercel — V7.9.9 fix (read this)

MoIAT blocks Vercel's (non-UAE datacenter) IPs, so the live search can never work from there, and Chromium does not help
because the block is on the IP. V7.9.9 detects this in ~10 seconds and offers three ways forward (use any one):

1. **Snapshot (most reliable, no proxy needed).** On a PC that can open MoIAT run `python build_moiat_snapshot.py`, then
   `vercel --prod`. The file `data/moiat/directory_all_v2.json` is deployed and served offline with verified MoIAT records.
2. **UAE proxy.** Set `MOIAT_PROXY_URL` (e.g. `http://user:pass@host:port`, a UAE-located HTTP(S) proxy) in Vercel env vars.
3. **Web fallback.** Set `TAVILY_API_KEY` or `SERPER_API_KEY`; without a snapshot/proxy you get labelled, MoIAT-unverified candidates.
