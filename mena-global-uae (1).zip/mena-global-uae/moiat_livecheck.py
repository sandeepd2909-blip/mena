"""Live smoke check for incremental official UAE MoIAT discovery."""
from app.moiat_directory import MOIAT_DIRECTORY_URL, MOIAT_MAIN_ACTIVITY_URL, MOIAT_SEARCH_URL, discover_moiat_batch

print("MoIAT directory:", MOIAT_DIRECTORY_URL)
print("Main activity API:", MOIAT_MAIN_ACTIVITY_URL)
print("Search API:", MOIAT_SEARCH_URL)
try:
    rows, cursors, total, more = discover_moiat_batch(main_activity_code="10", limit=50)
    keys = {x.company_key for x in rows}
    print("ACTIVITY 10 TOTAL:", total)
    print("BATCH SIZE:", len(rows))
    print("UNIQUE COMPANIES:", len(keys))
    print("NEXT CURSOR:", cursors)
    print("HAS NEXT:", more)
    print("FIRST 5:", [x.company_name for x in rows[:5]])
    if len(rows) != min(50, total or 50):
        raise RuntimeError("Unexpected first-batch size")
    if len(keys) != len(rows):
        raise RuntimeError("Duplicate companies in first batch")
    print("RESULT: Incremental MoIAT 50-company discovery is readable.")
except Exception as exc:
    print("DISCOVERY FAILED:", exc)
    raise SystemExit(1)
