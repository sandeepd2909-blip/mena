"""Single-credential login for the web UI.

One username + one password, both read from the environment (.env):
    APP_USERNAME   (default: admin)
    APP_PASSWORD   (required to turn the login on)
    SESSION_SECRET (optional; signs the session cookie. Defaults to a key derived from the credentials,
                    so changing the password logs everyone out.)
    SESSION_DAYS   (optional; default 7)

No password is ever stored in the code. If APP_PASSWORD is empty the login is off, which is only
allowed when the server listens on localhost (see serve()).
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import os
import secrets
import threading
import time

COOKIE = "mena_session"
MAX_FAILS = 5
LOCK_SECONDS = 60

_lock = threading.Lock()
_fails: dict[str, list[float]] = {}  # ip -> [fail_count, locked_until]


def _env(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip()


def enabled() -> bool:
    return bool(_env("APP_PASSWORD"))


def username() -> str:
    return _env("APP_USERNAME", "admin") or "admin"


def session_days() -> float:
    try:
        return max(0.01, float(_env("SESSION_DAYS", "7")))
    except ValueError:
        return 7.0


def _secret() -> bytes:
    explicit = _env("SESSION_SECRET")
    if explicit:
        return explicit.encode()
    return hashlib.sha256(f"mena-session|{username()}|{_env('APP_PASSWORD')}".encode()).digest()


def _digest(value: str) -> bytes:
    return hashlib.sha256(value.encode("utf-8")).digest()


def check_credentials(user: str, password: str) -> bool:
    """Constant-time check of both fields (always evaluates both)."""
    ok_user = hmac.compare_digest(_digest(str(user or "").strip()), _digest(username()))
    ok_pass = hmac.compare_digest(_digest(str(password or "")), _digest(_env("APP_PASSWORD")))
    return bool(enabled() and ok_user and ok_pass)


def make_token(now: float | None = None) -> str:
    expiry = int((now if now is not None else time.time()) + session_days() * 86400)
    payload = f"{expiry}.{secrets.token_hex(8)}"
    sig = hmac.new(_secret(), payload.encode(), hashlib.sha256).hexdigest()
    return base64.urlsafe_b64encode(f"{payload}.{sig}".encode()).decode()


def valid_token(token: str, now: float | None = None) -> bool:
    try:
        raw = base64.urlsafe_b64decode(token.encode()).decode()
        if base64.urlsafe_b64encode(raw.encode()).decode() != token:  # reject trailing/non-canonical input
            return False
        expiry_s, nonce, sig = raw.split(".")
        expected = hmac.new(_secret(), f"{expiry_s}.{nonce}".encode(), hashlib.sha256).hexdigest()
        return hmac.compare_digest(sig, expected) and int(expiry_s) > (now if now is not None else time.time())
    except Exception:
        return False


def token_from_cookie_header(header: str) -> str:
    for part in (header or "").split(";"):
        name, _, value = part.strip().partition("=")
        if name == COOKIE:
            return value
    return ""


def is_authenticated(cookie_header: str) -> bool:
    return valid_token(token_from_cookie_header(cookie_header))


def cookie_header(token: str, secure: bool) -> str:
    age = int(session_days() * 86400)
    return f"{COOKIE}={token}; Path=/; HttpOnly; SameSite=Lax; Max-Age={age}" + ("; Secure" if secure else "")


def clear_cookie_header(secure: bool) -> str:
    return f"{COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0" + ("; Secure" if secure else "")


# ---- brute-force protection: 5 wrong attempts from one address locks it for 60 seconds
def locked_for(ip: str, now: float | None = None) -> int:
    now = now if now is not None else time.time()
    with _lock:
        rec = _fails.get(ip)
        if rec and rec[1] > now:
            return int(rec[1] - now) + 1
    return 0


def record_failure(ip: str, now: float | None = None) -> None:
    now = now if now is not None else time.time()
    with _lock:
        rec = _fails.setdefault(ip, [0, 0.0])
        if rec[1] and rec[1] <= now:
            rec[0], rec[1] = 0, 0.0
        rec[0] += 1
        if rec[0] >= MAX_FAILS:
            rec[1] = now + LOCK_SECONDS
            rec[0] = 0


def record_success(ip: str) -> None:
    with _lock:
        _fails.pop(ip, None)


def reset_state() -> None:  # used by tests
    with _lock:
        _fails.clear()
