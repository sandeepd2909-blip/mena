"""Standalone phone enrichment for already-discovered LinkedIn leads.

This module deliberately does not run or modify LinkedIn discovery. It takes the
existing lead_generation.json output and enriches only rows missing a phone number.
"""
from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

from .config import settings
from .reversecontact_api import ReverseContactAPIError, enrich_phones_by_linkedin, get_reversecontact_usage, normalize_linkedin_url


def _text(value: Any) -> str:
    return str(value or "").strip()


def enrich_existing_leads_phones(
    input_path: Path = Path("data/output/lead_generation.json"),
    output_dir: Path = Path("data/output"),
    max_lookups: int | None = None,
) -> dict[str, Any]:
    """Enrich phones for existing leads without rerunning LinkedIn discovery."""
    if not input_path.exists():
        raise FileNotFoundError(f"Input lead file not found: {input_path}")

    payload = json.loads(input_path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("lead_generation.json must contain a JSON object")

    leads = payload.get("leads")
    if not isinstance(leads, list):
        raise ValueError("lead_generation.json does not contain a leads array")

    output_dir.mkdir(parents=True, exist_ok=True)
    effective_limit = max(0, int(max_lookups if max_lookups is not None else settings.reversecontact_max_lookups_per_run))

    candidates: list[dict[str, Any]] = []
    seen: set[str] = set()
    already_had_phone = 0
    missing_linkedin = 0

    # Preserve original lead ordering and all LinkedIn fields exactly as supplied.
    for index, lead in enumerate(leads):
        if not isinstance(lead, dict):
            continue
        phone = _text(lead.get("phone"))
        linkedin = _text(lead.get("linkedin_url"))
        if phone and phone.casefold() not in {"n/a", "na", "none", "null"}:
            already_had_phone += 1
            continue
        normalized = normalize_linkedin_url(linkedin)
        if not normalized or "linkedin.com/in/" not in normalized:
            missing_linkedin += 1
            continue
        if normalized in seen:
            continue
        seen.add(normalized)
        candidates.append({
            "index": index,
            "lead_id": _text(lead.get("lead_id")),
            "person_name": _text(lead.get("person_name")),
            "linkedin_url": linkedin,
        })

    candidates = candidates[:effective_limit]

    enriched_map: dict[str, dict[str, Any]] = {}
    provider_error = ""
    usage_before: dict[str, Any] = {}
    if candidates:
        try:
            usage_before = get_reversecontact_usage()
            if settings.reversecontact_skip_if_insufficient_credits:
                left = usage_before.get("credits_left")
                cost = max(1, int(settings.reversecontact_phone_cost_credits))
                if isinstance(left, (int, float)) and left < cost:
                    provider_error = f"Insufficient ReverseContact credits: {left} left, {cost} required per phone found"
                else:
                    enriched_map = enrich_phones_by_linkedin(candidates, max_lookups=effective_limit)
            else:
                enriched_map = enrich_phones_by_linkedin(candidates, max_lookups=effective_limit)
        except ReverseContactAPIError as exc:
            provider_error = str(exc)[:1200]

    updated_leads = [dict(lead) if isinstance(lead, dict) else lead for lead in leads]
    rows: list[dict[str, Any]] = []
    phones_found = 0
    not_found = 0
    failed = 0
    credits_consumed = 0.0

    for candidate in candidates:
        normalized = normalize_linkedin_url(candidate["linkedin_url"])
        result = enriched_map.get(normalized, {}) if isinstance(enriched_map, dict) else {}
        lead_index = int(candidate["index"])
        lead = updated_leads[lead_index]
        phone = _text(result.get("phone"))
        status = _text(result.get("reversecontact_status")) or ("provider_error" if provider_error else "not_attempted")
        if phone:
            lead["phone"] = phone
            lead["phone_source"] = "reversecontact"
            lead["enrichment_provider"] = "reversecontact"
            lead["reversecontact_phone_type"] = _text(result.get("phone_type"))
            lead["reversecontact_status"] = "found"
            lead["reversecontact_webhook_id"] = _text(result.get("reversecontact_webhook_id"))
            lead["reversecontact_error"] = ""
            lead["reversecontact_http_status"] = ""
            lead["reversecontact_credits_consumed"] = result.get("reversecontact_credits_consumed", "")
            phones_found += 1
        else:
            lead["reversecontact_status"] = status
            lead["reversecontact_error"] = _text(result.get("reversecontact_error")) or provider_error
            lead["reversecontact_http_status"] = result.get("reversecontact_http_status", "")
            lead["reversecontact_credits_consumed"] = result.get("reversecontact_credits_consumed", 0)
            if status == "phone-not-found":
                not_found += 1
            elif status == "provider_error" or provider_error:
                failed += 1

        credits_consumed += float(result.get("reversecontact_credits_consumed") or 0)
        rows.append({
            "lead_id": lead.get("lead_id", ""),
            "person_name": lead.get("person_name", ""),
            "linkedin_url": lead.get("linkedin_url", ""),
            "phone": lead.get("phone", ""),
            "phone_source": lead.get("phone_source", ""),
            "reversecontact_status": lead.get("reversecontact_status", ""),
            "reversecontact_phone_type": lead.get("reversecontact_phone_type", ""),
            "reversecontact_credits_consumed": lead.get("reversecontact_credits_consumed", ""),
            "reversecontact_error": lead.get("reversecontact_error", ""),
        })

    output_payload = dict(payload)
    output_payload["phase"] = "7.2-phone-enrichment"
    output_payload["phone_enrichment"] = {
        "input_file": str(input_path),
        "candidate_count": len(candidates),
        "already_had_phone": already_had_phone,
        "missing_linkedin": missing_linkedin,
        "phone_found": phones_found,
        "phone_not_found": not_found,
        "provider_failures": failed,
        "credits_consumed": credits_consumed,
        "usage_before": usage_before,
        "provider_error": provider_error,
        "max_lookups": effective_limit,
    }
    output_payload["leads"] = updated_leads

    json_path = output_dir / "phone_enriched_lead_generation.json"
    csv_path = output_dir / "phone_enriched_lead_generation.csv"
    diag_path = output_dir / "phone_enrichment_diagnostics.json"

    json_path.write_text(json.dumps(output_payload, indent=2, ensure_ascii=False), encoding="utf-8")
    with csv_path.open("w", newline="", encoding="utf-8-sig") as handle:
        fields = [
            "lead_id", "person_name", "linkedin_url", "phone", "phone_source",
            "reversecontact_status", "reversecontact_phone_type",
            "reversecontact_credits_consumed", "reversecontact_error",
        ]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    diag_path.write_text(json.dumps(output_payload["phone_enrichment"], indent=2, ensure_ascii=False), encoding="utf-8")

    return {
        "input": str(input_path),
        "json_output": str(json_path),
        "csv_output": str(csv_path),
        "diagnostics_output": str(diag_path),
        **output_payload["phone_enrichment"],
    }
