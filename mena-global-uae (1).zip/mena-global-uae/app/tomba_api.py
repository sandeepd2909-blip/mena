"""Tomba API integration for exact LinkedIn-based contact enrichment.

Uses Tomba's documented REST endpoints:
  GET /v1/linkedin?url=<linkedin>&enrich_mobile=true&full=true
  GET /v1/phone-finder?linkedin=<linkedin>&full=true

The module never scrapes LinkedIn. Tomba receives the public LinkedIn URL as an
identifier and returns data from its own enrichment database.
"""
from __future__ import annotations

import re
from typing import Any
from urllib.parse import quote

import requests

from .config import settings

BASE_URL = "https://api.tomba.io/v1"
GENERIC_LOCALS = {
    "info", "contact", "hello", "sales", "support", "admin", "office", "marketing",
    "hr", "careers", "career", "jobs", "recruitment", "recruiting", "accounts",
    "billing", "finance", "procurement", "purchasing", "enquiries", "inquiries",
    "service", "services", "customerservice", "customer.service", "mobile", "o",
}


class TombaAPIError(RuntimeError):
    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


def configured() -> bool:
    return bool(getattr(settings, "tomba_api_key", "") and getattr(settings, "tomba_secret_key", ""))


def normalize_linkedin_url(value: Any) -> str:
    text = str(value or "").strip().rstrip("/")
    if not text:
        return ""
    if not text.startswith(("http://", "https://")):
        text = "https://" + text
    try:
        from urllib.parse import urlparse
        parsed = urlparse(text)
        host = parsed.netloc.casefold().removeprefix("www.")
        path = parsed.path.rstrip("/")
        if host != "linkedin.com" or not path.casefold().startswith("/in/"):
            return ""
        return "https://www.linkedin.com" + path
    except Exception:
        return ""


def normalize_email(value: Any) -> str:
    email = str(value or "").strip().casefold()
    if "@" not in email:
        return ""
    local = email.split("@", 1)[0].replace(".", "")
    if not local or local in {x.replace(".", "") for x in GENERIC_LOCALS} or len(local) <= 1:
        return ""
    return email


def normalize_phone(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    digits = re.sub(r"\D", "", text)
    if digits.startswith("00"):
        digits = digits[2:]
    if not 8 <= len(digits) <= 15:
        return ""
    return "+" + digits


def _headers() -> dict[str, str]:
    key = str(getattr(settings, "tomba_api_key", "") or "").strip()
    secret = str(getattr(settings, "tomba_secret_key", "") or "").strip()
    if not key or not secret:
        raise TombaAPIError("TOMBA_API_KEY/TOMBA_SECRET_KEY are missing")
    return {"X-Tomba-Key": key, "X-Tomba-Secret": secret, "Accept": "application/json"}


def _get(path: str, params: dict[str, Any]) -> dict[str, Any]:
    try:
        response = requests.get(
            f"{BASE_URL}/{path.lstrip('/')}",
            params=params,
            headers=_headers(),
            timeout=int(getattr(settings, "tomba_timeout", 45)),
        )
    except requests.RequestException as exc:
        raise TombaAPIError(f"Tomba request failed: {exc}") from exc
    try:
        body = response.json()
    except ValueError:
        body = {}
    if response.status_code >= 400:
        message = "Tomba API error"
        if isinstance(body, dict):
            errors = body.get("errors")
            if isinstance(errors, list) and errors:
                first = errors[0] if isinstance(errors[0], dict) else {}
                message = str(first.get("details") or first.get("message") or first.get("id") or message)
            elif isinstance(body.get("message"), str):
                message = body["message"]
        raise TombaAPIError(f"Tomba HTTP {response.status_code}: {message}"[:1500], response.status_code)
    return body if isinstance(body, dict) else {}


def account() -> dict[str, Any]:
    """Authenticated account check. No contact lookup is performed."""
    return _get("me", {})


def _source_urls(data: dict[str, Any]) -> list[str]:
    result: list[str] = []
    sources = data.get("sources")
    if isinstance(sources, list):
        for source in sources:
            if isinstance(source, dict):
                uri = str(source.get("uri") or "").strip()
                if uri and uri not in result:
                    result.append(uri)
    return result[:20]


def _company_match(target_company: str, returned_company: str, target_domain: str = "", returned_domain: str = "") -> bool:
    from .identity import company_match_score
    if returned_company:
        return company_match_score(target_company, returned_company) >= 85
    if target_domain and returned_domain:
        return target_domain.casefold().removeprefix("www.") == returned_domain.casefold().removeprefix("www.")
    return False


def _extract_phone_candidates(data: dict[str, Any]) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    raw_items = data.get("phone_data")
    if isinstance(raw_items, list):
        for item in raw_items:
            if not isinstance(item, dict):
                continue
            phone = normalize_phone(item.get("phone_number") or item.get("phone"))
            if phone:
                candidates.append({
                    "phone": phone,
                    "phone_type": str(item.get("phone_type") or item.get("line_type") or "").casefold(),
                    "valid": item.get("valid"),
                    "carrier": str(item.get("carrier") or ""),
                })
    direct = normalize_phone(data.get("phone_number") or data.get("phone"))
    if direct and not any(x.get("phone") == direct for x in candidates):
        candidates.insert(0, {
            "phone": direct,
            "phone_type": str(data.get("phone_type") or data.get("line_type") or "").casefold(),
            "valid": data.get("valid"),
            "carrier": str(data.get("carrier") or ""),
        })
    return candidates


def find_by_linkedin(linkedin_url: str, target_name: str = "", target_company: str = "", target_domain: str = "") -> dict[str, Any]:
    """Find an exact person's email/phone from a LinkedIn URL via Tomba.

    Company and LinkedIn identity are checked before accepting contact data.
    Generic mailbox emails are rejected. Phone candidates are returned for a
    second-stage duplicate/switchboard check by the lead pipeline.
    """
    normalized = normalize_linkedin_url(linkedin_url)
    if not normalized:
        return {"status": "invalid_linkedin", "email": "", "phone": "", "phone_candidates": []}

    result: dict[str, Any] = {
        "status": "not_found", "email": "", "phone": "", "phone_type": "",
        "phone_candidates": [], "sources": [], "linkedin_url": normalized,
        "score": None, "company": "", "position": "", "verification_status": "",
        "error": "",
    }

    # LinkedIn Finder is the strongest identity path and can enrich mobile.
    try:
        payload = _get("linkedin", {"url": normalized, "enrich_mobile": "true", "full": "true"})
    except TombaAPIError as exc:
        result["status"] = "provider_error"
        result["error"] = str(exc)
        return result

    data = payload.get("data")
    items = data if isinstance(data, list) else [data] if isinstance(data, dict) else []
    # Tomba may return either one record or an array. Prefer the exact requested
    # LinkedIn record so a full response cannot accidentally select another row.
    raw = {}
    for item in items:
        if not isinstance(item, dict):
            continue
        candidate_li = normalize_linkedin_url(item.get("linkedin"))
        if candidate_li and candidate_li.casefold() == normalized.casefold():
            raw = item
            break
        if not raw:
            raw = item
    result["company"] = str(raw.get("company") or "").strip()
    result["position"] = str(raw.get("position") or "").strip()
    result["score"] = raw.get("score")
    result["verification_status"] = str((raw.get("verification") or {}).get("status") or "").casefold() if isinstance(raw.get("verification"), dict) else ""
    result["sources"] = _source_urls(raw)
    returned_linkedin = normalize_linkedin_url(raw.get("linkedin"))
    result["returned_linkedin"] = returned_linkedin

    # Exact LinkedIn URL must match when Tomba returns one. Never accept a different person.
    if returned_linkedin and returned_linkedin.casefold() != normalized.casefold():
        result["status"] = "rejected_linkedin_mismatch"
        return result

    returned_name = str(raw.get("full_name") or f"{raw.get('first_name') or ''} {raw.get('last_name') or ''}").strip()
    if target_name and returned_name:
        from .identity import company_match_score
        # Name check is deliberately permissive for Arabic/compound names, but requires
        # at least one substantial token in common unless the exact LinkedIn URL matched.
        a = set(re.findall(r"[a-zA-Z\u0600-\u06ff]{2,}", target_name.casefold()))
        b = set(re.findall(r"[a-zA-Z\u0600-\u06ff]{2,}", returned_name.casefold()))
        if returned_linkedin == normalized:
            pass
        elif not (a & b):
            result["status"] = "rejected_name_mismatch"
            return result

    returned_domain = str(raw.get("domain") or "").strip()
    if target_company and not _company_match(target_company, result["company"], target_domain, returned_domain):
        result["status"] = "rejected_company_mismatch"
        return result

    email = normalize_email(raw.get("email"))
    verification = raw.get("verification") if isinstance(raw.get("verification"), dict) else {}
    verification_status = str(verification.get("status") or "").strip().casefold()
    if email and verification_status and verification_status not in {"valid", "verified", "deliverable"}:
        result["error"] = f"email_verification_{verification_status}"
        email = ""
    if email:
        result["email"] = email

    phone_candidates = _extract_phone_candidates(raw)
    result["phone_candidates"] = phone_candidates
    # Prefer valid mobile. Do not force a landline into the final person phone field.
    for candidate in phone_candidates:
        if candidate.get("valid") is False:
            continue
        if candidate.get("phone_type") == "mobile":
            result["phone"] = candidate["phone"]
            result["phone_type"] = candidate.get("phone_type", "")
            break
    if not result["phone"] and phone_candidates:
        # Keep a valid non-mobile candidate available for diagnostics, but don't
        # automatically attribute it as a direct mobile.
        mobileish = next((x for x in phone_candidates if x.get("phone_type") in {"cell", "wireless"}), None)
        if mobileish:
            result["phone"] = mobileish["phone"]
            result["phone_type"] = mobileish.get("phone_type", "")

    if result["email"] or result["phone"]:
        result["status"] = "found"
    elif raw:
        result["status"] = "no_contact"
    return result


def find_phone_by_linkedin(linkedin_url: str) -> dict[str, Any]:
    """Direct Tomba Phone Finder path using a LinkedIn URL."""
    normalized = normalize_linkedin_url(linkedin_url)
    if not normalized:
        return {"status": "invalid_linkedin", "phones": []}
    try:
        payload = _get("phone-finder", {"linkedin": normalized, "full": "true"})
    except TombaAPIError as exc:
        return {"status": "provider_error", "phones": [], "error": str(exc)}
    data = payload.get("data")
    items = data if isinstance(data, list) else [data] if isinstance(data, dict) else []
    phones: list[dict[str, Any]] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        for candidate in _extract_phone_candidates(item):
            if not any(x.get("phone") == candidate.get("phone") for x in phones):
                phones.append(candidate)
    return {"status": "found" if phones else "not_found", "phones": phones, "linkedin_url": normalized}
