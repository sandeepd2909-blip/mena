"""Hunter enrichment for already-identified people.

Conservative rules:
- LinkedIn handle is the primary identity key.
- Email accepted only when verification=valid and Hunter exposes public source URLs.
- Generic/role mailboxes are rejected.
- Phone values are candidates only; callers reject shared/company numbers.
"""
from __future__ import annotations

from typing import Any
from urllib.parse import urlparse
import re
import requests

from .config import settings

GENERIC_LOCALS = {
    "info", "contact", "contactus", "sales", "support", "hello", "admin", "office",
    "enquiries", "enquiry", "inquiries", "inquiry", "mail", "media", "press", "hr",
    "careers", "jobs", "marketing", "service", "customerservice", "webmaster", "noreply",
    "no-reply", "reception", "accounts", "mobile", "phone", "telephone", "tel", "general",
    "business",
}


class HunterAPIError(RuntimeError):
    def __init__(self, message: str, status_code: int | None = None, error_code: str = "") -> None:
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code


def _key() -> str:
    return str(getattr(settings, "hunter_api_key", "") or "").strip()


def configured() -> bool:
    key = _key()
    return bool(key) and not key.startswith("PASTE_YOUR_")


def _base() -> str:
    return "https://api.hunter.io/v2"


def _headers() -> dict[str, str]:
    if not configured():
        raise HunterAPIError("HUNTER_API_KEY is missing")
    return {"X-API-KEY": _key(), "Accept": "application/json"}


def _json(response: requests.Response) -> dict[str, Any]:
    try:
        value = response.json()
    except ValueError:
        return {}
    return value if isinstance(value, dict) else {}


def _error_message(response: requests.Response) -> tuple[str, str]:
    body = _json(response)
    errors = body.get("errors")
    if isinstance(errors, list) and errors:
        first = errors[0] if isinstance(errors[0], dict) else {}
        return (
            str(first.get("details") or first.get("id") or response.text or "Hunter API error")[:1000],
            str(first.get("id") or ""),
        )
    if isinstance(errors, dict):
        return str(errors.get("details") or errors.get("message") or errors)[:1000], str(errors.get("id") or "")
    return str(body.get("message") or response.text or "Hunter API error")[:1000], ""


def _get(path: str, params: dict[str, Any]) -> dict[str, Any]:
    try:
        response = requests.get(
            f"{_base()}/{path.lstrip('/')}",
            params=params,
            headers=_headers(),
            timeout=int(getattr(settings, "hunter_timeout", 30)),
        )
    except requests.RequestException as exc:
        raise HunterAPIError(f"Hunter request failed: {exc}") from exc
    if response.status_code >= 400:
        message, code = _error_message(response)
        raise HunterAPIError(f"Hunter HTTP {response.status_code}: {message}", response.status_code, code)
    return _json(response)


def normalize_linkedin_handle(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    parsed = urlparse(text if "://" in text else f"https://{text}")
    host = parsed.netloc.casefold().removeprefix("www.")
    path = parsed.path.rstrip("/")
    if host != "linkedin.com" or not path.casefold().startswith("/in/"):
        return ""
    return path.split("/", 2)[2].strip().casefold()


def normalize_email(value: Any) -> str:
    return str(value or "").strip().casefold()


def normalize_hunter_phone(value: Any) -> str:
    """Accept only complete international numbers returned by Hunter."""
    text = str(value or "").strip()
    if not text:
        return ""
    digits = re.sub(r"\D", "", text)
    if text.startswith("00"):
        digits = digits[2:]
    if not (11 <= len(digits) <= 15):
        return ""
    return "+" + digits


def _name_tokens(value: Any) -> list[str]:
    raw = re.sub(r"[^a-zA-Z\u0600-\u06ff]+", " ", str(value or "")).casefold().split()
    stop = {"dr", "mr", "mrs", "ms", "prof", "the", "and", "of", "at"}
    return [x for x in raw if x not in stop and len(x) >= 2]


def _linkedin_handle_matches(value: Any, target_handle: str) -> bool:
    handle = normalize_linkedin_handle(value) if value else str(value or "").strip().casefold()
    return bool(handle and target_handle and handle == target_handle)


def _person_match(target_name: str, target_handle: str, item: dict[str, Any]) -> bool:
    linkedin = item.get("linkedin")
    if isinstance(linkedin, dict):
        linkedin = linkedin.get("handle")
    if _linkedin_handle_matches(linkedin, target_handle):
        return True
    returned = f"{item.get('first_name', '')} {item.get('last_name', '')}".strip()
    target_tokens = _name_tokens(target_name)
    returned_tokens = _name_tokens(returned)
    if not target_tokens or not returned_tokens:
        return False
    if len(target_tokens) == 1:
        return target_tokens[0] in returned_tokens
    # For Arabic/compound names, exact last-token + at least one other token is enough.
    return target_tokens[-1] in returned_tokens and any(t in returned_tokens for t in target_tokens[:-1])


def _email_is_generic(email: str) -> bool:
    local = email.split("@", 1)[0].casefold().replace(".", "") if "@" in email else email.casefold()
    return local in GENERIC_LOCALS or len(local) <= 1


def _source_urls(data: dict[str, Any]) -> list[str]:
    urls: list[str] = []
    sources = data.get("sources")
    if isinstance(sources, list):
        for item in sources:
            if isinstance(item, dict):
                uri = str(item.get("uri") or "").strip()
                if uri and uri not in urls:
                    urls.append(uri)
    return urls[:20]


def hunter_account() -> dict[str, Any]:
    """Free authenticated account check; does not consume search credits."""
    return _get("account", {})


def find_email_by_linkedin(linkedin_url: str) -> dict[str, Any]:
    handle = normalize_linkedin_handle(linkedin_url)
    if not handle:
        return {"status": "invalid_linkedin", "email": "", "sources": []}
    payload = _get("email-finder", {"linkedin_handle": handle, "max_duration": 20})
    data = payload.get("data") if isinstance(payload.get("data"), dict) else {}
    email = normalize_email(data.get("email"))
    verification = data.get("verification") if isinstance(data.get("verification"), dict) else {}
    verification_status = str(verification.get("status") or "").casefold()
    sources = _source_urls(data)
    if not email:
        return {"status": "not_found", "email": "", "sources": [], "raw": data}
    if _email_is_generic(email):
        return {"status": "rejected_generic", "email": "", "sources": sources, "raw": data}
    if verification_status != "valid":
        return {
            "status": "rejected_verification",
            "email": "",
            "verification_status": verification_status,
            "sources": sources,
            "raw": data,
        }
    if not sources:
        return {
            "status": "rejected_no_public_source",
            "email": "",
            "verification_status": verification_status,
            "sources": [],
            "raw": data,
        }
    return {
        "status": "found",
        "email": email,
        "sources": sources,
        "verification_status": verification_status,
        "score": data.get("score"),
        "position": data.get("position") or "",
        "company": data.get("company") or "",
        "domain": data.get("domain") or "",
        "phone": normalize_hunter_phone(data.get("phone_number")),
        "linkedin_url": data.get("linkedin_url") or "",
        "raw": data,
    }


def enrich_person_by_linkedin(linkedin_url: str) -> dict[str, Any]:
    handle = normalize_linkedin_handle(linkedin_url)
    if not handle:
        return {"status": "invalid_linkedin"}
    payload = _get("people/find", {"linkedin_handle": handle})
    data = payload.get("data") if isinstance(payload.get("data"), dict) else {}
    employment = data.get("employment") if isinstance(data.get("employment"), dict) else {}
    name = data.get("name") if isinstance(data.get("name"), dict) else {}
    linkedin = data.get("linkedin") if isinstance(data.get("linkedin"), dict) else {}
    return {
        "status": "found",
        "full_name": str(name.get("fullName") or "").strip(),
        "company": str(employment.get("name") or "").strip(),
        "job_title": str(employment.get("title") or "").strip(),
        "domain": str(employment.get("domain") or "").strip(),
        "linkedin_handle": str(linkedin.get("handle") or handle).strip().casefold(),
        "phone": normalize_hunter_phone(data.get("phone")),
        "email": normalize_email(data.get("email")),
        "raw": data,
    }


def domain_search_person(
    domain: str,
    person_name: str,
    linkedin_url: str = "",
    job_title: str = "",
) -> dict[str, Any]:
    """Use Hunter Domain Search to recover an exact person's email/phone when the LinkedIn lookup lacks one."""
    domain = str(domain or "").strip().casefold().removeprefix("www.")
    target_handle = normalize_linkedin_handle(linkedin_url)
    if not domain or not person_name:
        return {"status": "invalid_params"}

    params: dict[str, Any] = {
        "domain": domain,
        "type": "personal",
        "required_field": "full_name,phone_number",
        "verification_status": "valid",
        "decision_maker": "true",
        "limit": 10,
    }
    if job_title:
        params["job_titles"] = job_title
    payload = _get("domain-search", params)
    data = payload.get("data") if isinstance(payload.get("data"), dict) else {}
    rows = data.get("emails") if isinstance(data.get("emails"), list) else []
    best = None
    for row in rows:
        if not isinstance(row, dict):
            continue
        if not _person_match(person_name, target_handle, row):
            continue
        phone = normalize_hunter_phone(row.get("phone_number"))
        email = normalize_email(row.get("value"))
        if email and _email_is_generic(email):
            email = ""
        if not phone and not email:
            continue
        best = {
            "status": "found",
            "email": email,
            "phone": phone,
            "position": str(row.get("position") or "").strip(),
            "linkedin_url": str(row.get("linkedin") or "").strip(),
            "sources": _source_urls(row),
            "score": row.get("confidence"),
            "verification_status": str((row.get("verification") or {}).get("status") or "").casefold(),
            "raw": row,
        }
        break
    if best:
        return best

    # Second exact-person pass: allow a verified personal email without a phone.
    # This is only used when the phone-bearing query did not surface the person.
    params["required_field"] = "full_name"
    payload = _get("domain-search", params)
    data = payload.get("data") if isinstance(payload.get("data"), dict) else {}
    rows = data.get("emails") if isinstance(data.get("emails"), list) else []
    for row in rows:
        if not isinstance(row, dict) or not _person_match(person_name, target_handle, row):
            continue
        email = normalize_email(row.get("value"))
        if not email or _email_is_generic(email):
            continue
        return {
            "status": "found",
            "email": email,
            "phone": normalize_hunter_phone(row.get("phone_number")),
            "position": str(row.get("position") or "").strip(),
            "linkedin_url": str(row.get("linkedin") or "").strip(),
            "sources": _source_urls(row),
            "score": row.get("confidence"),
            "verification_status": str((row.get("verification") or {}).get("status") or "").casefold(),
            "raw": row,
        }
    return {"status": "not_found"}

