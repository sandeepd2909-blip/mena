"""FullEnrich mobile-only enrichment for the UAE prospecting UI.

This module deliberately requests ONLY ``contact.phones``. It never sends email
fields and it never returns landlines as mobile contacts.
"""
from __future__ import annotations

import re
import time
from typing import Any

import requests

from .config import settings
from .identity import person_names_match
from .fullenrich_api import (
    FullEnrichAPIError,
    _company_from_result,
    _company_match,
    _first,
    _linkedin_key,
    _name_match,
    _norm,
    _text,
    _walk,
    normalize_linkedin_url,
)


def configured() -> bool:
    key = _text(getattr(settings, "fullenrich_api_key", ""))
    return bool(getattr(settings, "fullenrich_enabled", True) and key and not key.startswith("PASTE_YOUR_"))


def provider_status() -> dict[str, Any]:
    """Check the FullEnrich key and credit balance using its read-only credits endpoint."""
    if not configured():
        return {"status": "not_configured", "configured": False, "message": "FullEnrich is disabled or FULLENRICH_API_KEY is missing."}
    base = _text(getattr(settings, "fullenrich_base_url", "https://app.fullenrich.com/api/v2")).rstrip("/")
    try:
        response = requests.get(
            base + "/account/credits",
            headers={"Authorization": f"Bearer {_text(settings.fullenrich_api_key)}", "Accept": "application/json"},
            timeout=min(12, max(3, int(getattr(settings, "fullenrich_timeout", 30)))),
        )
    except requests.RequestException as exc:
        return {"status": "network_error", "configured": True, "message": f"Cannot reach FullEnrich ({type(exc).__name__}). Check internet/proxy/DNS and retry."}
    try:
        body = response.json()
    except ValueError:
        body = {}
    if response.status_code in {401, 403}:
        return {"status": "invalid_api_key", "configured": True, "message": f"FullEnrich rejected the API key (HTTP {response.status_code}). Replace FULLENRICH_API_KEY with a valid key."}
    if response.status_code == 402:
        return {"status": "insufficient_credits", "configured": True, "remaining_credits": 0, "message": "FullEnrich reports a billing or credit restriction."}
    if response.status_code == 429:
        return {"status": "rate_limited", "configured": True, "message": "FullEnrich rate limit reached. Wait before retrying."}
    if response.status_code >= 400:
        return {"status": "provider_error", "configured": True, "message": _describe_provider_error(response.status_code, body, phase="credit check")}
    balance = body.get("balance") if isinstance(body, dict) else None
    if isinstance(balance, (int, float)):
        cost = max(1, int(getattr(settings, "fullenrich_mobile_cost", 10)))
        return {"status": "ok", "configured": True, "valid_api_key": True, "remaining_credits": balance, "estimated_mobile_lookups": int(balance // cost), "mobile_cost": cost, "message": "FullEnrich API key verified."}
    return {"status": "unexpected_response", "configured": True, "message": "FullEnrich returned HTTP 200 but no numeric credit balance. Check the provider response/API version."}


def _request_mobile(linkedin_url: str, name: str, company: str, domain: str) -> str:
    base = _text(getattr(settings, "fullenrich_base_url", "https://app.fullenrich.com/api/v2")).rstrip("/")
    parts = _text(name).split()
    contact = {
        "first_name": parts[0] if parts else "",
        "last_name": " ".join(parts[1:]),
        "company_name": _text(company),
        "linkedin_url": linkedin_url,
        # IMPORTANT: mobile only. No email field is requested.
        "enrich_fields": ["contact.phones"],
    }
    clean_domain = re.sub(r"^https?://", "", _text(domain)).split("/", 1)[0].strip().strip("/")
    # MoIAT directory rows often have no public domain. Omitting an unknown field is
    # safer than submitting domain="", which some provider validators reject.
    if clean_domain:
        contact["domain"] = clean_domain
    payload = {"name": "MENA UAE Prospecting Engine", "data": [contact]}
    try:
        r = requests.post(
            base + "/contact/enrich/bulk",
            headers={
                "Authorization": f"Bearer {_text(settings.fullenrich_api_key)}",
                "Content-Type": "application/json",
            },
            json=payload,
            timeout=int(settings.fullenrich_timeout),
        )
    except requests.RequestException as exc:
        raise FullEnrichAPIError(f"request_error: {exc}") from exc
    try:
        body = r.json()
    except ValueError as exc:
        raise FullEnrichAPIError(f"invalid_json:{r.status_code}") from exc
    if r.status_code >= 400 or not isinstance(body, dict):
        raise FullEnrichAPIError(_describe_provider_error(r.status_code, body, phase="submit"))
    enrichment_id = _text(body.get("enrichment_id") or body.get("id") or _first(body, {"enrichment_id"}))
    if not enrichment_id:
        raise FullEnrichAPIError("missing_enrichment_id")
    return enrichment_id


def _describe_provider_error(status_code: int, body: Any, *, phase: str) -> str:
    """Return a useful provider error without logging headers or credentials."""
    detail = ""
    if isinstance(body, dict):
        for key in ("message", "detail", "error_description", "error", "title", "code"):
            value = body.get(key)
            if isinstance(value, str) and value.strip():
                detail = value.strip()
                break
            if isinstance(value, dict):
                for inner in ("message", "detail", "code"):
                    iv = value.get(inner)
                    if isinstance(iv, str) and iv.strip():
                        detail = iv.strip()
                        break
                if detail:
                    break
    if status_code in {401, 403}:
        return f"FullEnrich authentication/permission failure (HTTP {status_code}); verify FULLENRICH_API_KEY and its access."
    if status_code == 402:
        return "FullEnrich reports insufficient credits or billing restrictions (HTTP 402). Check the workspace balance and API-key spending limit."
    if status_code == 429:
        return "FullEnrich rate limit reached (HTTP 429). Wait before retrying."
    if status_code >= 500:
        return f"FullEnrich service error during {phase} (HTTP {status_code}). Retry later."
    if detail:
        # The body is an untrusted provider message; cap its size before exposing it in the UI.
        return f"FullEnrich {phase} failed (HTTP {status_code}): {detail[:240]}"
    return f"FullEnrich {phase} failed (HTTP {status_code})."


def _provider_job_status(body: dict[str, Any]) -> str:
    # Read only the job-level status. Recursive lookup can accidentally pick a
    # nested phone/email validation status and terminate polling too early.
    return _norm(body.get("status") or body.get("enrichment_status") or body.get("state"))


def _poll(enrichment_id: str) -> dict[str, Any]:
    """Poll until FullEnrich says the job is terminal.

    A partial ``profile`` can be returned while a contact waterfall is still in
    progress. Do not treat that as a completed phone lookup: wait for FINISHED,
    or for a response with contact data but no job status (compatibility mode).
    """
    base = _text(getattr(settings, "fullenrich_base_url", "https://app.fullenrich.com/api/v2")).rstrip("/")
    deadline = time.time() + int(getattr(settings, "fullenrich_poll_timeout", 180))
    last: dict[str, Any] = {}
    terminal_success = {"finished", "completed", "complete", "success", "succeeded"}
    terminal_failure = {"failed", "error", "cancelled", "canceled"}
    while time.time() < deadline:
        try:
            r = requests.get(
                base + f"/contact/enrich/bulk/{enrichment_id}",
                headers={"Authorization": f"Bearer {_text(settings.fullenrich_api_key)}"},
                timeout=min(15, max(3, int(settings.fullenrich_timeout))),
            )
        except requests.RequestException as exc:
            raise FullEnrichAPIError(f"poll_request_error: {type(exc).__name__}; check network access and retry") from exc
        try:
            body = r.json()
        except ValueError as exc:
            raise FullEnrichAPIError(f"FullEnrich polling returned non-JSON data (HTTP {r.status_code}).") from exc
        if r.status_code >= 400:
            raise FullEnrichAPIError(_describe_provider_error(r.status_code, body, phase="poll"))
        if not isinstance(body, dict):
            raise FullEnrichAPIError("FullEnrich polling returned an unexpected response format.")
        last = body
        status = _provider_job_status(body)
        if status in terminal_failure:
            detail = _first(body, {"message", "detail", "error", "failure_reason"})
            raise FullEnrichAPIError(f"FullEnrich enrichment job ended with status {status.upper()}" + (f": {_text(detail)[:240]}" if detail else "."))
        if status in terminal_success:
            return body
        has_contact_data = bool(_first(body, {"contact_info", "most_probable_phone", "phones", "phone", "mobile_phone"}))
        if not status and has_contact_data:
            return body
        time.sleep(max(1, min(10, int(getattr(settings, "fullenrich_poll_interval", 5)))))
    last_status = _provider_job_status(last) or "unknown"
    raise FullEnrichAPIError(f"FullEnrich polling timed out after {int(getattr(settings, 'fullenrich_poll_timeout', 180))}s (last status: {last_status}).")


def _phone_candidates(body: Any) -> list[tuple[str, str]]:
    """Return (number, declared line type) candidates from arbitrary provider wrappers."""
    out: list[tuple[str, str]] = []
    seen: set[str] = set()

    def visit(obj: Any, context_type: str = "") -> None:
        if isinstance(obj, dict):
            local_type = _text(
                obj.get("phone_type") or obj.get("line_type") or obj.get("type") or obj.get("phoneType") or context_type
            ).casefold()
            # Explicit phone-ish dictionary.
            for key in ("phone_number", "number", "phone", "value", "mobile_phone", "mobile"):
                value = _text(obj.get(key))
                if value and re.sub(r"\D", "", value):
                    k = re.sub(r"\D", "", value)
                    if k not in seen:
                        seen.add(k)
                        out.append((value, local_type or ("mobile" if key in {"mobile", "mobile_phone"} else "")))
            for k, v in obj.items():
                next_type = local_type
                if str(k).casefold() in {"mobile_phone", "mobile", "mobile_phones", "mobile_numbers"}:
                    next_type = "mobile"
                elif str(k).casefold() in {"landline", "landlines", "fixed_line", "fixed_lines"}:
                    next_type = "landline"
                visit(v, next_type)
        elif isinstance(obj, list):
            for item in obj:
                visit(item, context_type)

    visit(body)
    return out


def _is_mobile(number: str, declared_type: str) -> tuple[bool, str]:
    t = _norm(declared_type)
    if any(token in t for token in ("landline", "fixed", "switchboard", "office", "desk")):
        return False, "landline_or_fixed_line"
    if "mobile" in t or t in {"cell", "cellphone", "cell phone"}:
        return True, "provider_mobile_type"
    # If the provider omitted a type, accept only an unambiguous UAE mobile prefix.
    digits = re.sub(r"\D", "", number)
    if digits.startswith("00971"):
        digits = digits[5:]
    elif digits.startswith("971"):
        digits = digits[3:]
    elif digits.startswith("0"):
        digits = digits[1:]
    if len(digits) == 9 and digits[:2] in {"50", "52", "54", "55", "56", "58"}:
        return True, "uae_mobile_prefix"
    return False, "line_type_unknown"


_BATCH_NAMES = {"mena uae prospecting engine", "mena opportunity intelligence engine"}
_ECHO_KEYS = {"input", "inputs", "request", "requests", "custom", "custom_fields", "payload", "query"}


def _strip_echo(obj: Any) -> Any:
    """Drop parts of a provider response that merely echo OUR request.

    FullEnrich returns the submitted input (our linkedin_url, company_name, domain) and the
    batch name next to the result. Reading those back as if the provider had *found* them made
    identity/company validation pass vacuously, so a wrong LinkedIn URL still produced a number.
    """
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            key = str(k).casefold()
            if key in _ECHO_KEYS:
                continue
            if key == "name" and isinstance(v, str) and _norm(v) in _BATCH_NAMES:
                continue
            out[k] = _strip_echo(v)
        return out
    if isinstance(obj, list):
        return [_strip_echo(x) for x in obj]
    return obj


def _returned_person_name(body: dict[str, Any]) -> str:
    full = _text(_first(body, {"full_name", "name"}))
    if full:
        return full
    first = _text(_first(body, {"first_name", "firstname"}))
    last = _text(_first(body, {"last_name", "lastname"}))
    return f"{first} {last}".strip()


def _names_agree(target: str, returned: str) -> bool:
    return person_names_match(target, returned) or _name_match(target, returned)


def parse_mobile_result(body: dict[str, Any], requested_linkedin: str, target_name: str, target_company: str, target_domain: str) -> dict[str, Any]:
    body = _strip_echo(body)
    returned_linkedin = _text(_first(body, {"linkedin_url", "professional_network_url"}))
    if not normalize_linkedin_url(returned_linkedin):
        returned_linkedin = next(
            (_text(v) for _, v in _walk(body, {"url"}) if normalize_linkedin_url(_text(v))), ""
        )
    returned_name = _returned_person_name(body)
    got_company, got_domain = _company_from_result(body)
    linkedin_exact = bool(returned_linkedin and _linkedin_key(returned_linkedin) == _linkedin_key(requested_linkedin))
    identity_reasons: list[str] = []
    if returned_linkedin and not linkedin_exact:
        identity_reasons.append("returned_linkedin_mismatch")
    if returned_name and target_name and not _names_agree(target_name, returned_name):
        # V7.8.56: an exact LinkedIn match no longer excuses a different person's name. If the
        # profile the URL points to belongs to someone else, the URL (not the name) is wrong, and
        # the number would belong to the wrong person.
        identity_reasons.append("name_mismatch")
    if not returned_linkedin and not returned_name:
        identity_reasons.append("identity_unconfirmed_by_provider")
    identity_ok = bool(
        (returned_linkedin and linkedin_exact) or
        (returned_name and target_name and _names_agree(target_name, returned_name))
    ) and not any(x in identity_reasons for x in {"returned_linkedin_mismatch", "name_mismatch"})
    company_status, company_conf, company_basis = _company_match(target_company, target_domain, got_company, got_domain)
    rejected: list[str] = []
    phone = ""
    verification = ""
    if company_status == "mismatch":
        for candidate, _ in _phone_candidates(body):
            rejected.append(f"company_mismatch_phone:{candidate}")
    elif not identity_ok:
        for candidate, _ in _phone_candidates(body):
            rejected.append(f"identity_mismatch_phone:{candidate}")
    else:
        for candidate, declared_type in _phone_candidates(body):
            ok, reason = _is_mobile(candidate, declared_type)
            if ok:
                phone = candidate
                verification = reason
                break
            rejected.append(f"rejected_phone:{candidate}:{reason}")
    status = "found" if phone else ("person_found_no_mobile" if identity_ok else "not_found")
    return {
        "status": status,
        "provider": "fullenrich",
        "person_found": bool(identity_ok and (returned_linkedin or returned_name or got_company)),
        "phone": phone,
        "phone_candidates": [x[0] for x in _phone_candidates(body)],
        "rejected_phone_candidates": rejected,
        "returned_name": returned_name,
        "returned_company": got_company,
        "returned_domain": got_domain,
        "returned_linkedin": normalize_linkedin_url(returned_linkedin),
        "company_association": company_status,
        "company_association_confidence": company_conf,
        "company_association_basis": company_basis,
        "identity_reasons": identity_reasons,
        "verification": verification,
        "phone_source": "fullenrich:verified_mobile" if phone else "",
        "email": "",
        "email_candidates": [],
        "requested_fields": ["contact.phones"],
        "errors": [],
    }


def enrich_mobile_by_linkedin(linkedin_url: str, *, target_name: str = "", target_company: str = "", target_domain: str = "", exclude_phones: set[str] | frozenset[str] = frozenset()) -> dict[str, Any]:
    requested = normalize_linkedin_url(linkedin_url)
    if not requested:
        return {"status": "invalid_linkedin", "provider": "fullenrich", "phone": "", "email": "", "errors": ["invalid_linkedin"], "requested_fields": ["contact.phones"]}
    if not configured():
        return {"status": "disabled", "provider": "fullenrich", "phone": "", "email": "", "errors": ["FULLENRICH_API_KEY is missing or provider disabled"], "requested_fields": ["contact.phones"]}
    try:
        eid = _request_mobile(requested, target_name, target_company, target_domain)
        body = _poll(eid)
        job_status = _provider_job_status(body)
        if job_status in {"failed", "error", "cancelled", "canceled"}:
            raise FullEnrichAPIError(f"FullEnrich enrichment job ended with status {job_status.upper()}.")
        parsed = parse_mobile_result(body, requested, target_name, target_company, target_domain)
        if parsed.get("phone"):
            digits = re.sub(r"\D", "", parsed["phone"])
            if any(digits[-8:] == re.sub(r"\D", "", x)[-8:] for x in exclude_phones):
                parsed["rejected_phone_candidates"].append(f"known_shared_number:{parsed['phone']}")
                parsed["phone"] = ""
                parsed["phone_source"] = ""
                parsed["status"] = "person_found_no_mobile"
        parsed["attempts"] = [{
            "mode": "full_enrich_mobile_only",
            "status": parsed.get("status"),
            "person_found": parsed.get("person_found"),
            "phone": bool(parsed.get("phone")),
            "company_association": parsed.get("company_association"),
            "requested_fields": ["contact.phones"],
        }]
        return parsed
    except FullEnrichAPIError as exc:
        return {
            "status": "error", "provider": "fullenrich", "phone": "", "email": "",
            "errors": [str(exc)[:500]], "attempts": [{"mode": "full_enrich_mobile_only", "status": "error", "error": str(exc)[:500]}],
            "requested_fields": ["contact.phones"],
        }
