"""Company resolution step (V7.8.58).

When a user selects a company from the MoIAT list, the name on the licence is not always the
name the company is known by on the web / LinkedIn. It may be

  * a subsidiary of a larger group,
  * a legal entity that trades under a brand ("Foo Trading LLC" -> "Foo Fresh"),
  * renamed / previously named.

This module asks the AI to work out *which company it really is*, using only public search
results, and then VALIDATES every claim in code against those sources. Nothing the model says is
trusted unless a source supports it. If anything fails, the pipeline silently continues with the
registered name exactly as before (never worse than V7.8.57).

The rest of the pipeline is unchanged: the validated names are simply extra aliases of the same
company, so people discovery, LinkedIn matching, UAE geography checks and FullEnrich all run on
"that company". Subsidiary information is reported as a label only.
"""
from __future__ import annotations

import json
import re
import threading
from typing import Any, Callable
from urllib.parse import urlparse

from .config import settings
from .geo import geo_verdict
from .identity import company_match_score, company_mentioned, normalize_identity

_CACHE: dict[str, dict[str, Any]] = {}
_CACHE_LOCK = threading.Lock()

# A parent/subsidiary claim needs an explicit ownership cue in the supporting source.
_OWNERSHIP_CUE = re.compile(
    r"\b(?:subsidiary|sub-?sidiary|wholly[\s-]*owned|owned\s+by|part\s+of|member\s+of|division\s+of|"
    r"arm\s+of|brand\s+of|unit\s+of|affiliate\s+of|belongs\s+to|acquired\s+by|a\s+company\s+of|"
    r"parent\s+company|group\s+company|sister\s+company|under\s+the\s+umbrella)\b",
    re.I,
)
_SOCIAL_HOSTS = (
    "linkedin.", "facebook.", "instagram.", "twitter.", "x.com", "youtube.", "wikipedia.",
    "crunchbase.", "zoominfo.", "dnb.", "bloomberg.", "google.", "yellowpages", "tripadvisor.",
    "glassdoor.", "indeed.", "naukri", "kompass.", "alibaba.", "tradeindia", "exportersindia",
)
_MAX_SOURCES = 14
_SRC_CHARS = 1100


def _text(v: Any) -> str:
    return str(v or "").strip()


def enabled() -> bool:
    return bool(getattr(settings, "company_resolver_enabled", True))


def _unresolved(name: str, status: str, note: str = "") -> dict[str, Any]:
    return {
        "status": status,
        "registered_name": name,
        "resolved_name": name,
        "aliases": [],
        "relationship": "unknown" if status != "disabled" else "unknown",
        "is_subsidiary": False,
        "parent_company": "",
        "website_domain": "",
        "company_linkedin": "",
        "confidence": 0.0,
        "evidence": [],
        "label": "",
        "note": note,
    }


def _host(url: str) -> str:
    try:
        raw = url if "://" in url else f"https://{url}"
        return urlparse(raw).netloc.casefold().removeprefix("www.").split(":", 1)[0]
    except Exception:
        return ""


def _plain(s: str) -> str:
    return normalize_identity(s)


def _in_sources(value: str, sources: list[dict[str, Any]]) -> bool:
    """Does the (normalised) value literally occur in any retrieved source?"""
    v = _plain(value)
    if len(v) < 3:
        return False
    for s in sources:
        hay = _plain(s["title"] + " " + s["text"])
        if re.search(r"(?<![a-z0-9])" + re.escape(v).replace(r"\ ", r"\s+") + r"(?![a-z0-9])", hay):
            return True
        if v.replace(" ", "") in hay.replace(" ", "") and len(v.replace(" ", "")) >= 6:
            return True
    return False


def _gather_sources(
    name: str, country: str, search: Callable[..., list[dict[str, Any]]], emirate: str, known_domain: str
) -> tuple[list[dict[str, Any]], list[str]]:
    base = re.sub(r"\s+", " ", name).strip()
    where = f"{emirate} {country}".strip() or country
    queries: list[tuple[str, list[str] | None]] = [
        (f'"{base}" {where} company', None),
        (f'"{base}" "subsidiary of" OR "part of" OR "owned by" OR "member of" OR "parent company" {country}', None),
        (f'"{base}" {where} official website about us', None),
        (f'site:linkedin.com/company "{base}"', ["linkedin.com"]),
    ]
    if known_domain:
        queries.insert(0, (f'"{base}" about us group', [known_domain]))
    sources: list[dict[str, Any]] = []
    errors: list[str] = []
    seen: set[str] = set()
    for query, domains in queries:
        try:
            hits = search(query, include_domains=domains, max_results=8) or []
        except Exception as exc:  # provider failure must not break people discovery
            errors.append(f"{type(exc).__name__}: {str(exc)[:120]}")
            continue
        for h in hits:
            if not isinstance(h, dict):
                continue
            url = _text(h.get("url"))
            if not url or url in seen:
                continue
            title = _text(h.get("title"))
            body = _text(h.get("content")) or ""
            raw = _text(h.get("raw_content"))
            text = (body + " " + raw[:1500]).strip()
            combined = f"{title} {text}"
            if not company_mentioned(name, combined):
                continue
            # Same-named companies abroad must not define who this UAE company is.
            if not geo_verdict(country, title, text, url).person_ok(False):
                continue
            seen.add(url)
            sources.append({"id": len(sources), "url": url, "title": title, "text": text[:_SRC_CHARS]})
            if len(sources) >= _MAX_SOURCES:
                return sources, errors
    return sources, errors


_SYSTEM = (
    "You identify which real company a registered company name in the target country refers to, using ONLY "
    "the numbered public sources supplied. The registered name may be a subsidiary, may trade under a brand, "
    "or may have been renamed. Rules: never invent anything; if the sources do not show it, leave it empty. "
    "Ignore sources about a different company that merely has a similar or identical name, and about "
    "companies outside the target country. 'parent_company' is ONLY a company that a source explicitly says owns / "
    "is the group of the registered company (subsidiary of, owned by, part of, member of group). "
    "'aliases' are other names the SAME company is known by in the sources (trading name, brand, former "
    "name, the name on its LinkedIn company page) - never the parent's name, never a person's name. "
    "'resolved_name' is the name the company is best known by (usually the LinkedIn company page name); "
    "use the registered name if nothing better is supported. 'uae_entity' is true only if the sources "
    "describe this company as operating in the target country. Return JSON only: "
    '{"resolved_name":"","aliases":[""],"relationship":"standalone|subsidiary|brand|unknown",'
    '"parent_company":"","website_domain":"","company_linkedin":"","uae_entity":true,'
    '"confidence":0.0,"evidence_ids":[0],"note":""}'
)


def _ask(system: str, user: str) -> dict[str, Any]:
    from .ai import ask_json
    return ask_json(system, user)


def _validate(
    name: str, raw: dict[str, Any], sources: list[dict[str, Any]], country: str,
    verify: Callable[[str, str], dict[str, Any]] | None = None,
) -> dict[str, Any]:
    out = _unresolved(name, "resolved")
    try:
        confidence = float(raw.get("confidence") or 0)
    except (TypeError, ValueError):
        confidence = 0.0
    out["confidence"] = round(max(0.0, min(1.0, confidence)), 2)

    min_conf = float(getattr(settings, "company_resolver_min_confidence", 0.5))
    from .geo import is_uae_country
    if (is_uae_country(country) and raw.get("uae_entity") is False) or out["confidence"] < min_conf:
        out["status"] = "unresolved"
        out["note"] = f"Sources did not identify the {country} company with enough confidence; registered name used."
        return out

    ids = [i for i in (raw.get("evidence_ids") or []) if isinstance(i, int) and 0 <= i < len(sources)]
    out["evidence"] = [sources[i]["url"] for i in ids][:5]

    # --- resolved name: must relate to the registered name or literally appear in the sources.
    resolved = re.sub(r"\s+", " ", _text(raw.get("resolved_name")))[:120]
    if resolved and (company_match_score(name, resolved) > 0 or _in_sources(resolved, sources)):
        out["resolved_name"] = resolved
    else:
        out["resolved_name"] = name

    # --- parent company: needs literal presence + an explicit ownership cue in one source.
    parent = re.sub(r"\s+", " ", _text(raw.get("parent_company")))[:120]
    relationship = _text(raw.get("relationship")).casefold()
    parent_ok = False
    if parent and company_match_score(name, parent) < 85 and company_match_score(out["resolved_name"], parent) < 85:
        for s in sources:
            blob = s["title"] + " " + s["text"]
            if not _in_sources(parent, [s]):
                continue
            for m in re.finditer(r"(?<![A-Za-z0-9])" + re.escape(parent).replace(r"\ ", r"\s+") + r"(?![A-Za-z0-9])", blob, re.I):
                window = blob[max(0, m.start() - 160): m.end() + 160]
                if _OWNERSHIP_CUE.search(window) and (
                    company_mentioned(name, window) or company_mentioned(out["resolved_name"], window)
                ):
                    parent_ok = True
                    break
            if parent_ok:
                break
    if parent_ok:
        out["parent_company"] = parent
        out["relationship"] = relationship if relationship in {"subsidiary", "brand"} else "subsidiary"
        out["is_subsidiary"] = True
    else:
        out["relationship"] = "standalone" if relationship == "standalone" else "unknown"

    # --- aliases: only names that literally appear in the sources (or are the resolved name).
    aliases: list[str] = []
    seen = {_plain(name)}
    candidates = [out["resolved_name"]] + [a for a in (raw.get("aliases") or []) if isinstance(a, str)]
    for a in candidates:
        a = re.sub(r"\s+", " ", _text(a))[:100]
        key = _plain(a)
        if len(key) < 3 or key in seen:
            continue
        if parent_ok and company_match_score(parent, a) >= 85:
            continue  # never smuggle the parent in as an alias
        if a != out["resolved_name"] and not (company_match_score(name, a) > 0 or _in_sources(a, sources)):
            continue
        seen.add(key)
        aliases.append(a)
        if len(aliases) >= 6:
            break
    out["aliases"] = aliases

    # --- website: host must appear in a source and must not be a social / directory site.
    dom = _host(_text(raw.get("website_domain")))
    if dom and not any(h in dom for h in _SOCIAL_HOSTS) and any(dom in (s["url"] + " " + s["text"]).casefold() for s in sources):
        out["website_domain"] = dom

    # --- LinkedIn company page: must be a real linkedin.com/company/ page, appear in a source,
    #     and be confirmed by the AI as THIS company's page. Anything else is never displayed.
    verify_prompt = _LI_VERIFY_SYSTEM.replace("the target country", country).replace("outside the target country", f"outside {country}")
    out["company_linkedin"] = _verified_company_linkedin(
        _text(raw.get("company_linkedin")), name, out["resolved_name"], out["aliases"], sources, verify,
        system_prompt=verify_prompt,
    )

    out["note"] = _text(raw.get("note"))[:240]
    out["label"] = build_label(out)
    return out


_LI_COMPANY_RE = re.compile(r"(?:https?://)?(?:[a-z]{2,3}\.)?linkedin\.com/company/([A-Za-z0-9\-_%.]+)", re.I)
_LI_BAD_SLUGS = {"unavailable", "setup", "new", "jobs", "search", "showcase", "school", "people", "about", "login"}

_LI_VERIFY_SYSTEM = (
    "You check one LinkedIn URL. Decide (1) is it the LinkedIn page of a COMPANY / organisation (not a "
    "person's profile, post, job, school, group, article or search page) and (2) is it the page of the "
    "named company (or one of its names), not a different company with a similar name or a company "
    "outside the target country. Use ONLY the supplied source excerpts. If unsure, answer false. Return JSON only: "
    '{"is_company_page":false,"matches_company":false,"reason":""}'
)


def canonical_company_linkedin(url: str) -> str:
    """https://www.linkedin.com/company/<slug> or '' when the URL is not a company page
    (person /in/, /school/, /showcase/, /jobs/, /posts/, /pulse/ ... are all rejected)."""
    m = _LI_COMPANY_RE.search(_text(url))
    if not m:
        return ""
    slug = m.group(1).rstrip(".").strip()
    if len(slug) < 2 or slug.casefold() in _LI_BAD_SLUGS:
        return ""
    return f"https://www.linkedin.com/company/{slug}"


def _verified_company_linkedin(
    raw_url: str, name: str, resolved: str, aliases: list[str], sources: list[dict[str, Any]],
    verify: Callable[[str, str], dict[str, Any]] | None, system_prompt: str | None = None,
) -> str:
    canon = canonical_company_linkedin(raw_url)
    if not canon:
        return ""
    slug = canon.rsplit("/", 1)[1].casefold()
    excerpts = []
    for s in sources:
        blob = s["url"] + " " + s["text"]
        if f"linkedin.com/company/{slug}" in blob.casefold():
            excerpts.append({"url": s["url"], "title": s["title"], "text": s["text"][:600]})
    if not excerpts:
        return ""
    try:
        verdict = (verify or _ask)(system_prompt or _LI_VERIFY_SYSTEM, json.dumps({
            "linkedin_url": canon, "registered_name": name, "resolved_name": resolved,
            "other_names": aliases[:6], "sources": excerpts[:4],
        }, ensure_ascii=False))
    except Exception:
        return ""  # cannot confirm -> do not display
    if isinstance(verdict, dict) and verdict.get("is_company_page") is True and verdict.get("matches_company") is True:
        return canon
    return ""


def build_label(res: dict[str, Any]) -> str:
    bits: list[str] = []
    registered = _text(res.get("registered_name"))
    resolved = _text(res.get("resolved_name"))
    if resolved and registered and company_match_score(registered, resolved) < 95:
        bits.append(f"Operates as {resolved}")
    if res.get("is_subsidiary") and res.get("parent_company"):
        verb = "Brand of" if res.get("relationship") == "brand" else "Subsidiary of"
        bits.append(f"{verb} {res['parent_company']}")
    return " · ".join(bits)


def resolve_company(
    name: str,
    *,
    country: str = "United Arab Emirates",
    emirate: str = "",
    known_domain: str = "",
    search: Callable[..., list[dict[str, Any]]] | None = None,
    ask: Callable[[str, str], dict[str, Any]] | None = None,
    use_cache: bool = True,
) -> dict[str, Any]:
    """Resolve the real company behind a registered company name. Never raises."""
    name = re.sub(r"\s+", " ", _text(name))
    if not name:
        return _unresolved(name, "unresolved", "empty name")
    if not enabled():
        return _unresolved(name, "disabled", "Company resolver disabled")
    key = _plain(name) + "|" + _plain(country)
    if use_cache:
        with _CACHE_LOCK:
            if key in _CACHE:
                return dict(_CACHE[key])
    try:
        if search is None:
            from .search import public_search
            search = public_search
        sources, errors = _gather_sources(name, country, search, emirate, known_domain)
        if not sources:
            res = _unresolved(name, "unresolved", "No public sources found for the company; registered name used.")
            if errors:
                res["note"] += " (" + errors[0] + ")"
            return res  # not cached: a later retry may succeed
        payload = {
            "registered_name": name,
            "country": country,
            "emirate": emirate,
            "sources": [{"id": s["id"], "url": s["url"], "title": s["title"], "text": s["text"]} for s in sources],
        }
        system_prompt = _SYSTEM.replace("the target country", country).replace("outside the target country", f"outside {country}")
        raw = (ask or _ask)(system_prompt, json.dumps(payload, ensure_ascii=False))
        if not isinstance(raw, dict):
            raise ValueError("resolver returned non-object")
        res = _validate(name, raw, sources, country, verify=ask or _ask)
    except Exception as exc:
        return _unresolved(name, "error", f"{type(exc).__name__}: {str(exc)[:160]}")
    with _CACHE_LOCK:
        _CACHE[key] = dict(res)
    return res


def include_parent_default() -> bool:
    return bool(getattr(settings, "company_resolver_include_parent", False))


def search_aliases(res: dict[str, Any]) -> list[str]:
    """Names the rest of the pipeline may use to find people at THIS company."""
    out = list(res.get("aliases") or [])
    if include_parent_default() and res.get("parent_company"):
        out.append(res["parent_company"])
    return out


def clear_cache() -> None:
    with _CACHE_LOCK:
        _CACHE.clear()
