"""Persistent state for UAE MoIAT discovery cycles and enrichment history."""
from __future__ import annotations

import json
import os
import tempfile
import threading
from hashlib import sha256
from pathlib import Path
from typing import Any

BASE = Path("data/uae_state")
STATE_FILE = BASE / "state.json"
# Every load -> modify -> save of state.json must hold this lock. Mobile enrichment and job saves run in
# parallel threads; without it concurrent writers overwrite each other and enrichment history is lost
# (which would make already-enriched people eligible, and chargeable, again).
_STATE_LOCK = threading.RLock()


def _empty() -> dict[str, Any]:
    return {
        "segments": {},
        "served_company_keys": {},
        "enrichment_history": {},
        "last_job_id": "",
    }


def load_state() -> dict[str, Any]:
    with _STATE_LOCK:
        if not STATE_FILE.exists():
            return _empty()
        try:
            obj = json.loads(STATE_FILE.read_text(encoding="utf-8"))
            if isinstance(obj, dict):
                base = _empty()
                base.update(obj)
                return base
        except Exception:
            pass
        return _empty()


def save_state(state: dict[str, Any]) -> None:
    with _STATE_LOCK:
        BASE.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(prefix="state_", suffix=".tmp", dir=str(BASE))
        os.close(fd)
        p = Path(tmp)
        p.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")
        p.replace(STATE_FILE)


def stable_person_id(person: dict[str, Any], company_name: str) -> str:
    linkedin = str(person.get("linkedin_url") or "").strip().rstrip("/").casefold()
    if linkedin:
        raw = f"linkedin|{linkedin}"
    else:
        name = " ".join(str(person.get("person_name") or "").casefold().split())
        title = " ".join(str(person.get("job_title") or "").casefold().split())
        company = " ".join(str(company_name or "").casefold().split())
        raw = f"name|{name}|company|{company}|title|{title}"
    return sha256(raw.encode("utf-8")).hexdigest()[:24]


def jobs_dir() -> Path:
    p = BASE / "jobs"
    p.mkdir(parents=True, exist_ok=True)
    return p


def write_job(job: dict[str, Any]) -> None:
    path = jobs_dir() / f"{job['id']}.json"
    fd, tmp = tempfile.mkstemp(prefix=f"{job['id']}_", suffix=".tmp", dir=str(path.parent))
    os.close(fd)
    p = Path(tmp)
    p.write_text(json.dumps(job, indent=2, ensure_ascii=False), encoding="utf-8")
    p.replace(path)


def read_job(job_id: str) -> dict[str, Any] | None:
    path = jobs_dir() / f"{job_id}.json"
    if not path.exists():
        return None
    try:
        obj = json.loads(path.read_text(encoding="utf-8"))
        return obj if isinstance(obj, dict) else None
    except Exception:
        return None


def mark_company_served(segment: str, company_key: str) -> None:
    with _STATE_LOCK:
        state = load_state()
        state.setdefault("served_company_keys", {}).setdefault(segment, [])
        if company_key not in state["served_company_keys"][segment]:
            state["served_company_keys"][segment].append(company_key)
        save_state(state)


def served_company_keys(segment: str) -> set[str]:
    state = load_state()
    return set(state.get("served_company_keys", {}).get(segment, []))


def enrichment_record(person_id: str) -> dict[str, Any] | None:
    return load_state().get("enrichment_history", {}).get(person_id)


def record_enrichment(person_id: str, record: dict[str, Any]) -> None:
    with _STATE_LOCK:
        state = load_state()
        state.setdefault("enrichment_history", {})[person_id] = record
        save_state(state)


def set_last_job(job_id: str) -> None:
    with _STATE_LOCK:
        state = load_state()
        state["last_job_id"] = job_id
        save_state(state)
