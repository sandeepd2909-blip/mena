import json
from datetime import datetime, timezone
from typing import Any, Iterable
from urllib.parse import quote

import requests

from .config import settings


class ApifyAPIError(RuntimeError):
    """Raised when an Apify API call fails."""


def _actor_path(actor_id: str) -> str:
    cleaned = str(actor_id or "").strip().strip("/")
    if not cleaned:
        raise ValueError("Apify actor ID is missing")
    return cleaned.replace("/", "~")


def _auth_headers() -> dict[str, str]:
    return {
        "Authorization": f"Bearer {settings.apify_api_token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }


def _check_token() -> None:
    if not settings.apify_api_token or settings.apify_api_token.startswith("PASTE_YOUR_"):
        raise ApifyAPIError("APIFY_API_TOKEN is missing")


def _response_detail(response: Any) -> str:
    try:
        payload = response.json()
        if isinstance(payload, dict):
            data = payload.get("data")
            message = payload.get("message") or payload.get("error")
            if isinstance(data, dict):
                message = data.get("message") or data.get("error") or message
            if message:
                return str(message)[:1000]
        return response.text[:1000].strip()
    except Exception:
        return str(getattr(response, "text", "") or "")[:1000].strip()


def get_apify_user_data() -> dict[str, Any]:
    """Return the authenticated Apify account metadata without starting an Actor."""
    _check_token()
    url = "https://api.apify.com/v2/users/me"
    try:
        response = requests.get(
            url,
            headers=_auth_headers(),
            timeout=settings.request_timeout,
        )
    except requests.RequestException as exc:
        raise ApifyAPIError(f"Apify account check failed: {exc}") from exc
    if response.status_code >= 400:
        raise ApifyAPIError(
            f"Apify account check returned HTTP {response.status_code}: {_response_detail(response)}"
        )
    try:
        payload = response.json()
    except ValueError as exc:
        raise ApifyAPIError("Apify account check returned non-JSON data") from exc
    data = payload.get("data") if isinstance(payload, dict) else None
    if not isinstance(data, dict):
        raise ApifyAPIError("Apify account check returned an unexpected response")
    return data


def get_apify_actor_data(actor_id: str) -> dict[str, Any]:
    """Return Actor metadata without starting a run."""
    _check_token()
    actor = _actor_path(actor_id)
    url = f"https://api.apify.com/v2/actors/{quote(actor, safe='~')}"
    try:
        response = requests.get(
            url,
            headers=_auth_headers(),
            timeout=settings.request_timeout,
        )
    except requests.RequestException as exc:
        raise ApifyAPIError(f"Apify Actor metadata check failed for {actor_id}: {exc}") from exc
    if response.status_code >= 400:
        raise ApifyAPIError(
            f"Apify Actor metadata check returned HTTP {response.status_code} for {actor_id}: "
            f"{_response_detail(response)}"
        )
    try:
        payload = response.json()
    except ValueError as exc:
        raise ApifyAPIError(f"Apify Actor metadata check returned non-JSON data for {actor_id}") from exc
    data = payload.get("data") if isinstance(payload, dict) else None
    if not isinstance(data, dict):
        raise ApifyAPIError(f"Apify Actor metadata for {actor_id} was empty or malformed")
    return data


def _unique_actor_ids(actor_ids: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for actor_id in actor_ids:
        value = str(actor_id or "").strip()
        if not value:
            continue
        key = value.casefold()
        if key in seen:
            continue
        result.append(value)
        seen.add(key)
    return result


def _plan_label(plan: Any) -> str:
    if isinstance(plan, dict):
        for key in ("name", "id", "title", "planId"):
            value = plan.get(key)
            if value not in (None, "", [], {}):
                return str(value)
    if plan not in (None, "", [], {}):
        return str(plan)
    return "unknown"


def preflight_apify(actor_ids: Iterable[str]) -> dict[str, Any]:
    """Check account + Actor metadata without consuming an Actor run.

    This is a metadata/configuration check, not a billable lead search. A provider
    may still reject an actual run for plan, approval, proxy, or Actor-specific
    reasons; those runtime errors are captured separately by Phase 7.2.
    """
    checked_at = datetime.now(timezone.utc).isoformat()
    result: dict[str, Any] = {
        "provider": "apify",
        "checked_at": checked_at,
        "status": "unknown",
        "account": {"status": "unknown", "plan": "unknown"},
        "actors": [],
        "message": "",
    }

    try:
        account = get_apify_user_data()
    except ApifyAPIError as exc:
        result["status"] = "account_unavailable"
        result["account"] = {"status": "error", "plan": "unknown"}
        result["message"] = str(exc)[:1000]
        return result

    result["account"] = {
        "status": "ok",
        "plan": _plan_label(account.get("plan")),
    }

    actor_results: list[dict[str, Any]] = []
    for actor_id in _unique_actor_ids(actor_ids):
        item: dict[str, Any] = {"actor": actor_id, "status": "unknown"}
        try:
            actor = get_apify_actor_data(actor_id)
            permission = str(actor.get("actorPermissionLevel") or "").strip()
            notice = str(actor.get("notice") or "").strip()
            item.update(
                {
                    "status": "ok",
                    "actor_id": actor.get("id") or "",
                    "title": actor.get("title") or actor.get("name") or "",
                    "public": bool(actor.get("isPublic")),
                    "deprecated": bool(actor.get("isDeprecated")),
                    "permission_level": permission,
                    "notice": notice,
                    "api_access_metadata": "available",
                }
            )
            if item["deprecated"]:
                item["status"] = "deprecated"
            elif notice and notice != "NONE":
                item["status"] = "warning"
            if permission == "FULL_PERMISSIONS" and item["status"] == "ok":
                item["status"] = "approval_check_needed"
        except ApifyAPIError as exc:
            item["status"] = "metadata_unavailable"
            item["error"] = str(exc)[:1000]
        actor_results.append(item)

    result["actors"] = actor_results
    usable = [a for a in actor_results if a.get("status") in {"ok", "warning", "approval_check_needed"}]
    deprecated_or_missing = [a for a in actor_results if a.get("status") in {"deprecated", "metadata_unavailable"}]
    if usable:
        result["status"] = "ready" if not deprecated_or_missing else "degraded"
        result["message"] = "Apify account and at least one configured Actor are accessible via metadata API."
    elif actor_results:
        result["status"] = "actors_unavailable"
        result["message"] = "No configured lead Actor was accessible via the Apify metadata API."
    else:
        result["status"] = "no_actors_configured"
        result["message"] = "No Apify lead Actors are configured."
    return result


def run_actor_get_dataset_items(actor_id: str, run_input: dict[str, Any]) -> list[dict[str, Any]]:
    """Run an Apify Actor synchronously and return its default dataset items.

    Uses the API token in the Authorization header, not in the URL.
    """
    _check_token()

    actor = _actor_path(actor_id)
    url = f"https://api.apify.com/v2/acts/{quote(actor, safe='~')}/run-sync-get-dataset-items"
    headers = _auth_headers()
    try:
        response = requests.post(
            url,
            headers=headers,
            data=json.dumps(run_input, ensure_ascii=False),
            timeout=settings.apify_timeout_seconds,
        )
    except requests.RequestException as exc:
        raise ApifyAPIError(f"Apify request failed: {exc}") from exc

    if response.status_code >= 400:
        detail = response.text[:1000].strip()
        raise ApifyAPIError(
            f"Apify returned HTTP {response.status_code} for {actor_id}: {detail}"
        )

    try:
        payload = response.json()
    except ValueError as exc:
        raise ApifyAPIError("Apify returned a non-JSON response") from exc

    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, dict)]
    if isinstance(payload, dict):
        # Some Actor implementations wrap dataset items in a result/items field.
        for key in ("items", "data", "results"):
            value = payload.get(key)
            if isinstance(value, list):
                return [item for item in value if isinstance(item, dict)]
        # A single object is a valid one-item result.
        if payload:
            return [payload]
    return []
