from __future__ import annotations

import json
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Any
from urllib.parse import urlparse

from .ai import ask_json
from .apify_api import ApifyAPIError, preflight_apify, run_actor_get_dataset_items
from .config import settings
from .leads import (
    _actor_family,
    _company_match,
    _extract_company_linkedin,
    _extract_company_name,
    _extract_company_website,
    _extract_emails,
    _extract_job_title,
    _extract_linkedin,
    _extract_name,
    _extract_phone,
    _identity_keys,
    _is_provider_contact,
    _norm,
    _provider_error_kind,
    _resolve_afanasenko_company_urls,
    _text,
)
from .search import public_search, serper_search, tavily_search
from .identity import company_name_variants


def _log(message: str) -> None:
    """Progress line so a long run shows where the time goes."""
    print(message, file=sys.stderr, flush=True)


_ACCEPTED_LEVELS = (
    "CEO / President / Founder",
    "C-Suite",
    "EVP / SVP",
    "VP",
    "General Manager / Managing Director",
    "Director",
    "Head / Department Head",
    "Senior Manager",
    "Manager / Product Manager",
)

# Label the model uses for people below the Product Manager cutoff (never output).
_BELOW_CUTOFF_LABEL = "Below cutoff"


def _level_rank(level: str) -> int:
    """Deterministic rank from the level's position (1 = most senior).

    The model only chooses the label; the order is fixed by _ACCEPTED_LEVELS so
    ranks are stable and comparable across companies and runs.
    """
    try:
        return _ACCEPTED_LEVELS.index(level) + 1
    except ValueError:
        return 999


def _canonical_profile_url(url: str) -> str:
    value = _text(url)
    if "linkedin.com/in/" not in value.casefold():
        return ""
    try:
        parsed = urlparse(value if "://" in value else f"https://{value}")
        if "/in/" not in parsed.path.casefold():
            return ""
        return f"https://www.linkedin.com{parsed.path.rstrip('/')}/"
    except Exception:
        return ""


def _canonical_company_urls_for_actor(actor_id: str, company: dict[str, Any]) -> tuple[list[str], list[str], list[dict[str, Any]]]:
    if _actor_family(actor_id) == "afanasenko_profile_search":
        urls, inputs, errors = _resolve_afanasenko_company_urls(actor_id, company)
        return urls, errors, inputs
    known = _text(company.get("known_linkedin"))
    if "linkedin.com/company/" in known.casefold():
        return [known], [], []
    return [], [], []


def _company_hierarchy_search_input(company_urls: list[str], job_title: str, count: int) -> dict[str, Any]:
    return {
        "operationMode": "searchLead",
        "searchLeadCompanyUrls": company_urls[:5],
        "searchLeadJobTitle": job_title,
        "searchLeadCount": max(1, min(int(count), 100)),
        "maxItemsMode3": max(1, min(int(count), 100)),
    }


def _dynamic_hierarchy_search_terms(company: dict[str, Any], max_queries: int) -> list[str]:
    """Ask the model for broad, recall-oriented title queries instead of a hardcoded taxonomy."""
    if max_queries <= 0 or not settings.openai_api_key:
        return []
    system = """
You are a LinkedIn hierarchy search-query planner.

Goal: maximize recall for one company. Find identifiable people from the top of the organization down through Product Manager.
The application will scope the search to the company's LinkedIn page, so do NOT return company names or URLs.
Return broad job-title search strings, not people names.
Use title variants and synonyms that would reasonably uncover executives, senior leadership, directors, department heads, managers and product managers.
Avoid junior, assistant, associate, intern and coordinator variants because those are below the requested cutoff.
Do not assume a particular industry-specific organizational chart. Use the company's supplied industry only to suggest plausible title wording.
Do not hardcode a fixed list across companies: tailor the query set to the supplied company and industry.

Return JSON only:
{"queries":["...","..."]}
""".strip()
    user = f"""
Company: {company.get('company_name', '')}
Country: {company.get('country', '')}
Industry: {company.get('industry', '')}
Known domain: {company.get('known_domain') or ''}
Generate up to {max_queries} distinct, broad LinkedIn title queries. Prioritize recall over specificity.
""".strip()
    try:
        result = ask_json(system, user)
    except Exception:
        return []
    values = result.get("queries", []) if isinstance(result, dict) else []
    if not isinstance(values, list):
        return []
    output: list[str] = []
    seen: set[str] = set()
    for value in values:
        q = _text(value)
        key = _norm(q)
        if not q or key in seen:
            continue
        output.append(q)
        seen.add(key)
        if len(output) >= max_queries:
            break
    return output



def _split_dynamic_title_terms(query: str) -> list[str]:
    """Turn an AI-generated OR query into provider-friendly individual titles.

    The AI planner is intentionally free-form. code_crafter/leads-finder accepts
    an array of title values, so compound strings such as `CFO OR Finance Director`
    are split without introducing a fixed title taxonomy.
    """
    text = _text(query)
    if not text:
        return []
    parts = re.split(r"\s+\bOR\b\s+", text, flags=re.IGNORECASE)
    output: list[str] = []
    seen: set[str] = set()
    for part in parts:
        value = part.strip().strip('"\'`')
        value = re.sub(r"\s+", " ", value)
        if not value:
            continue
        key = _norm(value)
        if key not in seen:
            output.append(value)
            seen.add(key)
    return output


_APIFY_ALLOWED_CONTACT_LOCATIONS = {
    "united states", "germany", "india", "united kingdom", "russia", "france", "china",
    "canada", "netherlands", "mexico", "belgium", "japan", "brazil", "australia",
    "poland", "thailand", "sweden", "portugal", "spain", "czech republic", "taiwan",
    "south africa", "colombia", "italy", "vietnam", "nigeria", "singapore", "hong kong",
    "ireland", "israel", "switzerland", "turkey", "romania", "south korea", "indonesia",
    "united arab emirates", "saudi arabia", "austria", "philippines", "peru", "malaysia",
    "argentina", "ukraine", "ghana", "denmark", "norway", "finland", "puerto rico",
    "qatar", "macau", "new zealand", "hungary", "luxembourg", "kuwait", "egypt",
    "slovakia", "greece", "kenya", "bulgaria", "costa rica", "chile",
}


def _normalize_apify_contact_location(country: str) -> str:
    """Normalize a company country to the exact lowercase value expected by Leads Finder.

    The Actor schema is case-sensitive. For unsupported/custom country labels we omit
    the location filter rather than sending an invalid request that aborts the run.
    """
    value = re.sub(r"\s+", " ", _text(country)).strip().casefold()
    return value if value in _APIFY_ALLOWED_CONTACT_LOCATIONS else ""


def _hierarchy_provider_inputs(actor_id: str, company: dict[str, Any], job_title_query: str, count: int, company_urls: list[str] | None = None) -> list[tuple[dict[str, Any], str]]:
    """Build provider-native hierarchy inputs without hardcoding job titles."""
    family = _actor_family(actor_id)
    company_name = _text(company.get("company_name"))
    domain = _text(company.get("known_domain"))
    country = _normalize_apify_contact_location(_text(company.get("country")))
    count = max(1, min(int(count), 100))

    if family == "afanasenko_profile_search":
        urls = list(company_urls or [])
        if not urls:
            return []
        return [(_company_hierarchy_search_input(urls, job_title_query, count), job_title_query or "company-wide decision-makers")]

    if family == "code_crafter_leads_finder":
        base: dict[str, Any] = {
            "fetch_count": count,
            "email_status": ["validated", "unknown"],
        }
        if domain:
            base["company_domain"] = [domain]
        elif company_name:
            base["company_keywords"] = [company_name]
        if country:
            base["contact_location"] = [country]
        titles = _split_dynamic_title_terms(job_title_query) if job_title_query else []
        if titles:
            base["contact_job_title"] = titles
        return [(base, job_title_query or "company-wide decision-makers")]

    # Preserve support for any future provider adapters already present in the project.
    return []

def _fallback_hierarchy_decision(title: str) -> dict[str, Any] | None:
    """Conservative non-AI safety net when classification is unavailable.

    This only interprets the supplied title. It never invents a person, employer,
    LinkedIn URL, email, or phone.
    """
    value = _text(title).casefold()
    value = re.sub(r"[^a-z0-9]+", " ", value).strip()
    if not value:
        return None
    low = value
    if re.search(r"\b(former|ex|previously)\b", low):
        return {"hierarchy_level": _BELOW_CUTOFF_LABEL, "hierarchy_rank": 999, "keep": False, "reason": "former role"}
    if re.search(r"\b(junior|jr|assistant|associate|coordinator|intern|analyst|specialist|engineer|developer|designer)\b", low):
        # Product Manager is handled explicitly below; generic Executive is not a seniority level.
        if "product manager" not in low:
            return {"hierarchy_level": _BELOW_CUTOFF_LABEL, "hierarchy_rank": 999, "keep": False, "reason": "below Product Manager cutoff"}
    checks = [
        (r"\b(ceo|chief executive|president|founder|co founder|cofounder|owner)\b", "CEO / President / Founder"),
        (r"\b(cfo|cto|cio|cmo|chief [a-z ]{2,30})\b", "C-Suite"),
        (r"\b(evp|svp|executive vice president|senior vice president)\b", "EVP / SVP"),
        (r"\b(vp|vice president)\b", "VP"),
        (r"\b(general manager|managing director|country manager|regional manager)\b", "General Manager / Managing Director"),
        (r"\bdirector\b", "Director"),
        (r"\b(head|department head)\b", "Head / Department Head"),
        (r"\bsenior manager\b", "Senior Manager"),
        (r"\bmanager\b", "Manager / Product Manager"),
        (r"\bproduct manager\b", "Manager / Product Manager"),
    ]
    for pattern, level in checks:
        if re.search(pattern, low):
            return {"hierarchy_level": level, "hierarchy_rank": _level_rank(level), "keep": True, "reason": "title-based fallback"}
    return None


_CLASSIFY_CHUNK_SIZE = 40


def _classify_chunk(company: dict[str, Any], rows: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    """One model call. Returned ids are local to ``rows`` (0..len-1)."""
    compact = []
    for index, row in enumerate(rows):
        compact.append({
            "id": str(index),
            "person_name": row.get("person_name", ""),
            "job_title": row.get("job_title", ""),
            "headline": row.get("headline", ""),
            "provider_company_name": row.get("provider_company_name", ""),
        })
    system = f"""
You are a strict organizational-hierarchy classifier.

For the supplied company and people, classify each person's CURRENT role by seniority.
Keep people from the top of the organization down through Product Manager. Discard roles clearly below Product Manager, such as junior, assistant, associate, coordinator, analyst, engineer, specialist, team-lead or intern roles.
Do not require the exact title words used in examples; interpret the whole current title/headline, including non-English titles.
Do not infer a person's seniority from their name or LinkedIn URL.
Ignore people whose title shows they no longer work at the company (e.g. "former", "ex-", "previously").

Allowed hierarchy labels for kept people, from highest to lowest, are exactly:
{json.dumps(list(_ACCEPTED_LEVELS), ensure_ascii=False)}

Product Manager is the cutoff. A Product Manager is kept. An Associate Product Manager or Assistant Product Manager is discarded.
For a discarded person set "keep": false and "hierarchy_level": "{_BELOW_CUTOFF_LABEL}".
Return an entry for EVERY supplied id.
Return JSON only:
{{
  "people": [
    {{"id": "0", "hierarchy_level": "...", "keep": true, "reason": "..."}}
  ]
}}
""".strip()
    user = f"""
Company: {company.get('company_name', '')}
Country: {company.get('country', '')}
Industry: {company.get('industry', '')}
People to classify:
{json.dumps(compact, ensure_ascii=False)}
""".strip()
    try:
        result = ask_json(system, user)
    except Exception:
        return {}
    values = result.get("people", []) if isinstance(result, dict) else []
    if not isinstance(values, list):
        return {}
    output: dict[str, dict[str, Any]] = {}
    allowed = set(_ACCEPTED_LEVELS)
    for item in values:
        if not isinstance(item, dict):
            continue
        idx = _text(item.get("id"))
        level = _text(item.get("hierarchy_level"))
        if not idx:
            continue
        keep = item.get("keep") is True
        if keep and level not in allowed:
            # A "kept" person without a valid label is unusable; leave it
            # unclassified so the caller retries it.
            continue
        output[idx] = {
            "hierarchy_level": level if keep else _BELOW_CUTOFF_LABEL,
            "hierarchy_rank": _level_rank(level) if keep else 999,
            "keep": keep,
            "reason": _text(item.get("reason")),
        }
    return output


def _classify_hierarchy_batch(company: dict[str, Any], rows: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    """Classify found people dynamically with AI; Product Manager is the cutoff.

    Large candidate pools are classified in chunks, and any person the model
    skipped is retried once so nobody is silently lost.
    """
    if not rows or not settings.openai_api_key:
        return {}
    output: dict[str, dict[str, Any]] = {}
    starts = list(range(0, len(rows), _CLASSIFY_CHUNK_SIZE))

    def work(start: int) -> tuple[int, dict[str, dict[str, Any]]]:
        chunk = rows[start:start + _CLASSIFY_CHUNK_SIZE]
        decisions = _classify_chunk(company, chunk)
        missing = [i for i in range(len(chunk)) if str(i) not in decisions]
        if missing:
            retry = _classify_chunk(company, [chunk[i] for i in missing])
            for local_id, decision in retry.items():
                try:
                    decisions[str(missing[int(local_id)])] = decision
                except (ValueError, IndexError):
                    continue
        return start, decisions

    # Model calls are independent, so run the chunks concurrently.
    with ThreadPoolExecutor(max_workers=min(4, len(starts))) as pool:
        for start, decisions in pool.map(work, starts):
            for local_id, decision in decisions.items():
                try:
                    output[str(start + int(local_id))] = decision
                except ValueError:
                    continue
    return output


def _raw_person_candidate(company: dict[str, Any], raw: dict[str, Any], actor_id: str, source_query: str) -> dict[str, Any] | None:
    provider_company = _extract_company_name(raw)
    provider_website = _extract_company_website(raw)
    matches, match_basis = _company_match(
        _text(company.get("company_name")),
        provider_company,
        provider_website,
        _text(company.get("known_domain")),
    )
    if raw.get("__company_scoped") and not provider_company:
        matches, match_basis = True, "company_scoped_actor_search"
    if not matches:
        return None

    name = _extract_name(raw)
    linkedin = _canonical_profile_url(_extract_linkedin(raw))
    if not linkedin or (not name and not linkedin):
        return None
    # A provider-returned LinkedIn URL is not accepted solely because the provider
    # reported the target company. The public-web identity validator must support the
    # same person + current employer relationship; otherwise the hierarchy UI can show
    # a perfectly valid LinkedIn profile for the wrong person.
    if name and (settings.tavily_api_key or getattr(settings, "serper_api_key", "")):
        try:
            from .identity import linkedin_slug_conflicts_with_name
            from .webpeople import _profile_search, find_person_linkedin
            # A slug that spells a different person is rejected before spending any search calls.
            if linkedin_slug_conflicts_with_name(linkedin, name):
                return None
            verified = find_person_linkedin(
                {"person_name": name, "job_title": _extract_job_title(raw)},
                company,
                search=_profile_search(),
            )
            if not verified or verified.get("url", "").rstrip("/").casefold() != linkedin.rstrip("/").casefold():
                return None
        except Exception:
            return None

    provider_emails = []
    for email in _extract_emails(raw):
        local = _text(email).split("@", 1)[0].casefold()
        local_compact = local.replace(".", "")
        if len(local_compact) <= 1 or local_compact in {
            "info", "contact", "contactus", "sales", "support", "hello", "admin", "office",
            "enquiries", "enquiry", "inquiries", "inquiry", "mail", "media", "press", "hr",
            "careers", "jobs", "marketing", "service", "customerservice", "webmaster",
            "noreply", "no-reply", "reception", "accounts", "mobile", "phone", "telephone", "tel",
            "general", "business",
        }:
            continue
        provider_emails.append(email)

    provider_phone = _extract_phone(raw)

    return {
        "lead_id": "",
        "company": _text(company.get("company_name")),
        "country": _text(company.get("country")),
        "industry": _text(company.get("industry")),
        "matched_opportunity": "",
        "matched_opportunity_id": "",
        "matched_signal_id": "",
        "matched_pattern_id": "",
        "opportunity_validation_status": "",
        "target_department": "",
        "target_role": "Company-wide hierarchy",
        "person_name": name,
        "job_title": _extract_job_title(raw),
        "headline": _text(raw.get("headline")),
        "hierarchy_level": "",
        "hierarchy_rank": 999,
        "hierarchy_cutoff": "Product Manager",
        "business_email": (provider_emails or [""])[0],
        "email_status": "found" if provider_emails else "not_found",
        "email_source": "discovery" if provider_emails else "",
        "phone": provider_phone,
        "phone_source": "discovery" if provider_phone else "",
        "linkedin_url": linkedin,
        "company_website": provider_website or _text(company.get("known_domain")),
        "company_linkedin": _extract_company_linkedin(raw),
        "provider_company_name": provider_company,
        "location": _text(raw.get("location") or raw.get("city")),
        "why_this_person": "",
        "why_this_company": "",
        "lead_match_basis": match_basis,
        "target_query": source_query,
        "lead_confidence": 1.0 if match_basis in {"provider_company_exact", "provider_domain_exact", "company_scoped_actor_search"} else 0.9,
        "source_actor": actor_id,
        "enrichment_provider": "",
        "reversecontact_phone_type": "",
        "reversecontact_status": "",
        "reversecontact_webhook_id": "",
        "reversecontact_error": "",
        "reversecontact_http_status": "",
        "reversecontact_credits_consumed": "",
    }


def _search_tavily_profile_urls(company: dict[str, Any], queries: list[str], limit: int) -> list[tuple[str, str]]:
    """Use Google/Tavily public search as a dynamic recovery path for profile URLs."""
    if limit <= 0 or (not getattr(settings, "tavily_api_key", "") and not getattr(settings, "serper_api_key", "")):
        return []
    company_aliases = company_name_variants(_text(company.get("company_name")))[:5] or [_text(company.get("company_name"))]
    domain = _text(company.get("known_domain"))
    seeds: list[str] = []
    for alias in company_aliases:
        if domain:
            seeds.append(f'site:linkedin.com/in "{alias}" "{domain}"')
        seeds.append(f'site:linkedin.com/in "{alias}"')
        for query in queries:
            seeds.append(f'site:linkedin.com/in "{alias}" "{query}"')
    found: list[tuple[str, str]] = []
    seen: set[str] = set()
    for query in seeds:
        try:
            results = public_search(
                query,
                include_domains=["linkedin.com"],
                max_results=min(10, settings.hierarchy_results_per_query),
            )
        except Exception:
            continue
        for result in results or []:
            if not isinstance(result, dict):
                continue
            url = _canonical_profile_url(_text(result.get("url")))
            if not url:
                continue
            key = _norm(url.rstrip("/"))
            if key in seen:
                continue
            seen.add(key)
            found.append((url, query))
            if len(found) >= limit:
                return found
    return found


def _lookup_linkedin_profiles(
    actor_id: str, profile_urls: list[tuple[str, str]], workers: int = 1
) -> tuple[list[dict[str, Any]], list[str]]:
    """Resolve each discovered LinkedIn URL to a structured person record."""
    def one(item: tuple[str, str]) -> tuple[list[dict[str, Any]], str]:
        url, source_query = item
        payload = {"operationMode": "lookupByUrl", "profileUrls": [url], "maxItemsMode1": 1}
        try:
            result = run_actor_get_dataset_items(actor_id, payload)
        except ApifyAPIError as exc:
            return [], str(exc)
        rows = []
        for row in result:
            if isinstance(row, dict):
                copy = dict(row)
                copy["__source_query"] = source_query
                rows.append(copy)
        return rows, ""

    rows: list[dict[str, Any]] = []
    errors: list[str] = []
    if not profile_urls:
        return rows, errors
    with ThreadPoolExecutor(max_workers=max(1, min(workers, len(profile_urls)))) as pool:
        for got, error in pool.map(one, profile_urls):  # keeps input order
            rows.extend(got)
            if error:
                errors.append(error)
    return rows, errors


def generate_company_hierarchy(
    companies: list[dict[str, Any]],
    provider_preflight: dict[str, Any] | None = None,
) -> tuple[list[dict[str, Any]], list[str], list[dict[str, Any]]]:
    """Dynamically discover and classify company people through Product Manager."""
    people: list[dict[str, Any]] = []
    errors: list[str] = []
    diagnostics: list[dict[str, Any]] = []
    max_people = max(1, int(getattr(settings, "max_hierarchy_people_per_company", 50)))
    per_query = max(1, int(getattr(settings, "hierarchy_results_per_query", 15)))
    max_queries = max(1, int(getattr(settings, "max_hierarchy_queries_per_company", 15)))
    # Gather a larger candidate pool than the output cap, classify it, and only
    # then keep the most senior `max_people`. Provider row order is arbitrary, so
    # capping before classification could let juniors crowd out executives.
    pool_multiplier = max(1, int(getattr(settings, "hierarchy_pool_multiplier", 3)))
    pool_size = max_people * pool_multiplier
    max_runs = max(1, int(getattr(settings, "max_hierarchy_apify_runs_per_company", 8)))
    max_lookups = max(0, int(getattr(settings, "max_hierarchy_profile_lookups", 10)))
    parallel = max(1, int(getattr(settings, "hierarchy_parallel_runs", 3)))

    if not companies:
        return [], [], []
    if not settings.apify_api_token or settings.apify_api_token.startswith("PASTE_YOUR_"):
        return [], ["APIFY_API_TOKEN is missing"], []

    actor_candidates = list(getattr(settings, "apify_lead_actors", ()) or ())
    if not actor_candidates:
        actor_candidates = [
            _text(getattr(settings, "apify_lead_fallback_actor", "")),
            _text(getattr(settings, "apify_lead_actor", "")),
        ]
    actor_candidates = [x for i, x in enumerate(actor_candidates) if x and x not in actor_candidates[:i]]
    if provider_preflight is None and getattr(settings, "apify_provider_preflight", False):
        provider_preflight = preflight_apify(actor_candidates)

    metadata_by_actor = {
        _norm(item.get("actor")): item
        for item in (provider_preflight.get("actors", []) if provider_preflight else [])
    }
    runnable = [a for a in actor_candidates if metadata_by_actor.get(_norm(a), {}).get("status") == "ok"]
    runnable += [a for a in actor_candidates if a not in runnable and metadata_by_actor.get(_norm(a), {}).get("status") not in {"deprecated", "metadata_unavailable"}]
    if not runnable:
        runnable = actor_candidates

    for company in companies:
        diag: dict[str, Any] = {
            "company": _text(company.get("company_name")),
            "country": _text(company.get("country")),
            "status": "started",
            "actor": "",
            "actors_attempted": [],
            "company_urls": [],
            "search_terms_attempted": [],
            "records_received": 0,
            "candidate_contacts": 0,
            "company_matches": 0,
            "kept_people": 0,
            "filtered_below_product_manager": 0,
            "missing_linkedin_url": 0,
            "duplicates_removed": 0,
            "provider_error": "",
            "provider_error_kind": "",
            "actor_results": [],
            "hierarchy_levels_found": [],
            "discovery_mode": "dynamic_ai_plus_company_search",
        }
        if provider_preflight:
            diag["provider_preflight_status"] = provider_preflight.get("status", "")
            diag["provider_plan"] = provider_preflight.get("account", {}).get("plan", "")

        dynamic_queries = _dynamic_hierarchy_search_terms(company, max_queries)
        diag["dynamic_queries"] = dynamic_queries
        collected: dict[str, dict[str, Any]] = {}
        successful_actor = ""
        all_actor_errors: list[str] = []

        for actor_id in runnable:
            diag["actors_attempted"].append(actor_id)
            company_urls, resolution_errors, resolution_inputs = _canonical_company_urls_for_actor(actor_id, company)
            diag["company_urls"] = company_urls or diag.get("company_urls", [])
            actor_errors = list(resolution_errors)
            before = len(collected)
            actor_raw_total = 0
            attempted_labels: list[str] = []
            runs_done = 0
            stale_runs = 0

            # Provider-native company-wide search first. This is critical for
            # recall: the configured code_crafter Actor supports company_domain /
            # company_keywords directly and does not use the searchLead schema.
            native_queries = [""] + dynamic_queries
            if _actor_family(actor_id) == "code_crafter_leads_finder":
                # Keep the broad query first, then use AI-generated title variants
                # only to augment the initial company-wide result set.
                pass
            elif _actor_family(actor_id) == "afanasenko_profile_search" and not company_urls:
                # No provider-native company URL means this Actor cannot execute
                # searchLead reliably; its Tavily profile recovery happens below.
                native_queries = []

            for term in native_queries:
                remaining = pool_size - len(collected)
                if remaining <= 0:
                    break
                count = min(per_query if term else max(per_query, 25), remaining, 100)
                provider_inputs = _hierarchy_provider_inputs(actor_id, company, term, count, company_urls)
                for payload, label in provider_inputs:
                    if runs_done >= max_runs:
                        break
                    attempted_labels.append(label)
                    diag["search_terms_attempted"].append(label)
                    runs_done += 1
                    started = time.monotonic()
                    size_before = len(collected)
                    try:
                        rows = run_actor_get_dataset_items(actor_id, payload)
                    except ApifyAPIError as exc:
                        actor_errors.append(str(exc))
                        _log(f"[{diag['company']}] Apify run {runs_done}/{max_runs} failed after {time.monotonic() - started:.0f}s")
                        stale_runs += 1
                        continue
                    actor_raw_total += len(rows)
                    diag["records_received"] += len(rows)
                    for row in rows:
                        if not isinstance(row, dict):
                            continue
                        row = dict(row)
                        row["__company_scoped"] = True
                        row["__source_query"] = label
                        if not _is_provider_contact(row):
                            continue
                        diag["candidate_contacts"] += 1
                        person = _raw_person_candidate(company, row, actor_id, label)
                        if not person:
                            diag["missing_linkedin_url"] += 1
                            continue
                        key = _norm(person.get("linkedin_url") or "")
                        if not key:
                            diag["missing_linkedin_url"] += 1
                            continue
                        if key in collected:
                            diag["duplicates_removed"] += 1
                            continue
                        collected[key] = person
                        if len(collected) >= pool_size:
                            break
                    new_people = len(collected) - size_before
                    stale_runs = 0 if new_people else stale_runs + 1
                    _log(f"[{diag['company']}] Apify run {runs_done}/{max_runs}: {len(rows)} rows, "
                         f"+{new_people} new people ({len(collected)} total) in {time.monotonic() - started:.0f}s")
                    if len(collected) >= pool_size:
                        break
                if len(collected) >= pool_size or runs_done >= max_runs:
                    break
                if stale_runs >= 2:
                    _log(f"[{diag['company']}] two searches in a row found nobody new; stopping early")
                    break

            # Public-search recovery/augmentation is useful for the native
            # LinkedIn scraper and also protects against sparse provider output.
            if len(collected) < pool_size and settings.tavily_api_key:
                tavily_profiles = _search_tavily_profile_urls(
                    company, dynamic_queries, min(pool_size - len(collected), max_lookups)
                )
                if tavily_profiles:
                    _log(f"[{diag['company']}] looking up {len(tavily_profiles)} profile(s) found via web search")
                # Only the afanasenko Actor documents lookupByUrl in this project.
                lookup_actor = actor_id if _actor_family(actor_id) == "afanasenko_profile_search" else _text(getattr(settings, "apify_lead_fallback_actor", ""))
                if lookup_actor and tavily_profiles:
                    lookup_rows, lookup_errors = _lookup_linkedin_profiles(lookup_actor, tavily_profiles, workers=parallel)
                    actor_errors.extend(lookup_errors)
                    actor_raw_total += len(lookup_rows)
                    diag["records_received"] += len(lookup_rows)
                    for _, query in tavily_profiles:
                        if query not in diag["search_terms_attempted"]:
                            diag["search_terms_attempted"].append(query)
                    for row in lookup_rows:
                        person = _raw_person_candidate(
                            company, row, lookup_actor,
                            _text(row.get("__source_query")) or "tavily LinkedIn profile recovery",
                        )
                        if not person:
                            continue
                        key = _norm(person.get("linkedin_url") or "")
                        if not key:
                            continue
                        if key in collected:
                            diag["duplicates_removed"] += 1
                            continue
                        diag["candidate_contacts"] += 1
                        collected[key] = person
                        if len(collected) >= pool_size:
                            break

            diag["actor_results"].append({
                "actor": actor_id,
                "records_received": actor_raw_total,
                "contact_records": max(0, len(collected) - before),
                "errors": actor_errors[:5],
                "error_kinds": list(dict.fromkeys(_provider_error_kind(x) for x in actor_errors if _provider_error_kind(x))),
                "inputs_attempted": len(resolution_inputs) + len(attempted_labels),
                "company_urls": company_urls,
            })
            all_actor_errors.extend(actor_errors)

            if collected:
                successful_actor = actor_id
                # A provider with actual person rows is authoritative for this
                # company; fallback providers are only needed when no person was found.
                break

        # Classify only after discovery so hierarchy is dynamic and no title taxonomy
        # is hardcoded into the search layer.
        raw_people = list(collected.values())
        classification = _classify_hierarchy_batch(company, raw_people)
        kept: list[dict[str, Any]] = []
        for index, person in enumerate(raw_people):
            decision = classification.get(str(index), {})
            if not decision or not decision.get("keep"):
                diag["filtered_below_product_manager"] += 1
                continue
            person["hierarchy_level"] = decision.get("hierarchy_level", "")
            person["hierarchy_rank"] = _level_rank(person["hierarchy_level"])
            person["hierarchy_classification_reason"] = decision.get("reason", "")
            kept.append(person)
        if not classification and raw_people:
            message = f"{diag['company']}: hierarchy classification returned nothing for {len(raw_people)} candidates (check OPENAI_API_KEY / model)."
            diag["provider_error"] = "Dynamic hierarchy classification returned no classifications."
            diag["provider_error_kind"] = "llm_classification_empty"
            errors.append(message)

        # Most senior first; the cap is applied here, after classification.
        kept.sort(key=lambda p: (int(p.get("hierarchy_rank", 999)), _norm(p.get("job_title")), _norm(p.get("person_name"))))
        diag["candidates_before_cap"] = len(kept)
        if len(kept) > max_people:
            diag["dropped_by_cap"] = len(kept) - max_people
            kept = kept[:max_people]
        _remove_duplicate_company_phones(kept)
        for position, person in enumerate(kept, 1):
            person["company_people_position"] = position  # 1 = most senior within this company
            people.append(person)

        diag["actor"] = successful_actor or (runnable[0] if runnable else "")
        diag["kept_people"] = len(kept)
        diag["company_matches"] = len(raw_people)
        diag["hierarchy_levels_found"] = list(dict.fromkeys(p.get("hierarchy_level", "") for p in kept if p.get("hierarchy_level")))
        if kept:
            diag["status"] = "success" if not all_actor_errors else "success_with_provider_warning"
        elif all_actor_errors:
            diag["status"] = "provider_error_or_no_match"
            diag["provider_error"] = (diag.get("provider_error") or all_actor_errors[-1])[:1000]
            diag["provider_error_kind"] = _provider_error_kind(diag["provider_error"])
        else:
            diag["status"] = "no_match"
        diagnostics.append(diag)

    for index, person in enumerate(people, 1):
        person["lead_id"] = f"L{index:04d}"
    return people, errors, diagnostics



def _remove_duplicate_company_phones(people: list[dict[str, Any]]) -> int:
    """Treat a phone repeated across multiple people in one company as a shared line."""
    from collections import Counter

    counts: Counter[str] = Counter()
    for person in people:
        phone = _text(person.get("phone"))
        if phone:
            key = re.sub(r"\D", "", phone)[-8:]
            if key:
                counts[key] += 1
    removed = 0
    for person in people:
        phone = _text(person.get("phone"))
        key = re.sub(r"\D", "", phone)[-8:] if phone else ""
        if phone and key and counts[key] > 1:
            person["phone"] = ""
            person["phone_source"] = ""
            person["phone_status"] = "rejected_shared_company_number"
            removed += 1
    return removed



# ---------------------------------------------------------------------------
# Standalone "give me a company, get its people" support + hierarchy views
# ---------------------------------------------------------------------------

def build_company_record(
    company_name: str,
    country: str = "",
    industry: str = "",
    domain: str = "",
    company_linkedin: str = "",
) -> dict[str, Any]:
    """Build the minimal company dict the hierarchy engine needs from user input.

    Only the name is required. A domain or LinkedIn company URL improves match
    accuracy but is never guessed here.
    """
    name = _text(company_name)
    host = _text(domain)
    if host:
        parsed = urlparse(host if "://" in host else f"https://{host}")
        host = parsed.netloc.casefold().removeprefix("www.")
    return {
        "company_name": name,
        "country": _text(country),
        "industry": _text(industry),
        "known_domain": host or None,
        "known_linkedin": _text(company_linkedin) or None,
    }


def build_hierarchy_tree(people: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Group people per company, then per hierarchy level, most senior first."""
    companies: dict[str, dict[str, Any]] = {}
    for person in people:
        name = _text(person.get("company"))
        entry = companies.setdefault(name, {"company": name, "country": _text(person.get("country")), "levels": {}})
        level = _text(person.get("hierarchy_level")) or "Unclassified"
        bucket = entry["levels"].setdefault(level, {
            "hierarchy_level": level,
            "hierarchy_rank": int(person.get("hierarchy_rank") or 999),
            "people": [],
        })
        bucket["people"].append({
            "person_name": _text(person.get("person_name")),
            "job_title": _text(person.get("job_title")),
            "linkedin_url": _text(person.get("linkedin_url")),
            "email": _text(person.get("business_email")),
            "email_source": _text(person.get("email_source")),
            "phone": _text(person.get("phone")),
            "phone_source": _text(person.get("phone_source")),
            "location": _text(person.get("location")),
        })
    tree = []
    for entry in companies.values():
        levels = sorted(entry["levels"].values(), key=lambda b: b["hierarchy_rank"])
        tree.append({
            "company": entry["company"],
            "country": entry["country"],
            "people_count": sum(len(b["people"]) for b in levels),
            "levels": levels,
        })
    return tree


def format_hierarchy_markdown(people: list[dict[str, Any]]) -> str:
    """CEO-down view: each person with LinkedIn, email and phone when publicly found."""
    lines: list[str] = []
    for company in build_hierarchy_tree(people):
        header = company["company"] + (f" ({company['country']})" if company["country"] else "")
        lines.append(f"# {header} - {company['people_count']} people")
        for bucket in company["levels"]:
            lines.append("")
            lines.append(f"## {bucket['hierarchy_level']}")
            for p in bucket["people"]:
                title = f" - {p['job_title']}" if p["job_title"] else ""
                lines.append(f"- {p['person_name'] or '(name unavailable)'}{title}")
                lines.append(f"    LinkedIn: {p['linkedin_url']}")
                lines.append(f"    Email   : {p['email'] or 'not publicly found'}")
                lines.append(f"    Phone   : {p['phone'] or 'not publicly found'}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def save_hierarchy_views(people: list[dict[str, Any]], output_dir) -> None:
    """Write company_hierarchy.json and company_hierarchy.md (CEO-down grouping)."""
    from pathlib import Path
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out / "company_hierarchy.json").write_text(
        json.dumps(build_hierarchy_tree(people), indent=2, ensure_ascii=False), encoding="utf-8"
    )
    (out / "company_hierarchy.md").write_text(format_hierarchy_markdown(people), encoding="utf-8")
