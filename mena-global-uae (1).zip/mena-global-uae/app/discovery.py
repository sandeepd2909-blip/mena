"""Company discovery entry point.

For the new prospecting application, UAE company discovery is exclusively backed
by the official MoIAT Industrial Production License Directory. No AI-generated
company list is produced here.
"""
from __future__ import annotations

from .moiat_directory import TARGET_SEGMENTS, companies_for_segment


def discover_companies(country: str, industry: str, target: int) -> list[dict]:
    if str(country or "").strip().casefold() not in {"united arab emirates", "uae"}:
        raise ValueError("Official source-of-truth discovery is currently available only for United Arab Emirates")
    segment = str(industry or "").strip()
    if segment not in TARGET_SEGMENTS:
        # Deterministic label aliases for compatibility with older CLI callers.
        aliases = {
            "manufacturing": TARGET_SEGMENTS[0],
            "food & beverage": TARGET_SEGMENTS[1],
            "logistics & supply chain": TARGET_SEGMENTS[3],
            "industrial equipment": TARGET_SEGMENTS[4],
        }
        segment = aliases.get(segment.casefold(), "")
    if not segment:
        raise ValueError(f"Unknown UAE target segment: {industry}")
    return [c.as_dict() for c in companies_for_segment(segment)[: max(1, int(target))]]
