import os
from dataclasses import dataclass
from pathlib import Path
from dotenv import load_dotenv

# Always load the project-level .env, even when launched from another working directory.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
load_dotenv(dotenv_path=PROJECT_ROOT / ".env", override=False)


@dataclass(frozen=True)
class Settings:
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-5-mini")
    tavily_api_key: str = os.getenv("TAVILY_API_KEY", "")
    search_provider: str = os.getenv("SEARCH_PROVIDER", "tavily").strip().lower()
    hunter_api_key: str = os.getenv("HUNTER_API_KEY", "")
    tomba_api_key: str = os.getenv("TOMBA_API_KEY", "")
    tomba_secret_key: str = os.getenv("TOMBA_SECRET_KEY", "")
    tomba_timeout: int = int(os.getenv("TOMBA_TIMEOUT", "45"))
    tomba_enabled: bool = os.getenv("TOMBA_ENABLED", "true").strip().lower() in {"1", "true", "yes", "y"}
    hunter_timeout: int = int(os.getenv("HUNTER_TIMEOUT", "30"))
    hunter_max_lookups_per_company: int = int(os.getenv("HUNTER_MAX_LOOKUPS_PER_COMPANY", "30"))
    hunter_phone_match_limit: int = int(os.getenv("HUNTER_PHONE_MATCH_LIMIT", "10"))
    prospeo_api_key: str = os.getenv("PROSPEO_API_KEY", "")
    prospeo_enabled: bool = os.getenv("PROSPEO_ENABLED", "true").strip().lower() in {"1", "true", "yes", "y"}
    prospeo_base_url: str = os.getenv("PROSPEO_BASE_URL", "https://api.prospeo.io")
    prospeo_timeout: int = int(os.getenv("PROSPEO_TIMEOUT", "30"))
    prospeo_enrich_mobile: bool = os.getenv("PROSPEO_ENRICH_MOBILE", "false").strip().lower() in {"1", "true", "yes", "y"}
    fullenrich_api_key: str = os.getenv("FULLENRICH_API_KEY", "")
    fullenrich_enabled: bool = os.getenv("FULLENRICH_ENABLED", "true").strip().lower() in {"1", "true", "yes", "y"}
    fullenrich_base_url: str = os.getenv("FULLENRICH_BASE_URL", "https://app.fullenrich.com/api/v2")
    fullenrich_timeout: int = int(os.getenv("FULLENRICH_TIMEOUT", "30"))
    fullenrich_poll_timeout: int = int(os.getenv("FULLENRICH_POLL_TIMEOUT", "180"))
    fullenrich_poll_interval: int = int(os.getenv("FULLENRICH_POLL_INTERVAL", "5"))
    fullenrich_enrich_phones: bool = os.getenv("FULLENRICH_ENRICH_PHONES", "true").strip().lower() in {"1", "true", "yes", "y"}
    serper_api_key: str = os.getenv("SERPER_API_KEY", "")
    request_timeout: int = int(os.getenv("REQUEST_TIMEOUT", "30"))
    max_search_results: int = int(os.getenv("MAX_SEARCH_RESULTS", "5"))
    max_lead_targets_per_company: int = int(os.getenv("MAX_LEAD_TARGETS_PER_COMPANY", "3"))
    max_leads_per_company: int = int(os.getenv("MAX_LEADS_PER_COMPANY", "10"))
    max_companies: int = int(os.getenv("MAX_COMPANIES", "10"))
    max_people_per_company: int = int(os.getenv("MAX_PEOPLE_PER_COMPANY", "75"))
    dynamic_search_queries_per_company: int = int(os.getenv("DYNAMIC_SEARCH_QUERIES_PER_COMPANY", "14"))
    company_resolver_enabled: bool = os.getenv("COMPANY_RESOLVER_ENABLED", "true").strip().lower() in {"1", "true", "yes", "on"}
    company_resolver_include_parent: bool = os.getenv("COMPANY_RESOLVER_INCLUDE_PARENT", "false").strip().lower() in {"1", "true", "yes", "on"}
    company_resolver_min_confidence: float = float(os.getenv("COMPANY_RESOLVER_MIN_CONFIDENCE", "0.5"))
    linkedin_require_uae_evidence: bool = os.getenv("LINKEDIN_REQUIRE_UAE_EVIDENCE", "false").strip().lower() in {"1", "true", "yes", "on"}
    profile_recovery_search_queries_per_person: int = int(os.getenv("PROFILE_RECOVERY_SEARCH_QUERIES_PER_PERSON", "18"))
    company_size_lookup_workers: int = int(os.getenv("COMPANY_SIZE_LOOKUP_WORKERS", "6"))
    company_size_max_lookups_per_batch: int = int(os.getenv("COMPANY_SIZE_MAX_LOOKUPS_PER_BATCH", "50"))
    max_hierarchy_people_per_company: int = int(os.getenv("MAX_HIERARCHY_PEOPLE_PER_COMPANY", "50"))
    hierarchy_results_per_query: int = int(os.getenv("HIERARCHY_RESULTS_PER_QUERY", "15"))
    max_hierarchy_queries_per_company: int = int(os.getenv("MAX_HIERARCHY_QUERIES_PER_COMPANY", "15"))
    # Candidates gathered per company = MAX_HIERARCHY_PEOPLE_PER_COMPANY x this multiplier.
    # The cap is applied AFTER seniority classification so juniors cannot crowd out executives.
    hierarchy_pool_multiplier: int = int(os.getenv("HIERARCHY_POOL_MULTIPLIER", "2"))
    # Speed controls: every Apify run is a slow cloud job, so bound how many one company may use.
    max_hierarchy_apify_runs_per_company: int = int(os.getenv("MAX_HIERARCHY_APIFY_RUNS_PER_COMPANY", "8"))
    max_hierarchy_profile_lookups: int = int(os.getenv("MAX_HIERARCHY_PROFILE_LOOKUPS", "10"))
    # Person-level public contact search: most senior N people per company, run K at a time.
    max_person_contact_lookups_per_company: int = int(os.getenv("MAX_PERSON_CONTACT_LOOKUPS_PER_COMPANY", "30"))
    person_contact_workers: int = int(os.getenv("PERSON_CONTACT_WORKERS", "4"))
    # V7.8.59: hard time limits so a company can never sit on "Searching" for 30+ minutes.
    linkedin_recovery_workers: int = int(os.getenv("LINKEDIN_RECOVERY_WORKERS", "8"))
    linkedin_recovery_budget_seconds: int = int(os.getenv("LINKEDIN_RECOVERY_BUDGET_SECONDS", "150"))
    company_people_timeout_seconds: int = int(os.getenv("COMPANY_PEOPLE_TIMEOUT_SECONDS", "420"))
    hierarchy_parallel_runs: int = int(os.getenv("HIERARCHY_PARALLEL_RUNS", "3"))
    apify_api_token: str = os.getenv("APIFY_API_TOKEN", "")
    apify_contact_enabled: bool = os.getenv("APIFY_CONTACT_ENABLED", "true").strip().lower() in {"1", "true", "yes", "y"}
    apify_contact_actor: str = os.getenv("APIFY_CONTACT_ACTOR", "b2bsearch/bulk-people-enrichment")
    apify_contact_fallback_actor: str = os.getenv("APIFY_CONTACT_FALLBACK_ACTOR", "datablow/linkedin-profile-enrichment")
    apify_contact_actors: tuple[str, ...] = tuple(
        item.strip() for item in os.getenv(
            "APIFY_CONTACT_ACTORS",
            "b2bsearch/bulk-people-enrichment,datablow/linkedin-profile-enrichment,b2bsearch/linkedin-email-finder",
        ).split(",") if item.strip()
    )
    apify_lead_actor: str = os.getenv("APIFY_LEAD_ACTOR", "code_crafter/leads-finder")
    apify_lead_fallback_actor: str = os.getenv("APIFY_LEAD_FALLBACK_ACTOR", "afanasenko/linkedin-profile-api-scraper")
    apify_lead_actors: tuple[str, ...] = tuple(
        item.strip() for item in os.getenv("APIFY_LEAD_ACTORS", "").split(",") if item.strip()
    )
    apify_provider_preflight: bool = os.getenv("APIFY_PROVIDER_PREFLIGHT", "true").strip().lower() in {"1", "true", "yes", "y"}
    apify_timeout_seconds: int = int(os.getenv("APIFY_TIMEOUT_SECONDS", "300"))
    reversecontact_api_key: str = os.getenv("REVERSECONTACT_API_KEY", "")
    reversecontact_base_url: str = os.getenv("REVERSECONTACT_BASE_URL", "https://api.reversecontact.com")
    reversecontact_max_lookups_per_run: int = int(os.getenv("REVERSECONTACT_MAX_LOOKUPS_PER_RUN", "3"))
    reversecontact_phone_cost_credits: int = int(os.getenv("REVERSECONTACT_PHONE_COST_CREDITS", "20"))
    reversecontact_poll_timeout_seconds: int = int(os.getenv("REVERSECONTACT_POLL_TIMEOUT_SECONDS", "120"))
    reversecontact_poll_interval_seconds: int = int(os.getenv("REVERSECONTACT_POLL_INTERVAL_SECONDS", "2"))
    reversecontact_skip_if_insufficient_credits: bool = os.getenv("REVERSECONTACT_SKIP_IF_INSUFFICIENT_CREDITS", "true").strip().lower() in {"1", "true", "yes", "y"}
    max_sources_per_query_type: int = int(os.getenv("MAX_SOURCES_PER_QUERY_TYPE", "3"))
    discovery_pool_multiplier: int = int(os.getenv("DISCOVERY_POOL_MULTIPLIER", "3"))
    search_depth: str = os.getenv("TAVILY_SEARCH_DEPTH", "advanced")
    # UAE MoIAT official Industrial Production License Directory
    moiat_xml_url: str = os.getenv("MOIAT_XML_URL", "https://il.moiat.gov.ae/en/OpenData/ExporttoXML")
    moiat_xlsx_url: str = os.getenv("MOIAT_XLSX_URL", "https://il.moiat.gov.ae/en/OpenData/ExporttoExcel")
    moiat_directory_url: str = os.getenv("MOIAT_DIRECTORY_URL", "https://il.moiat.gov.ae/en/OpenData/IPLDirectory")
    moiat_timeout: int = int(os.getenv("MOIAT_TIMEOUT", "90"))
    # Search pages are interactive calls, not bulk exports: keep their timeout and
    # retry budget independent so one slow page cannot stall discovery for minutes.
    moiat_search_timeout: int = int(os.getenv("MOIAT_SEARCH_TIMEOUT", "45"))
    moiat_search_attempts: int = int(os.getenv("MOIAT_SEARCH_ATTEMPTS", "3"))
    moiat_cache_ttl_seconds: int = int(os.getenv("MOIAT_CACHE_TTL_SECONDS", "21600"))
    moiat_cache_dir: str = os.getenv("MOIAT_CACHE_DIR", "data/moiat")
    moiat_min_records: int = int(os.getenv("MOIAT_MIN_RECORDS", "1000"))
    moiat_download_attempts: int = int(os.getenv("MOIAT_DOWNLOAD_ATTEMPTS", "6"))
    moiat_page_count_ratio: float = float(os.getenv("MOIAT_PAGE_COUNT_RATIO", "0.90"))
    moiat_browser_fallback: bool = os.getenv("MOIAT_BROWSER_FALLBACK", "true").strip().lower() in {"1", "true", "yes", "y"}
    moiat_browser_binary: str = os.getenv("MOIAT_BROWSER_BINARY", "")
    # V7.9.9: MoIAT blocks most foreign datacenter IPs (Vercel). Optional UAE egress proxy,
    # fast reachability probe, and a hard time budget for the live path before web fallback.
    moiat_proxy_url: str = os.getenv("MOIAT_PROXY_URL", "").strip()
    moiat_probe_connect_timeout: int = int(os.getenv("MOIAT_PROBE_CONNECT_TIMEOUT", "6"))
    moiat_probe_read_timeout: int = int(os.getenv("MOIAT_PROBE_READ_TIMEOUT", "12"))
    moiat_live_budget_seconds: int = int(os.getenv("MOIAT_LIVE_BUDGET_SECONDS", "60"))
    # Optional local credit estimate. FullEnrich does not expose a documented public balance endpoint.
    fullenrich_remaining_credits: float | None = (
        float(os.getenv("FULLENRICH_REMAINING_CREDITS"))
        if os.getenv("FULLENRICH_REMAINING_CREDITS", "").strip() else None
    )
    fullenrich_mobile_cost: int = int(os.getenv("FULLENRICH_MOBILE_COST", "10"))
    fullenrich_max_people_per_run: int = int(os.getenv("FULLENRICH_MAX_PEOPLE_PER_RUN", "5"))


settings = Settings()
