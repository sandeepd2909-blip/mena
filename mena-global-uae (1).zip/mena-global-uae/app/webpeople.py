"""People discovery from public web sources only (no Apify).

Pipeline:
  1. Public search uses Google via Serper when configured, otherwise Tavily, across the company's own site, the open web,
     and public LinkedIn search results (linkedin.com/in/... pages as a search engine shows them).
  2. OpenAI reads ONLY those source texts and lists people: name, title, LinkedIn URL, email, phone.
  3. Code re-verifies every value against the source text. The AI is never trusted on its own:
       - the name must appear in the cited source
       - a LinkedIn URL must literally appear in a source (as its URL or in its text)
       - an email/phone must appear in the text right next to the person's name
       - role mailboxes (info@, sales@ ...) and the company switchboard are never given to a person
  4. People are classified by seniority (CEO down to Product Manager) with the existing classifier.
  5. Anything still missing gets one more public-web lookup per person.
Nothing is guessed or pattern-generated. Missing values stay empty.
"""
from __future__ import annotations

import csv
import json
import re
import sys
from pathlib import Path
from typing import Any, Callable

from .config import settings
from .search import public_search, serper_search, tavily_search, _SEARCH_DIAGNOSTICS
from .geo import geo_verdict, is_uae_country
from .identity import (
    company_mentioned,
    company_match_score,
    company_name_variants,
    linkedin_owner_name,
    linkedin_slug_conflicts_with_name,
    linkedin_profile_owner_matches,
    normalize_identity,
    person_name_tokens,
    person_names_match,
)
from .webcontacts import (
    _GENERIC_LOCALS,
    _MAX_TEXT,
    _ascii_digits,
    _host,
    _name_pattern,
    _norm,
    _page_is_about_company,
    _phone_key,
    _windows,
    extract_emails,
    extract_phones,
    enrich_people_public_contacts,
    find_company_contacts,
)

_LI_RE = re.compile(r"(?:https?://)?(?:[a-z]{2,3}\.)?linkedin\.com/in/[A-Za-z0-9\-_%.]+", re.I)
_MAX_SOURCE_CHARS = 5000   # per source sent to the model
_MAX_SOURCES = 32          # total sources sent to the model

_AI_STATS = {"calls": 0, "failures": 0, "last_error": ""}


def _log(msg: str) -> None:
    print(msg, file=sys.stderr, flush=True)


def _text(value: Any) -> str:
    return str(value or "").strip()


def _company_evidence(company_name: str, text: str, aliases: list[str] | None = None) -> bool:
    """Require a strong employer-name match in public-source text.

    Unlike company_mentioned(), this avoids accepting a long source merely because
    it contains one generic token such as "food" or "industries". Exact/variant
    matches score highest; a full set of non-generic company tokens is also accepted.
    """
    combined = _text(text)
    if not combined or not _text(company_name):
        return False
    candidates = [_text(company_name)] + [a for a in (aliases or []) if _text(a)]
    return any(company_match_score(candidate, combined) >= 75 for candidate in candidates)


def _company_evidence_geo(company: dict[str, Any], title: str, text: str, aliases: list[str] | None = None) -> bool:
    """Source is about THIS company: name evidence AND (for UAE companies) a UAE location.

    Derived acronyms (NFI...) are dropped unless the source itself shows a UAE location, and a
    source located abroad without any UAE mention is rejected.
    """
    name = _text(company.get("company_name"))
    country = _text(company.get("country"))
    combined = f"{title}\n{text}"
    geo = geo_verdict(country, title, text)
    # Ordinary web pages often carry no location; only reject when they are clearly abroad.
    if not geo.person_ok(False):
        return False
    alias_list = [a for a in (aliases or []) if geo.acronym_ok() or not _is_acronym_alias(a)]
    return _company_evidence(name, combined, alias_list)


def canonical_linkedin(url: str) -> str:
    """https://www.linkedin.com/in/<slug>/ or '' when not an individual profile URL."""
    m = _LI_RE.search(_text(url))
    if not m:
        return ""
    slug = m.group(0).split("/in/", 1)[1].strip("/").split("?")[0]
    return f"https://www.linkedin.com/in/{slug}/" if slug else ""


_LINKEDIN_NEGATIVE_EMPLOYER = re.compile(
    r"\b(?:former|formerly|ex[- ]|previously|previous employer|left|until)\b", re.I
)


def _linkedin_name_present(source: dict[str, Any], person_name: str) -> bool:
    """The result must be the requested person's OWN profile (not merely mention the name)."""
    return linkedin_profile_owner_matches(
        _text(source.get("url")), _text(source.get("title")), person_name
    )


def _alias_pattern(alias: str) -> re.Pattern[str] | None:
    """Whole-word, whitespace/punctuation tolerant matcher for one company alias.

    Short ALL-CAPS aliases (acronyms such as IBFI) are matched case-sensitively so that
    ordinary words cannot be mistaken for an employer.
    """
    alias = re.sub(r"\s+", " ", _text(alias)).strip()
    if len(re.sub(r"[^A-Za-z0-9\u0600-\u06ff]", "", alias)) < 2:
        return None
    body = r"[\s\-_.,&/]*".join(re.escape(p) for p in re.findall(r"[A-Za-z0-9\u0600-\u06ff]+", alias))
    flags = 0 if (alias.isupper() and len(alias) <= 7) else re.I
    return re.compile(r"(?<![A-Za-z0-9])" + body + r"(?![A-Za-z0-9])", flags)


def _is_acronym_alias(alias: str) -> bool:
    a = _text(alias)
    return a.isalpha() and a.isupper() and 3 <= len(a) <= 7


def _alias_spans(company_name: str, text: str, allow_acronym: bool = True) -> list[tuple[int, int]]:
    spans: list[tuple[int, int]] = []
    for alias in _company_query_variants(company_name):
        if not allow_acronym and _is_acronym_alias(alias):
            continue
        pat = _alias_pattern(alias)
        if not pat:
            continue
        for m in pat.finditer(text):
            spans.append((m.start(), m.end()))
    spans.sort()
    merged: list[tuple[int, int]] = []
    for s, e in spans:  # drop overlapping hits produced by several aliases of one mention
        if merged and s < merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], e))
        else:
            merged.append((s, e))
    return merged


_PRESENT = r"(?:present|current|now|today|till date|to date|حتى الآن|الحالي)"
_DATE_RANGE = re.compile(
    r"(?:[A-Za-z]{3,9}\.?\s+)?(?:19|20)\d{2}\s*(?:[-–—]|to)\s*(" + _PRESENT + r"|(?:[A-Za-z]{3,9}\.?\s+)?(?:19|20)\d{2})",
    re.I,
)
_PRESENT_RE = re.compile(r"^" + _PRESENT + r"$", re.I)
_FORMER_BEFORE = re.compile(r"\b(?:former|formerly|ex|previously|previous|past|prior|left|worked)\b[^.\n]{0,40}$", re.I)
_FORMER_AFTER = re.compile(r"^[^.\n]{0,25}\b(?:until|till)\b\s+(?:19|20)\d{2}", re.I)
_CURRENT_LEAD = re.compile(r"(?:\bat|\bwith|\bfor|@|[·•|:]|\s[-–—])\s*$", re.I)
_HEAD_CHARS = 450


def _span_employment_state(text: str, start: int, end: int) -> str:
    """'current' | 'former' | 'unknown' for one company mention inside profile text."""
    before = text[max(0, start - 70):start]
    if _FORMER_BEFORE.search(before):
        return "former"
    after = text[end:end + 110]
    if _FORMER_AFTER.search(after):
        return "former"
    # Only the date range that belongs to THIS entry: it must start right after the mention.
    m = _DATE_RANGE.search(after)
    if m and m.start() <= 70:
        return "current" if _PRESENT_RE.match(m.group(1).strip()) else "former"
    return "unknown"


def _title_parts(title: str) -> tuple[str, list[str]]:
    clean = re.sub(r"\s*[|\-–—·]\s*LinkedIn.*$", "", _text(title), flags=re.I).strip()
    parts = [p.strip() for p in re.split(r"\s+[-–—|·•]\s+", clean) if p.strip()]
    return (parts[0] if parts else ""), parts[1:]


def _linkedin_current_employer_score(
    company_name: str,
    person_name: str,
    job_title: str,
    source: dict[str, Any],
    country: str = "",
) -> int:
    """Score evidence that a LinkedIn result is THIS person's profile AND shows them CURRENTLY
    at THIS company. Returns 0 whenever either leg is missing.

    Hard requirements (V7.8.56):
      * the profile owner (result title, else URL slug) must be the requested person;
      * the company must be tied to the CURRENT position: the profile headline, a role dated
        to 'Present', or an undated mention in the headline area. A company that only appears in
        a finished/former role, a recommendation or 'people also viewed' never qualifies;
      * a headline naming a different employer needs explicit 'Present' proof for the target.
    """
    url = _text(source.get("url"))
    if not canonical_linkedin(url):
        return 0
    title = _text(source.get("title"))
    text = _text(source.get("text"))
    if not linkedin_profile_owner_matches(url, title, person_name):
        return 0

    # V7.8.57 UAE geography layer: for a UAE company the profile itself must place the person in
    # the UAE. A foreign location (e.g. New Jersey) rejects it; derived acronyms such as "NFI"
    # are only trusted when UAE evidence is present in the same result.
    geo = geo_verdict(country, title, text, url, source.get("raw_url", ""))
    if not geo.person_ok(bool(getattr(settings, "linkedin_require_uae_evidence", False))):
        return 0
    allow_acronym = geo.acronym_ok()

    owner_in_title = bool(person_names_match(person_name, linkedin_owner_name(title))) and len(
        [t for t in person_name_tokens(linkedin_owner_name(title)) if len(t) >= 2]
    ) >= 2
    score = 5 if owner_in_title else 3

    _owner, tail = _title_parts(title)
    tail_text = " - ".join(tail)

    # 1) Headline (title tail) names the target company -> strongest evidence.
    headline_target = False
    for s, e in _alias_spans(company_name, tail_text, allow_acronym):
        if _span_employment_state(tail_text, s, e) != "former":
            headline_target = True
            break

    # 2) Does the headline name a DIFFERENT employer?
    headline_other = False
    if tail and not headline_target:
        if len(tail) >= 2 or re.search(r"(?:\bat|\b@)\s+[A-Z0-9]", tail_text):
            headline_other = True

    current_text = False
    present_text = False
    if headline_target:
        score += 8
    else:
        combined = f"{title}\n{text}"
        head = combined[:_HEAD_CHARS]
        for s, e in _alias_spans(company_name, combined, allow_acronym):
            state = _span_employment_state(combined, s, e)
            if state == "former":
                continue
            if state == "current":
                present_text = True
                break
            # Undated mention: only trusted in the headline area, introduced by a current-role cue.
            if s < _HEAD_CHARS and _CURRENT_LEAD.search(combined[max(0, s - 14):s]) and not headline_other:
                current_text = True
        if present_text:
            score += 7
        elif current_text:
            score += 6
        else:
            return 0

    # Role consistency is a tie-breaker, but only inside headline/snippet area (not distant text).
    role_tokens = [t for t in normalize_identity(job_title).split() if len(t) > 2]
    if role_tokens:
        area = normalize_identity(f"{title}\n{text[:_HEAD_CHARS]}")
        if all(t in area for t in role_tokens[:5]):
            score += 2
    return score


def _select_verified_linkedin_candidate(
    row: dict[str, Any], company: dict[str, Any], candidates: list[dict[str, Any]]
) -> dict[str, Any] | None:
    """Select only a clearly supported LinkedIn candidate; never guess on a tie."""
    scored: list[tuple[int, dict[str, Any]]] = []
    for cand in candidates:
        score = _linkedin_current_employer_score(
            _text(company.get("company_name")),
            _text(row.get("person_name")),
            _text(row.get("job_title")),
            cand,
            _text(company.get("country")),
        )
        cand = dict(cand)
        cand["evidence_score"] = score
        if score >= 10:
            scored.append((score, cand))
    if not scored:
        return None
    scored.sort(key=lambda x: x[0], reverse=True)
    best_score, best = scored[0]
    if len(scored) == 1:
        return best
    second_score = scored[1][0]
    if best_score >= 14 and best_score - second_score >= 3:
        return best
    # Same-name/same-role collisions are common on LinkedIn. Do not guess.
    return None


def _search_plan(company: dict[str, Any]) -> list[tuple[str, list[str] | None]]:
    """Build a recall-first company search plan with LinkedIn people queries early.

    LinkedIn individual-profile searches are deliberately in the first pass. The previous
    planner placed ``site:linkedin.com/in`` queries after enough generic queries that the
    configured 14-query cap could prevent them from ever running.
    """
    names = _company_query_variants(company)
    primary = names[0] if names else _text(company.get("company_name"))
    aliases = " OR ".join(f'"{n}"' for n in names[:6]) or f'"{primary}"'
    country = _text(company.get("country"))
    domain = _host(_text(company.get("known_domain")))
    where = f" {country}" if country else ""

    queries: list[tuple[str, list[str] | None]] = []
    if domain:
        queries += [
            (f'{aliases} leadership team management board', [domain]),
            (f'{aliases} about us our team executives', [domain]),
            (f'{aliases} contact us', [domain]),
        ]

    # Broad individual-profile searches are the highest-value recovery path for companies
    # whose own site does not publish a leadership page. These are discovery queries, not
    # hardcoded title filters; the returned people are still verified and AI-classified.
    # Balance direct LinkedIn profile discovery with ordinary web results. The old
    # 13-profile-query block consumed the whole default 14-query budget (especially
    # for companies without a known domain), so leadership/team pages were barely searched.
    profile_terms = [
        'CEO president founder',
        'chief executive managing director',
        'general manager director',
        'VP head executive',
        'procurement purchasing supply chain',
        'operations warehouse logistics',
    ]
    for term in profile_terms:
        queries.append((f'site:linkedin.com/in ({aliases}) {term}', ['linkedin.com']))

    # General-web corroboration comes after the direct LinkedIn profile pass.
    general_terms = [
        'leadership team executives CEO CFO CTO',
        'management team directors',
        'commercial sales business development',
        'procurement purchasing sourcing',
        'finance CFO',
        'operations supply chain',
        'board chairman managing director',
        'senior leadership executive team',
        'regional country general manager',
    ]
    for term in general_terms:
        queries.append((f'{aliases}{where} {term}'.strip(), None))

    max_queries = max(1, int(getattr(settings, 'dynamic_search_queries_per_company', 14)))
    out: list[tuple[str, list[str] | None]] = []
    seen = set()
    for q, doms in queries:
        key = (q, tuple(doms or []))
        if key in seen:
            continue
        seen.add(key)
        out.append((q, doms))
        if len(out) >= max_queries:
            break
    return out


def _people_fallback_queries(company: dict[str, Any]) -> list[tuple[str, list[str] | None]]:
    """High-recall second pass used when source extraction yields no people."""
    names = _company_query_variants(company)
    primary = names[0] if names else _text(company.get("company_name"))
    joined = " OR ".join(f'"{n}"' for n in names[:6]) or f'"{primary}"'
    country = _text(company.get("country"))
    queries = [
        (f'{joined} CEO president founder', None),
        (f'{joined} "Chief Executive Officer" OR "Managing Director"', None),
        (f'{joined} director "head of" vice president', None),
        (f'{joined} executives leadership management {country}'.strip(), None),
        (f'site:linkedin.com/in {primary} CEO director', ["linkedin.com"]),
        (f'site:linkedin.com/in {primary} "head of" manager', ["linkedin.com"]),
    ]
    return queries[: max(1, int(getattr(settings, 'dynamic_search_queries_per_company', 14)))]


def collect_sources(
    company: dict[str, Any],
    search: Callable[..., list[dict[str, Any]]] | None = None,
) -> tuple[list[dict[str, Any]], list[str]]:
    """Run the searches and keep pages that are about the company. No AI here."""
    search = search or public_search
    name = _text(company.get("company_name"))
    domain = _host(_text(company.get("known_domain")))
    sources: list[dict[str, Any]] = []
    errors: list[str] = []
    seen: set[str] = set()
    for query, domains in _search_plan(company):
        try:
            hits = search(query, include_domains=domains, max_results=8) or []
        except Exception as exc:
            errors.append(f"{query}: {exc}")
            continue
        for hit in hits:
            if not isinstance(hit, dict):
                continue
            url = _text(hit.get("url"))
            if not url or url in seen:
                continue
            text = _ascii_digits(" ".join(_text(hit.get(k)) for k in ("title", "content", "raw_content")))[:_MAX_TEXT]
            host = _host(url)
            is_li = bool(canonical_linkedin(url))
            on_domain = bool(domain and (host == domain or host.endswith("." + domain)))
            # A LinkedIn result is only a people source when it positively identifies a current
            # employer match. Do not admit a profile merely because the company appears somewhere
            # in a noisy search snippet.
            li_company_match = False
            if is_li:
                aliases = _company_query_variants(company)
                combined_source = {"url": url, "title": _text(hit.get("title")), "text": text}
                result_owner = _clean_candidate_name(linkedin_owner_name(_text(hit.get("title"))))
                li_company_match = bool(result_owner) and (
                    _linkedin_current_employer_score(name, result_owner, "", combined_source, _text(company.get("country"))) >= 10
                )
            relevant = on_domain or li_company_match or _company_evidence_geo(company, _text(hit.get("title")), text, _company_query_variants(company)[1:])
            if not relevant:
                continue
            seen.add(url)
            sources.append({
                "url": url,
                "title": _text(hit.get("title")),
                "text": text,
                "official": on_domain,
                "linkedin": li_company_match,
            })
    # Official-site pages first, then LinkedIn profile hits, then everything else.
    # The AI payload separately guarantees that a slice of LinkedIn profile results is included.
    sources.sort(key=lambda s: (not s["official"], not s["linkedin"]))
    return sources, errors


def _collect_people_fallback_sources(company: dict[str, Any], search: Callable[..., list[dict[str, Any]]] | None = None, limit: int = 18) -> tuple[list[dict[str, Any]], list[str]]:
    """Search public results again when the first source pass is too sparse."""
    search = search or public_search
    sources: list[dict[str, Any]] = []
    errors: list[str] = []
    seen: set[str] = set()
    aliases = _company_query_variants(company)
    company_name = _text(company.get("company_name"))
    for query, domains in _people_fallback_queries(company):
        try:
            hits = search(query, include_domains=domains, max_results=10) or []
        except Exception as exc:
            errors.append(f'{query}: {exc}')
            continue
        for hit in hits:
            if not isinstance(hit, dict):
                continue
            url = _text(hit.get('url'))
            if not url or url in seen:
                continue
            text = _ascii_digits(' '.join(_text(hit.get(k)) for k in ('title', 'content', 'raw_content')))[:_MAX_TEXT]
            is_li = bool(canonical_linkedin(url))
            li_company_match = False
            if is_li:
                combined_source = {"url": url, "title": _text(hit.get('title')), "text": text}
                candidate_name = _clean_candidate_name(linkedin_owner_name(_text(hit.get('title'))))
                if candidate_name:
                    li_company_match = _linkedin_current_employer_score(company_name, candidate_name, "", combined_source, _text(company.get("country"))) >= 10
            relevant = li_company_match or _company_evidence_geo(company, _text(hit.get('title')), text, aliases[1:])
            if not relevant:
                continue
            seen.add(url)
            sources.append({
                'url': url, 'title': _text(hit.get('title')), 'text': text,
                'official': False, 'linkedin': li_company_match, 'fallback_search': True,
            })
            if len(sources) >= limit:
                return sources, errors
    return sources, errors



def _clean_candidate_name(value: str) -> str:
    value = re.sub(r"\s*\|\s*LinkedIn.*$", "", value, flags=re.I).strip(" -–—|")
    value = re.sub(r"\s+", " ", value)
    return value


def _title_from_linkedin_source(source: dict[str, Any], person_name: str, company: dict[str, Any]) -> str:
    """Extract an explicit title from a LinkedIn search result without a fixed title whitelist."""
    title = _text(source.get("title"))
    owner, title_parts = _title_parts(title)
    if title_parts and _norm(owner) == _norm(person_name):
        candidate = title_parts[0]
        # Do not mistake the company name for the person's title.
        if company_match_score(_text(company.get("company_name")), candidate) < 75:
            return candidate
    # Some search providers put the person's current role in the snippet rather than
    # the title. Use a line immediately following the person's name when present.
    text_lines = [re.sub(r"\s+", " ", line).strip(" -–—") for line in _text(source.get("text")).splitlines()]
    normalized_name = _norm(person_name)
    aliases = [_text(company.get("company_name"))]
    for i, line in enumerate(text_lines):
        # Search-result text can prepend the page title to the same line as the name,
        # so accept either an exact line or a line that contains the normalized name.
        if normalized_name not in _norm(line):
            continue
        for candidate in text_lines[i + 1 : i + 6]:
            if not candidate:
                continue
            if _company_evidence(_text(company.get("company_name")), candidate, aliases[1:]):
                continue
            return candidate
    return ""


def _linkedin_profile_fallback_people(company: dict[str, Any], sources: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Recover high-confidence people directly from LinkedIn profile search results.

    This is intentionally narrow: only individual linkedin.com/in/ URLs are used, the
    source must explicitly identify the target company, and the result must expose an
    explicit title/headline segment. There is no fixed title whitelist.
    """
    out: list[dict[str, Any]] = []
    for idx, source in enumerate(sources):
        url = canonical_linkedin(_text(source.get("url")))
        if not url or "/in/" not in url.casefold():
            continue
        text = _text(source.get("text"))
        title = _text(source.get("title"))
        combined = f"{title}\n{text}"
        # Require current-employer evidence on the same individual LinkedIn result.
        candidate_probe = {"url": url, "title": title, "text": text}
        # Parse result owners using the same delimiter-tolerant helper used by identity
        # verification. Search engines commonly render LinkedIn titles with en/em dashes
        # or pipe delimiters; an ASCII-only split loses otherwise verifiable people.
        name = _clean_candidate_name(linkedin_owner_name(title))
        if _linkedin_current_employer_score(_text(company.get("company_name")), name, "", candidate_probe, _text(company.get("country"))) < 10:
            continue
        if not _name_pattern(name):
            continue
        job_title = _title_from_linkedin_source(source, name, company)
        if not job_title:
            continue
        out.append({
            "person_name": name,
            "job_title": job_title,
            "linkedin_url": url,
            "email": "",
            "phone": "",
            "source_ids": [idx],
        })
    return out


def _ai_extract(company: dict[str, Any], sources: list[dict[str, Any]]) -> list[dict[str, Any]]:
    from .ai import ask_json

    linkedins = [s for s in sources if s.get("linkedin")]
    officials = [s for s in sources if s.get("official") and not s.get("linkedin")]
    others = [s for s in sources if not s.get("official") and not s.get("linkedin")]
    # Preserve official evidence while reserving a meaningful slice for public LinkedIn profiles.
    selected: list[dict[str, Any]] = []
    selected.extend(officials[: max(8, _MAX_SOURCES // 2)])
    selected.extend(linkedins[: max(8, _MAX_SOURCES // 2)])
    selected.extend(others)
    seen_ids: set[str] = set()
    selected_unique: list[dict[str, Any]] = []
    for source in selected:
        marker = _text(source.get("url"))
        if not marker or marker in seen_ids:
            continue
        seen_ids.add(marker)
        selected_unique.append(source)
        if len(selected_unique) >= _MAX_SOURCES:
            break
    payload = [
        {"id": i, "url": s["url"], "text": s["text"][:_MAX_SOURCE_CHARS]}
        for i, s in enumerate(selected_unique)
    ]
    system = """
You extract people from public web pages about ONE company.

Use ONLY the supplied source texts. Never use outside knowledge. Never guess or construct values.
List every named individual who CURRENTLY holds a role at the target company (executives, directors, managers, founders, board members).
Skip people described as former/ex/previously, and people who work at other companies.

For each person return:
- person_name: as written in the source
- job_title: as written in the source
- linkedin_url: a linkedin.com/in/... URL ONLY if it literally appears in the source url or text for that person, else ""
- email: ONLY if it literally appears in the source text next to that person, else ""
- phone: ONLY if it literally appears in the source text next to that person, else ""
- source_ids: ids of the sources that mention the person

Never copy a company-wide email (info@, sales@ ...) or a switchboard number onto a person.
A LinkedIn search-result page title usually looks like "Name - Title - Company | LinkedIn": the person's name and title can be read from it.
Return JSON only: {"people": [{"person_name": "", "job_title": "", "linkedin_url": "", "email": "", "phone": "", "source_ids": [0]}]}
""".strip()
    user = (
        f"Target company: {company.get('company_name', '')}\n"
        f"Country: {company.get('country', '')}\n"
        f"Website: {company.get('known_domain') or ''}\n"
        f"Sources:\n{json.dumps(payload, ensure_ascii=False)}"
    )
    _AI_STATS["calls"] += 1
    try:
        result = ask_json(system, user)
    except Exception as exc:
        _AI_STATS["failures"] += 1
        _AI_STATS["last_error"] = str(exc)[:500]
        _log(f"AI extraction failed: {exc}")
        return []
    people = result.get("people", []) if isinstance(result, dict) else []
    return [p for p in people if isinstance(p, dict)]


def verify_person(
    raw: dict[str, Any],
    sources: list[dict[str, Any]],
    company: dict[str, Any],
    switchboard_keys: frozenset[str] = frozenset(),
) -> dict[str, Any] | None:
    """Re-check an AI-extracted person against the source text. Returns a clean row or None."""
    name = _text(raw.get("person_name"))
    parsed = _name_pattern(name)
    if not parsed:
        return None  # one-word names cannot be attributed safely
    pattern, tokens = parsed
    ids = [i for i in (raw.get("source_ids") or []) if isinstance(i, int) and 0 <= i < len(sources)]
    cited = [sources[i] for i in ids] or []
    # The name must really be in a cited source (fall back to all sources if the ids were wrong).
    cited = [s for s in cited if pattern.search(s["text"])] or [s for s in sources if pattern.search(s["text"])]
    company_name = _text(company.get("company_name"))
    aliases = _company_query_variants(company)
    # A LinkedIn URL alone is NOT proof that the person works for the target company.
    # Require the target company (or a conservative alias) to be present in the actual
    # LinkedIn result/profile text. This prevents unrelated profiles such as
    # "Angel de Los Reyes - Nestlé | LinkedIn" from being attached to another company
    # merely because the profile came back from a company-name search.
    def _source_belongs_to_company(source: dict[str, Any]) -> bool:
        combined = " ".join((_text(source.get("title")), _text(source.get("text"))))
        if source.get("official"):
            return True
        return _company_evidence_geo(company, _text(source.get("title")), _text(source.get("text")), aliases[1:])

    cited = [s for s in cited if _source_belongs_to_company(s)]
    if not cited:
        return None

    row: dict[str, Any] = {
        "person_name": name,
        "job_title": _text(raw.get("job_title")),
        "linkedin_url": "",
        "business_email": "",
        "email_source": "",
        "email_status": "",
        "phone": "",
        "phone_source": "",
        "company": _text(company.get("company_name")),
        "country": _text(company.get("country")),
        "company_website": _text(company.get("known_domain")),
        "location": "",
        "source_actor": "web_sources_ai",
        "profile_source": cited[0]["url"],
    }
    domain = _host(_text(company.get("known_domain")))

    # LinkedIn: the URL must be tied to the same person AND current employer in the source.
    claimed = canonical_linkedin(_text(raw.get("linkedin_url")))
    linkedin_candidates: list[dict[str, Any]] = []
    for s in sources:
        url_li = canonical_linkedin(s["url"])
        if url_li and pattern.search(s["text"]) and (not claimed or url_li == claimed):
            linkedin_candidates.append({"url": url_li, "title": s.get("title", ""), "text": s.get("text", "")})
    if claimed:
        for s in cited:
            for m in _LI_RE.finditer(s["text"]):
                if canonical_linkedin(m.group(0)).casefold() != claimed.casefold():
                    continue
                # Team/leadership pages list many people and many profile links. Accept the link
                # only when this person's name is the closest name to it (within 160 chars) and the
                # URL slug does not spell a different person.
                lo, hi = max(0, m.start() - 160), min(len(s["text"]), m.end() + 160)
                local = s["text"][lo:hi]
                if not pattern.search(local) or linkedin_slug_conflicts_with_name(claimed, name):
                    continue
                linkedin_candidates.append({"url": claimed, "title": "", "text": local})
                break
    if linkedin_candidates:
        best = _select_verified_linkedin_candidate(row, company, linkedin_candidates)
        if best:
            row["linkedin_url"] = canonical_linkedin(best["url"])
            # Prefer the strongest LinkedIn source as the profile source.
            row["profile_source"] = best["url"]

    # Email / phone: must sit in a window around the person's name on a cited page.
    best_email: tuple[int, str, str] | None = None
    phone: tuple[str, str] | None = None
    for s in cited:
        for window in _windows(s["text"], pattern):
            for email in extract_emails(window):
                local = email.split("@")[0].casefold()
                if len(local.replace(".", "")) <= 1 or local in _GENERIC_LOCALS or local.replace(".", "") in _GENERIC_LOCALS:
                    continue
                score = 1
                if any(len(t) >= 3 and t.casefold() in email.split("@")[0] for t in (tokens[0], tokens[-1])):
                    score += 2
                if domain and email.endswith("@" + domain):
                    score += 1
                if not best_email or score > best_email[0]:
                    best_email = (score, email, s["url"])
            for p in extract_phones(window):
                if _phone_key(p) not in switchboard_keys and not phone:
                    phone = (p, s["url"])
    if best_email:
        row.update(business_email=best_email[1], email_source="web:" + best_email[2], email_status="found_public_web")
    if phone:
        row.update(phone=phone[0], phone_source="web:" + phone[1])
    return row


def _dedupe(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    for r in rows:
        key = r["linkedin_url"].casefold() or _norm(r["person_name"])
        old = out.get(key)
        if not old:
            out[key] = r
            continue
        for field in ("job_title", "linkedin_url", "business_email", "email_source", "email_status", "phone", "phone_source"):
            if not old.get(field) and r.get(field):
                old[field] = r[field]
    # Same person found once with a LinkedIn URL and once without: merge by name.
    by_name: dict[str, dict[str, Any]] = {}
    for r in out.values():
        n = _norm(r["person_name"])
        old = by_name.get(n)
        if not old:
            by_name[n] = r
            continue
        for field in ("job_title", "linkedin_url", "business_email", "email_source", "email_status", "phone", "phone_source"):
            if not old.get(field) and r.get(field):
                old[field] = r[field]
    return list(by_name.values())


def linkedin_id(url: str) -> str:
    """The profile slug, e.g. https://www.linkedin.com/in/omar-khan-123/ -> omar-khan-123."""
    canon = canonical_linkedin(url)
    return canon.rstrip("/").rsplit("/", 1)[-1] if canon else ""


def _pick_profile(person: dict[str, Any], company: dict[str, Any], cands: list[dict[str, Any]], lenient: bool = False) -> dict[str, Any] | None:
    """AI chooses which public LinkedIn result is the same person at the same company."""
    from .ai import ask_json

    system = (
        "You match a person to public LinkedIn search results. Use ONLY the supplied snippets. "
        + ("Pick the candidate MOST LIKELY to be this person, weighing name spelling, job title, employer, industry and country. "
           "Choose only if you are reasonably confident; if several people could fit equally, or none fits, answer -1. "
           if lenient else
           "Pick the candidate that is clearly the SAME person at the SAME company (name, employer and role must be consistent). "
           "If none clearly matches, answer -1. ")
        + "Never guess. Return JSON only: {\"index\": -1}"
    )
    user = json.dumps({
        "person": person.get("person_name"), "title": person.get("job_title"), "company": company.get("company_name"),
        "candidates": [{"index": i, "url": c["url"], "snippet": c["text"][:600]} for i, c in enumerate(cands)],
    }, ensure_ascii=False)
    try:
        idx = int(ask_json(system, user).get("index", -1))
    except Exception:
        return None
    return cands[idx] if 0 <= idx < len(cands) else None


_GENERIC_CO_WORDS = {"group", "company", "holding", "holdings", "limited", "international", "corporation", "trading", "services", "the", "for", "and"}


_SEARCH_STATS = {"serper_ok": 0, "serper_errors": 0, "last_error": ""}


def _profile_search():
    """Use the configured provider first, with the other provider as fallback."""
    provider = str(getattr(settings, "search_provider", "tavily") or "tavily").strip().lower()
    if provider == "serper" and getattr(settings, "serper_api_key", ""):
        def serper_then_tavily(query, include_domains=None, max_results=None):
            try:
                hits = serper_search(query, include_domains, max_results)
                if hits:
                    _SEARCH_STATS["serper_ok"] += 1
                    return hits
            except Exception as exc:
                _SEARCH_STATS["serper_errors"] += 1
                _SEARCH_STATS["last_error"] = str(exc)[:200]
            if getattr(settings, "tavily_api_key", ""):
                return tavily_search(query, include_domains, max_results)
            return []
        return serper_then_tavily
    if getattr(settings, "tavily_api_key", ""):
        def tavily_then_serper(query, include_domains=None, max_results=None):
            try:
                hits = tavily_search(query, include_domains, max_results)
                if hits:
                    return hits
            except Exception as exc:
                _SEARCH_STATS["last_error"] = str(exc)[:200]
            if getattr(settings, "serper_api_key", ""):
                try:
                    hits = serper_search(query, include_domains, max_results)
                    _SEARCH_STATS["serper_ok"] += 1
                    return hits
                except Exception as inner:
                    _SEARCH_STATS["serper_errors"] += 1
                    _SEARCH_STATS["last_error"] = str(inner)[:200]
                    raise
            return []
        return tavily_then_serper
    return serper_search


def _company_loose(company_name: str, text: str) -> bool:
    """Match employer text despite spacing/punctuation variants such as Al Majdouie/Almajdouie."""
    if company_mentioned(company_name, text):
        return True
    hay = _norm(text)
    return any(len(t) >= 4 and t not in _GENERIC_CO_WORDS and t in hay.split() for t in _norm(company_name).split())


def _name_variants(name: str, company: str) -> list[str]:
    """AI proposes alternative Latin spellings of the same name (Mohammed/Muhammad, Sulaiman/Sulayman ...)."""
    from .ai import ask_json

    system = (
        "Give up to 3 alternative Latin-script spellings or transliterations of this person's name as they might appear on LinkedIn "
        "(e.g. Mohammed/Muhammad, Sulaiman/Sulayman, with or without 'Al', with or without a title). "
        "Do not invent a different person. Return JSON only: {\"variants\": [\"...\"]}"
    )
    try:
        data = ask_json(system, json.dumps({"name": name, "company": company}, ensure_ascii=False))
        return [v.strip() for v in data.get("variants", []) if isinstance(v, str) and v.strip()][:3]
    except Exception:
        return []


_REGISTERED_ALIASES: dict[str, list[str]] = {}


def register_company_aliases(company_name: str, aliases: list[str]) -> None:
    """Make AI-resolved, source-validated aliases visible to every name check for this company.

    Keyed by the registered company name because the scoring helpers receive only the name string.
    """
    key = normalize_identity(company_name)
    if not key:
        return
    clean = [re.sub(r"\s+", " ", _text(a)) for a in (aliases or []) if _text(a)]
    if clean:
        _REGISTERED_ALIASES[key] = clean[:6]
    else:
        _REGISTERED_ALIASES.pop(key, None)


def _company_query_variants(company_or_name: Any) -> list[str]:
    """Return dynamic company-name aliases from the supplied company or name."""
    extra: list[str] = []
    if isinstance(company_or_name, dict):
        raw = _text(company_or_name.get("company_name"))
        extra.extend(_text(a) for a in (company_or_name.get("aliases") or []) if _text(a))
    else:
        raw = _text(company_or_name)
    if not raw:
        return []
    extra.extend(_REGISTERED_ALIASES.get(normalize_identity(raw), []))
    values: list[str] = []
    seen: set[str] = set()

    def add(value: str) -> None:
        value = re.sub(r"\s+", " ", _text(value)).strip(" ,;/|")
        key = value
        if value and key and key not in seen:
            seen.add(key)
            values.append(value)

    add(raw)
    # Resolver aliases (trading / brand / LinkedIn page name) right after the registered name.
    for alias in extra:
        add(alias)
        add(_strip_legal(alias))
    for group in re.findall(r"\(([^)]*)\)", raw):
        for part in re.split(r"\s*(?:/|\||;|,|\bor\b)\s*", group, flags=re.I):
            add(part)
    for variant in company_name_variants(raw):
        add(variant)
    return values[: (10 if extra else 6)] or [raw]


def _strip_legal(value: str) -> str:
    from .identity import _strip_legal_suffixes
    return _strip_legal_suffixes(value)


def _fallback_profile(row, company, search, pick) -> dict[str, Any] | None:
    """Second pass when the strict match found nothing: try spelling variants and let AI choose
    the most likely profile. Result is flagged 'probable'."""
    name, cname = _text(row.get("person_name")), _text(company.get("company_name"))
    title, country = _text(row.get("job_title")), _text(company.get("country"))
    variants = [name] + _name_variants(name, cname)
    company_aliases = _company_query_variants(cname)
    patterns = [p for p in (_name_pattern(v) for v in variants) if p]
    queries = []
    for v in variants:
        for alias in company_aliases:
            queries += [f'"{v}" "{alias}" linkedin', f'site:linkedin.com/in "{v}" "{alias}"']
        queries.append(f"site:linkedin.com/in {v} {title} {country}")
    cands: list[dict[str, Any]] = []
    seen: set[str] = set()
    for q in queries:
        try:
            hits = search(q, include_domains=None, max_results=10) or []
        except Exception:
            continue
        for h in hits:
            if not isinstance(h, dict):
                continue
            url = canonical_linkedin(_text(h.get("url")))
            if not url or url in seen:
                continue
            text = _ascii_digits(" ".join(_text(h.get(k)) for k in ("title", "content", "raw_content")))[:_MAX_TEXT]
            if any(pat.search(text) for pat, _ in patterns):
                seen.add(url)
                cands.append({"url": url, "title": _text(h.get("title")), "text": text})
        if len(cands) >= 8:
            break
    if not cands:
        return None
    verified = []
    for cand in cands:
        score = _linkedin_current_employer_score(cname, name, row.get("job_title", ""), cand, country)
        if score >= 10:
            c = dict(cand)
            c["evidence_score"] = score
            verified.append(c)
    selected = _select_verified_linkedin_candidate(row, company, verified)
    return selected


def find_person_linkedin(
    row: dict[str, Any],
    company: dict[str, Any],
    search: Callable[..., list[dict[str, Any]]] | None = None,
    pick: Callable[..., dict[str, Any] | None] | None = None,
) -> dict[str, Any] | None:
    """Search public LinkedIn results for this person. Returns {url, text} or None."""
    search = search or _profile_search()
    parsed = _name_pattern(_text(row.get("person_name")))
    cname = _text(company.get("company_name"))
    if not parsed or not cname:
        return None
    pattern, tokens = parsed
    name = _text(row.get("person_name"))
    cands: list[dict[str, Any]] = []
    seen: set[str] = set()
    short = f"{tokens[0]} {tokens[-1]}"  # drops titles/middle names that profiles often omit
    country = _text(company.get("country"))
    title = _text(row.get("job_title"))
    aliases = _company_query_variants(cname)
    plan: list[tuple[str, list[str] | None]] = []
    for alias in aliases:
        plan.extend([
            (f'"{name}" "{alias}" linkedin', ["linkedin.com"]),
            (f'site:linkedin.com/in "{short}" "{alias}"', ["linkedin.com"]),
            (f'"{short}" "{title}" "{alias}"', ["linkedin.com"]),
        ])
    plan.append((f'site:linkedin.com/in "{short}" {country} {cname}', ["linkedin.com"]))
    plan = plan[: max(1, int(getattr(settings, 'profile_recovery_search_queries_per_person', 18)))]
    for q, doms in plan:
        if cands:
            break  # stop at the first query that yields a verified match
        try:
            hits = search(q, include_domains=doms, max_results=10) or []
        except Exception:
            continue
        for h in hits:
            if not isinstance(h, dict):
                continue
            url = canonical_linkedin(_text(h.get("url")))
            if not url or url in seen:
                continue
            text = _ascii_digits(" ".join(_text(h.get(k)) for k in ("title", "content", "raw_content")))[:_MAX_TEXT]
            if pattern.search(text):
                candidate = {"url": url, "title": _text(h.get("title")), "text": text}
                score = _linkedin_current_employer_score(cname, name, title, candidate, country)
                if score >= 10:
                    seen.add(url)
                    candidate["evidence_score"] = score
                    cands.append(candidate)
    if not cands:
        return _fallback_profile(row, company, search, pick)
    selected = _select_verified_linkedin_candidate(row, company, cands)
    if selected:
        return selected
    # Do not let an LLM guess between same-name or same-role profiles.
    return None


def enrich_linkedin_and_contacts(
    rows: list[dict[str, Any]],
    company: dict[str, Any],
    switchboard: frozenset[str] = frozenset(),
    search: Callable[..., list[dict[str, Any]]] | None = None,
    pick: Callable[..., dict[str, Any] | None] | None = None,
) -> dict[str, int]:
    """For each person lacking a LinkedIn URL, find the matching public profile; then take any
    email/phone printed on that profile text. Only literal values are used."""
    from concurrent.futures import ThreadPoolExecutor

    cap = int(getattr(settings, "max_person_contact_lookups_per_company", 30))
    workers = int(getattr(settings, "person_contact_workers", 4))
    stats = {"profiles_found": 0, "emails_found": 0, "phones_found": 0}
    todo = [r for r in rows[:cap] if not r.get("linkedin_url")]

    def work(row: dict[str, Any]):
        return row, find_person_linkedin(row, company, search=search, pick=pick)

    with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
        for row, cand in pool.map(work, todo):
            if not cand:
                continue
            row["linkedin_url"] = cand["url"]
            row["profile_source"] = cand["url"]
            row["linkedin_confidence"] = "verified"
            stats["profiles_found"] += 1
            # Only copy a value when it is attributable to this person on the profile/search snippet.
            parsed = _name_pattern(_text(row.get("person_name")))
            windows = _windows(cand["text"], parsed[0]) if parsed else []
            for window in windows:
                if not row.get("business_email"):
                    for email in extract_emails(window):
                        local = email.split("@")[0].casefold()
                        if len(local.replace(".", "")) <= 1 or local in _GENERIC_LOCALS or local.replace(".", "") in _GENERIC_LOCALS:
                            continue
                        row.update(business_email=email, email_source="web:" + cand["url"], email_status="found_public_web")
                        stats["emails_found"] += 1
                        break
                if row.get("business_email"):
                    break
            for window in windows:
                if row.get("phone"):
                    break
                for ph in extract_phones(window):
                    if _phone_key(ph) not in switchboard:
                        row.update(phone=ph, phone_source="web:" + cand["url"])
                        stats["phones_found"] += 1
                        break
    return stats


def _remove_shared_company_phone_numbers(rows: list[dict[str, Any]]) -> int:
    """Remove a phone number when it is attributed to multiple people in one company.

    A number repeated across two or more people is treated as a company line rather
    than a direct personal number, unless a future explicit override is added.
    """
    from collections import Counter

    counts = Counter()
    for row in rows:
        phone = _text(row.get("phone"))
        if phone:
            counts[_phone_key(phone)] += 1
    removed = 0
    for row in rows:
        phone = _text(row.get("phone"))
        if phone and counts.get(_phone_key(phone), 0) > 1:
            row["phone"] = ""
            row["phone_source"] = ""
            row["phone_status"] = "rejected_shared_company_number"
            removed += 1
    return removed


def find_web_people(
    company: dict[str, Any],
    search: Callable[..., list[dict[str, Any]]] | None = None,
    extract: Callable[[dict[str, Any], list[dict[str, Any]]], list[dict[str, Any]]] | None = None,
    classify: Callable[[dict[str, Any], list[dict[str, Any]]], dict[str, dict[str, Any]]] | None = None,
    enrich: bool = True,
) -> dict[str, Any]:
    """Return {people, company_contacts, sources_used, errors}. Public web only."""
    if not _text(company.get("company_name")):
        return {"people": [], "company_contacts": {}, "sources_used": 0, "errors": ["company name missing"]}
    _AI_STATS.update({"calls": 0, "failures": 0, "last_error": ""})
    _SEARCH_DIAGNOSTICS.update({"serper_attempts": 0, "serper_failures": 0, "tavily_attempts": 0, "tavily_failures": 0, "last_serper_error": "", "last_tavily_error": ""})
    _log(f"[1/4] Searching public sources for {company['company_name']} ...")
    sources, errors = collect_sources(company, search=search)
    _log(f"      {len(sources)} relevant pages ({sum(s['linkedin'] for s in sources)} LinkedIn profile hits)")

    contacts = find_company_contacts(company, search=search) if search or getattr(settings, "tavily_api_key", "") or getattr(settings, "serper_api_key", "") else {}
    switchboard = frozenset(_phone_key(p["value"]) for p in contacts.get("phones", []))

    _log("[2/4] AI reading sources and listing people ...")
    raw_people = (extract or _ai_extract)(company, sources)
    deterministic_people = _linkedin_profile_fallback_people(company, sources)
    if deterministic_people:
        raw_people = list(raw_people) + deterministic_people
    rows = [r for r in (verify_person(p, sources, company, switchboard) for p in raw_people) if r]
    rows = _dedupe(rows)

    # High-recall recovery: a company can have plenty of search hits but no
    # parseable leadership page. Run a second public-web pass before declaring
    # the company empty. This is still dynamic; no people are hardcoded.
    recovery_sources_added = 0
    if not rows:
        fallback_sources, fallback_errors = _collect_people_fallback_sources(company, search=search)
        if fallback_sources:
            existing_urls = {s["url"] for s in sources}
            for source in fallback_sources:
                if source["url"] not in existing_urls:
                    sources.append(source)
                    existing_urls.add(source["url"])
                    recovery_sources_added += 1
            errors.extend(fallback_errors[:3])
            _log(f"      Recovery search added {len(fallback_sources)} public result(s)")
            raw_people = (extract or _ai_extract)(company, sources)
            deterministic_people = _linkedin_profile_fallback_people(company, sources)
            if deterministic_people:
                raw_people = list(raw_people) + deterministic_people
            rows = [r for r in (verify_person(p, sources, company, switchboard) for p in raw_people) if r]
            rows = _dedupe(rows)

    if _AI_STATS["last_error"]:
        errors.append("AI extraction: " + _AI_STATS["last_error"][:300])
    if _SEARCH_DIAGNOSTICS.get("serper_failures"):
        errors.append("Serper fallback: " + (_SEARCH_DIAGNOSTICS.get("last_serper_error") or "search failed")[:300])
    if _SEARCH_DIAGNOSTICS.get("tavily_failures"):
        tavily_error = (_SEARCH_DIAGNOSTICS.get("last_tavily_error") or "search failed")[:300]
        serper_attempts = int(_SEARCH_DIAGNOSTICS.get("serper_attempts") or 0)
        serper_failures = int(_SEARCH_DIAGNOSTICS.get("serper_failures") or 0)
        if serper_attempts > serper_failures:
            errors.append(
                "Search fallback notice: Tavily is unavailable (" + tavily_error +
                "); Serper fallback was attempted. Any remaining no-match result means the returned pages did not pass company/person verification."
            )
        else:
            errors.append("Tavily search unavailable: " + tavily_error)

    dropped = len(raw_people) - len(rows)
    _log(f"      AI listed {len(raw_people)} | verified against page text: {len(rows)} | rejected/merged: {dropped}")

    _log("[3/4] Classifying seniority (CEO down to Product Manager, no fixed title list) ...")
    from .hierarchy import _BELOW_CUTOFF_LABEL, _classify_hierarchy_batch

    decisions = (classify or _classify_hierarchy_batch)(company, rows) if rows else {}
    if rows and not decisions:
        errors.append("seniority AI classification unavailable; verified people kept as Unclassified")
    kept: list[dict[str, Any]] = []
    for i, row in enumerate(rows):
        d = decisions.get(str(i)) if decisions else None
        if d is None:
            # Never hide a source-verified person solely because OpenAI billing, quota,
            # timeout or response-format errors prevented classification.
            row["hierarchy_level"] = "Unclassified"
            row["hierarchy_rank"] = 998
            row["hierarchy_classification_status"] = "unclassified"
            kept.append(row)
            continue
        if not d.get("keep"):
            continue
        row["hierarchy_level"] = d.get("hierarchy_level") or "Unclassified"
        row["hierarchy_rank"] = int(d.get("hierarchy_rank") or 998)
        row["hierarchy_classification_status"] = "ai"
        kept.append(row)
    kept.sort(key=lambda r: (r["hierarchy_rank"], _norm(r["person_name"])))
    kept = kept[: max(1, int(getattr(settings, "max_people_per_company", 75)))]
    for pos, row in enumerate(kept, 1):
        row["company_people_position"] = pos

    if enrich and kept:
        _log("[4/4] Checking each person's public LinkedIn profile, email and phone ...")
        provider = str(getattr(settings, "search_provider", "tavily") or "tavily").strip().lower()
        engine = "Tavily" if provider == "tavily" else "Google via Serper"
        if provider not in {"tavily", "serper"}:
            engine = "Tavily"
        _log(f"      LinkedIn lookup engine: {engine}")
        st1 = enrich_linkedin_and_contacts(kept, company, switchboard, search=search)
        if getattr(settings, "serper_api_key", ""):
            _log(f"      Serper searches ok: {_SEARCH_STATS['serper_ok']} | failed: {_SEARCH_STATS['serper_errors']}"
                 + (f" | last error: {_SEARCH_STATS['last_error']}" if _SEARCH_STATS["serper_errors"] else ""))
        _log(f"      LinkedIn profiles found +{st1['profiles_found']} | emails +{st1['emails_found']} | phones +{st1['phones_found']}")
        st2 = enrich_people_public_contacts(kept, [contacts] if contacts else [], search=search or public_search)
        _log(f"      web lookup: emails +{st2['emails_found']} | phones +{st2['phones_found']}")
    duplicate_phones_removed = _remove_shared_company_phone_numbers(kept)
    if duplicate_phones_removed:
        _log(f"      removed {duplicate_phones_removed} repeated phone number(s) shared by multiple people")
    for row in kept:
        row["linkedin_id"] = linkedin_id(row.get("linkedin_url", ""))
        row.setdefault("linkedin_confidence", "verified" if row["linkedin_id"] else "")
    return {
        "people": kept,
        "company_contacts": contacts,
        "sources_used": len(sources),
        "errors": list(dict.fromkeys(errors)),
        "diagnostics": {
            "ai_calls": _AI_STATS["calls"],
            "ai_failures": _AI_STATS["failures"],
            "ai_last_error": _AI_STATS["last_error"],
            "serper_attempts": _SEARCH_DIAGNOSTICS.get("serper_attempts", 0),
            "serper_failures": _SEARCH_DIAGNOSTICS.get("serper_failures", 0),
            "serper_last_error": _SEARCH_DIAGNOSTICS.get("last_serper_error", ""),
            "tavily_failures": _SEARCH_DIAGNOSTICS.get("tavily_failures", 0),
            "tavily_last_error": _SEARCH_DIAGNOSTICS.get("last_tavily_error", ""),
            "linkedin_profile_candidates": len(_linkedin_profile_fallback_people(company, sources)),
            "raw_people_candidates": len(raw_people),
            "verified_people_before_classification": len(rows),
            "recovery_sources_added": recovery_sources_added,
        },
    }


def save_web_people(people: list[dict[str, Any]], output_dir) -> None:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    fields = [
        "company", "country", "hierarchy_level", "person_name", "job_title", "linkedin_id", "linkedin_url", "linkedin_confidence",
        "business_email", "email_source", "phone", "phone_source", "profile_source",
    ]
    with (out / "web_people.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(people)
    (out / "web_people.json").write_text(json.dumps(people, indent=2, ensure_ascii=False), encoding="utf-8")
