"""UAE person discovery wrapper.

People are discovered from public sources and verified against the target company.
There is deliberately no hardcoded list of target titles here: the hierarchy classifier
handles CEO -> Product Manager dynamically, so titles such as Production Manager,
Procurement Manager, Quality Manager, Sales Director, Plant Head, etc. are not lost.
"""
from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeout, as_completed
from typing import Any

from .config import settings
from .webpeople import find_person_linkedin, find_web_people


def normalize_title(title: str) -> str:
    return " ".join(str(title or "").split()).strip()


def _clean_person(row: dict[str, Any], company: dict[str, Any]) -> dict[str, Any]:
    out = dict(row)
    out["person_name"] = str(out.get("person_name") or "").strip()
    out["job_title"] = normalize_title(out.get("job_title") or out.get("headline") or "")
    out["company"] = company.get("company_name", "")
    out["country"] = company.get("country") or "United Arab Emirates"
    # Kept for UI/CSV compatibility. This is a dynamic hierarchy label, not a title whitelist.
    out["target_title"] = out.get("hierarchy_level") or ""
    out.setdefault("business_email", "")
    out.setdefault("email_source", "")
    out.setdefault("phone", "")
    out.setdefault("phone_source", "")
    return out


def find_target_people(company: dict[str, Any], *, search=None) -> dict[str, Any]:
    # IMPORTANT: no fixed title regex/filter. webpeople performs source verification and
    # dynamic CEO -> Product Manager classification. If AI classification is unavailable,
    # verified people remain visible as "Unclassified" rather than disappearing.
    result = find_web_people(company, search=search, enrich=False)
    rows = [_clean_person(p, company) for p in result.get("people", [])]

    # Recover exact LinkedIn profile URLs dynamically for relevant people who don't have one yet.
    # We search every returned row up to the configured company cap; no fixed title list is used.
    limit = max(1, int(getattr(settings, "max_people_per_company", 75)))
    todo = [r for r in rows[:limit] if not r.get("linkedin_url")]
    if todo:
        # Parallel + time-boxed. This used to be a sequential loop of up to 75 multi-query
        # searches, which alone could take 30+ minutes. People whose profile is not found within
        # the budget are still shown (without a LinkedIn URL) instead of blocking the company.
        workers = max(1, int(getattr(settings, "linkedin_recovery_workers", 8)))
        budget = max(10, int(getattr(settings, "linkedin_recovery_budget_seconds", 150)))
        deadline = time.monotonic() + budget
        pool = ThreadPoolExecutor(max_workers=workers)
        futures = {pool.submit(find_person_linkedin, row, company, search=search): row for row in todo}
        try:
            for fut in as_completed(futures, timeout=budget):
                row = futures[fut]
                try:
                    cand = fut.result()
                except Exception:
                    cand = None
                if cand and cand.get("url") and not cand.get("probable"):
                    row["linkedin_url"] = cand["url"]
                    row["linkedin_confidence"] = "verified"
                    row["profile_source"] = cand.get("url", "")
        except FuturesTimeout:
            pass
        finally:
            for fut in futures:
                fut.cancel()
            pool.shutdown(wait=False, cancel_futures=True)

    # Dedupe by LinkedIn first, then name/company/title.
    out: dict[str, dict[str, Any]] = {}
    for row in rows:
        li = str(row.get("linkedin_url") or "").strip().rstrip("/").casefold()
        key = "li:" + li if li else "fallback:" + "|".join([
            str(row.get("person_name") or "").casefold(),
            str(company.get("company_name") or "").casefold(),
            str(row.get("job_title") or "").casefold(),
        ])
        out.setdefault(key, row)
    final = list(out.values())
    # AI assigns hierarchy_rank when available. Unclassified people are kept at the end.
    final.sort(key=lambda x: (int(x.get("hierarchy_rank") or 999), str(x.get("person_name") or "").casefold()))
    return {
        "people": final,
        "sources_used": int(result.get("sources_used") or 0),
        "errors": list(result.get("errors") or []),
        "diagnostics": dict(result.get("diagnostics") or {}),
    }
