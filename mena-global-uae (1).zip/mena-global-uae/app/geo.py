"""UAE geography validation for people / LinkedIn identity (V7.8.57).

A company that is registered in the UAE must only be matched to people whose public
profile/page places them in the UAE. This stops same-name / same-acronym companies abroad
(e.g. "Nuitree Food Industries" -> "NFI" -> NFI in New Jersey) from leaking into results.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

_UAE_COUNTRY_NAMES = {"united arab emirates", "uae", "u.a.e", "u.a.e.", "ae", "emirates", "الإمارات"}

_UAE_RE = re.compile(
    r"(?<![A-Za-z])(?:united\s+arab\s+emirates|u\.a\.e\.?|dubai|abu\s*dhabi|sharjah|ajman|"
    r"ras\s+al[\s-]*khaimah|fujairah|fujeirah|umm\s+al[\s-]*quwain|al\s+ain|jebel\s+ali|"
    r"dubai\s+silicon\s+oasis|khalifa\s+industrial|kizad|jafza|hamriyah)(?![A-Za-z])"
    r"|(?<![A-Za-z])UAE(?![A-Za-z])|الإمارات|دبي|أبوظبي|ابوظبي|الشارقة|عجمان|رأس الخيمة|الفجيرة",
    re.I,
)
# Plain-text evidence only; 'UAE' above is intentionally matched with re.I too.

_FOREIGN_WORDS = (
    # countries
    "united states", "united kingdom", "england", "scotland", "canada", "australia", "new zealand",
    "india", "pakistan", "bangladesh", "sri lanka", "nepal", "saudi arabia", "qatar", "kuwait",
    "bahrain", "oman", "egypt", "lebanon", "turkey", "iran", "iraq", "syria", "morocco", "tunisia",
    "algeria", "germany", "france", "italy", "spain", "netherlands", "switzerland", "ireland",
    "belgium", "sweden", "norway", "denmark", "poland", "russia", "singapore", "malaysia",
    "indonesia", "thailand", "vietnam", "china", "japan", "south korea", "philippines", "nigeria",
    "kenya", "ghana", "south africa", "ethiopia", "brazil", "mexico", "argentina",
    # US states / big US cities
    "new jersey", "new york", "california", "texas", "florida", "illinois", "pennsylvania",
    "massachusetts", "ohio", "michigan", "north carolina", "arizona", "colorado", "washington dc",
    "princeton", "newark", "jersey city", "houston", "chicago", "los angeles", "san francisco",
    "boston", "atlanta", "dallas", "seattle", "miami", "philadelphia",
    # other major non-UAE cities
    "london", "manchester", "paris", "berlin", "munich", "mumbai", "new delhi", "delhi",
    "bangalore", "bengaluru", "chennai", "hyderabad", "pune", "kolkata", "karachi", "lahore",
    "islamabad", "dhaka", "colombo", "riyadh", "jeddah", "dammam", "khobar", "doha", "manama",
    "muscat", "kuwait city", "cairo", "amman", "beirut", "istanbul", "kuala lumpur", "sydney",
    "melbourne", "toronto", "vancouver", "manila", "lagos", "nairobi", "johannesburg",
    "cape town", "tehran", "baghdad", "shanghai", "beijing", "hong kong", "tokyo", "seoul",
)
_FOREIGN_RE = re.compile(
    r"(?<![A-Za-z])(?:" + "|".join(re.escape(w).replace(r"\ ", r"\s+") for w in _FOREIGN_WORDS) + r")(?![A-Za-z])",
    re.I,
)
# Case-sensitive abbreviations (never lower-case words): USA, UK, KSA and US state suffixes.
_FOREIGN_ABBR_RE = re.compile(
    r"(?<![A-Za-z])(?:USA|U\.S\.A?\.?|UK|KSA|"
    r",\s*(?:NJ|NY|CA|TX|FL|IL|PA|MA|OH|MI|VA|NC|AZ|CO|WA|GA))(?![A-Za-z])"
)

HEAD_CHARS = 700


def is_uae_country(country: Any) -> bool:
    return re.sub(r"\s+", " ", str(country or "").strip().casefold()) in _UAE_COUNTRY_NAMES


def _location_hint(host_or_url: str) -> bool:
    return bool(re.match(r"^(?:https?://)?ae\.linkedin\.com/", str(host_or_url or ""), re.I))


@dataclass(frozen=True)
class GeoVerdict:
    applies: bool          # the company is UAE-based, so geography is enforced
    uae_head: bool         # UAE location in title / first part of the result
    uae_any: bool          # UAE location anywhere in the result
    foreign_head: bool     # a non-UAE location in title / first part of the result

    def person_ok(self, strict: bool = True) -> bool:
        """May this result be attributed to a UAE company?"""
        if not self.applies:
            return True
        if self.uae_head or (self.uae_any and not self.foreign_head):
            return True
        if self.foreign_head:
            return False
        return not strict  # no location evidence at all

    def acronym_ok(self) -> bool:
        """Derived acronyms (NFI, IBFI...) are ambiguous worldwide: UAE evidence is mandatory."""
        return (not self.applies) or self.uae_head


def geo_verdict(country: Any, title: Any, text: Any, url: Any = "", raw_url: Any = "") -> GeoVerdict:
    if not is_uae_country(country):
        return GeoVerdict(False, False, False, False)
    title_s, text_s = str(title or ""), str(text or "")
    head = (title_s + "\n" + text_s)[:HEAD_CHARS]
    full = title_s + "\n" + text_s
    uae_head = bool(_UAE_RE.search(head)) or _location_hint(raw_url or url)
    uae_any = uae_head or bool(_UAE_RE.search(full))
    foreign_head = bool(_FOREIGN_RE.search(head) or _FOREIGN_ABBR_RE.search(head))
    return GeoVerdict(True, uae_head, uae_any, foreign_head)
