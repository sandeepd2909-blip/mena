import json
from typing import Any

from .config import settings

_client = None


def get_client():
    global _client
    if _client is None:
        if not settings.openai_api_key:
            raise RuntimeError("OPENAI_API_KEY is missing")
        from openai import OpenAI
        _client = OpenAI(api_key=settings.openai_api_key)
    return _client


def ask_json(system_prompt: str, user_prompt: str) -> dict[str, Any]:
    response = get_client().chat.completions.create(
        model=settings.openai_model,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        response_format={"type": "json_object"},
    )
    content = response.choices[0].message.content or "{}"
    return json.loads(content)


def discover_company_list(country: str, industry: str, requested_count: int) -> list[dict[str, Any]]:
    """Disabled: UAE company discovery is source-of-truth driven by MoIAT."""
    raise RuntimeError("AI company discovery is disabled; use the official MoIAT directory")


def generate_lead_target_batch(
    company: dict[str, Any], opportunities: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """Choose human target roles for Phase 7.1 lead discovery from supplied opportunities."""
    if not opportunities:
        return []

    system = """
You are a B2B lead-target planning engine.

Given one company and its already-qualified software opportunity hypotheses, identify the most relevant internal
roles to contact about those hypotheses. This is lead targeting, not a claim that the person owns a problem or will buy.

Rules:
- Work only from the supplied company and opportunity records.
- Prefer decision-makers or strong operational owners who could reasonably evaluate the software concept.
- Use 1-3 target records for the company. Each record maps to exactly one supplied opportunity.
- Use practical job-title search keywords suitable for a LinkedIn people search. Include the company name in the query only through the application; return the role keywords themselves.
- Do not invent a person's name, email, phone, or LinkedIn URL. You are only selecting roles.
- Department and role must be plausible from the target_user / software_concept, but do not invent internal organizational structure.
- why_this_person must explain why this type of role is relevant to the supplied opportunity.
- why_this_company must explain why the supplied company is relevant to the opportunity, using only the supplied opportunity/company context.
- target_confidence is confidence in role relevance, not contact availability or purchase intent.

Return JSON only:
{
  "targets": [
    {
      "opportunity_id": "O001",
      "target_department": "Operations",
      "target_role": "Chief Operating Officer / Head of Operations",
      "role_keywords": ["Chief Operating Officer", "COO", "Head of Operations"],
      "why_this_person": "...",
      "why_this_company": "...",
      "target_confidence": 0.0
    }
  ]
}
""".strip()
    compact = []
    for item in opportunities:
        compact.append({
            "opportunity_id": item.get("opportunity_id"),
            "signal_id": item.get("signal_id"),
            "signal_status": item.get("signal_status"),
            "opportunity": item.get("opportunity"),
            "target_user": item.get("target_user"),
            "problem_addressed": item.get("problem_addressed"),
            "software_concept": item.get("software_concept"),
            "why_software_could_help": item.get("why_software_could_help"),
            "evidence_ids": item.get("evidence_ids", []),
        })
    user = f"""
Company: {company.get('company_name', '')}
Country: {company.get('country', '')}
Industry: {company.get('industry', '')}

Qualified opportunity hypotheses:
{json.dumps(compact, ensure_ascii=False)}
""".strip()
    result = ask_json(system, user)
    targets = result.get("targets", [])
    return targets if isinstance(targets, list) else []
