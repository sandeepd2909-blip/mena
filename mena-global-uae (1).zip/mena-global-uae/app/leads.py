import csv
import json
from pathlib import Path
from typing import Any

from urllib.parse import urlparse, urlunparse

from .ai import generate_lead_target_batch
from .reversecontact_api import ReverseContactAPIError, enrich_phones_by_linkedin, normalize_linkedin_url
from .apify_api import ApifyAPIError, preflight_apify, run_actor_get_dataset_items
from .config import settings
from .identity import company_match_score, company_name_variants
from .search import public_search


def _text(value: Any) -> str:
    return str(value or "").strip()


def _norm(value: Any) -> str:
    return " ".join(_text(value).casefold().split())


# Current code_crafter/leads-finder accepts lowercase country values.  The
# normalization is deliberately data-driven and covers common Middle East /
# MENA aliases without changing the human-readable project data.
_APIFY_LOCATION_ALIASES = {
    "uae": "united arab emirates",
    "u.a.e.": "united arab emirates",
    "u.a.e": "united arab emirates",
    "emirates": "united arab emirates",
    "united arab emirates": "united arab emirates",
    "ksa": "saudi arabia",
    "saudi": "saudi arabia",
    "saudi arabia": "saudi arabia",
    "qatar": "qatar",
    "kuwait": "kuwait",
    "bahrain": "bahrain",
    "oman": "oman",
    "sultanate of oman": "oman",
    "yemen": "yemen",
    "iraq": "iraq",
    "iran": "iran",
    "islamic republic of iran": "iran",
    "iran (islamic republic of)": "iran",
    "jordan": "jordan",
    "lebanon": "lebanon",
    "syria": "syria",
    "syrian arab republic": "syria",
    "israel": "israel",
    "turkey": "turkey",
    "türkiye": "turkey",
    "turkiye": "turkey",
    "egypt": "egypt",
    "morocco": "morocco",
    "algeria": "algeria",
    "tunisia": "tunisia",
    "libya": "libya",
    "sudan": "sudan",
    "mauritania": "mauritania",
}

# Relevant current enum values exposed by the configured Actor.  If the user
# supplies a country that the Actor does not currently support, we omit the
# location filter instead of sending an invalid value and causing HTTP 400.
_APIFY_SUPPORTED_MENA_LOCATIONS = {
    "united arab emirates", "saudi arabia", "qatar", "kuwait", "bahrain",
    "oman", "yemen", "iraq", "iran", "jordan", "lebanon", "syria",
    "israel", "turkey", "egypt", "morocco", "algeria", "tunisia", "libya",
    "sudan", "mauritania", "cyprus",
}


def _apify_location(value: Any) -> str:
    normalized = _norm(value)
    return _APIFY_LOCATION_ALIASES.get(normalized, normalized)


def _apify_supported_location(value: Any) -> str:
    normalized = _apify_location(value)
    if normalized in _APIFY_SUPPORTED_MENA_LOCATIONS:
        return normalized
    return ""


def _as_text_from_nested(value: Any) -> str:
    if isinstance(value, dict):
        for key in ("name", "value", "url", "href", "text", "label", "title"):
            candidate = _text(value.get(key))
            if candidate:
                return candidate
        return ""
    if isinstance(value, (list, tuple)):
        for item in value:
            candidate = _as_text_from_nested(item)
            if candidate:
                return candidate
        return ""
    return _text(value)


def _first_list_value(value: Any) -> str:
    if isinstance(value, list):
        for item in value:
            text = _text(item)
            if text:
                return text
    return _text(value)


def _extract_emails(item: dict[str, Any]) -> list[str]:
    values: list[str] = []
    for key in (
        "emails", "email", "businessEmail", "business_email", "workEmail",
        "work_email", "emailAddress", "email_address", "personal_email", "personalEmail",
    ):
        value = item.get(key)
        if isinstance(value, list):
            values.extend(_text(x) for x in value if _text(x))
        elif isinstance(value, dict):
            nested = _as_text_from_nested(value)
            if nested:
                values.append(nested)
        elif _text(value):
            values.append(_text(value))
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        key = value.casefold()
        if key not in seen:
            result.append(value)
            seen.add(key)
    return result


def _extract_linkedin(item: dict[str, Any]) -> str:
    # Support the configured Actors plus common LinkedIn search/enrichment aliases.
    for key in (
        "linkedinProfile", "linkedin_url", "linkedinUrl", "linkedin", "userLink",
        "person_linkedin", "personLinkedin", "profile_url", "profileUrl",
        "profile_link", "profileLink", "linkedin_profile", "linkedin_profile_url",
        "linkedinProfileUrl", "url",
    ):
        value = _as_text_from_nested(item.get(key))
        if "linkedin.com/in/" in value.casefold():
            return value
    for parent_key in ("person", "profile", "contact", "data", "result", "lead"):
        nested = item.get(parent_key)
        if isinstance(nested, dict):
            value = _extract_linkedin(nested)
            if value:
                return value
    return ""


def _extract_name(item: dict[str, Any]) -> str:
    for key in ("full_name", "fullName", "name", "person_name", "personName", "contact_name", "contactName", "display_name", "displayName"):
        value = _as_text_from_nested(item.get(key))
        if value:
            return value
    for parent_key in ("person", "profile", "contact", "data", "result", "lead"):
        nested = item.get(parent_key)
        if isinstance(nested, dict):
            value = _extract_name(nested)
            if value:
                return value
    first = _as_text_from_nested(item.get("first_name") or item.get("firstName"))
    last = _as_text_from_nested(item.get("last_name") or item.get("lastName"))
    return " ".join(x for x in (first, last) if x)


def _extract_phone(item: dict[str, Any]) -> str:
    # Do not mislabel a company switchboard as a person's phone number.
    for key in (
        "phone", "phoneNumber", "phone_number", "mobile", "mobileNumber",
        "mobile_number", "mobilePhone", "mobile_phone", "personal_phone",
    ):
        value = _as_text_from_nested(item.get(key))
        if value:
            return value
    return ""


def _extract_job_title(item: dict[str, Any]) -> str:
    for key in (
        "jobTitle", "job_title", "headline", "title", "current_title", "currentTitle",
        "current_position", "currentPosition", "functional_title", "description",
    ):
        value = _as_text_from_nested(item.get(key))
        if value:
            return value
    for parent_key in ("person", "profile", "contact", "data", "result", "lead"):
        nested = item.get(parent_key)
        if isinstance(nested, dict):
            value = _extract_job_title(nested)
            if value:
                return value
    return ""


def _extract_company_name(item: dict[str, Any]) -> str:
    for key in (
        "company_name", "companyName", "company", "name_company", "current_company",
        "current_company_name", "currentCompanyName", "organization_name",
        "organizationName", "currentCompany", "employer",
    ):
        value = item.get(key)
        text = _as_text_from_nested(value)
        if text:
            return text
    for parent_key in ("person", "profile", "contact", "data", "result", "lead"):
        nested = item.get(parent_key)
        if isinstance(nested, dict):
            value = _extract_company_name(nested)
            if value:
                return value
    return ""


def _extract_company_website(item: dict[str, Any]) -> str:
    for key in (
        "companyWebsite", "company_website", "website", "company_domain",
        "companyDomain", "domain", "organization_primary_domain", "organization_website_url",
    ):
        value = _as_text_from_nested(item.get(key))
        if value:
            return value
    for parent_key in ("company", "organization", "currentCompany", "data", "result", "lead"):
        nested = item.get(parent_key)
        if isinstance(nested, dict):
            value = _extract_company_website(nested)
            if value:
                return value
    return ""


def _extract_company_linkedin(item: dict[str, Any]) -> str:
    for key in (
        "company_linkedin", "companyLinkedin", "company_linkedin_url",
        "companyLinkedInUrl", "organization_linkedin_url", "companyLinkedIn",
    ):
        value = _as_text_from_nested(item.get(key))
        if "linkedin.com/company/" in value.casefold():
            return value
    for parent_key in ("company", "organization", "currentCompany", "data", "result", "lead"):
        nested = item.get(parent_key)
        if isinstance(nested, dict):
            value = _extract_company_linkedin(nested)
            if value:
                return value
    return ""


def _identity_keys(item: dict[str, Any], requested_company: str = "") -> list[str]:
    keys: list[str] = []
    linkedin = _extract_linkedin(item)
    if linkedin:
        keys.append(f"linkedin:{_norm(linkedin.rstrip('/'))}")
    for email in _extract_emails(item):
        keys.append(f"email:{email.casefold()}")
    phone = _extract_phone(item)
    if phone:
        digits = "".join(ch for ch in phone if ch.isdigit())
        if digits:
            keys.append(f"phone:{digits}")
    name = _extract_name(item)
    if name:
        company = _extract_company_name(item) or requested_company
        if company:
            keys.append(f"name:{_norm(name)}|company:{_norm(company)}")
        else:
            keys.append(f"name:{_norm(name)}")
    return list(dict.fromkeys(keys))


def _is_provider_contact(item: dict[str, Any]) -> bool:
    """Return True when an Apify row looks like a person lead, not a run/message row."""
    if not isinstance(item, dict):
        return False
    return bool(
        _extract_name(item)
        or _extract_emails(item)
        or _extract_linkedin(item)
        or _extract_phone(item)
        or _extract_job_title(item)
    )


def _person_contact_count(item: dict[str, Any]) -> int:
    return sum(bool(x) for x in (_extract_emails(item), _extract_linkedin(item), _extract_phone(item)))

def _unique_targets_by_company(
    targets: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = {}
    for target in targets:
        company = _text(target.get("company_name"))
        if not company:
            continue
        key = _norm(company)
        grouped.setdefault(key, [])
        if len(grouped[key]) < settings.max_lead_targets_per_company:
            grouped[key].append(target)
    result = []
    for items in grouped.values():
        result.extend(items)
    return result


def _make_target_queries(targets: list[dict[str, Any]]) -> list[str]:
    queries = []
    seen = set()
    for target in targets:
        company = _text(target.get("company_name"))
        role_keywords = target.get("role_keywords") or []
        if not isinstance(role_keywords, list):
            role_keywords = [role_keywords]
        for role in role_keywords:
            role_text = _text(role)
            if not role_text:
                continue
            query = f'"{company}" "{role_text}"'
            key = query.casefold()
            if key not in seen:
                queries.append(query)
                seen.add(key)
    return queries


def _company_match(
    requested_company: str,
    provider_company: str,
    provider_website: str,
    requested_domain: str = "",
) -> tuple[bool, str]:
    requested = _norm(requested_company)
    provider = _norm(provider_company)
    req_domain = _norm(requested_domain).replace("https://", "").replace("http://", "").strip("/")
    provider_domain = _norm(provider_website).replace("https://", "").replace("http://", "").strip("/")
    if provider:
        score = company_match_score(requested_company, provider_company)
        if score >= 95:
            return True, "provider_company_exact" if score == 100 else "provider_company_variant_match"
    if req_domain and provider_domain:
        req_host = req_domain.removeprefix("www.").split("/")[0]
        provider_host = provider_domain.removeprefix("www.").split("/")[0]
        if req_host and provider_host and req_host == provider_host:
            return True, "provider_domain_exact"
    if provider:
        requested_tokens = {t for t in requested.replace(".", " ").split() if len(t) > 2}
        provider_tokens = {t for t in provider.replace(".", " ").split() if len(t) > 2}
        # Preserve the original token fallback for partial/extended legal names.
        if requested_tokens and requested_tokens.issubset(provider_tokens):
            return True, "provider_company_token_match"
    if provider_domain and requested:
        compact_requested = "".join(ch for ch in requested if ch.isalnum())
        compact_domain = "".join(ch for ch in provider_domain if ch.isalnum())
        if compact_requested and compact_requested in compact_domain:
            return True, "provider_website_name_match"
    # The Actor request is company-specific. If the provider omits employer
    # fields entirely, keep the candidate rather than dropping a valid contact.
    if not provider:
        return True, "company_specific_search_query"
    return False, "provider_company_mismatch"

def _build_lead(
    company: dict[str, Any],
    opportunity: dict[str, Any],
    target: dict[str, Any],
    raw: dict[str, Any],
    enrichment: dict[str, Any] | None,
    target_query: str,
    source_actor: str | None = None,
) -> dict[str, Any] | None:
    merged = {k: v for k, v in raw.items() if not str(k).startswith("__")}
    if enrichment:
        merged.update({k: v for k, v in enrichment.items() if v not in (None, "", [], {})})

    provider_company = _extract_company_name(merged)
    provider_website = _extract_company_website(merged)
    requested_domain = _text(company.get("known_domain"))
    matches, match_basis = _company_match(
        company.get("company_name", ""), provider_company, provider_website, requested_domain
    )
    if not matches and raw.get("__company_scoped") and not provider_company:
        matches = True
        match_basis = "company_specific_actor_search"
    if not matches:
        return None

    linkedin = _extract_linkedin(merged)
    emails = _extract_emails(merged)
    email = emails[0] if emails else ""
    raw_email_status = _text(merged.get("email_status") or merged.get("emailStatus")).casefold()
    email_status = (
        "verified"
        if raw_email_status in {"validated", "verified", "valid"}
        or bool(merged.get("email_company_verified") or merged.get("emailVerified") or merged.get("email_verified"))
        else ("found" if email else "not_found")
    )

    full_name = _extract_name(merged)
    phone = _extract_phone(merged)
    if not full_name and not linkedin and not email and not phone:
        return None

    return {
        "lead_id": "",
        "company": company.get("company_name", ""),
        "country": company.get("country", ""),
        "industry": company.get("industry", ""),
        "matched_opportunity": opportunity.get("opportunity", ""),
        "matched_opportunity_id": opportunity.get("opportunity_id", ""),
        "matched_signal_id": opportunity.get("signal_id", ""),
        "matched_pattern_id": target.get("pattern_id", ""),
        "opportunity_validation_status": opportunity.get("validation_status", ""),
        "target_department": target.get("target_department", ""),
        "target_role": target.get("target_role", ""),
        "person_name": full_name,
        "job_title": _extract_job_title(merged),
        "business_email": email,
        "email_status": email_status,
        "email_source": "discovery" if email and not (enrichment and enrichment.get("email")) else ("reversecontact" if email else ""),
        "phone": phone,
        "phone_source": "reversecontact" if enrichment and enrichment.get("phone") else ("discovery" if phone else ""),
        "linkedin_url": linkedin,
        "company_website": provider_website or requested_domain,
        "company_linkedin": _extract_company_linkedin(merged),
        "provider_company_name": provider_company,
        "location": _text(merged.get("location") or merged.get("city")),
        "why_this_person": _text(target.get("why_this_person")),
        "why_this_company": _text(target.get("why_this_company")),
        "lead_match_basis": match_basis,
        "target_query": target_query,
        "lead_confidence": max(0.0, min(1.0, float(target.get("target_confidence") or 0))),
        "source_actor": source_actor or settings.apify_lead_actor,
        "enrichment_provider": "reversecontact" if enrichment and enrichment.get("phone") else "",
        "reversecontact_phone_type": _text(merged.get("phone_type")),
        "reversecontact_status": _text(merged.get("reversecontact_status")),
        "reversecontact_webhook_id": _text(merged.get("reversecontact_webhook_id")),
        "reversecontact_error": _text(merged.get("reversecontact_error")),
        "reversecontact_http_status": merged.get("reversecontact_http_status", ""),
        "reversecontact_credits_consumed": merged.get("reversecontact_credits_consumed", ""),
    }

def _actor_family(actor_id: Any) -> str:
    value = _norm(actor_id)
    if value == "afanasenko/linkedin-profile-api-scraper":
        return "afanasenko_profile_search"
    if value == "scrapesage/linkedin-people-search-scraper":
        return "scrapesage_people_search"
    if value == "automly/linkedin-people-search-scraper":
        return "automly_people_search"
    return "code_crafter_leads_finder"


def _configured_lead_actors() -> list[str]:
    configured = getattr(settings, "apify_lead_actors", ())
    actors: list[str] = []
    if configured:
        actors.extend(str(x).strip() for x in configured if str(x).strip())
    else:
        actors.extend([
            _text(getattr(settings, "apify_lead_actor", "")),
            _text(getattr(settings, "apify_lead_fallback_actor", "")),
        ])
    seen: set[str] = set()
    result: list[str] = []
    for actor in actors:
        key = actor.casefold()
        if key and key not in seen:
            result.append(actor)
            seen.add(key)
    return result


def _provider_error_kind(message: Any) -> str:
    value = _norm(message)
    if not value:
        return ""
    if "free apify plan" in value or "free plan" in value or "plan" in value and "via the ui" in value:
        return "plan_restriction"
    if "insufficient permissions" in value or "forbidden" in value or "permission" in value:
        return "permissions"
    if "not found" in value or "does not exist" in value:
        return "actor_not_found"
    if "timed out" in value or "timeout" in value:
        return "timeout"
    if "rate limit" in value or "too many requests" in value:
        return "rate_limit"
    if "proxy" in value and "residential" in value:
        return "proxy_requirement"
    return "provider_error"


def _build_apify_inputs(
    company: dict[str, Any], role_keywords: list[str],
) -> tuple[dict[str, Any], str]:
    """Build the configured Actor payload and return the normalized location sent."""
    actor_family = _actor_family(settings.apify_lead_actor)
    country = _text(company.get("country"))
    location = _apify_supported_location(country)
    domain = _text(company.get("known_domain"))
    company_name = _text(company.get("company_name"))

    if actor_family == "afanasenko_profile_search":
        # This Actor's documented searchLead mode accepts a company URL/domain
        # and one title string, so the caller uses a target-specific request.
        role = _text(role_keywords[0] if role_keywords else "")
        run_input: dict[str, Any] = {
            "operationMode": "searchLead",
            "searchLeadCompanyUrls": [domain or company_name],
            "searchLeadJobTitle": role,
            "searchLeadCount": max(1, settings.max_leads_per_company),
            "maxItemsMode3": max(1, settings.max_leads_per_company),
        }
        if country:
            run_input["countryFilter"] = country
        return run_input, location

    if actor_family == "scrapesage_people_search":
        run_input = {
            "jobTitles": role_keywords[:10],
            "companies": [domain or company_name],
            "locations": [country] if country else [],
            "maxPerTitle": max(1, settings.max_leads_per_company),
            "maxResults": max(1, settings.max_leads_per_company),
            "verifyProfiles": True,
        }
        return run_input, location

    if actor_family == "automly_people_search":
        run_input = {
            "jobTitles": role_keywords[:10],
            "companies": [domain or company_name],
            "locations": [country] if country else [],
            "maxResults": max(1, settings.max_leads_per_company),
        }
        return run_input, location

    # code_crafter/leads-finder (legacy/current primary-compatible path).
    run_input = {
        "fetch_count": max(1, settings.max_leads_per_company),
        "contact_job_title": role_keywords,
    }
    if domain:
        run_input["company_domain"] = [domain]
    elif company_name:
        run_input["company_keywords"] = [company_name]
    if location:
        run_input["contact_location"] = [location]
    run_input["email_status"] = ["validated", "unknown"]
    return run_input, location


def _relaxed_apify_input(run_input: dict[str, Any]) -> dict[str, Any]:
    """Relax restrictive legacy Leads Finder filters for a bounded retry."""
    relaxed = dict(run_input)
    actor_family = _actor_family(settings.apify_lead_actor)
    if actor_family != "code_crafter_leads_finder":
        # The newer search Actors have separate, documented input shapes.
        return relaxed
    relaxed.pop("email_status", None)
    if "company_domain" in relaxed:
        domain = relaxed.pop("company_domain")
        if domain:
            host = _text(domain[0]).replace("https://", "").replace("http://", "").strip("/")
            company_keyword = host.split(".")[0].replace("-", " ").strip()
            if company_keyword:
                relaxed["company_keywords"] = [company_keyword]
    return relaxed


def _safe_provider_error(item: dict[str, Any]) -> str:
    """Extract a concise provider error without copying credentials/tokens."""
    for key in ("error", "message", "statusMessage", "status_message"):
        value = item.get(key)
        if value in (None, "", [], {}):
            continue
        if isinstance(value, (dict, list)):
            try:
                value = json.dumps(value, ensure_ascii=False)
            except TypeError:
                value = str(value)
        text = _text(value)
        for secret_key in ("Authorization", "Bearer ", "APIFY_API_TOKEN"):
            if secret_key in text:
                text = text.split(secret_key, 1)[0].rstrip(" :,-")
        return text[:1000]
    return ""


def _provider_error_from_items(items: list[dict[str, Any]]) -> str:
    for item in items:
        if isinstance(item, dict):
            message = _safe_provider_error(item)
            if message:
                return message
    return ""


def _target_role_variants(target: dict[str, Any], limit: int = 5) -> list[str]:
    values: list[str] = []
    seen: set[str] = set()
    raw_roles = target.get("role_keywords") or []
    if not isinstance(raw_roles, list):
        raw_roles = [raw_roles]
    for value in [*raw_roles, target.get("target_role")]:
        text = _text(value)
        key = _norm(text)
        if key and key not in seen:
            values.append(text)
            seen.add(key)
    return values[:limit]


def _normalize_linkedin_company_url(url: str) -> str:
    """Canonicalize any LinkedIn company URL to the www host used by searchLead."""
    value = _text(url)
    if "linkedin.com/company/" not in value.casefold():
        return ""
    try:
        parsed = urlparse(value if "://" in value else f"https://{value}")
        path = parsed.path.rstrip("/")
        if "/company/" not in path.casefold():
            return ""
        return urlunparse(("https", "www.linkedin.com", path, "", "", "")) + "/"
    except Exception:
        return ""


def _company_linkedin_candidates_from_items(items: list[dict[str, Any]], requested_company: str) -> list[str]:
    urls: list[str] = []
    seen: set[str] = set()
    requested_norm = _norm(requested_company)
    for item in items:
        if not isinstance(item, dict):
            continue
        raw_url = _text(item.get("linkedin_url") or item.get("linkedinUrl") or item.get("company_linkedin_url"))
        url = _normalize_linkedin_company_url(raw_url)
        entity_type = _norm(item.get("entity_type"))
        name = _norm(item.get("company_name") or item.get("company") or item.get("name"))
        if not url:
            continue
        if entity_type and entity_type not in {"company", "organization", "organisation", "business"}:
            continue
        if requested_norm and name and requested_norm != name:
            req_tokens = {t for t in requested_norm.replace(".", " ").replace("-", " ").split() if len(t) > 2}
            name_tokens = {t for t in name.replace(".", " ").replace("-", " ").split() if len(t) > 2}
            overlap = len(req_tokens & name_tokens)
            if req_tokens and name_tokens and overlap < max(2, min(4, len(req_tokens) // 2 + 1)):
                continue
        key = _norm(url.rstrip("/"))
        if key not in seen:
            urls.append(url)
            seen.add(key)
    return urls


def _resolve_linkedin_company_urls_via_tavily(company: dict[str, Any]) -> list[str]:
    """Recover the public LinkedIn company URL when Apify returns no company row."""
    company_name = _text(company.get("company_name"))
    domain = _text(company.get("known_domain"))
    if not company_name or not (getattr(settings, "tavily_api_key", "") or getattr(settings, "serper_api_key", "")):
        return []
    queries = [f'"{company_name}" LinkedIn company']
    if domain:
        queries.insert(0, f'"{company_name}" "{domain}" LinkedIn company')
    urls: list[str] = []
    seen: set[str] = set()
    for query in queries:
        try:
            results = public_search(query, include_domains=["linkedin.com"], max_results=5)
        except Exception:
            continue
        for result in results or []:
            if not isinstance(result, dict):
                continue
            url = _normalize_linkedin_company_url(_text(result.get("url")))
            if not url:
                continue
            key = _norm(url.rstrip("/"))
            if key not in seen:
                urls.append(url)
                seen.add(key)
        if urls:
            break
    return urls[:3]


def _resolve_afanasenko_company_urls(
    actor_id: str, company: dict[str, Any]
) -> tuple[list[str], list[dict[str, Any]], list[str]]:
    """Resolve a company/domain to LinkedIn company URLs before searchLead.

    The fallback Actor documents company/domain inputs for companyLookup and
    LinkedIn company URLs for searchLead. Keeping those stages separate avoids
    silently sending an unsupported domain value into searchLead.
    """
    company_name = _text(company.get("company_name"))
    domain = _text(company.get("known_domain"))
    country = _text(company.get("country"))
    known_linkedin = _text(company.get("known_linkedin"))
    lookup_inputs: list[dict[str, Any]] = []
    errors: list[str] = []
    urls: list[str] = []

    normalized_known = _normalize_linkedin_company_url(known_linkedin)
    if normalized_known:
        urls.append(normalized_known)

    if domain and not urls:
        lookup_input = {
            "operationMode": "companyLookup",
            "companyInputs": [domain],
            "maxItemsMode2": 1,
        }
        lookup_inputs.append(lookup_input)
        try:
            lookup_items = run_actor_get_dataset_items(actor_id, lookup_input)
            urls.extend(_company_linkedin_candidates_from_items(lookup_items, company_name))
        except ApifyAPIError as exc:
            errors.append(str(exc))

    if not urls:
        search_input: dict[str, Any] = {
            "operationMode": "searchCompany",
            "searchCompanyKeywords": company_name,
            "searchCompanyCount": 5,
            "maxItemsMode4": 5,
        }
        if country:
            search_input["countryFilter"] = country
        lookup_inputs.append(search_input)
        try:
            search_items = run_actor_get_dataset_items(actor_id, search_input)
            urls.extend(_company_linkedin_candidates_from_items(search_items, company_name))
        except ApifyAPIError as exc:
            errors.append(str(exc))

    if not urls:
        urls.extend(_resolve_linkedin_company_urls_via_tavily(company))

    return list(dict.fromkeys(urls)), lookup_inputs, errors


def _discover_with_actor(
    actor_id: str,
    company: dict[str, Any],
    company_targets: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Run one lead Actor using its documented input style."""
    actor_family = _actor_family(actor_id)
    items: list[dict[str, Any]] = []
    attempted_inputs: list[dict[str, Any]] = []
    errors: list[str] = []

    if actor_family == "afanasenko_profile_search":
        company_urls, resolution_inputs, resolution_errors = _resolve_afanasenko_company_urls(actor_id, company)
        attempted_inputs.extend(resolution_inputs)
        errors.extend(resolution_errors)
        if not company_urls:
            if not errors:
                errors.append(f"Could not resolve a LinkedIn company URL for {company.get('company_name', '')}")
            return [], {"inputs": attempted_inputs, "errors": errors, "company_urls": []}

        # Search each AI-selected target independently. The Actor documents fuzzy
        # title matching, so we progressively broaden each target instead of
        # sending a compound title such as "CIO / VP Digital Health". The
        # company URL already scopes the search, so countryFilter is intentionally
        # omitted here; a country filter can accidentally exclude a valid executive
        # whose LinkedIn location differs from the company's HQ.
        for target in company_targets:
            roles = _target_role_variants(target, limit=4)
            if not roles:
                continue
            for role_index, role in enumerate(roles):
                run_input: dict[str, Any] = {
                    "operationMode": "searchLead",
                    "searchLeadCompanyUrls": company_urls[:3],
                    "searchLeadJobTitle": role,
                    "searchLeadCount": max(1, settings.max_leads_per_company),
                    "maxItemsMode3": max(1, settings.max_leads_per_company),
                }
                attempted_inputs.append(run_input)
                try:
                    result = run_actor_get_dataset_items(actor_id, run_input)
                    for row in result:
                        if isinstance(row, dict):
                            row = dict(row)
                            row["__company_scoped"] = True
                            row["__search_role"] = role
                            items.append(row)
                    if any(_is_provider_contact(row) for row in result if isinstance(row, dict)):
                        break
                except ApifyAPIError as exc:
                    errors.append(str(exc))

        # If title-specific searches found nothing, make one bounded company-wide
        # decision-maker search. The Actor explicitly supports a blank title filter
        # for all decision-makers at a target company. We keep the result scoped to
        # the supplied company URL and cap the output with searchLeadCount.
        if not any(_is_provider_contact(row) for row in items if isinstance(row, dict)):
            run_input = {
                "operationMode": "searchLead",
                "searchLeadCompanyUrls": company_urls[:3],
                "searchLeadJobTitle": "",
                "searchLeadCount": max(1, settings.max_leads_per_company),
                "maxItemsMode3": max(1, settings.max_leads_per_company),
            }
            attempted_inputs.append(run_input)
            try:
                result = run_actor_get_dataset_items(actor_id, run_input)
                for row in result:
                    if isinstance(row, dict):
                        row = dict(row)
                        row["__company_scoped"] = True
                        row["__search_role"] = "company-wide decision-makers"
                        items.append(row)
            except ApifyAPIError as exc:
                errors.append(str(exc))

        # Recovery path: the Actor's company search can resolve the same company
        # to a canonical LinkedIn URL when a previously supplied slug is stale,
        # unindexed, or temporarily returns no people. This costs no result rows
        # when the company search produces no match and gives us a second set of
        # company URLs to try before declaring the provider a no-match.
        if not any(_is_provider_contact(row) for row in items if isinstance(row, dict)):
            recovery_input: dict[str, Any] = {
                "operationMode": "searchCompany",
                "searchCompanyKeywords": _text(company.get("company_name")),
                "searchCompanyCount": 5,
                "maxItemsMode4": 5,
            }
            country = _text(company.get("country"))
            if country:
                recovery_input["countryFilter"] = country
            attempted_inputs.append(recovery_input)
            try:
                recovered_company_rows = run_actor_get_dataset_items(actor_id, recovery_input)
                recovered_urls = _company_linkedin_candidates_from_items(
                    recovered_company_rows, _text(company.get("company_name"))
                )
                for url in recovered_urls:
                    if _norm(url.rstrip("/")) not in {_norm(x.rstrip("/")) for x in company_urls}:
                        company_urls.append(url)
                if recovered_urls:
                    recovery_lead_input = {
                        "operationMode": "searchLead",
                        "searchLeadCompanyUrls": recovered_urls[:5],
                        "searchLeadJobTitle": "",
                        "searchLeadCount": max(1, settings.max_leads_per_company),
                        "maxItemsMode3": max(1, settings.max_leads_per_company),
                    }
                    attempted_inputs.append(recovery_lead_input)
                    recovery_result = run_actor_get_dataset_items(actor_id, recovery_lead_input)
                    for row in recovery_result:
                        if isinstance(row, dict):
                            row = dict(row)
                            row["__company_scoped"] = True
                            row["__search_role"] = "canonical-company recovery"
                            items.append(row)
            except ApifyAPIError as exc:
                errors.append(str(exc))

        return items, {"inputs": attempted_inputs, "errors": errors, "company_urls": company_urls}

    if actor_family in {"scrapesage_people_search", "automly_people_search"}:
        roles = _select_role_keywords(company_targets)
        run_input, _ = _build_apify_inputs_for_actor(actor_id, company, roles)
        attempted_inputs.append(run_input)
        try:
            items = run_actor_get_dataset_items(actor_id, run_input)
        except ApifyAPIError as exc:
            errors.append(str(exc))
        return items, {"inputs": attempted_inputs, "errors": errors}

    roles = _select_role_keywords(company_targets)
    run_input, _ = _build_apify_inputs_for_actor(actor_id, company, roles)
    attempted_inputs.append(run_input)
    try:
        items = run_actor_get_dataset_items(actor_id, run_input)
    except ApifyAPIError as exc:
        errors.append(str(exc))
        return [], {"inputs": attempted_inputs, "errors": errors}

    # Legacy Actor: if it returned no contacts, do one documented relaxed retry.
    if not any(_is_provider_contact(item) for item in items if isinstance(item, dict)):
        retry_input = _relaxed_apify_input_for_actor(actor_id, run_input)
        if retry_input != run_input:
            attempted_inputs.append(retry_input)
            try:
                retry_items = run_actor_get_dataset_items(actor_id, retry_input)
                if retry_items:
                    items = retry_items
            except ApifyAPIError as exc:
                errors.append(str(exc))

    return items, {"inputs": attempted_inputs, "errors": errors}


def _build_apify_inputs_for_actor(
    actor_id: str, company: dict[str, Any], role_keywords: list[str],
) -> tuple[dict[str, Any], str]:
    """Build an input payload for a specific configured/fallback Actor."""
    actor_family = _actor_family(actor_id)
    country = _text(company.get("country"))
    location = _apify_supported_location(country)
    domain = _text(company.get("known_domain"))
    company_name = _text(company.get("company_name"))

    if actor_family == "afanasenko_profile_search":
        role = _text(role_keywords[0] if role_keywords else "")
        # searchLead expects LinkedIn company URLs. Company/domain resolution is
        # handled by _discover_with_actor before this payload is executed.
        payload: dict[str, Any] = {
            "operationMode": "searchLead",
            "searchLeadCompanyUrls": [domain or company_name],
            "searchLeadJobTitle": role,
            "searchLeadCount": max(1, settings.max_leads_per_company),
            "maxItemsMode3": max(1, settings.max_leads_per_company),
        }
        if country:
            payload["countryFilter"] = country
        return payload, location

    if actor_family == "scrapesage_people_search":
        payload = {
            "jobTitles": role_keywords[:10],
            "companies": [domain or company_name],
            "locations": [country] if country else [],
            "maxPerTitle": max(1, settings.max_leads_per_company),
            "maxResults": max(1, settings.max_leads_per_company),
            "verifyProfiles": True,
        }
        return payload, location

    if actor_family == "automly_people_search":
        payload = {
            "jobTitles": role_keywords[:10],
            "companies": [domain or company_name],
            "locations": [country] if country else [],
            "maxResults": max(1, settings.max_leads_per_company),
        }
        return payload, location

    payload = {
        "fetch_count": max(1, settings.max_leads_per_company),
        "contact_job_title": role_keywords,
    }
    if domain:
        payload["company_domain"] = [domain]
    elif company_name:
        payload["company_keywords"] = [company_name]
    if location:
        payload["contact_location"] = [location]
    payload["email_status"] = ["validated", "unknown"]
    return payload, location


def _build_apify_inputs(
    company: dict[str, Any], role_keywords: list[str],
) -> tuple[dict[str, Any], str]:
    """Backward-compatible wrapper using the primary configured Actor."""
    return _build_apify_inputs_for_actor(settings.apify_lead_actor, company, role_keywords)


def _relaxed_apify_input_for_actor(actor_id: str, run_input: dict[str, Any]) -> dict[str, Any]:
    relaxed = dict(run_input)
    if _actor_family(actor_id) != "code_crafter_leads_finder":
        return relaxed
    relaxed.pop("email_status", None)
    if "company_domain" in relaxed:
        domain = relaxed.pop("company_domain")
        if domain:
            host = _text(domain[0]).replace("https://", "").replace("http://", "").strip("/")
            company_keyword = host.split(".")[0].replace("-", " ").strip()
            if company_keyword:
                relaxed["company_keywords"] = [company_keyword]
    return relaxed


def _relaxed_apify_input(run_input: dict[str, Any]) -> dict[str, Any]:
    """Backward-compatible wrapper for the primary configured Actor."""
    return _relaxed_apify_input_for_actor(settings.apify_lead_actor, run_input)


def _select_role_keywords(company_targets: list[dict[str, Any]]) -> list[str]:
    roles: list[str] = []
    seen: set[str] = set()
    for target in company_targets:
        raw_roles = target.get("role_keywords") or []
        if not isinstance(raw_roles, list):
            raw_roles = [raw_roles]
        target_role = _text(target.get("target_role"))
        candidates = [*raw_roles, target_role]
        for role in candidates:
            role_text = _text(role)
            key = _norm(role_text)
            if key and key not in seen:
                roles.append(role_text)
                seen.add(key)
    return roles


def generate_leads(
    companies: list[dict[str, Any]],
    opportunities: list[dict[str, Any]],
    validations: list[dict[str, Any]],
    patterns: list[dict[str, Any]],
    provider_preflight: dict[str, Any] | None = None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[str], list[dict[str, Any]]]:
    """Generate AI lead targets, discover LinkedIn contacts with Apify, and enrich missing phones with Reverse Contact.

    Apify is the discovery provider. Contact data already present in the Apify row is
    preserved. Reverse Contact is used only for selected contacts that still lack a phone.
    Returns (lead_targets, leads, errors, diagnostics).
    """
    if not companies or not opportunities:
        return [], [], [], []

    allowed_validation_by_opp = {
        _text(item.get("opportunity_id")): item
        for item in validations
        if _text(item.get("opportunity_id"))
        and _text(item.get("validation_status")) != "insufficient_support"
    }
    if validations:
        opportunities = [
            item for item in opportunities
            if _text(item.get("opportunity_id")) in allowed_validation_by_opp
        ]
    if not opportunities:
        return [], [], [], []
    opportunities = [
        dict(item, validation_status=allowed_validation_by_opp.get(_text(item.get("opportunity_id")), {}).get("validation_status", item.get("validation_status", "")))
        for item in opportunities
    ]

    pattern_by_opp: dict[str, str] = {}
    for pattern in patterns:
        pattern_id = _text(pattern.get("pattern_id"))
        for opportunity_id in pattern.get("opportunity_ids", []):
            if pattern_id and opportunity_id:
                pattern_by_opp[_text(opportunity_id)] = pattern_id

    all_targets: list[dict[str, Any]] = []
    errors: list[str] = []
    diagnostics: list[dict[str, Any]] = []

    for company in companies:
        company_opportunities = [
            item for item in opportunities if _norm(item.get("company_name")) == _norm(company.get("company_name"))
        ]
        if not company_opportunities:
            continue
        try:
            targets = generate_lead_target_batch(company, company_opportunities)
        except Exception as exc:
            errors.append(f"{company.get('company_name', '')}: target planning failed: {exc}")
            diagnostics.append({"company": company.get("company_name", ""), "status": "target_planning_failed", "error": str(exc)})
            continue
        if not isinstance(targets, list):
            diagnostics.append({"company": company.get("company_name", ""), "status": "target_planning_empty"})
            continue
        for target in targets[: settings.max_lead_targets_per_company]:
            if not isinstance(target, dict):
                continue
            target = dict(target)
            target["company_name"] = company.get("company_name", "")
            target["pattern_id"] = pattern_by_opp.get(_text(target.get("opportunity_id")), "")
            all_targets.append(target)

    all_targets = _unique_targets_by_company(all_targets)
    if not settings.apify_api_token or settings.apify_api_token.startswith("PASTE_YOUR_"):
        errors.append("APIFY_API_TOKEN is missing")
        return all_targets, [], errors, diagnostics

    opportunities_by_id = {
        _text(o.get("opportunity_id")): o for o in opportunities if _text(o.get("opportunity_id"))
    }
    leads_by_key: dict[str, dict[str, Any]] = {}

    actor_candidates = _configured_lead_actors()
    if provider_preflight is None and getattr(settings, "apify_provider_preflight", False):
        provider_preflight = preflight_apify(actor_candidates)

    for company in companies:
        company_targets = [
            t for t in all_targets if _norm(t.get("company_name")) == _norm(company.get("company_name"))
        ]
        if not company_targets:
            continue

        role_keywords = _select_role_keywords(company_targets)
        if not role_keywords:
            diagnostics.append({
                "company": company.get("company_name", ""),
                "status": "no_role_keywords",
                "country": company.get("country", ""),
            })
            continue

        sent_location = _apify_supported_location(company.get("country"))
        discovery_actor = _text(settings.apify_lead_actor)
        diag: dict[str, Any] = {
            "company": company.get("company_name", ""),
            "country": company.get("country", ""),
            "apify_location": sent_location,
            "actor": settings.apify_lead_actor,
            "role_keyword_count": len(role_keywords),
            "records_received": 0,
            "candidate_contacts": 0,
            "company_matches": 0,
            "usable_leads": 0,
            "relaxed_retry": False,
            "status": "started",
            "provider_fields": [],
            "non_contact_records": 0,
            "provider_error": "",
            "fallback_actor": "",
            "actors_attempted": [],
            "actor_results": [],
            "provider_error_kind": "",
            "enrichment_provider": "reversecontact",
            "enrichment_status": "not_attempted",
            "reversecontact_submitted": 0,
            "reversecontact_phone_found": 0,
            "reversecontact_credits_consumed": 0,
        }

        if provider_preflight:
            diag["provider_preflight_status"] = provider_preflight.get("status", "")
            diag["provider_plan"] = provider_preflight.get("account", {}).get("plan", "")

        configured_actors = actor_candidates or [_text(settings.apify_lead_actor)]
        if provider_preflight and provider_preflight.get("status") == "account_unavailable":
            diag["provider_error"] = _text(provider_preflight.get("message"))[:1000]
            diag["provider_error_kind"] = _provider_error_kind(diag["provider_error"])
            diag["status"] = "provider_unavailable"
            diag["actors_attempted"] = []
            diagnostics.append(diag)
            continue

        metadata_by_actor = {
            _norm(item.get("actor")): item
            for item in (provider_preflight.get("actors", []) if provider_preflight else [])
        }
        runnable_actors: list[str] = []
        for actor_id in configured_actors:
            metadata = metadata_by_actor.get(_norm(actor_id))
            if metadata and metadata.get("status") in {"deprecated", "metadata_unavailable"}:
                continue
            runnable_actors.append(actor_id)
        if not runnable_actors and configured_actors:
            diag["provider_error"] = "No configured Apify lead Actor is accessible via the metadata API."
            diag["provider_error_kind"] = "actor_unavailable"
            diag["status"] = "provider_unavailable"
            diag["actors_attempted"] = []
            diagnostics.append(diag)
            continue

        raw_items: list[dict[str, Any]] = []
        discovery_actor = ""
        for actor_id in runnable_actors:
            diag["actors_attempted"].append(actor_id)
            actor_raw, provider_meta = _discover_with_actor(actor_id, company, company_targets)
            actor_errors = [_text(x) for x in provider_meta.get("errors", []) if _text(x)]
            row_error = _provider_error_from_items(actor_raw) if actor_raw else ""
            combined_errors = list(dict.fromkeys([*actor_errors, row_error] if row_error else actor_errors))
            actor_result: dict[str, Any] = {
                "actor": actor_id,
                "records_received": len(actor_raw),
                "contact_records": sum(1 for item in actor_raw if isinstance(item, dict) and _is_provider_contact(item)),
                "errors": combined_errors[:5],
                "error_kinds": list(dict.fromkeys(_provider_error_kind(x) for x in combined_errors if _provider_error_kind(x))),
                "inputs_attempted": len(provider_meta.get("inputs", [])),
                "company_urls": provider_meta.get("company_urls", []),
            }
            diag["actor_results"].append(actor_result)

            if combined_errors:
                latest_error = combined_errors[-1]
                # Keep the first and most actionable provider error. Each actor's
                # full error list is also preserved in actor_results.
                if not diag.get("provider_error"):
                    diag["provider_error"] = latest_error[:1000]
                if not diag.get("provider_error_kind"):
                    diag["provider_error_kind"] = _provider_error_kind(latest_error)

            if actor_raw:
                has_actor_contacts = any(_is_provider_contact(item) for item in actor_raw if isinstance(item, dict))
                if has_actor_contacts:
                    raw_items = actor_raw
                    discovery_actor = actor_id
                    break
                # Keep the most recent raw rows so their provider error/status is visible.
                raw_items = actor_raw

        if not discovery_actor and raw_items:
            primary_error = _provider_error_from_items(raw_items)
            if primary_error and not diag.get("provider_error"):
                diag["provider_error"] = primary_error
                diag["provider_error_kind"] = _provider_error_kind(primary_error)

        if configured_actors:
            diag["actor"] = configured_actors[0]
        if len(diag.get("actors_attempted", [])) > 1:
            diag["fallback_actor"] = diag["actors_attempted"][1]
        diag["relaxed_retry"] = any(
            int(item.get("inputs_attempted") or 0) > 1
            for item in diag.get("actor_results", [])
            if isinstance(item, dict)
        )

        if raw_items:
            diag["records_received"] = len(raw_items)
            diag["provider_fields"] = sorted({k for item in raw_items if isinstance(item, dict) for k in item.keys()})[:60]
            diag["provider_error"] = diag["provider_error"] or _provider_error_from_items(raw_items)
            diag["non_contact_records"] = sum(
                1 for item in raw_items
                if isinstance(item, dict) and not _is_provider_contact(item)
            )

        has_contacts = any(_is_provider_contact(item) for item in raw_items if isinstance(item, dict))

        if not raw_items:
            diag["status"] = "no_match"
            diagnostics.append(diag)
            continue

        raw_by_identity: dict[str, tuple[dict[str, Any], str, dict[str, Any], str]] = {}
        for raw in raw_items:
            if not isinstance(raw, dict) or not _is_provider_contact(raw):
                continue
            identity_keys = _identity_keys(raw, _text(company.get("company_name")))
            if not identity_keys:
                fallback_name = _extract_name(raw) or _extract_job_title(raw)
                if not fallback_name:
                    continue
                identity_keys = [f"fallback:{_norm(fallback_name)}"]
            diag["candidate_contacts"] += 1
            provider_company = _extract_company_name(raw)
            provider_website = _extract_company_website(raw)
            company_matches, _ = _company_match(
                company.get("company_name", ""),
                provider_company,
                provider_website,
                _text(company.get("known_domain")),
            )
            scoped_match = bool(raw.get("__company_scoped")) and not provider_company
            if not company_matches and scoped_match:
                company_matches = True
            if not company_matches:
                continue
            diag["company_matches"] += 1

            best_target = company_targets[0]
            raw_title = _norm(_extract_job_title(raw))
            if raw_title:
                for candidate_target in company_targets:
                    candidate_roles = candidate_target.get("role_keywords") or []
                    if not isinstance(candidate_roles, list):
                        candidate_roles = [candidate_roles]
                    candidates = [_norm(role) for role in candidate_roles if _norm(role)]
                    target_role = _norm(candidate_target.get("target_role"))
                    if any(role in raw_title for role in candidates if role) or (target_role and target_role in raw_title):
                        best_target = candidate_target
                        break
            best_query = f'"{company.get("company_name", "")}" "{best_target.get("target_role", "")}"'
            identity_key = identity_keys[0]
            if identity_key not in raw_by_identity:
                raw_by_identity[identity_key] = (raw, best_query, best_target, discovery_actor)

        selected = list(raw_by_identity.values())[: settings.max_leads_per_company]
        enrichment_by_linkedin: dict[str, dict[str, Any]] = {}
        linkedin_people: list[dict[str, Any]] = []
        for raw, _, _, _ in selected:
            # Apify may already have a legitimate phone. Keep it and avoid a paid lookup.
            if _extract_phone(raw):
                continue
            linkedin_url = _extract_linkedin(raw)
            if linkedin_url:
                linkedin_people.append({
                    "linkedin_url": linkedin_url,
                    "name": _extract_name(raw),
                    "domain": _text(company.get("known_domain")),
                    "organization_name": _text(company.get("company_name")),
                })

        if linkedin_people:
            rc_key = _text(getattr(settings, "reversecontact_api_key", ""))
            if not rc_key or rc_key.startswith("PASTE_YOUR_"):
                diag["enrichment_provider"] = "reversecontact"
                diag["enrichment_status"] = "not_configured"
                diag["enrichment_error"] = "REVERSECONTACT_API_KEY is missing"
            else:
                try:
                    enrichment_by_linkedin = enrich_phones_by_linkedin(linkedin_people)
                    diag["reversecontact_submitted"] = len(linkedin_people)
                    diag["reversecontact_phone_found"] = sum(1 for item in enrichment_by_linkedin.values() if isinstance(item, dict) and item.get("phone"))
                    diag["reversecontact_credits_consumed"] = sum(float(item.get("reversecontact_credits_consumed") or 0) for item in enrichment_by_linkedin.values() if isinstance(item, dict) and str(item.get("reversecontact_credits_consumed") or "").replace(".", "", 1).isdigit())
                    diag["enrichment_provider"] = "reversecontact"
                    diag["enrichment_status"] = "completed" if enrichment_by_linkedin else "no_match"
                except ReverseContactAPIError as exc:
                    diag["enrichment_error"] = str(exc)[:1000]
                    diag["enrichment_provider"] = "reversecontact"
                    diag["enrichment_status"] = "provider_error"

        for raw, target_query, target, row_source_actor in selected:
            opportunity_id = _text(target.get("opportunity_id"))
            opportunity = opportunities_by_id.get(opportunity_id)
            if not opportunity:
                continue
            enrichment = None
            linkedin_key = _text(_extract_linkedin(raw))
            if linkedin_key:
                enrichment = enrichment_by_linkedin.get(normalize_linkedin_url(linkedin_key))
            lead = _build_lead(company, opportunity, target, raw, enrichment, target_query, row_source_actor)
            if not lead:
                continue
            keys = _identity_keys(lead, _text(company.get("company_name")))
            key = next((candidate for candidate in keys if candidate), "")
            if key and key not in leads_by_key:
                leads_by_key[key] = lead
                diag["usable_leads"] += 1

        if diag["usable_leads"]:
            diag["status"] = "fallback_success" if discovery_actor and _norm(discovery_actor) != _norm(diag.get("actor")) else "success"
        elif diag.get("provider_error"):
            diag["status"] = "provider_error"
        else:
            diag["status"] = "records_filtered_or_unusable"
        diagnostics.append(diag)

    if provider_preflight is not None:
        diagnostics.append({
            "status": "provider_preflight",
            "provider_preflight": provider_preflight,
            "provider_plan": provider_preflight.get("account", {}).get("plan", ""),
        })

    leads = list(leads_by_key.values())
    for index, lead in enumerate(leads, 1):
        lead["lead_id"] = f"L{index:03d}"

    return all_targets, leads, errors, diagnostics

def test_lead_provider(
    company_name: str,
    country: str,
    role: str,
    company_linkedin: str = "",
) -> dict[str, Any]:
    """Run a bounded one-company/one-role provider test without the full pipeline."""
    company = {
        "company_name": _text(company_name),
        "country": _text(country),
        "industry": "",
        "known_domain": "",
    }
    if company_linkedin:
        company["known_linkedin"] = _text(company_linkedin)

    actors = _configured_lead_actors()
    preflight = preflight_apify(actors) if settings.apify_provider_preflight else None
    result: dict[str, Any] = {
        "test": "lead_provider",
        "company": company["company_name"],
        "country": company["country"],
        "role": _text(role),
        "company_linkedin": company.get("known_linkedin", ""),
        "provider_preflight": preflight,
        "actor_results": [],
        "status": "not_run",
        "leads_found": 0,
        "contacts": [],
    }
    if not settings.apify_api_token or settings.apify_api_token.startswith("PASTE_YOUR_"):
        result["status"] = "provider_unavailable"
        result["message"] = "APIFY_API_TOKEN is missing"
        return result
    if preflight and preflight.get("status") == "account_unavailable":
        result["status"] = "provider_unavailable"
        result["message"] = _text(preflight.get("message"))
        return result

    # If the caller already knows the LinkedIn company URL, skip company search.
    # This makes the standalone test deterministic and avoids spending a lookup run.
    if company.get("known_linkedin"):
        original_resolver = globals().get("_resolve_afanasenko_company_urls")
        try:
            globals()["_resolve_afanasenko_company_urls"] = lambda actor_id, _company: (
                [company["known_linkedin"]], [], []
            )
            targets = [{"target_role": role, "role_keywords": [role], "company_name": company_name}]
            for actor_id in actors:
                metadata = next((a for a in (preflight or {}).get("actors", []) if _norm(a.get("actor")) == _norm(actor_id)), None)
                if metadata and metadata.get("status") in {"deprecated", "metadata_unavailable"}:
                    continue
                raw, meta = _discover_with_actor(actor_id, company, targets)
                contacts = [row for row in raw if isinstance(row, dict) and _is_provider_contact(row)]
                errors = list(meta.get("errors", []))
                provider_error = _provider_error_from_items(raw)
                if provider_error:
                    errors.append(provider_error)
                result["actor_results"].append({
                    "actor": actor_id,
                    "records_received": len(raw),
                    "contact_records": len(contacts),
                    "errors": list(dict.fromkeys(_text(x) for x in errors if _text(x)))[:5],
                    "error_kinds": list(dict.fromkeys(_provider_error_kind(x) for x in errors if _provider_error_kind(x))),
                    "inputs_attempted": len(meta.get("inputs", [])),
                    "company_urls": meta.get("company_urls", []),
                })
                if contacts:
                    for row in contacts[:settings.max_leads_per_company]:
                        result["contacts"].append({
                            "name": _extract_name(row),
                            "job_title": _extract_job_title(row),
                            "linkedin_url": _extract_linkedin(row),
                            "email": (_extract_emails(row) or [""])[0],
                            "phone": _extract_phone(row),
                            "company": _extract_company_name(row),
                            "location": _text(row.get("location") or row.get("city")),
                            "source_actor": actor_id,
                        })
                    break
        finally:
            if original_resolver is not None:
                globals()["_resolve_afanasenko_company_urls"] = original_resolver
    else:
        targets = [{"target_role": role, "role_keywords": [role], "company_name": company_name}]
        for actor_id in actors:
            raw, meta = _discover_with_actor(actor_id, company, targets)
            contacts = [row for row in raw if isinstance(row, dict) and _is_provider_contact(row)]
            errors = list(meta.get("errors", []))
            provider_error = _provider_error_from_items(raw)
            if provider_error:
                errors.append(provider_error)
            result["actor_results"].append({
                "actor": actor_id,
                "records_received": len(raw),
                "contact_records": len(contacts),
                "errors": list(dict.fromkeys(_text(x) for x in errors if _text(x)))[:5],
                "error_kinds": list(dict.fromkeys(_provider_error_kind(x) for x in errors if _provider_error_kind(x))),
                "inputs_attempted": len(meta.get("inputs", [])),
                "company_urls": meta.get("company_urls", []),
            })
            if contacts:
                for row in contacts[:settings.max_leads_per_company]:
                    result["contacts"].append({
                        "name": _extract_name(row),
                        "job_title": _extract_job_title(row),
                        "linkedin_url": _extract_linkedin(row),
                        "email": (_extract_emails(row) or [""])[0],
                        "phone": _extract_phone(row),
                        "company": _extract_company_name(row),
                        "location": _text(row.get("location") or row.get("city")),
                        "source_actor": actor_id,
                    })
                break

    result["leads_found"] = len(result["contacts"])
    result["status"] = "success" if result["contacts"] else (
        "provider_error" if any(r.get("errors") for r in result["actor_results"]) else "no_match"
    )
    return result


def save_lead_outputs(
    companies: list[dict[str, Any]],
    lead_targets: list[dict[str, Any]],
    leads: list[dict[str, Any]],
    errors: list[str],
    output_dir: Path,
    diagnostics: list[dict[str, Any]] | None = None,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    payload = {
        "phase": "7.1",
        "mode": "company_hierarchy_through_product_manager",
        "target_count": len(lead_targets),
        "lead_count": len(leads),
        "people_count": len(leads),
        "errors": errors,
        "provider": next(
            (item.get("provider_preflight") for item in (diagnostics or []) if item.get("status") == "provider_preflight"),
            {},
        ),
        "diagnostics": [
            {k: v for k, v in item.items() if k != "provider_preflight"}
            for item in (diagnostics or [])
        ],
        "leads": leads,
        "lead_targets": lead_targets,
    }
    (output_dir / "lead_generation.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    fields = [
        "lead_id", "company", "country", "industry", "matched_opportunity",
        "matched_opportunity_id", "matched_signal_id", "matched_pattern_id",
        "opportunity_validation_status",
        "target_department", "target_role", "person_name", "job_title",
        "hierarchy_level", "hierarchy_rank", "hierarchy_cutoff", "company_people_position",
        "business_email", "email_status", "email_source", "phone", "phone_source", "company_phone", "company_email", "linkedin_url",
        "company_website", "company_linkedin", "provider_company_name",
        "location", "why_this_person", "why_this_company", "lead_match_basis",
        "target_query", "lead_confidence", "source_actor", "enrichment_provider",
        "reversecontact_phone_type", "reversecontact_status", "reversecontact_webhook_id",
        "reversecontact_error", "reversecontact_http_status", "reversecontact_credits_consumed",
    ]
    rows = [dict(lead) for lead in leads]
    with (output_dir / "lead_generation.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    diagnostics_rows = diagnostics or []
    diagnostic_fields = [
        "company", "country", "apify_location", "actor", "role_keyword_count",
        "records_received", "candidate_contacts", "company_matches", "usable_leads",
        "relaxed_retry", "status", "provider_error", "provider_error_kind", "fallback_actor", "actors_attempted",
        "actor_results", "provider_preflight_status", "provider_plan", "provider_fields", "non_contact_records",
        "error", "retry_api_error", "enrichment_error", "enrichment_provider", "enrichment_status",
        "reversecontact_submitted", "reversecontact_phone_found", "reversecontact_credits_consumed",
    ]
    with (output_dir / "lead_generation_diagnostics.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=diagnostic_fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(diagnostics_rows)

    (output_dir / "lead_generation_diagnostics.json").write_text(
        json.dumps(diagnostics_rows, indent=2, ensure_ascii=False), encoding="utf-8"
    )
