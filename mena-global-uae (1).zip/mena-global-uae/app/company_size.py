"""Dynamic public company-size ranking used only to order the UAE company list.

The source of truth for company identity remains MoIAT. Size is a secondary public-web
attribute. We only parse explicit size/follower evidence returned by search providers;
we never invent employee counts.
"""
from __future__ import annotations

import re
import math
from concurrent.futures import ThreadPoolExecutor
from typing import Any

from .config import settings
from .search import public_search
from .identity import company_name_variants


_EMPLOYEE_BANDS = [
    ("1-10", 5, 1),
    ("11-50", 30, 2),
    ("51-200", 125, 3),
    ("201-500", 350, 4),
    ("501-1,000", 750, 5),
    ("1,001-5,000", 3000, 6),
    ("5,001-10,000", 7500, 7),
    ("10,001+", 15000, 8),
]


def _text(v: Any) -> str:
    return str(v or "").strip()


def _parse_employee_size(text: str) -> tuple[str, float, int, str] | None:
    value = re.sub(r"\s+", " ", _text(text))
    patterns = [
        re.compile(r"(?:company size|size of company|company-size|employees)\D{0,25}(\d[\d,]*(?:\s*[-–]\s*\d[\d,]*|\s*\+))\s*(?:employees|people)?", re.I),
        re.compile(r"(\d[\d,]*(?:\s*[-–]\s*\d[\d,]*|\s*\+))\s*employees\b", re.I),
        re.compile(r"no\.?\s*employees\s*(\d[\d,]*(?:\s*[-–]\s*\d[\d,]*|\s*\+))", re.I),
    ]
    for pat in patterns:
        m = pat.search(value)
        if not m:
            continue
        raw = m.group(1).replace(",", "").replace(" ", "")
        if "+" in raw:
            low = int(raw[:-1])
            label = f"{low:,}+"
            return label, float(low), 8, m.group(0)
        parts = re.split(r"[-–]", raw)
        if len(parts) == 2 and parts[0].isdigit() and parts[1].isdigit():
            low, high = int(parts[0]), int(parts[1])
            midpoint = (low + high) / 2.0
            band_rank = 1
            for label, _, rank in _EMPLOYEE_BANDS:
                lo_text = label.split("-")[0].replace(",", "").replace("+", "")
                if low >= int(lo_text):
                    band_rank = max(band_rank, rank)
            return f"{low:,}-{high:,}", midpoint, band_rank, m.group(0)
    return None


def _parse_followers(text: str) -> int | None:
    m = re.search(r"([0-9][0-9,]*(?:\.\d+)?)\s*([km])?\s*followers\b", _text(text), re.I)
    if not m:
        return None
    num = float(m.group(1).replace(",", ""))
    mult = {"k": 1000, "m": 1_000_000}.get((m.group(2) or "").lower(), 1)
    return int(num * mult)


def lookup_company_size(company: dict[str, Any], *, search=None) -> dict[str, Any]:
    search = search or public_search
    name = _text(company.get("name") or company.get("company_name"))
    if not name:
        return {}
    aliases = company_name_variants(name)[:6]
    joined = " OR ".join(f'"{x}"' for x in aliases) or f'"{name}"'
    queries = [
        (f'site:linkedin.com/company ({joined}) "Company size"', ["linkedin.com"]),
        (f'({joined}) employees followers', None),
    ]
    best: dict[str, Any] = {}
    for q_index, (q, domains) in enumerate(queries):
        try:
            hits = search(q, include_domains=domains, max_results=6) or []
        except Exception:
            continue
        for hit in hits:
            if not isinstance(hit, dict):
                continue
            text = " ".join(_text(hit.get(k)) for k in ("title", "content", "raw_content"))
            size = _parse_employee_size(text)
            if size:
                label, midpoint, rank, evidence = size
                candidate = {
                    "company_size": label,
                    "company_size_score": midpoint,
                    "company_size_band_rank": rank,
                    "company_size_source": _text(hit.get("url")),
                    "company_size_evidence": evidence[:250],
                    "company_followers": _parse_followers(text) or 0,
                }
                if not best or rank > int(best.get("company_size_band_rank") or 0) or midpoint > float(best.get("company_size_score") or 0):
                    best = candidate
            followers = _parse_followers(text)
            if followers and followers > int(best.get("company_followers") or 0):
                best["company_followers"] = followers
                best.setdefault("company_size_score", 0.0)
                best.setdefault("company_size_band_rank", 0)
                best.setdefault("company_size", "")
                best.setdefault("company_size_source", _text(hit.get("url")))
        # The first query is LinkedIn company search and is normally the strongest source.
        # Avoid spending an extra provider call when it already returned an explicit employee band.
        if q_index == 0 and best.get("company_size_score"):
            break
    # Followers are only a weak tiebreaker; employee-size evidence always dominates.
    followers = int(best.get("company_followers") or 0)
    if followers:
        best["company_public_footprint_score"] = float(best.get("company_size_score") or 0) + min(50.0, math.log10(followers + 1) * 3.0)
    else:
        best["company_public_footprint_score"] = float(best.get("company_size_score") or 0)
    return best


def rank_companies_by_public_size(companies: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if not companies:
        return []
    cap = min(len(companies), max(0, int(getattr(settings, "company_size_max_lookups_per_batch", 50))))
    workers = max(1, int(getattr(settings, "company_size_lookup_workers", 6)))
    target = companies[:cap]
    results: dict[str, dict[str, Any]] = {}
    def work(c: dict[str, Any]) -> tuple[str, dict[str, Any]]:
        return str(c.get("id") or c.get("company_key") or c.get("name")), lookup_company_size(c)
    with ThreadPoolExecutor(max_workers=min(workers, len(target))) as pool:
        for key, data in pool.map(work, target):
            results[key] = data
    enriched = []
    for idx, company in enumerate(companies):
        row = dict(company)
        key = str(row.get("id") or row.get("company_key") or row.get("name"))
        data = results.get(key) or {}
        row.update(data)
        row["_size_original_index"] = idx
        row["_size_has_evidence"] = bool(row.get("company_size_score") or row.get("company_followers"))
        enriched.append(row)
    enriched.sort(
        key=lambda r: (
            bool(r.get("_size_has_evidence")),
            float(r.get("company_size_score") or 0),
            int(r.get("company_size_band_rank") or 0),
            int(r.get("company_followers") or 0),
            -int(r.get("_size_original_index") or 0),
        ),
        reverse=True,
    )
    for row in enriched:
        row.pop("_size_original_index", None)
        row.pop("_size_has_evidence", None)
    return enriched
