"""Apify-backed exact LinkedIn profile -> contact enrichment.

The exact LinkedIn URL supplied by the caller is the primary identity anchor.
Provider-returned name/company/domain values are secondary checks when present;
missing provider fields are not treated as proof of an identity mismatch.

Provider waterfall (configurable):
1. datablow/linkedin-profile-enrichment
2. b2bsearch/bulk-people-enrichment
3. b2bsearch/linkedin-email-finder

Every contact candidate is still re-validated for generic mailboxes, employer
identity, and shared/company phone indicators.
"""
from __future__ import annotations

import csv
import io
import re
import unicodedata
from typing import Any
from urllib.parse import urlparse

from .apify_api import ApifyAPIError, run_actor_get_dataset_items
from .config import settings
from .identity import company_match_score

_PERSONAL_EMAIL_DOMAINS = {
    "gmail.com", "googlemail.com", "yahoo.com", "yahoo.co.uk", "outlook.com",
    "hotmail.com", "hotmail.co.uk", "live.com", "msn.com", "icloud.com",
    "me.com", "proton.me", "protonmail.com", "aol.com",
}

_GENERIC_LOCALS = {
    "info", "contact", "contactus", "sales", "support", "hello", "admin", "office",
    "enquiries", "enquiry", "inquiries", "inquiry", "mail", "media", "press", "hr",
    "careers", "jobs", "marketing", "service", "customerservice", "webmaster", "noreply",
    "no-reply", "reception", "accounts", "mobile", "phone", "telephone", "tel", "general",
    "business",
}


def _text(value: Any) -> str:
    return str(value or "").strip()


def _norm(value: Any) -> str:
    text = unicodedata.normalize("NFKC", _text(value))
    text = "".join(ch for ch in text if unicodedata.category(ch) not in {"Cf", "Cs"})
    return " ".join(text.casefold().split())


def _host(value: str) -> str:
    try:
        raw = value if "://" in value else f"https://{value}"
        return urlparse(raw).netloc.casefold().removeprefix("www.")
    except Exception:
        return ""


def normalize_linkedin_url(value: str) -> str:
    url = _text(value)
    if "linkedin.com/in/" not in url.casefold():
        return ""
    try:
        parsed = urlparse(url if "://" in url else f"https://{url}")
        path = parsed.path.rstrip("/")
        if "/in/" not in path.casefold():
            return ""
        return f"https://www.linkedin.com{path}/"
    except Exception:
        return ""


def _linkedin_key(value: str) -> str:
    url = normalize_linkedin_url(value)
    if not url:
        return ""
    return _norm(url.rstrip("/"))


def configured() -> bool:
    token = _text(getattr(settings, "apify_api_token", ""))
    enabled = getattr(settings, "apify_contact_enabled", True)
    return bool(enabled and token and not token.startswith("PASTE_YOUR_"))


def configured_contact_actors() -> list[str]:
    raw = getattr(settings, "apify_contact_actors", ())
    actors = [str(x).strip() for x in raw if str(x).strip()]
    if not actors:
        primary = _text(getattr(settings, "apify_contact_actor", ""))
        fallback = _text(getattr(settings, "apify_contact_fallback_actor", ""))
        actors = [x for x in (primary, fallback) if x]
    result = []
    seen = set()
    for actor in actors:
        key = actor.casefold()
        if key not in seen:
            result.append(actor)
            seen.add(key)
    return result


def _actor_family(actor_id: str) -> str:
    value = _norm(actor_id)
    if value == "datablow/linkedin-profile-enrichment":
        return "datablow"
    if value == "b2bsearch/bulk-people-enrichment":
        return "b2b_bulk"
    if value == "b2bsearch/linkedin-email-finder":
        return "b2b_email"
    return "generic"


def _csv_for_profile(linkedin_url: str, name: str = "", domain: str = "") -> str:
    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=["profile_url", "full_name", "domain"], lineterminator="\n")
    writer.writeheader()
    writer.writerow({"profile_url": linkedin_url, "full_name": name, "domain": domain})
    return out.getvalue()


def build_input(actor_id: str, linkedin_url: str, name: str = "", domain: str = "") -> dict[str, Any]:
    family = _actor_family(actor_id)
    if family == "datablow":
        return {
            "urls": [linkedin_url],
            "emails": [],
            "phoneNumbers": [],
            "maxItems": 1,
            "scrapeCompanyDetailsOnPerson": True,
        }
    if family == "b2b_bulk":
        return {
            "csv": _csv_for_profile(linkedin_url, name, domain),
            "contacts": True,
            "mustHave": [],
            "compact": True,
        }
    if family == "b2b_email":
        return {
            "profileUrls": [linkedin_url],
            "includePersonalEmails": True,
        }
    return {
        "urls": [linkedin_url],
        "profileUrls": [linkedin_url],
        "contacts": True,
        "maxItems": 1,
    }


def _walk_values(item: Any, keys: set[str], out: list[Any]) -> None:
    if isinstance(item, dict):
        for key, value in item.items():
            if key.casefold() in keys:
                out.append(value)
            _walk_values(value, keys, out)
    elif isinstance(item, list):
        for value in item:
            _walk_values(value, keys, out)


def _flatten_strings(value: Any) -> list[str]:
    result: list[str] = []
    if isinstance(value, list):
        for item in value:
            result.extend(_flatten_strings(item))
    elif isinstance(value, dict):
        for key in ("number", "phone", "phoneNumber", "value", "email", "address", "url", "profileUrl"):
            if key in value and _text(value.get(key)):
                result.append(_text(value.get(key)))
        for nested in value.values():
            if isinstance(nested, (list, dict)):
                result.extend(_flatten_strings(nested))
    elif _text(value):
        result.append(_text(value))
    return result


def _extract_emails(item: dict[str, Any]) -> list[str]:
    raw: list[Any] = []
    _walk_values(item, {
        "email", "emails", "workemail", "workemails", "businessemail", "businessemails",
        "personalemail", "personalemails", "emailaddress", "email_addresses", "emailaddresses",
        "currentworkemail", "current_work_email", "contactemail", "contactemails",
    }, raw)
    values: list[str] = []
    for value in raw:
        values.extend(_flatten_strings(value))
    result: list[str] = []
    seen = set()
    for email in values:
        email = email.strip().casefold()
        if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
            continue
        if email not in seen:
            result.append(email)
            seen.add(email)
    return result


def _phone_objects(item: dict[str, Any]) -> list[dict[str, Any]]:
    raw: list[Any] = []
    _walk_values(item, {
        "phones", "phonenumbers", "phone_numbers", "phone", "primaryphone", "primary_phone",
        "mobile", "mobilenumber", "mobile_number", "directphone", "direct_phone",
    }, raw)
    objs: list[dict[str, Any]] = []
    def add(value: Any) -> None:
        if isinstance(value, dict):
            number = _text(value.get("number") or value.get("phone") or value.get("phoneNumber") or value.get("value"))
            if number:
                objs.append({**value, "number": number})
        elif isinstance(value, list):
            for x in value:
                add(x)
        elif _text(value):
            objs.append({"number": _text(value)})
    for value in raw:
        add(value)
    seen = set()
    unique = []
    for obj in objs:
        key = re.sub(r"\D", "", obj.get("number", ""))
        if not key or key in seen:
            continue
        seen.add(key)
        unique.append(obj)
    return unique


def _extract_profile(item: dict[str, Any]) -> dict[str, str]:
    def first(keys: set[str]) -> str:
        vals: list[Any] = []
        _walk_values(item, keys, vals)
        for value in vals:
            text = _text(value)
            if text:
                return text
        return ""

    linkedin = first({
        "profileurl", "profile_url", "linkedinurl", "linkedin_url", "linkedinprofile", "linkedin",
    })
    if not linkedin and isinstance(item.get("_input"), dict):
        linkedin = _text(item["_input"].get("profile") or item["_input"].get("profile_url"))

    return {
        "name": first({"fullname", "full_name", "name", "displayname", "display_name", "personname"}),
        "company": first({"companyname", "company_name", "company", "employer", "currentcompany", "current_company"}),
        "domain": first({"domain", "companydomain", "company_domain", "organization_primary_domain", "website"}),
        "linkedin": linkedin,
        "job_title": first({"jobtitle", "job_title", "title", "headline", "currenttitle", "current_position"}),
    }


def _name_match(requested: str, returned: str) -> bool:
    if not returned:
        return True
    def tokens(value: str) -> set[str]:
        return {t for t in re.findall(r"[\wÀ-ÿ]+", value.casefold()) if len(t) > 1}
    want, got = tokens(requested), tokens(returned)
    if not want or not got:
        return True
    if _norm(requested) == _norm(returned):
        return True
    overlap = len(want & got)
    return overlap >= 2 and overlap / max(1, len(want | got)) >= 0.5


def _company_association(
    requested_company: str,
    requested_domain: str,
    returned_company: str,
    returned_domain: str,
    employer_match: Any,
) -> tuple[str, float, str]:
    """Classify company association independently from person identity.

    Returns (status, confidence, basis), where status is one of matched,
    mismatch, or unknown. A provider saying employerMatch=false is not proof
    that the person is the wrong person when the exact LinkedIn profile/name
    match; it only lowers company-association confidence.
    """
    target_domain = _host(requested_domain)
    provider_domain = _host(returned_domain)

    if employer_match is True:
        return "matched", 0.98, "provider_employer_match_true"

    if returned_company and requested_company:
        score = company_match_score(requested_company, returned_company)
        if score >= 95:
            return "matched", 0.98, "company_name_exact_or_variant"
        if score >= 80:
            return "matched", 0.90, "company_name_strong_match"
        if target_domain and provider_domain == target_domain:
            return "matched", 0.96, "company_domain_match"
        return "mismatch", max(0.15, min(0.49, score / 100.0)), "company_name_mismatch"

    if target_domain and provider_domain:
        if provider_domain == target_domain:
            return "matched", 0.96, "company_domain_match"
        return "mismatch", 0.25, "company_domain_mismatch"

    # Provider omitted employer details: exact LinkedIn/name can still establish
    # person identity, but company association remains unknown.
    return "unknown", 0.55, "provider_company_not_echoed"


def _identity_diagnostics(
    normalized_linkedin: str,
    target_name: str,
    target_company: str,
    target_domain: str,
    profile: dict[str, str],
    employer_match: Any,
) -> tuple[bool, list[str], dict[str, Any]]:
    reasons: list[str] = []
    returned_li = normalize_linkedin_url(profile.get("linkedin", ""))
    if returned_li and _linkedin_key(returned_li) != _linkedin_key(normalized_linkedin):
        reasons.append("returned_linkedin_mismatch")

    returned_name = profile.get("name", "")
    if target_name and returned_name and not _name_match(target_name, returned_name):
        reasons.append("name_mismatch")

    company_status, company_confidence, company_basis = _company_association(
        target_company, target_domain, profile.get("company", ""), profile.get("domain", ""), employer_match
    )
    association_reasons: list[str] = []
    if company_status == "mismatch":
        if employer_match is False:
            association_reasons.append("provider_employer_match_false")
        else:
            association_reasons.append("company_or_domain_mismatch")
    elif company_status == "unknown":
        association_reasons.append("provider_company_association_unknown")

    if not returned_li:
        reasons.append("provider_did_not_echo_linkedin")
    if not returned_name:
        reasons.append("provider_did_not_echo_name")
    if not profile.get("company") and not profile.get("domain"):
        reasons.append("provider_did_not_echo_company")

    # ONLY person-identity mismatches are hard failures. Employer mismatch is
    # retained as a company-association warning so the waterfall can continue
    # looking for a target-company contact for the same person.
    hard_fail = any(
        reason in {
            "returned_linkedin_mismatch",
            "name_mismatch",
        }
        for reason in reasons
    )
    meta = {
        "company_association": company_status,
        "company_association_confidence": company_confidence,
        "company_association_basis": company_basis,
        "company_association_reasons": association_reasons,
        "provider_employer_match": employer_match,
    }
    return not hard_fail, reasons, meta


def _generic_email(email: str) -> bool:
    local = email.split("@", 1)[0].casefold().replace(".", "").replace("-", "").replace("_", "")
    return local in {x.replace(".", "") for x in _GENERIC_LOCALS} or len(local) <= 1


def _candidate_emails(emails: list[str], requested_domain: str) -> list[str]:
    clean: list[str] = []
    domain = _host(requested_domain)
    for email in emails:
        if _generic_email(email):
            continue
        if domain and email.rsplit("@", 1)[-1] == domain:
            clean.insert(0, email)
        elif email not in clean:
            clean.append(email)
    return list(dict.fromkeys(clean))


def _select_contact_email(
    emails: list[str],
    requested_domain: str,
    company_association: str,
) -> tuple[str, list[str]]:
    """Choose an email without silently accepting another employer's address."""
    domain = _host(requested_domain)
    rejected: list[str] = []
    if not emails:
        return "", rejected

    target = [e for e in emails if domain and e.rsplit("@", 1)[-1] == domain]
    if target:
        return target[0], rejected

    if company_association != "mismatch":
        return emails[0], rejected

    # Explicit provider mismatch means the provider has associated the exact
    # person with a different employer. Do not surface either personal mail or
    # another employer's corporate mail as a contact for the requested company.
    # A target-company domain email was already handled above and can still be
    # accepted because it independently supports the requested company.
    for email in emails:
        rejected.append(f"company_mismatch_email:{email}")
    return "", rejected


def _candidate_phones(phone_objects: list[dict[str, Any]], exclude_phones: frozenset[str]) -> tuple[str, str, list[str]]:
    candidates: list[str] = []
    rejected: list[str] = []
    for obj in phone_objects:
        number = _text(obj.get("number"))
        digits = re.sub(r"\D", "", number)
        if len(digits) < 8:
            rejected.append(f"invalid:{number}")
            continue
        shared = obj.get("sharedBy")
        try:
            shared_n = int(shared) if shared not in (None, "") else 1
        except (TypeError, ValueError):
            shared_n = 1
        company_line = obj.get("companyLine") is True or _norm(obj.get("type")) in {"company", "company line", "switchboard"}
        if shared_n > 1 or company_line:
            rejected.append(f"shared_or_company:{number}")
            continue
        key = re.sub(r"\D", "", number)
        if any(re.sub(r"\D", "", excluded)[-8:] == key[-8:] for excluded in exclude_phones):
            rejected.append(f"known_company_number:{number}")
            continue
        candidates.append(number)
    # Prefer mobile-looking types, but keep any direct non-shared phone as a fallback.
    def score(obj: dict[str, Any]) -> tuple[int, int]:
        kind = _norm(obj.get("type") or obj.get("phoneType") or obj.get("phone_type"))
        mobile = 1 if kind in {"mobile", "cell", "wireless", "phone_mobile"} else 0
        return (mobile, 1)
    valid_objs = []
    for obj in phone_objects:
        n = _text(obj.get("number"))
        if n in candidates:
            valid_objs.append(obj)
    valid_objs.sort(key=score, reverse=True)
    return (valid_objs[0]["number"] if valid_objs else "", "apify:linkedin", rejected)


def _looks_like_error_row(item: dict[str, Any]) -> bool:
    provider_status = _norm(item.get("_status") or item.get("status"))
    if provider_status in {"error", "paused"}:
        return True
    return bool(item.get("error") or item.get("errorMessage") or item.get("statusMessage"))


def enrich_by_linkedin(
    linkedin_url: str,
    *,
    target_name: str = "",
    target_company: str = "",
    target_domain: str = "",
    exclude_phones: frozenset[str] = frozenset(),
) -> dict[str, Any]:
    result: dict[str, Any] = {
        "status": "not_found",
        "provider": "apify",
        "actor": "",
        "email": "",
        "phone": "",
        "email_candidates": [],
        "phone_candidates": [],
        "rejected_email_candidates": [],
        "rejected_phone_candidates": [],
        "returned_name": "",
        "returned_company": "",
        "returned_domain": "",
        "returned_linkedin": "",
        "job_title": "",
        "errors": [],
        "attempts": [],
        "identity_confidence": 0.0,
        "identity_reasons": [],
        "email_source": "",
        "phone_source": "",
    }
    normalized = normalize_linkedin_url(linkedin_url)
    if not normalized or not configured():
        result["status"] = "not_configured" if not normalized else "provider_unavailable"
        if not normalized:
            result["errors"].append("invalid_linkedin")
        return result

    actors = configured_contact_actors()
    for actor_id in actors:
        payload = build_input(actor_id, normalized, target_name, _host(target_domain))
        attempt = {"actor": actor_id, "status": "started", "records": 0}
        try:
            rows = run_actor_get_dataset_items(actor_id, payload)
        except ApifyAPIError as exc:
            attempt["status"] = "error"
            attempt["error"] = str(exc)[:500]
            result["attempts"].append(attempt)
            result["errors"].append(str(exc)[:500])
            continue
        attempt["records"] = len(rows)
        if not rows:
            attempt["status"] = "not_found"
            result["attempts"].append(attempt)
            continue

        valid_rows = []
        rejection_reasons: list[str] = []
        row_diagnostics: list[dict[str, Any]] = []
        for row in rows:
            if not isinstance(row, dict) or _looks_like_error_row(row):
                continue
            profile = _extract_profile(row)
            employer_match = row.get("employerMatch")
            if employer_match is None:
                employer_match = row.get("employer_match")
            ok, reasons, identity_meta = _identity_diagnostics(
                normalized, target_name, target_company, target_domain, profile, employer_match
            )
            row_diagnostics.append({
                "returned_name": profile.get("name", ""),
                "returned_company": profile.get("company", ""),
                "returned_domain": profile.get("domain", ""),
                "returned_linkedin": profile.get("linkedin", ""),
                "provider_status": _text(row.get("_status") or row.get("status")),
                "company_association": identity_meta["company_association"],
                "company_association_confidence": identity_meta["company_association_confidence"],
                "company_association_basis": identity_meta["company_association_basis"],
                "provider_employer_match": identity_meta["provider_employer_match"],
                "reasons": reasons,
            })
            if not ok:
                rejection_reasons.extend(reasons)
                continue
            valid_rows.append((row, profile, reasons, identity_meta))

        attempt["diagnostics"] = row_diagnostics[:5]

        if not valid_rows:
            attempt["status"] = "identity_rejected"
            attempt["reasons"] = list(dict.fromkeys(rejection_reasons))
            result["identity_reasons"] = attempt["reasons"]
            result["attempts"].append(attempt)
            continue

        # Prefer rows with a returned exact LinkedIn URL, then name/company, then contacts.
        def row_rank(entry: tuple[dict[str, Any], dict[str, str], list[str], dict[str, Any]]) -> tuple[int, int, int, int, int]:
            row, profile, reasons, identity_meta = entry
            company_rank = {"matched": 3, "unknown": 2, "mismatch": 1}.get(
                identity_meta.get("company_association"), 0
            )
            exact_li = int(bool(profile.get("linkedin")))
            name = int(bool(profile.get("name")))
            contacts = int(bool(_extract_emails(row) or _phone_objects(row)))
            return (company_rank, contacts, exact_li, name, -len(reasons))

        row, profile, identity_reasons, identity_meta = sorted(valid_rows, key=row_rank, reverse=True)[0]
        emails = _candidate_emails(_extract_emails(row), target_domain)
        selected_email, rejected_emails = _select_contact_email(
            emails, target_domain, identity_meta.get("company_association", "unknown")
        )
        phones = _phone_objects(row)
        phone, phone_source, rejected = _candidate_phones(phones, exclude_phones)
        if identity_meta.get("company_association") == "mismatch":
            mismatch_rejected = [f"company_mismatch_phone:{p.get('number', '')}" for p in phones if p.get("number")]
            rejected = list(dict.fromkeys(mismatch_rejected + rejected))
            phone = ""
            phone_source = ""

        result.update({
            "actor": actor_id,
            "company_association_reasons": identity_meta.get("company_association_reasons", []),
            "returned_name": profile.get("name", ""),
            "returned_company": profile.get("company", ""),
            "returned_domain": profile.get("domain", ""),
            "returned_linkedin": profile.get("linkedin", ""),
            "job_title": profile.get("job_title", ""),
            "email_candidates": emails,
            "rejected_email_candidates": rejected_emails,
            "rejected_phone_candidates": rejected,
            "identity_reasons": identity_reasons,
            "identity_confidence": 1.0 if profile.get("linkedin") else (0.9 if profile.get("name") else 0.75),
            "company_association": identity_meta.get("company_association", "unknown"),
            "company_association_confidence": identity_meta.get("company_association_confidence", 0.0),
            "company_association_basis": identity_meta.get("company_association_basis", ""),
            "provider_employer_match": identity_meta.get("provider_employer_match"),
            "requested_company": target_company,
            "requested_domain": _host(target_domain),
        })
        if selected_email:
            result["email"] = selected_email
            result["email_source"] = f"apify:{actor_id}"
        if phone:
            result["phone"] = phone
            result["phone_source"] = f"apify:{actor_id}"
            result["phone_candidates"] = [phone]
        elif phones and identity_meta.get("company_association") != "mismatch":
            result["phone_candidates"] = [p.get("number", "") for p in phones if p.get("number")]
        else:
            result["phone_candidates"] = []

        if result["email"] or result["phone"]:
            result["status"] = "found"
            attempt["status"] = "found"
            attempt["email"] = bool(result["email"])
            attempt["phone"] = bool(result["phone"])
            result["attempts"].append(attempt)
            break
        attempt["status"] = "no_usable_contact"
        result["attempts"].append(attempt)

    return result
