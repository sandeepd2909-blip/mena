"""Official UAE MoIAT Industrial Production License Directory integration.

Company discovery is deterministic and source-of-truth driven:
- official MoIAT Industrial Production License Directory page
- official XML export endpoint linked by the directory
- no AI-generated company names

The XML parser is intentionally tolerant of minor schema/tag-name changes while
still requiring a valid, complete XML document and a recognizable factory name
for every delivered record.
"""
from __future__ import annotations

import hashlib
import json
import re
import time
import os
import shutil
import subprocess
import tempfile
import threading
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import requests

try:
    from lxml import etree as LET
except Exception:  # pragma: no cover - optional recovery parser
    LET = None

from .config import PROJECT_ROOT, settings

MOIAT_DIRECTORY_URL = "https://il.moiat.gov.ae/en/OpenData/IPLDirectory"
MOIAT_XML_URL = "https://il.moiat.gov.ae/en/OpenData/ExporttoXML"
MOIAT_XLSX_URL = "https://il.moiat.gov.ae/en/OpenData/ExporttoExcel"
MOIAT_HTML_URL = MOIAT_DIRECTORY_URL
MOIAT_MAIN_ACTIVITY_URL = "https://il.moiat.gov.ae/en/AjaxRequests/GetMainActivities?LoadOldActivities=true"
MOIAT_SEARCH_URL = "https://il.moiat.gov.ae/en/OpenData/SearchIPLDirectory"

TARGET_SEGMENTS = [
    "Industrial & Building Material Manufacturers",
    "Food & Beverage (F&B) Manufacturers & Distributors",
    "Raw Material & Commodity Wholesalers",
    "Multi-Site 3PL & Warehousing Providers",
    "Industrial Equipment & Spare Parts Distributors",
]

# Exact Main Activity choices requested for the UAE MoIAT directory filter.
MOIAT_MAIN_ACTIVITIES = [
    ("01", "Crop and animal production, hunting and related service activities"),
    ("02", "Forestry and logging"),
    ("08", "Other mining and quarrying"),
    ("10", "Manufacture of food products"),
    ("11", "Manufacture of beverages"),
    ("12", "Manufacture of tobacco products"),
    ("13", "Manufacture of textiles"),
    ("14", "Manufacture of wearing apparel"),
    ("15", "Manufacture of leather and related products"),
    ("16", "Manufacture of wood and of products of wood and cork, except furniture; manufacture of articles of straw and plaiting materials"),
    ("17", "Manufacture of paper and paper products"),
    ("18", "Printing and reproduction of recorded media"),
    ("19", "Manufacture of coke and refined petroleum products"),
    ("20", "Manufacture of chemicals and chemical products"),
    ("21", "Manufacture of pharmaceuticals, medicinal chemical and botanical products"),
    ("22", "Manufacture of rubber and plastics products"),
    ("23", "Manufacture of other non-metallic mineral products"),
    ("24", "Manufacture of basic metals"),
    ("25", "Manufacture of fabricated metal products, except machinery and equipment"),
    ("26", "Manufacture of optical instruments and photographic equipment"),
    ("27", "Manufacture of electrical equipment"),
    ("28", "Manufacture of machinery and equipment n.e.c"),
    ("29", "Manufacture of motor vehicles, trailers and semi-trailers"),
    ("30", "Manufacture of other transport equipment"),
    ("31", "Manufacture of furniture"),
    ("32", "Other manufacturing"),
    ("35", "Electricity, gas, steam and air conditioning supply"),
    ("36", "Water collection, treatment and supply"),
    ("37", "Sewerage"),
    ("38", "Waste collection, treatment, and disposal activities; materials recovery"),
    ("39", "Remediation activities and other waste management services"),
]
MAIN_ACTIVITY_LABELS = dict(MOIAT_MAIN_ACTIVITIES)
MAIN_ACTIVITY_CODES = tuple(code for code, _ in MOIAT_MAIN_ACTIVITIES)

# Deterministic mapping only. These codes are based on the directory's visible
# ISIC-style Main Activity / Sub Activity taxonomy and product HS classifications.
# Keyword filters are applied to source-provided activity/product/factory-name text;
# they do not generate or invent companies.
SEGMENT_RULES: dict[str, dict[str, Any]] = {
    TARGET_SEGMENTS[0]: {
        "main_activity_prefixes": ("16", "22", "23", "24", "25", "27", "28", "31"),
        "sub_activity_keywords": (
            "building", "construction", "cement", "concrete", "gypsum", "glass",
            "ceramic", "tile", "tiles", "marble", "granite", "stone", "brick",
            "steel", "iron", "aluminium", "aluminum", "metal", "pipe", "pipes",
            "profiles", "doors", "windows", "insulation", "roof", "roofing",
        ),
        "product_keywords": (
            "cement", "concrete", "gypsum", "glass", "ceramic", "tile", "marble",
            "granite", "stone", "brick", "steel", "iron", "aluminium", "aluminum",
            "metal", "pipe", "door", "window", "insulation", "roof", "cladding",
        ),
    },
    TARGET_SEGMENTS[1]: {
        "main_activity_prefixes": ("10", "11"),
        "sub_activity_keywords": (
            "food", "meat", "fish", "fruit", "vegetable", "oil", "dairy", "grain",
            "bakery", "beverage", "drink", "water", "juice", "feed", "prepared food",
        ),
        "product_keywords": (
            "food", "meat", "fish", "fruit", "vegetable", "oil", "dairy", "milk",
            "cheese", "grain", "flour", "sugar", "bread", "beverage", "drink", "water",
            "juice", "coffee", "tea", "chocolate", "frozen", "edible",
        ),
    },
    TARGET_SEGMENTS[2]: {
        # The industrial-production register is not a general commercial-license register.
        # A company is treated as a raw-material/commodity wholesaler only when the
        # source data contains a wholesale/trading signal AND raw-material/commodity
        # evidence, or when the source explicitly classifies the activity as wholesale.
        "main_activity_prefixes": ("46",),
        "sub_activity_keywords": (
            "wholesale", "trading", "commodity", "commodities", "raw material",
            "raw materials", "metal trading", "chemical trading", "mineral trading",
            "general trading", "materials trading",
        ),
        "product_keywords": (
            "raw material", "raw materials", "commodity", "commodities", "ore", "mineral",
            "metal", "steel", "iron", "aluminium", "aluminum", "chemical", "fertilizer",
            "polymer", "resin", "plastic raw", "wood", "paper pulp", "copper", "zinc",
            "nickel", "lead", "tin", "coal", "coke", "petroleum",
        ),
        "name_keywords": (
            "wholesale", "trading", "traders", "commodity", "commodities", "raw material",
            "general trading", "materials trading",
        ),
        "requires_trade_signal": True,
        "requires_product_signal": True,
    },
    TARGET_SEGMENTS[3]: {
        # 49/52/53 are accepted when present in the directory taxonomy. The text rules
        # also catch licensed records whose sub-activity labels explicitly mention these services.
        "main_activity_prefixes": ("49", "52", "53"),
        "sub_activity_keywords": (
            "warehousing", "warehouse", "storage", "logistics", "freight", "transport",
            "distribution center", "distribution centre", "fulfilment", "fulfillment",
            "third party logistics", "3pl", "cargo", "handling",
        ),
        "product_keywords": (),
        "name_keywords": (
            "logistics", "warehouse", "warehousing", "3pl", "freight", "fulfillment",
            "fulfilment", "distribution center", "distribution centre",
        ),
    },
    TARGET_SEGMENTS[4]: {
        "main_activity_prefixes": ("28", "29", "30", "33", "46"),
        "sub_activity_keywords": (
            "machinery", "equipment", "industrial equipment", "machinery and equipment",
            "parts", "spare parts", "motor", "pump", "compressor", "bearing", "valve",
            "generator", "electrical equipment", "vehicle parts", "motor vehicle parts",
            "maintenance and repair of machinery", "equipment repair",
        ),
        "product_keywords": (
            "machinery", "equipment", "spare part", "parts", "pump", "valve", "bearing",
            "compressor", "motor", "generator", "transformer", "gear", "vehicle part",
            "automotive part", "industrial part", "tool", "machine",
        ),
        "name_keywords": (
            "equipment", "machinery", "spare parts", "parts", "industrial supplies",
            "trading", "distributor", "distribution",
        ),
    },
}


@dataclass(frozen=True)
class MoIATCompany:
    company_key: str
    company_name: str
    company_name_ar: str
    emirate: str
    phone: str
    email: str
    activities: tuple[dict[str, str], ...]
    products: tuple[dict[str, str], ...]
    matched_segments: tuple[str, ...]
    source_url: str = MOIAT_DIRECTORY_URL

    def as_dict(self) -> dict[str, Any]:
        return {
            "company_key": self.company_key,
            "company_name": self.company_name,
            "company_name_ar": self.company_name_ar,
            "emirate": self.emirate,
            "phone": self.phone,
            "email": self.email,
            "activities": list(self.activities),
            "products": list(self.products),
            "matched_segments": list(self.matched_segments),
            "source_url": self.source_url,
            "source_type": "MoIAT Industrial Production License Directory",
        }


class MoIATDirectoryError(RuntimeError):
    pass


def _cache_paths() -> tuple[Path, Path]:
    """Return stable project-relative cache paths, independent of the launch CWD."""
    base = Path(getattr(settings, "moiat_cache_dir", "data/moiat"))
    if not base.is_absolute():
        base = PROJECT_ROOT / base
    return base / "directory.xml", base / "directory_all_v2.json"


def _write_directory_cache(rows: Iterable[MoIATCompany]) -> None:
    """Atomically write only fully parsed official-directory records to JSON cache."""
    _, json_path = _cache_paths()
    json_path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps([row.as_dict() for row in rows], indent=2, ensure_ascii=False)
    temp_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=str(json_path.parent),
            prefix=json_path.name + ".", suffix=".tmp", delete=False,
        ) as tmp:
            tmp.write(payload)
            temp_path = Path(tmp.name)
        os.replace(temp_path, json_path)
    finally:
        if temp_path and temp_path.exists():
            try:
                temp_path.unlink()
            except OSError:
                pass


def _read_cached_directory() -> tuple[list[MoIATCompany], bool] | None:
    """Read cached source rows immediately. Returns rows and whether TTL expired."""
    _, json_path = _cache_paths()
    if not json_path.exists():
        return None
    try:
        raw = json.loads(json_path.read_text(encoding="utf-8"))
        if not isinstance(raw, list) or not raw:
            return None
        rows: list[MoIATCompany] = []
        for item in raw:
            if not isinstance(item, dict):
                continue
            name = _clean(item.get("company_name"))
            emirate = _clean(item.get("emirate"))
            if not name or not emirate:
                continue
            activities = tuple(dict(x) for x in (item.get("activities") or []) if isinstance(x, dict))
            products = tuple(dict(x) for x in (item.get("products") or []) if isinstance(x, dict))
            base = MoIATCompany(
                company_key=_stable_live_company_key(name, emirate),
                company_name=name,
                company_name_ar=_clean(item.get("company_name_ar")),
                emirate=emirate,
                phone=_clean(item.get("phone")),
                email=_clean(item.get("email")),
                activities=activities,
                products=products,
                matched_segments=(),
                source_url=_clean(item.get("source_url")) or MOIAT_DIRECTORY_URL,
            )
            matched = tuple(item.get("matched_segments") or classify_company(base))
            rows.append(MoIATCompany(**{**base.__dict__, "matched_segments": matched}))
        if not rows:
            return None
        ttl = max(0, int(getattr(settings, "moiat_cache_ttl_seconds", 21600)))
        stale = (time.time() - json_path.stat().st_mtime) > ttl
        return rows, stale
    except (OSError, ValueError, TypeError, KeyError):
        # Never trust a truncated cache file; atomically written files normally avoid this.
        return None


_REFRESH_GUARD = threading.Lock()
_REFRESH_IN_PROGRESS = False


def _refresh_directory_cache_worker() -> None:
    global _REFRESH_IN_PROGRESS
    try:
        rows = load_directory(force=True)
        if rows:
            _write_directory_cache(rows)
            print(f"[MoIAT cache] refreshed {len(rows)} official company records", flush=True)
    except Exception as exc:
        print(f"[MoIAT cache] background refresh failed: {type(exc).__name__}: {exc}", flush=True)
    finally:
        with _REFRESH_GUARD:
            _REFRESH_IN_PROGRESS = False


def _start_directory_cache_refresh() -> None:
    """Refresh MoIAT in the background so searches can use the existing snapshot."""
    global _REFRESH_IN_PROGRESS
    with _REFRESH_GUARD:
        if _REFRESH_IN_PROGRESS:
            return
        _REFRESH_IN_PROGRESS = True
    thread = threading.Thread(target=_refresh_directory_cache_worker, name="moiat-cache-refresh", daemon=True)
    thread.start()


def normalize_main_activity_code(value: Any) -> str:
    text = _clean(value) if "_clean" in globals() else str(value or "").strip()
    if not text:
        return ""
    import re as _re
    # MoIAT search results expose ISIC activity rows as 7-digit codes (e.g.
    # 1030001), while the UI filter uses the top-level two-digit Main Activity
    # code (10). Accept both representations plus common decimal forms.
    m = _re.fullmatch(r"(\d{2})(?:\.\d+|\d{2,})?", text)
    if m:
        return m.group(1)
    m = _re.search(r"(?<!\d)(\d{2})(?!\d)", text)
    return m.group(1) if m else ""


def _norm(value: Any) -> str:
    value = str(value or "")
    value = re.sub(r"[\u200b-\u200f\ufeff]", "", value)
    return " ".join(value.casefold().split())


def _local(tag: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", tag.casefold().split("}")[-1])


def _clean(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def _text_value(node: ET.Element) -> str:
    # Prefer direct text, then concatenated descendant text.
    direct = _clean(node.text)
    if direct:
        return direct
    return _clean(" ".join(x.text or "" for x in node.iter() if x.text))


def _descendants(node: ET.Element) -> Iterable[ET.Element]:
    return node.iter()


def _first_field(node: ET.Element, aliases: set[str]) -> str:
    for child in _descendants(node):
        key = _local(child.tag)
        if key in aliases:
            value = _text_value(child)
            if value:
                return value
    # Some exports use attributes.
    for child in _descendants(node):
        for k, v in child.attrib.items():
            if _local(k) in aliases and _clean(v):
                return _clean(v)
    return ""


def _field(node: ET.Element, aliases: set[str]) -> str:
    return _first_field(node, aliases)


NAME_EN = {
    "factorynameen", "factorynameenglish", "factoryname", "establishmentnameen",
    "establishmentnameenglish", "companyname", "companynameen", "nameen",
}
NAME_AR = {"factorynamear", "factorynamearabic", "establishmentnamear", "companynamear", "namear"}
EMIRATE = {"emirate", "emirates", "emirateen", "locationemirate"}
PHONE = {"factoryphonenumber", "factoryphone", "phonenumber", "phone", "telephone", "tel", "mobile"}
EMAIL = {"factoryemail", "email", "emailaddress"}
HS = {"hscode", "producthscode", "producthscodeen", "productcode"}
PRODUCT_EN = {"productdescriptionen", "productdescription", "descriptionen", "productnameen", "productname"}
PRODUCT_AR = {"productdescriptionar", "descriptionar", "productnamear"}
ISIC = {"isic4code", "isiccode", "activitycode", "mainactivitycode", "mainactivityid", "mainactivity", "mainisic4code", "isic4"}
ACTIVITY_EN = {"activityen", "activitynameen", "activity", "activitydescriptionen", "activityname"}
ACTIVITY_AR = {"activityar", "activitydescriptionar", "activitynamear"}


def _looks_like_record(node: ET.Element) -> bool:
    name = _field(node, NAME_EN)
    emirate = _field(node, EMIRATE)
    return bool(name and emirate)


def _candidate_records(root: ET.Element) -> list[ET.Element]:
    candidates = [node for node in root.iter() if _looks_like_record(node)]
    # Keep the smallest record-bearing nodes. If a parent also has a nested record,
    # discard the parent to avoid duplicating the complete directory.
    chosen: list[ET.Element] = []
    ids = {id(x): x for x in candidates}
    for node in candidates:
        has_record_descendant = any(desc is not node and id(desc) in ids for desc in node.iter())
        if not has_record_descendant:
            chosen.append(node)
    return chosen


def _extract_nested(node: ET.Element) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
    products: list[dict[str, str]] = []
    activities: list[dict[str, str]] = []
    for child in node.iter():
        key = _local(child.tag)
        hs = _field(child, HS) if key not in HS else _text_value(child)
        if hs:
            desc = _field(child, PRODUCT_EN)
            if desc or key in HS:
                item = {"hs_code": hs, "description_en": desc, "description_ar": _field(child, PRODUCT_AR)}
                if item not in products:
                    products.append(item)
        isic = _field(child, ISIC) if key not in ISIC else _text_value(child)
        if isic:
            desc = _field(child, ACTIVITY_EN)
            if desc or key in ISIC:
                item = {"isic4_code": isic, "activity_en": desc, "activity_ar": _field(child, ACTIVITY_AR)}
                if item not in activities:
                    activities.append(item)
    return products, activities


def _company_key(name: str, emirate: str, phone: str, email: str) -> str:
    raw = "|".join(_norm(x) for x in (name, emirate, phone, email))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20]


def _stable_live_company_key(name: str, emirate: str) -> str:
    """Stable company identity for the live directory, independent of contact-field changes."""
    raw = "|".join((_norm(name), _norm(emirate)))
    return "live-" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20]


def _matches(rule: dict[str, Any], company: MoIATCompany) -> bool:
    prefixes = rule.get("main_activity_prefixes", ())
    keywords_a = tuple(_norm(x) for x in rule.get("sub_activity_keywords", ()))
    keywords_p = tuple(_norm(x) for x in rule.get("product_keywords", ()))
    keywords_n = tuple(_norm(x) for x in rule.get("name_keywords", ()))

    activities = company.activities
    products = company.products
    activity_codes_match = any(_norm(a.get("isic4_code"))[:2] in prefixes for a in activities)
    activity_text = " | ".join(_norm(a.get("activity_en")) for a in activities)
    product_text = " | ".join(_norm(p.get("description_en")) for p in products)
    name_text = _norm(company.company_name)
    activity_signal = any(k and k in activity_text for k in keywords_a)
    product_signal = any(k and k in product_text for k in keywords_p)
    name_signal = any(k and k in name_text for k in keywords_n)
    if rule.get("requires_trade_signal"):
        trade_signal = (
            any(k in activity_text for k in ("wholesale", "trading", "trader", "trade"))
            or any(k in name_text for k in ("wholesale", "trading", "traders", "commodity", "commodities"))
            or activity_codes_match
        )
        if not trade_signal:
            return False
        if rule.get("requires_product_signal"):
            return product_signal
        return True
    return activity_codes_match or activity_signal or product_signal or name_signal


def classify_company(company: MoIATCompany) -> tuple[str, ...]:
    matched = [segment for segment, rule in SEGMENT_RULES.items() if _matches(rule, company)]
    return tuple(matched)


def _parse_records_from_root(root: Any) -> list[MoIATCompany]:
    nodes = _candidate_records(root)
    records: dict[str, MoIATCompany] = {}
    for node in nodes:
        name = _field(node, NAME_EN)
        if not name:
            continue
        name_ar = _field(node, NAME_AR)
        emirate = _field(node, EMIRATE)
        phone = _field(node, PHONE)
        email = _field(node, EMAIL)
        products, activities = _extract_nested(node)
        base = MoIATCompany(
            company_key=_company_key(name, emirate, phone, email),
            company_name=name,
            company_name_ar=name_ar,
            emirate=emirate,
            phone=phone,
            email=email,
            activities=tuple(activities),
            products=tuple(products),
            matched_segments=(),
        )
        matched = classify_company(base)
        records[base.company_key] = MoIATCompany(**{**base.__dict__, "matched_segments": matched})
    return list(records.values())


def parse_moiat_xml(xml_bytes: bytes, *, allow_recovery: bool = False) -> list[MoIATCompany]:
    if not xml_bytes or b"<" not in xml_bytes:
        raise MoIATDirectoryError("MoIAT export is empty or not XML")
    stripped = xml_bytes.rstrip()
    if not stripped.endswith(b">") and not allow_recovery:
        raise MoIATDirectoryError("MoIAT export appears truncated")
    try:
        root = ET.fromstring(xml_bytes)
        return _parse_records_from_root(root)
    except ET.ParseError as exc:
        if not allow_recovery or LET is None:
            raise MoIATDirectoryError(f"Invalid MoIAT XML: {exc}") from exc
        try:
            parser = LET.XMLParser(recover=True, huge_tree=True, no_network=True)
            recovered_root = LET.fromstring(xml_bytes, parser=parser)
            rows = _parse_records_from_root(recovered_root)
            if not rows:
                raise MoIATDirectoryError(f"Invalid MoIAT XML: {exc}")
            return rows
        except Exception as rec_exc:
            if isinstance(rec_exc, MoIATDirectoryError):
                raise rec_exc
            raise MoIATDirectoryError(f"Invalid MoIAT XML: {exc}") from rec_exc


def _expected_directory_count(session: requests.Session) -> int | None:
    """Read the official page's visible directory total when the server exposes it."""
    try:
        r = session.get(
            getattr(settings, "moiat_directory_url", MOIAT_DIRECTORY_URL),
            timeout=min(int(getattr(settings, "moiat_timeout", 90)), 45),
            headers={"User-Agent": "Mozilla/5.0 (compatible; MENA-UAE-Prospecting-Engine/7.8.40)"},
        )
        r.raise_for_status()
        text = re.sub(r"\s+", " ", r.text or "")
        m = re.search(r"Number of Entries\s*(?:</[^>]+>\s*)?([0-9][0-9,]*)", text, re.I)
        if m:
            return int(m.group(1).replace(",", ""))
        # Some server responses separate the number from the label in markup.
        m = re.search(r"Number of Entries.{0,500}?([0-9][0-9,]{2,})", text, re.I)
        return int(m.group(1).replace(",", "")) if m else None
    except Exception:
        return None


def _parse_moiat_html(html_bytes: bytes, expected_count: int | None = None) -> list[MoIATCompany]:
    """Parse the official directory page when MoIAT's export endpoints fail.

    The directory page itself is an official MoIAT source.  We only accept it when
    the page advertises a substantial number of establishments and we recover at
    least 90% (or the configured floor) of those factory rows.  This prevents a
    partial/error HTML response from silently becoming the company source.
    """
    if not html_bytes:
        raise MoIATDirectoryError("MoIAT directory HTML is empty")
    try:
        from bs4 import BeautifulSoup
    except Exception as exc:  # pragma: no cover - dependency is pinned
        raise MoIATDirectoryError(f"BeautifulSoup is required for MoIAT HTML fallback: {exc}") from exc
    soup = BeautifulSoup(html_bytes, "html.parser")
    page_text = re.sub(r"\s+", " ", soup.get_text(" ", strip=True) or "")
    m = re.search(r"Number of Entries\s*([0-9][0-9,]*)", page_text, re.I)
    page_count = int(m.group(1).replace(",", "")) if m else expected_count
    if expected_count is None:
        expected_count = page_count

    header_map: dict[str, int] | None = None
    rows: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None

    def norm_cell(value: str) -> str:
        return re.sub(r"\s+", " ", value or "").strip()

    def header_mapping(cells: list[str]) -> dict[str, int] | None:
        mapping: dict[str, int] = {}
        for i, c in enumerate(cells):
            k = re.sub(r"[^a-z0-9]", "", c.casefold())
            if "factorynameen" in k or k in {"factorynameenglish", "factoryname"}:
                mapping["name"] = i
            elif "factorynamear" in k or k in {"factorynamearabic"}:
                mapping["name_ar"] = i
            elif "factoryphone" in k or k in {"phonenumber", "phone", "telephone", "tel", "mobile"}:
                mapping["phone"] = i
            elif "factoryemail" in k or k in {"email", "emailaddress"}:
                mapping["email"] = i
            elif k in {"emirate", "emirates", "locationemirate"}:
                mapping["emirate"] = i
        return mapping if {"name", "emirate"}.issubset(mapping) else None

    def factory_from_current(raw: dict[str, Any]) -> MoIATCompany:
        base = MoIATCompany(
            company_key=_company_key(raw.get("company_name", ""), raw.get("emirate", ""), raw.get("phone", ""), raw.get("email", "")),
            company_name=raw.get("company_name", ""),
            company_name_ar=raw.get("company_name_ar", ""),
            emirate=raw.get("emirate", ""),
            phone=raw.get("phone", ""),
            email=raw.get("email", ""),
            activities=tuple(raw.get("activities", [])),
            products=tuple(raw.get("products", [])),
            matched_segments=(),
        )
        return MoIATCompany(**{**base.__dict__, "matched_segments": classify_company(base)})

    # Traverse rows in document order.  The official page renders each factory row
    # followed by nested Products/Activities rows, so keeping the latest factory as
    # the active context lets us associate the source-provided details without
    # inventing any company data.
    for tr in soup.find_all("tr"):
        cells = [norm_cell(td.get_text(" ", strip=True)) for td in tr.find_all(["th", "td"], recursive=False)]
        if not cells:
            continue
        mapping = header_mapping(cells)
        if mapping:
            header_map = mapping
            continue

        if header_map:
            name = norm_cell(cells[header_map["name"]]) if header_map["name"] < len(cells) else ""
            emirate = norm_cell(cells[header_map["emirate"]]) if header_map["emirate"] < len(cells) else ""
            if name and emirate and name.casefold() not in {"factory name (en)", "factory name"}:
                if current and current.get("company_name"):
                    rows.append(current)
                current = {
                    "company_name": name,
                    "company_name_ar": norm_cell(cells[header_map["name_ar"]]) if header_map.get("name_ar", 999) < len(cells) else "",
                    "emirate": emirate,
                    "phone": norm_cell(cells[header_map["phone"]]) if header_map.get("phone", 999) < len(cells) else "",
                    "email": norm_cell(cells[header_map["email"]]) if header_map.get("email", 999) < len(cells) else "",
                    "activities": [],
                    "products": [],
                }
                continue

        if not current:
            continue
        first = cells[0]
        # Activity rows use the official 7-digit ISIC4-derived activity code.
        if re.fullmatch(r"\d{7}", re.sub(r"\s+", "", first)) and len(cells) >= 2:
            val = {"isic4_code": re.sub(r"\s+", "", first), "activity_en": cells[1], "activity_ar": cells[2] if len(cells) > 2 else ""}
            if val not in current["activities"]:
                current["activities"].append(val)
            continue
        # Product rows carry an 8-12 digit HS code.
        if re.fullmatch(r"\d{8,12}", re.sub(r"\s+", "", first)) and len(cells) >= 2:
            val = {"hs_code": re.sub(r"\s+", "", first), "description_en": cells[1], "description_ar": cells[2] if len(cells) > 2 else ""}
            if val not in current["products"]:
                current["products"].append(val)

    if current and current.get("company_name"):
        rows.append(current)

    # Deduplicate on the same stable key used by XML/XLSX parsing.
    companies: dict[str, MoIATCompany] = {}
    for raw in rows:
        if not raw.get("company_name") or not raw.get("emirate"):
            continue
        company = factory_from_current(raw)
        companies[company.company_key] = company

    out = list(companies.values())
    floor = int(getattr(settings, "moiat_min_records", 1000))
    if expected_count and expected_count >= floor:
        ratio = float(getattr(settings, "moiat_page_count_ratio", 0.90))
        floor = max(floor, int(expected_count * ratio))
    if len(out) < floor:
        raise MoIATDirectoryError(f"MoIAT directory HTML returned too few establishments: {len(out)}; expected at least {floor}")
    return out


def download_moiat_html(*, force: bool = False) -> bytes:
    """Download/cache the official directory HTML as a transport fallback."""
    _, json_path = _cache_paths()
    html_path = json_path.with_suffix(".html")
    ttl = int(getattr(settings, "moiat_cache_ttl_seconds", 21600))
    if not force and html_path.exists() and (time.time() - html_path.stat().st_mtime) < ttl:
        data = html_path.read_bytes()
        if data:
            return data
    session = _new_session()
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/154 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Encoding": "identity",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
    }
    last_error = ""
    attempts = int(getattr(settings, "moiat_download_attempts", 6))
    for attempt in range(1, attempts + 1):
        try:
            r = session.get(getattr(settings, "moiat_directory_url", MOIAT_HTML_URL), timeout=int(getattr(settings, "moiat_timeout", 90)), headers=headers, allow_redirects=True)
            r.raise_for_status()
            data = r.content
            if b"<html" not in data[:10000].lower() and b"<!doctype" not in data[:10000].lower():
                raise MoIATDirectoryError("MoIAT directory response did not look like HTML")
            # Parse before caching so an error/partial page can never become the source cache.
            parsed = _parse_moiat_html(data, expected_count=None)
            html_path.parent.mkdir(parents=True, exist_ok=True)
            html_path.write_bytes(data)
            _write_directory_cache(parsed)
            return data
        except Exception as exc:
            last_error = str(exc)
            try: session.close()
            except Exception: pass
            session = _new_session()
            if attempt < attempts:
                time.sleep(min(2.0 * attempt, 8.0))
    raise MoIATDirectoryError(f"Unable to retrieve complete MoIAT directory HTML: {last_error}")


def _download_stream(session: requests.Session, url: str, *, max_seconds: int) -> tuple[bytes, dict[str, str]]:
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/154 Safari/537.36",
        "Accept": "application/xml,text/xml,*/*;q=0.8",
        "Accept-Encoding": "identity",
        "Referer": getattr(settings, "moiat_directory_url", MOIAT_DIRECTORY_URL),
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
        "Connection": "keep-alive",
    }
    chunks: list[bytes] = []
    r = session.get(url, timeout=max_seconds, headers=headers, stream=True, allow_redirects=True)
    r.raise_for_status()
    for chunk in r.iter_content(chunk_size=1024 * 128):
        if chunk:
            chunks.append(chunk)
    data = b"".join(chunks)
    return data, {k.casefold(): v for k, v in r.headers.items()}


def _validate_download(data: bytes, headers: dict[str, str], expected_count: int | None) -> list[MoIATCompany]:
    if not data:
        raise MoIATDirectoryError("MoIAT XML export is empty")
    content_type = headers.get("content-type", "")
    if "html" in content_type.casefold() and b"<html" in data[:2000].lower():
        raise MoIATDirectoryError("MoIAT export returned an HTML page instead of XML")
    declared = headers.get("content-length")
    if declared and declared.isdigit() and "content-encoding" not in headers:
        if len(data) != int(declared):
            raise MoIATDirectoryError(f"MoIAT XML download incomplete: received {len(data)} of {declared} bytes")
    # First try strict parsing. If the server delivered a complete-but-malformed XML,
    # allow recovery only when the recovered record count is consistent with the
    # official directory count/floor. We never accept a small partial document.
    try:
        rows = parse_moiat_xml(data, allow_recovery=False)
        record_count = _count_recognizable_records(data)
        _require_directory_floor(record_count, expected_count)
        return rows
    except MoIATDirectoryError as strict_exc:
        if LET is None:
            raise strict_exc
        recovered = parse_moiat_xml(data, allow_recovery=True)
        recovered_count = len(_candidate_records(LET.fromstring(data, parser=LET.XMLParser(recover=True, huge_tree=True, no_network=True))))
        _require_directory_floor(recovered_count, expected_count)
        return recovered


def _count_recognizable_records(data: bytes) -> int:
    root = ET.fromstring(data)
    return len(_candidate_records(root))


def _require_directory_floor(record_count: int, expected_count: int | None) -> None:
    configured_floor = int(getattr(settings, "moiat_min_records", 2500))
    if expected_count and expected_count >= configured_floor:
        # The export can move by a few rows while the page and export are generated;
        # require at least 99% of the official page count, never a fabricated fill-in.
        ratio = float(getattr(settings, "moiat_page_count_ratio", 0.90))
        floor = max(configured_floor, int(expected_count * ratio))
    else:
        floor = configured_floor
    if record_count < floor:
        raise MoIATDirectoryError(f"MoIAT export returned too few recognizable establishments: {record_count}; expected at least {floor}")


def download_moiat_xml(*, force: bool = False) -> bytes:
    xml_path, json_path = _cache_paths()
    xml_path.parent.mkdir(parents=True, exist_ok=True)
    ttl = int(getattr(settings, "moiat_cache_ttl_seconds", 21600))
    if not force and xml_path.exists() and (time.time() - xml_path.stat().st_mtime) < ttl:
        data = xml_path.read_bytes()
        if data:
            return data

    session = _new_session()
    expected_count = _expected_directory_count(session)
    last_error = ""
    attempts = int(getattr(settings, "moiat_download_attempts", 6))
    for attempt in range(1, attempts + 1):
        try:
            data, headers = _download_stream(
                session,
                getattr(settings, "moiat_xml_url", MOIAT_XML_URL),
                max_seconds=int(getattr(settings, "moiat_timeout", 90)),
            )
            parsed = _validate_download(data, headers, expected_count)
            xml_path.write_bytes(data)
            _write_directory_cache(parsed)
            return data
        except Exception as exc:
            last_error = str(exc)
            # Rebuild the session after a partial response; this prevents a bad pooled
            # connection from poisoning every subsequent attempt.
            try:
                session.close()
            except Exception:
                pass
            session = _new_session()
            if attempt < attempts:
                time.sleep(min(2.0 * attempt, 8.0))
    raise MoIATDirectoryError(f"Unable to retrieve complete MoIAT XML export: {last_error}")


def _header_maps(headers: list[Any]) -> dict[str, int]:
    out: dict[str, int] = {}
    for i, value in enumerate(headers):
        key = _local(str(value or ""))
        if key:
            out[key] = i
    return out


def _cell(row: tuple[Any, ...], mapping: dict[str, int], aliases: set[str]) -> str:
    for alias in aliases:
        idx = mapping.get(alias)
        if idx is not None and idx < len(row):
            value = _clean(row[idx])
            if value:
                return value
    return ""


def parse_moiat_excel(xlsx_bytes: bytes) -> list[MoIATCompany]:
    if not xlsx_bytes.startswith(b"PK"):
        raise MoIATDirectoryError("MoIAT Excel export is not a valid XLSX file")
    try:
        from openpyxl import load_workbook
        from io import BytesIO
        wb = load_workbook(BytesIO(xlsx_bytes), read_only=True, data_only=True)
    except Exception as exc:
        raise MoIATDirectoryError(f"Unable to read MoIAT Excel export: {exc}") from exc

    grouped: dict[str, dict[str, Any]] = {}
    NAME_ALIASES = {"factorynameen", "factorynameenglish", "factoryname", "establishmentnameen", "companyname", "companynameen"}
    NAME_AR_ALIASES = {"factorynamear", "factorynamearabic", "establishmentnamear", "companynamear"}
    EMIRATE_ALIASES = {"emirate", "emirates", "locationemirate"}
    PHONE_ALIASES = {"factoryphonenumber", "factoryphone", "phonenumber", "phone", "telephone", "tel", "mobile"}
    EMAIL_ALIASES = {"factoryemail", "email", "emailaddress"}
    HS_ALIASES = {"hscode", "producthscode", "productcode"}
    PRODUCT_ALIASES = {"productdescriptionen", "productdescription", "descriptionen", "productnameen", "productname"}
    ISIC_ALIASES = {"isic4code", "isiccode", "activitycode", "mainactivitycode", "mainactivityid", "mainactivity", "mainisic4code", "isic4"}
    ACTIVITY_ALIASES = {"activityen", "activitynameen", "activity", "activitydescriptionen", "activityname"}
    seen_header_rows = 0
    for ws in wb.worksheets:
        rows = ws.iter_rows(values_only=True)
        header = None
        mapping = None
        buffered: list[tuple[Any, ...]] = []
        for _ in range(10):
            try:
                r = tuple(next(rows))
            except StopIteration:
                break
            buffered.append(r)
            m = _header_maps(list(r))
            if any(x in m for x in NAME_ALIASES) and any(x in m for x in EMIRATE_ALIASES):
                header, mapping = r, m
                break
        if mapping is None:
            continue
        seen_header_rows += 1
        for row in rows:
            row = tuple(row)
            name = _cell(row, mapping, NAME_ALIASES)
            emirate = _cell(row, mapping, EMIRATE_ALIASES)
            if not name or not emirate:
                continue
            phone = _cell(row, mapping, PHONE_ALIASES)
            email = _cell(row, mapping, EMAIL_ALIASES)
            key = _norm(name) + "|" + _norm(emirate)
            item = grouped.setdefault(key, {
                "company_name": name, "company_name_ar": _cell(row, mapping, NAME_AR_ALIASES),
                "emirate": emirate, "phone": phone, "email": email,
                "products": [], "activities": [],
            })
            if not item["phone"]: item["phone"] = phone
            if not item["email"]: item["email"] = email
            hs = _cell(row, mapping, HS_ALIASES)
            prod = _cell(row, mapping, PRODUCT_ALIASES)
            if hs or prod:
                val = {"hs_code": hs, "description_en": prod, "description_ar": ""}
                if val not in item["products"]: item["products"].append(val)
            isic = _cell(row, mapping, ISIC_ALIASES)
            act = _cell(row, mapping, ACTIVITY_ALIASES)
            if isic or act:
                val = {"isic4_code": isic, "activity_en": act, "activity_ar": ""}
                if val not in item["activities"]: item["activities"].append(val)
    if not grouped or not seen_header_rows:
        raise MoIATDirectoryError("MoIAT Excel export contained no recognizable factory rows")
    out: list[MoIATCompany] = []
    for raw in grouped.values():
        base = MoIATCompany(
            company_key=_company_key(raw["company_name"], raw["emirate"], raw["phone"], raw["email"]),
            company_name=raw["company_name"], company_name_ar=raw["company_name_ar"],
            emirate=raw["emirate"], phone=raw["phone"], email=raw["email"],
            activities=tuple(raw["activities"]), products=tuple(raw["products"]), matched_segments=(),
        )
        matched = classify_company(base)
        out.append(MoIATCompany(**{**base.__dict__, "matched_segments": matched}))
    if not out:
        raise MoIATDirectoryError("MoIAT Excel export contained no recognizable companies")
    return out



def _browser_binary() -> tuple[str, str] | tuple[None, None]:
    """Return an explicitly configured/local Chrome or Edge binary when one exists.

    Selenium 4.x can also launch a compatible browser through Selenium Manager.  The
    caller therefore must not require this function to find a browser executable.
    """
    configured = str(os.getenv("MOIAT_BROWSER_BINARY", "")).strip()
    candidates: list[tuple[str, str]] = []
    if configured:
        candidates.append(("edge" if "msedge" in configured.casefold() else "chrome", configured))
    pf = os.getenv("ProgramFiles", r"C:\\Program Files")
    pfx86 = os.getenv("ProgramFiles(x86)", r"C:\\Program Files (x86)")
    local = os.getenv("LOCALAPPDATA", "")
    candidates.extend([
        ("chrome", str(Path(pf) / "Google/Chrome/Application/chrome.exe")),
        ("chrome", str(Path(pfx86) / "Google/Chrome/Application/chrome.exe")),
        ("chrome", str(Path(local) / "Google/Chrome/Application/chrome.exe")),
        ("edge", str(Path(pf) / "Microsoft/Edge/Application/msedge.exe")),
        ("edge", str(Path(pfx86) / "Microsoft/Edge/Application/msedge.exe")),
    ])
    for kind, path in candidates:
        if path and Path(path).exists():
            return kind, path
    for name in ("chrome", "chrome.exe", "msedge", "msedge.exe"):
        path = shutil.which(name)
        if path:
            return ("edge" if "edge" in name.casefold() else "chrome", path)
    return (None, None)


def _browser_options(kind: str | None, binary: str | None, workdir: Path):
    """Build headless Chromium options without requiring a browser on PATH."""
    from selenium import webdriver

    if kind == "edge":
        options = webdriver.EdgeOptions()
    else:
        options = webdriver.ChromeOptions()
    if binary:
        options.binary_location = binary
    options.add_argument("--headless=new")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--window-size=1920,1080")
    options.add_argument("--disable-notifications")
    options.add_experimental_option("prefs", {
        "download.default_directory": str(workdir),
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True,
    })
    return options


def _browser_fetch(driver, url: str, timeout_seconds: int) -> tuple[bytes, str, int] | None:
    """Fetch a same-origin MoIAT export inside the real browser session.

    This is the important recovery path: unlike requests(), browser fetch inherits
    the cookies/session/challenge state that the live MoIAT page requires.  It also
    works for XML responses that would never be written as a downloaded file.
    """
    script = r"""
const url = arguments[0];
const done = arguments[arguments.length - 1];
(async () => {
  try {
    const response = await fetch(url, {credentials: 'include', cache: 'no-store'});
    const blob = await response.blob();
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = String(reader.result || '');
      const comma = result.indexOf(',');
      done(JSON.stringify({
        ok: true,
        status: response.status,
        content_type: response.headers.get('content-type') || '',
        final_url: response.url || url,
        body_b64: comma >= 0 ? result.slice(comma + 1) : ''
      }));
    };
    reader.onerror = () => done(JSON.stringify({ok:false, error:'FileReader failed'}));
    reader.readAsDataURL(blob);
  } catch (e) {
    done(JSON.stringify({ok:false, error:String(e)}));
  }
})();
"""
    try:
        result = driver.execute_async_script(script, url)
    except Exception:
        return None
    if not result:
        return None
    try:
        payload = json.loads(result)
    except Exception:
        return None
    if not payload.get("ok"):
        return None
    encoded = str(payload.get("body_b64") or "")
    if not encoded:
        return None
    try:
        import base64
        data = base64.b64decode(encoded, validate=True)
    except Exception:
        return None
    return data, str(payload.get("content_type") or ""), int(payload.get("status") or 0)


def _looks_like_html(data: bytes, content_type: str = "") -> bool:
    head = data[:2048].lstrip().lower()
    ctype = str(content_type or "").lower()
    return "text/html" in ctype or head.startswith(b"<!doctype html") or head.startswith(b"<html")


def _download_moiat_export_with_browser(url: str, suffix: str, *, max_seconds: int) -> bytes:
    """Fetch an official MoIAT export through a bounded real browser session.

    Strategy order:
    1. Open the official directory in headless Chrome/Edge.
    2. Fetch the export URL inside that browser session (works for XML and XLSX).
    3. For XLSX, fall back to the browser's normal download handling.
    4. Fail with a bounded, actionable error; never wait indefinitely.

    Selenium Manager is allowed to select the browser when no explicit local binary
    can be found.  This matches the successful standalone Selenium behavior on the
    user's machine.
    """
    try:
        from selenium import webdriver
        from selenium.common.exceptions import TimeoutException, WebDriverException
    except Exception as exc:
        raise MoIATDirectoryError("Browser fallback requires selenium; run pip install -r requirements.txt") from exc

    max_seconds = max(30, int(max_seconds))
    deadline = time.monotonic() + max_seconds
    workdir = Path(tempfile.mkdtemp(prefix="moiat_export_"))
    driver = None
    startup_errors: list[str] = []
    try:
        kind, binary = _browser_binary()
        attempts = []
        if kind == "edge":
            attempts.append(("edge", binary))
            attempts.append(("chrome", None))
        elif kind == "chrome":
            attempts.append(("chrome", binary))
            attempts.append(("edge", None))
        else:
            # Let Selenium Manager handle browser/driver discovery.
            attempts.extend([("chrome", None), ("edge", None)])

        for attempt_kind, attempt_binary in attempts:
            if time.monotonic() >= deadline:
                break
            try:
                options = _browser_options(attempt_kind, attempt_binary, workdir)
                driver = webdriver.Edge(options=options) if attempt_kind == "edge" else webdriver.Chrome(options=options)
                driver.set_page_load_timeout(max(15, min(45, int(deadline - time.monotonic()))))
                driver.set_script_timeout(max(15, int(deadline - time.monotonic())))
                break
            except Exception as exc:
                startup_errors.append(f"{attempt_kind}: {exc}")
                driver = None

        if driver is None:
            raise MoIATDirectoryError("Unable to start Chromium browser; " + " | ".join(startup_errors[-2:]))

        # Establish the official first-party session/challenge state.
        try:
            driver.get(getattr(settings, "moiat_directory_url", MOIAT_DIRECTORY_URL))
        except TimeoutException:
            # A page-load timeout can still leave a usable browser session.
            pass
        except WebDriverException as exc:
            raise MoIATDirectoryError(f"MoIAT directory browser navigation failed: {exc}") from exc

        remaining = max(5, int(deadline - time.monotonic()))
        driver.set_script_timeout(remaining)
        fetched = _browser_fetch(driver, url, remaining)
        if fetched:
            data, content_type, status = fetched
            if status >= 400:
                raise MoIATDirectoryError(f"MoIAT export returned HTTP {status} in browser session")
            if _looks_like_html(data, content_type):
                # Keep the HTML only for diagnostics; it is not an export payload.
                raise MoIATDirectoryError(
                    f"MoIAT browser export returned HTML instead of {suffix} data (content-type={content_type or 'unknown'})"
                )
            if suffix.casefold() == ".xlsx" and not data.startswith(b"PK"):
                raise MoIATDirectoryError("MoIAT browser export response was not XLSX bytes")
            if suffix.casefold() == ".xml" and not data.lstrip().startswith((b"<", b"<?xml")):
                raise MoIATDirectoryError("MoIAT browser export response was not XML text")
            return data

        # XML fallback: some browsers render the response directly instead of
        # exposing it as a download.  In that case page_source contains the official
        # XML document even when fetch() was unavailable.
        if suffix.casefold() == ".xml":
            try:
                driver.get(url)
            except TimeoutException:
                pass
            try:
                source = str(driver.page_source or "").encode("utf-8", errors="ignore")
                if source and not _looks_like_html(source):
                    stripped = source.lstrip()
                    if stripped.startswith((b"<", b"<?xml")):
                        return source
            except Exception:
                pass

        # XLSX fallback: some browsers honor Content-Disposition as a download.
        if suffix.casefold() == ".xlsx":
            try:
                driver.get(url)
            except TimeoutException:
                pass
            while time.monotonic() < deadline:
                files = [f for f in workdir.iterdir() if f.is_file()]
                completed = [
                    f for f in files
                    if f.suffix.casefold() == suffix.casefold() and not f.name.endswith(".crdownload")
                ]
                if completed:
                    completed.sort(key=lambda x: x.stat().st_mtime, reverse=True)
                    data = completed[0].read_bytes()
                    if data and data.startswith(b"PK"):
                        return data
                time.sleep(0.25)

        raise MoIATDirectoryError(f"MoIAT browser export timed out or returned no {suffix} payload after {max_seconds} seconds")
    finally:
        if driver is not None:
            try:
                driver.quit()
            except Exception:
                pass
        shutil.rmtree(workdir, ignore_errors=True)

def download_moiat_browser_xml(*, force: bool = False) -> bytes:
    xml_path, json_path = _cache_paths()
    ttl = int(getattr(settings, "moiat_cache_ttl_seconds", 21600))
    if not force and xml_path.exists() and (time.time() - xml_path.stat().st_mtime) < ttl:
        data = xml_path.read_bytes()
        if data:
            return data
    data = _download_moiat_export_with_browser(
        getattr(settings, "moiat_xml_url", MOIAT_XML_URL), ".xml",
        max_seconds=max(30, int(getattr(settings, "moiat_timeout", 120))),
    )
    parsed = parse_moiat_xml(data, allow_recovery=False)
    _require_directory_floor(len(parsed), None)
    xml_path.parent.mkdir(parents=True, exist_ok=True)
    xml_path.write_bytes(data)
    _write_directory_cache(parsed)
    return data


def download_moiat_browser_excel(*, force: bool = False) -> bytes:
    xlsx_path = _cache_paths()[0].with_suffix(".xlsx")
    ttl = int(getattr(settings, "moiat_cache_ttl_seconds", 21600))
    if not force and xlsx_path.exists() and (time.time() - xlsx_path.stat().st_mtime) < ttl:
        data = xlsx_path.read_bytes()
        if data:
            return data
    data = _download_moiat_export_with_browser(
        getattr(settings, "moiat_xlsx_url", MOIAT_XLSX_URL), ".xlsx",
        max_seconds=max(30, int(getattr(settings, "moiat_timeout", 120))),
    )
    parsed = parse_moiat_excel(data)
    _require_directory_floor(len(parsed), None)
    xlsx_path.parent.mkdir(parents=True, exist_ok=True)
    xlsx_path.write_bytes(data)
    return data


def download_moiat_excel(*, force: bool = False) -> bytes:
    xlsx_path = _cache_paths()[0].with_suffix(".xlsx")
    ttl = int(getattr(settings, "moiat_cache_ttl_seconds", 21600))
    if not force and xlsx_path.exists() and (time.time() - xlsx_path.stat().st_mtime) < ttl:
        data = xlsx_path.read_bytes()
        if data:
            return data
    session = _new_session()
    last_error = ""
    for attempt in range(1, int(getattr(settings, "moiat_download_attempts", 6)) + 1):
        try:
            data, headers = _download_stream(session, getattr(settings, "moiat_xlsx_url", MOIAT_XLSX_URL), max_seconds=int(getattr(settings, "moiat_timeout", 90)))
            if not data.startswith(b"PK"):
                raise MoIATDirectoryError("MoIAT Excel export did not return XLSX bytes")
            # Parse before caching so a partial XLSX can never become the source cache.
            parse_moiat_excel(data)
            xlsx_path.parent.mkdir(parents=True, exist_ok=True)
            xlsx_path.write_bytes(data)
            return data
        except Exception as exc:
            last_error = str(exc)
            try: session.close()
            except Exception: pass
            session = _new_session()
            if attempt < int(getattr(settings, "moiat_download_attempts", 6)):
                time.sleep(min(2.0 * attempt, 8.0))
    raise MoIATDirectoryError(f"Unable to retrieve complete MoIAT Excel export: {last_error}")


_MAIN_ACTIVITY_ID_CACHE: dict[str, str] = {}


def _moiat_http_headers() -> dict[str, str]:
    return {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/154 Safari/537.36",
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Accept-Language": "en-US,en;q=0.9",
        "X-Requested-With": "XMLHttpRequest",
        "Origin": "https://il.moiat.gov.ae",
        "Referer": MOIAT_DIRECTORY_URL,
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
    }


def _new_session() -> requests.Session:
    """Create a requests session for MoIAT, routed through MOIAT_PROXY_URL when configured.

    MoIAT is a .gov.ae site that commonly refuses or silently drops traffic from foreign
    datacenter IPs (Vercel/AWS). A UAE-based egress proxy is the fix when that happens.
    """
    session = requests.Session()
    proxy = str(getattr(settings, "moiat_proxy_url", "") or "").strip()
    if proxy:
        session.proxies.update({"http": proxy, "https": proxy})
    return session


_REACH_LOCK = threading.Lock()
_REACH_STATE: dict[str, Any] = {"checked_at": 0.0, "ok": None, "reason": ""}


def moiat_reachable(*, force: bool = False) -> tuple[bool, str]:
    """Fast check (<= ~15s) that this host can actually talk to MoIAT.

    The result is cached (short for failures so recovery is noticed, longer for success), so
    a blocked host fails over to the fallback immediately instead of burning a 45s timeout
    on every request, retry and page.
    """
    with _REACH_LOCK:
        age = time.time() - float(_REACH_STATE["checked_at"] or 0)
        ttl = 1800 if _REACH_STATE["ok"] else 120
        if not force and _REACH_STATE["ok"] is not None and age < ttl:
            return bool(_REACH_STATE["ok"]), str(_REACH_STATE["reason"])
        ok, reason = False, ""
        try:
            with _new_session() as session:
                r = session.get(
                    getattr(settings, "moiat_directory_url", MOIAT_DIRECTORY_URL),
                    timeout=(int(getattr(settings, "moiat_probe_connect_timeout", 6)),
                             int(getattr(settings, "moiat_probe_read_timeout", 12))),
                    headers={**_moiat_http_headers(), "Accept": "text/html,*/*"},
                    allow_redirects=True,
                )
            if r.status_code >= 400:
                reason = (f"MoIAT answered HTTP {r.status_code} to this server. It is blocking requests from this "
                          "host's network (typical for cloud/datacenter IPs outside the UAE).")
            else:
                ok = True
        except requests.Timeout:
            reason = ("MoIAT did not respond (timed out). It is dropping connections from this host's network "
                      "(typical for cloud/datacenter IPs outside the UAE).")
        except requests.RequestException as exc:
            reason = f"Could not connect to MoIAT from this server: {type(exc).__name__}: {str(exc)[:160]}"
        _REACH_STATE.update({"checked_at": time.time(), "ok": ok, "reason": reason})
        return ok, reason


def _interactive_timeout_pair() -> tuple[int, int]:
    read = _interactive_moiat_timeout()
    return (min(8, read), read)


def _interactive_moiat_timeout() -> int:
    """A bounded timeout for user-facing MoIAT search/session/API calls."""
    configured = getattr(settings, "moiat_search_timeout", min(int(getattr(settings, "moiat_timeout", 90)), 20))
    return max(30, min(90, int(configured)))


def _seed_moiat_session(session: requests.Session, *, force: bool = False) -> None:
    """Visit the directory page first, exactly like the Ministry UI, so the server accepts searches."""
    if getattr(session, "_moiat_seeded", False) and not force:
        return
    try:
        session.get(
            MOIAT_DIRECTORY_URL,
            timeout=_interactive_timeout_pair(),
            headers={**_moiat_http_headers(), "Accept": "text/html,*/*"},
        )
    except requests.RequestException:
        pass
    try:
        session._moiat_seeded = True
    except Exception:
        pass


def _walk_json_objects(value: Any) -> Iterable[dict[str, Any]]:
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from _walk_json_objects(child)
    elif isinstance(value, list):
        for child in value:
            yield from _walk_json_objects(child)


def resolve_main_activity_id(code: str, *, session: requests.Session | None = None, force_refresh: bool = False) -> str:
    """Resolve a two-digit MoIAT Main Activity code to the UUID used by SearchIPLDirectory."""
    code = normalize_main_activity_code(code)
    if code not in MAIN_ACTIVITY_CODES:
        raise ValueError(f"Unknown MoIAT Main Activity code: {code or code!r}")
    if not force_refresh and code in _MAIN_ACTIVITY_ID_CACHE:
        return _MAIN_ACTIVITY_ID_CACHE[code]
    own_session = session is None
    session = session or _new_session()
    try:
        _seed_moiat_session(session)
        response = session.get(
            MOIAT_MAIN_ACTIVITY_URL,
            timeout=_interactive_timeout_pair(),
            headers=_moiat_http_headers(),
        )
        response.raise_for_status()
        payload = response.json()
        if isinstance(payload, str):
            payload = json.loads(payload)
        pattern = re.compile(rf"^\s*{re.escape(code)}\s*\|\s*.+$", re.I)
        for obj in _walk_json_objects(payload):
            text = _clean(obj.get("text"))
            href = _clean(obj.get("href"))
            if text and href and pattern.match(text):
                _MAIN_ACTIVITY_ID_CACHE[code] = href
                return href
        raise MoIATDirectoryError(f"MoIAT Main Activity {code} UUID was not found in GetMainActivities")
    except requests.RequestException as exc:
        raise MoIATDirectoryError(f"Unable to retrieve MoIAT Main Activity mapping: {exc}") from exc
    except (ValueError, json.JSONDecodeError) as exc:
        raise MoIATDirectoryError(f"MoIAT Main Activity mapping returned invalid JSON: {exc}") from exc
    finally:
        if own_session:
            try:
                session.close()
            except Exception:
                pass


def _parse_moiat_search_result(result_html: str) -> list[MoIATCompany]:
    """Parse one official SearchIPLDirectory Result fragment into company records."""
    if not result_html or not str(result_html).strip():
        return []
    try:
        from bs4 import BeautifulSoup
    except Exception as exc:  # pragma: no cover
        raise MoIATDirectoryError(f"BeautifulSoup is required for MoIAT SearchIPLDirectory parsing: {exc}") from exc

    soup = BeautifulSoup(str(result_html), "html.parser")
    header_map: dict[str, int] | None = None
    current: dict[str, Any] | None = None
    rows: dict[str, MoIATCompany] = {}

    def norm_cell(value: str) -> str:
        return re.sub(r"\s+", " ", value or "").strip()

    def make_company(raw: dict[str, Any]) -> MoIATCompany | None:
        name = norm_cell(raw.get("company_name", ""))
        emirate = norm_cell(raw.get("emirate", ""))
        if not name or not emirate:
            return None
        base = MoIATCompany(
            company_key=_stable_live_company_key(name, emirate),
            company_name=name,
            company_name_ar=norm_cell(raw.get("company_name_ar", "")),
            emirate=emirate,
            phone=norm_cell(raw.get("phone", "")),
            email=norm_cell(raw.get("email", "")),
            activities=tuple(raw.get("activities", [])),
            products=tuple(raw.get("products", [])),
            matched_segments=(),
        )
        return MoIATCompany(**{**base.__dict__, "matched_segments": classify_company(base)})

    def append_current() -> None:
        nonlocal current
        if not current:
            return
        company = make_company(current)
        if company:
            existing = rows.get(company.company_key)
            if existing:
                # Merge source details if duplicate markup for the same establishment occurs.
                activities = list(existing.activities)
                products = list(existing.products)
                for item in company.activities:
                    if item not in activities:
                        activities.append(item)
                for item in company.products:
                    if item not in products:
                        products.append(item)
                merged = MoIATCompany(
                    company_key=existing.company_key,
                    company_name=existing.company_name,
                    company_name_ar=existing.company_name_ar or company.company_name_ar,
                    emirate=existing.emirate,
                    phone=existing.phone or company.phone,
                    email=existing.email or company.email,
                    activities=tuple(activities),
                    products=tuple(products),
                    matched_segments=(),
                )
                rows[company.company_key] = MoIATCompany(**{**merged.__dict__, "matched_segments": classify_company(merged)})
            else:
                rows[company.company_key] = company
        current = None

    for tr in soup.find_all("tr"):
        cells = [norm_cell(td.get_text(" ", strip=True)) for td in tr.find_all(["th", "td"], recursive=False)]
        if not cells:
            continue
        mapping: dict[str, int] = {}
        for i, c in enumerate(cells):
            k = re.sub(r"[^a-z0-9]", "", c.casefold())
            if "factorynameen" in k or k in {"factorynameenglish", "factoryname"}:
                mapping["name"] = i
            elif "factorynamear" in k or k in {"factorynamearabic"}:
                mapping["name_ar"] = i
            elif "factoryphone" in k or k in {"phonenumber", "phone", "telephone", "tel", "mobile"}:
                mapping["phone"] = i
            elif "factoryemail" in k or k in {"email", "emailaddress"}:
                mapping["email"] = i
            elif k in {"emirate", "emirates", "locationemirate"}:
                mapping["emirate"] = i
        if {"name", "emirate"}.issubset(mapping):
            header_map = mapping
            continue

        if header_map:
            name = cells[header_map["name"]] if header_map["name"] < len(cells) else ""
            emirate = cells[header_map["emirate"]] if header_map["emirate"] < len(cells) else ""
            if name and emirate and name.casefold() not in {"factory name (en)", "factory name"}:
                append_current()
                current = {
                    "company_name": name,
                    "company_name_ar": cells[header_map["name_ar"]] if header_map.get("name_ar", 999) < len(cells) else "",
                    "phone": cells[header_map["phone"]] if header_map.get("phone", 999) < len(cells) else "",
                    "email": cells[header_map["email"]] if header_map.get("email", 999) < len(cells) else "",
                    "emirate": emirate,
                    "activities": [],
                    "products": [],
                }
                continue

        if not current:
            continue
        first = re.sub(r"\s+", "", cells[0]) if cells else ""
        if re.fullmatch(r"\d{7}", first) and len(cells) >= 2:
            item = {"isic4_code": first, "activity_en": cells[1], "activity_ar": cells[2] if len(cells) > 2 else ""}
            if item not in current["activities"]:
                current["activities"].append(item)
        elif re.fullmatch(r"\d{8,12}", first) and len(cells) >= 2:
            item = {"hs_code": first, "description_en": cells[1], "description_ar": cells[2] if len(cells) > 2 else ""}
            if item not in current["products"]:
                current["products"].append(item)

    append_current()
    return list(rows.values())


@dataclass(frozen=True)
class MoIATSearchPage:
    companies: tuple[MoIATCompany, ...]
    current_page: int
    total_pages: int
    total_records: int


def search_moiat_directory_page(
    *,
    main_activity_code: str = "",
    main_activity_id: str = "",
    page_index: int = 1,
    emirate_id: str = "",
    sub_activity_ids: Any = None,
    product_ids: Any = None,
    session: requests.Session | None = None,
) -> MoIATSearchPage:
    """Call the same server-side SearchIPLDirectory endpoint used by the MoIAT UI."""
    if page_index < 1:
        raise ValueError("page_index must be >= 1")
    own_session = session is None
    session = session or _new_session()
    try:
        _seed_moiat_session(session)
        if main_activity_code and not main_activity_id:
            main_activity_id = resolve_main_activity_id(main_activity_code, session=session)
        params: dict[str, Any] = {"pageIndex": int(page_index)}
        if main_activity_id:
            params["mainActivityId"] = main_activity_id
        if emirate_id:
            params["emirateId"] = emirate_id
        if sub_activity_ids:
            params["subActivityIds"] = sub_activity_ids
        if product_ids:
            params["productIds"] = product_ids
        payload = None
        last_problem = ""
        # Search requests must not inherit the much larger export timeout. A broken
        # page should be skipped/retried quickly rather than blocking a full batch.
        search_timeout = _interactive_moiat_timeout()
        attempts = max(1, min(3, int(getattr(settings, "moiat_search_attempts", 2))))
        for attempt in range(1, attempts + 1):
            response = session.get(
                MOIAT_SEARCH_URL,
                params=params,
                timeout=(min(8, search_timeout), search_timeout),
                headers=_moiat_http_headers(),
            )
            response.raise_for_status()
            body = (response.text or "").lstrip("\ufeff \r\n\t")
            try:
                payload = json.loads(body)
                if isinstance(payload, str):
                    payload = json.loads(payload)
                break
            except ValueError:
                last_problem = (
                    f"HTTP {response.status_code}, content-type={response.headers.get('content-type')!r}, "
                    f"{len(response.content)} bytes, url={response.url}, body starts: {body[:200]!r}"
                )
                payload = None
                if attempt < attempts:  # session likely expired/not established: re-visit and retry once
                    time.sleep(min(0.35 * attempt, 0.8))
                    _seed_moiat_session(session, force=True)
        if payload is None:
            raise MoIATDirectoryError(f"MoIAT SearchIPLDirectory returned non-JSON after {attempts} attempts: {last_problem}")
        if not isinstance(payload, dict) or "Result" not in payload:
            raise MoIATDirectoryError("MoIAT SearchIPLDirectory returned an unexpected JSON payload")
        current_page = int(payload.get("CurrentPage") or page_index)
        total_pages = int(payload.get("TotalPages") or 0)
        total_records = int(payload.get("TotalRecords") or 0)
        companies = tuple(_parse_moiat_search_result(payload.get("Result") or ""))
        if total_records > 0 and not companies:
            raise MoIATDirectoryError(
                f"MoIAT SearchIPLDirectory returned metadata ({total_records} records) but no parseable company rows on page {page_index}"
            )
        return MoIATSearchPage(companies, current_page, total_pages, total_records)
    except requests.RequestException as exc:
        raise MoIATDirectoryError(f"MoIAT SearchIPLDirectory request failed: {exc}") from exc
    except ValueError as exc:
        raise MoIATDirectoryError(f"MoIAT SearchIPLDirectory returned invalid metadata: {exc}") from exc
    finally:
        if own_session:
            try:
                session.close()
            except Exception:
                pass


_UAE_FALLBACK_TERMS: dict[str, tuple[str, ...]] = {
    TARGET_SEGMENTS[0]: ("building materials cement concrete steel glass ceramic manufacturer factory", "industrial construction materials manufacturer"),
    TARGET_SEGMENTS[1]: ("food beverage processing packaging factory manufacturer", "food and drinks manufacturer distributor"),
    TARGET_SEGMENTS[2]: ("raw materials commodities metals chemicals trading wholesaler", "industrial raw material supplier trader"),
    TARGET_SEGMENTS[3]: ("3PL logistics warehousing storage freight distribution provider", "warehouse fulfilment supply chain logistics company"),
    TARGET_SEGMENTS[4]: ("industrial machinery equipment spare parts distributor", "pumps valves bearings compressors industrial supplies"),
}
_UAE_EMIRATES = (
    "Dubai", "Abu Dhabi", "Sharjah", "Ajman", "Fujairah", "Ras Al Khaimah", "Umm Al Quwain"
)
_UAE_SEARCH_BLOCKLIST = (
    "google.", "bing.com", "yelp.", "facebook.com", "instagram.com", "linkedin.com", "youtube.com",
    "wikipedia.org", "moiat.gov.ae", "tavily.com", "serper.dev", "yellowpages.ae", "dnb.com",
    "kompass.com", "connect.ae", "uaecompanies.com", "2gis.ae", "gulfyp.com",
)


def _uae_fallback_queries(segment: str, main_activity_code: str) -> list[str]:
    label = MAIN_ACTIVITY_LABELS.get(main_activity_code, "") if main_activity_code else ""
    if label:
        core = f'"United Arab Emirates" UAE {label} manufacturer company'
    else:
        terms = _UAE_FALLBACK_TERMS.get(segment, (segment or "industrial manufacturer",))
        core = f'"United Arab Emirates" UAE {terms[0]} company'
    query_label = label or segment or "industrial companies"
    queries = [core, f'UAE Dubai Abu Dhabi {query_label} official website']
    # Keep calls bounded and do not repeat nearly identical query strings.
    out: list[str] = []
    for query in queries:
        query = " ".join(str(query or "").split())
        if query and query not in out:
            out.append(query)
    return out[:2]


def discover_uae_web_fallback(
    *, segment: str = "", main_activity_code: str = "", limit: int = 50,
    served_keys: set[str] | None = None,
) -> list[dict[str, Any]]:
    """Return source-linked company candidates from web search when MoIAT is unavailable.

    No AI-generated names are used. Every candidate is extracted from a result title and
    URL returned by the configured Tavily/Serper provider. These rows are explicitly marked
    MoIAT-unverified so users do not confuse web presence with an industrial license.
    """
    from urllib.parse import urlparse
    from .search import public_search

    seen = set(served_keys or set())
    candidates: dict[str, dict[str, Any]] = {}
    failures: list[str] = []
    for query in _uae_fallback_queries(segment, main_activity_code):
        try:
            hits = public_search(query, max_results=max(8, min(20, int(limit) * 2)))
        except Exception as exc:
            failures.append(f"{type(exc).__name__}: {str(exc)[:180]}")
            continue
        for hit in hits or []:
            if not isinstance(hit, dict):
                continue
            url = str(hit.get("url") or hit.get("link") or "").strip()
            title = re.sub(r"\s+", " ", str(hit.get("title") or "")).strip()
            content = re.sub(r"\s+", " ", str(hit.get("content") or hit.get("snippet") or hit.get("raw_content") or "")).strip()
            parsed = urlparse(url)
            host = (parsed.hostname or "").casefold().removeprefix("www.")
            if parsed.scheme not in {"http", "https"} or not host or not title:
                continue
            if any(blocked in host for blocked in _UAE_SEARCH_BLOCKLIST):
                continue
            # Require an actual UAE signal, not merely a UAE-targeted search query.
            evidence_text = f"{title} {content} {host}".casefold()
            uae_evidence = host.endswith(".ae") or "united arab emirates" in evidence_text or re.search(r"\buae\b", evidence_text)
            emirate = next((e for e in _UAE_EMIRATES if e.casefold() in evidence_text), "")
            if not uae_evidence and not emirate:
                continue
            # Directory/listicle pages are not company records. We only keep individual
            # company pages or direct company domains, with the result URL as evidence.
            title_lower = title.casefold()
            if any(term in title_lower for term in ("list of companies", "top companies in", "companies in uae", "company directory", "business directory", "industrial production license directory", "search results")):
                continue
            name = re.split(r"\s+[|–—]\s+|\s+::\s+|\s+-\s+(?=(?:official|contact|about|homepage|home page|manufacturer|supplier|distributor|uae|dubai|abu dhabi)\b)", title, maxsplit=1, flags=re.I)[0].strip(" .|–—-")
            if len(name) < 2 or len(name) > 100:
                continue
            if name.casefold() in {"home", "homepage", "official website", "contact us", "about us", "manufacturers", "suppliers"}:
                continue
            key = f"UAEWEB:{host}"
            if key in seen or key in candidates:
                continue
            # Only accept likely industrial/company pages; the query is targeted, and
            # these simple source-text checks reduce unrelated UAE results without AI.
            segment_terms = _UAE_FALLBACK_TERMS.get(segment, ("manufacturing",))[0].casefold().split()
            sector_text = f"{title} {content}".casefold()
            if segment and not any(t in sector_text for t in segment_terms if len(t) >= 5):
                # Search providers sometimes use the query itself as context. Allow an
                # individual .ae corporate site only when it provides UAE evidence.
                if not host.endswith(".ae"):
                    continue
            candidates[key] = {
                "company_key": key, "company_name": name, "company_name_ar": "",
                "country": "United Arab Emirates", "emirate": emirate or "United Arab Emirates",
                "region": emirate or "United Arab Emirates", "phone": "", "email": "", "domain": host,
                "activities": [], "products": [], "matched_segments": [segment] if segment else [],
                "source_url": url, "source_name": "Web search fallback · MoIAT unverified",
                "source_type": "Grounded web-search result; MoIAT industrial license not verified",
                "note": "Found via public web search because the MoIAT directory did not return usable records. Confirm MoIAT registration separately.",
                "evidence_snippet": content[:500],
            }
            if len(candidates) >= max(1, min(100, int(limit) * 2)):
                break
        if len(candidates) >= max(1, min(100, int(limit) * 2)):
            break
    if not candidates and failures:
        raise MoIATDirectoryError(
            "MoIAT directory did not return usable company records, and the web-search fallback failed: "
            + " | ".join(failures[:2])
        )
    return list(candidates.values())


def _segment_candidate_activity_codes(segment: str) -> tuple[str, ...]:
    rule = SEGMENT_RULES.get(segment) or {}
    prefixes = tuple(str(x) for x in rule.get("main_activity_prefixes", ()))
    return tuple(code for code in MAIN_ACTIVITY_CODES if code in prefixes)


def _emit(cb: Any, **info: Any) -> None:
    if cb:
        try:
            cb(info)
        except Exception:
            pass


_BLOCKED_HELP = (
    "Fix: (1) set MOIAT_PROXY_URL to a UAE-based HTTP(S) proxy in the Vercel environment variables, or "
    "(2) run `python build_moiat_snapshot.py` on a computer that can open MoIAT and redeploy so the snapshot "
    "in data/moiat/ is served offline, or (3) configure TAVILY_API_KEY / SERPER_API_KEY for the web-search fallback."
)
_QUERY_TOTAL_PAGES: dict[str, int] = {}
SKIPPED_PAGES: list[dict[str, Any]] = []  # pages MoIAT's own server failed to render (reported, not fatal)


def discover_moiat_batch(
    *,
    segment: str = "",
    main_activity_code: str = "",
    cursors: dict[str, int] | None = None,
    served_keys: set[str] | None = None,
    limit: int = 50,
    progress: Any = None,
) -> tuple[list[MoIATCompany], dict[str, int], int | None, bool]:
    """Fetch only enough official MoIAT pages to fill one UI batch.

    This is intentionally incremental: the first discovery must not scan every page
    of a large activity before showing the first 50 companies. ``cursors`` stores the
    next MoIAT page for each query and is persisted in the job by the server.
    """
    segment = str(segment or "").strip()
    main_activity_code = normalize_main_activity_code(main_activity_code)
    if not segment and not main_activity_code:
        raise ValueError("Choose a target segment or a MoIAT Main Activity")
    if segment and segment not in TARGET_SEGMENTS:
        raise ValueError(f"Unknown target segment: {segment}")
    if main_activity_code and main_activity_code not in MAIN_ACTIVITY_CODES:
        raise ValueError(f"Unknown MoIAT Main Activity code: {main_activity_code}")
    if limit < 1:
        raise ValueError("limit must be >= 1")

    # Continue a source-labelled web fallback in batches if its first result set was
    # larger than the requested page. Re-querying search results is safe because
    # served keys are removed before returning the next batch.
    if (cursors or {}).get("__uae_web_fallback__"):
        fallback_rows = discover_uae_web_fallback(
            segment=segment, main_activity_code=main_activity_code,
            limit=limit, served_keys=set(served_keys or set()),
        )
        batch = fallback_rows[:limit]
        more = len(fallback_rows) > len(batch)
        next_cursor = {"__uae_web_fallback__": 1} if more else {}
        _emit(progress, page=2, total_pages=2 if more else 1, found=len(batch),
              total_records=len(fallback_rows), skipped=0, cache=False, fallback=True,
              partial_companies=batch)
        return batch, next_cursor, len(fallback_rows), more

    # Cache-first path: serve verified MoIAT records from one local snapshot and
    # revalidate the snapshot asynchronously when it ages out. On a cold start,
    # warm the cache in the background while preserving live paginated search below.
    cached = _read_cached_directory()
    # V7.9.9: never start the (heavy, Chromium-driven) background refresh or the live search
    # against a MoIAT that this host cannot reach. Probe once, quickly; cache the verdict.
    moiat_ok, moiat_block_reason = (True, "")
    if cached is None or cached[1]:
        moiat_ok, moiat_block_reason = moiat_reachable()
    if cached is None:
        if moiat_ok:
            _start_directory_cache_refresh()
    else:
        cached_rows, cache_stale = cached
        if cache_stale and moiat_ok:
            _start_directory_cache_refresh()
        cache_mode_key = "__moiat_cache_mode__"
        cache_offset_key = "__moiat_cache_offset__"
        # A cached snapshot is deterministic and independent of network pagination.
        # On the first page use it immediately; later pages carry an explicit offset.
        cache_mode = cache_mode_key in (cursors or {}) or not cursors
        if cache_mode:
            served = set(served_keys or set())
            eligible: list[MoIATCompany] = []
            for company in cached_rows:
                if main_activity_code and not any(
                    normalize_main_activity_code(a.get("isic4_code")) == main_activity_code
                    for a in company.activities
                ):
                    continue
                if segment and not main_activity_code and segment not in company.matched_segments:
                    continue
                eligible.append(company)
            # A cached snapshot may predate a taxonomy change or lack activity details.
            # Never interpret a cache-filter miss as proof that MoIAT has no matching
            # companies; fall through to live discovery and the grounded web fallback.
            if eligible:
                position = max(0, int((cursors or {}).get(cache_offset_key, 0) or 0))
                results: list[MoIATCompany] = []
                while position < len(eligible) and len(results) < limit:
                    company = eligible[position]
                    position += 1
                    if company.company_key in served:
                        continue
                    results.append(company)
                has_more = position < len(eligible)
                next_cursors = {cache_mode_key: 1, cache_offset_key: position}
                _emit(progress, page=1 + ((position - 1) // max(1, limit)),
                      total_pages=(len(eligible) + limit - 1) // limit, found=len(results),
                      total_records=len(eligible), skipped=0, cache=True,
                      partial_companies=[row.as_dict() for row in results])
                return results, next_cursors, len(eligible), has_more

    if not moiat_ok:
        # MoIAT is unreachable from this host and there is no local snapshot to serve.
        # Fail over immediately (seconds, not minutes) with a clear, honest reason.
        print(f"[MoIAT] unreachable, using web fallback: {moiat_block_reason}", flush=True)
        _emit(progress, page=0, total_pages=0, found=0, skipped=0, cache=False, blocked=True,
              blocked_reason=moiat_block_reason)
        try:
            fallback_rows = discover_uae_web_fallback(
                segment=segment, main_activity_code=main_activity_code,
                limit=limit, served_keys=set(served_keys or set()),
            )
        except MoIATDirectoryError as exc:
            raise MoIATDirectoryError(f"{moiat_block_reason} {exc} {_BLOCKED_HELP}") from exc
        if not fallback_rows:
            raise MoIATDirectoryError(f"{moiat_block_reason} The web-search fallback found no usable companies. {_BLOCKED_HELP}")
        batch = fallback_rows[:limit]
        more = len(fallback_rows) > len(batch)
        next_cursor = {"__uae_web_fallback__": 1} if more else {}
        _emit(progress, page=1, total_pages=1 if not more else 2, found=len(batch),
              total_records=len(fallback_rows), skipped=0, cache=False, fallback=True,
              blocked=True, blocked_reason=moiat_block_reason, partial_companies=batch)
        return batch, next_cursor, len(fallback_rows), more

    if main_activity_code:
        queries: list[str | None] = [main_activity_code]
    else:
        candidate_codes = _segment_candidate_activity_codes(segment)
        queries = list(candidate_codes) if candidate_codes else [None]

    cursor_map = {str(k): max(1, int(v)) for k, v in (cursors or {}).items()}
    served = set(served_keys or set())
    results: dict[str, MoIATCompany] = {}
    live_deadline = time.monotonic() + max(20, int(getattr(settings, "moiat_live_budget_seconds", 60)))
    timed_out = False
    total_records: int | None = 0
    any_remaining = False

    with _new_session() as session:
        for code in queries:
            if timed_out:
                break
            query_key = code or "__all__"
            page_index = cursor_map.get(query_key, 1)
            query_total: int | None = None
            while len(results) < limit:
                if time.monotonic() > live_deadline:
                    # Live search is too slow to be useful: stop and let the caller fall back
                    # (or return what has been collected) instead of spinning for minutes.
                    timed_out = True
                    if not results and not cursors:
                        _REACH_STATE.update({"checked_at": time.time(), "ok": False,
                                             "reason": "MoIAT live search exceeded its time budget from this host."})
                    any_remaining = True
                    break
                try:
                    page = search_moiat_directory_page(
                        main_activity_code=code or "",
                        page_index=page_index,
                        session=session,
                    )
                    _QUERY_TOTAL_PAGES[query_key] = page.total_pages
                except MoIATDirectoryError as exc:
                    # MoIAT's server deterministically errors on some pages (observed: Activity 10, page 4).
                    # Skip such a page instead of aborting the whole discovery.
                    known = _QUERY_TOTAL_PAGES.get(query_key)
                    if known is None:
                        try:
                            known = search_moiat_directory_page(
                                main_activity_code=code or "", page_index=1, session=session
                            ).total_pages
                            _QUERY_TOTAL_PAGES[query_key] = known
                        except MoIATDirectoryError:
                            if not results and not cursors:
                                fallback_rows = discover_uae_web_fallback(
                                    segment=segment, main_activity_code=main_activity_code,
                                    limit=limit, served_keys=served,
                                )
                                if fallback_rows:
                                    batch = fallback_rows[:limit]
                                    more = len(fallback_rows) > len(batch)
                                    next_cursor = {"__uae_web_fallback__": 1} if more else {}
                                    _emit(progress, page=1, total_pages=1 if not more else 2,
                                          found=len(batch), total_records=len(fallback_rows), skipped=0,
                                          cache=False, fallback=True, partial_companies=batch)
                                    return batch, next_cursor, len(fallback_rows), more
                            raise exc
                    if not known:
                        raise exc
                    SKIPPED_PAGES.append({"query": query_key, "page": page_index, "error": str(exc)[:200]})
                    print(f"[MoIAT] skipped page {page_index}/{known} for {query_key}: server error", flush=True)
                    _emit(progress, page=page_index, total_pages=known, found=len(results),
                          total_records=None, skipped=len(SKIPPED_PAGES))
                    if page_index >= known:
                        cursor_map.pop(query_key, None)
                        break
                    page_index += 1
                    cursor_map[query_key] = page_index
                    continue
                query_total = page.total_records
                if total_records is not None and query_total is not None:
                    # For a single exact Main Activity this is the authoritative count.
                    # For segment-only multi-query discovery it is only an upper bound,
                    # so leave total_records unknown below.
                    if len(queries) == 1:
                        total_records = query_total
                    else:
                        total_records = None

                for company in page.companies:
                    if main_activity_code and not any(
                        normalize_main_activity_code(a.get("isic4_code")) == main_activity_code
                        for a in company.activities
                    ):
                        continue
                    # An explicit MoIAT Main Activity is the authoritative filter. The keyword
                    # segment classifier is only applied for segment-only discovery, otherwise
                    # the two filters intersect to an empty set (e.g. activity 18 + Building Materials).
                    if segment and not main_activity_code and segment not in company.matched_segments:
                        continue
                    if company.company_key in served or company.company_key in results:
                        continue
                    results[company.company_key] = company
                    if len(results) >= limit:
                        break

                _emit(progress, page=page.current_page, total_pages=page.total_pages,
                      found=len(results), total_records=page.total_records, skipped=len(SKIPPED_PAGES),
                      cache=False, partial_companies=[row.as_dict() for row in results.values()])
                next_page = page.current_page + 1
                if page.total_pages <= 0 or page.current_page >= page.total_pages:
                    cursor_map.pop(query_key, None)
                    break
                page_index = next_page
                cursor_map[query_key] = page_index

            if query_key in cursor_map:
                any_remaining = True
            # If this query is exhausted, continue to the next candidate query.

    # Any query still present in cursor_map has unconsumed MoIAT pages.
    any_remaining = any_remaining or bool(cursor_map)
    if not results and not cursors:
        # Zero parsed rows is not sufficient evidence that the UAE has no companies:
        # the MoIAT export/search service can respond with empty shells during outages.
        fallback_rows = discover_uae_web_fallback(
            segment=segment, main_activity_code=main_activity_code, limit=limit, served_keys=served,
        )
        if fallback_rows:
            batch = fallback_rows[:limit]
            more = len(fallback_rows) > len(batch)
            next_cursor = {"__uae_web_fallback__": 1} if more else {}
            _emit(progress, page=1, total_pages=1 if not more else 2, found=len(batch),
                  total_records=len(fallback_rows), skipped=0, cache=False, fallback=True,
                  partial_companies=batch)
            return batch, next_cursor, len(fallback_rows), more
        if timed_out:
            raise MoIATDirectoryError(
                "MoIAT live search exceeded its time budget from this host and the web-search fallback "
                "returned no usable companies. " + _BLOCKED_HELP)
    return list(results.values()), cursor_map, total_records, any_remaining


def discover_moiat_live(*, segment: str = "", main_activity_code: str = "") -> list[MoIATCompany]:
    """Discover companies from the official paginated MoIAT search endpoint.

    Main Activity filters use MoIAT's UUID-backed server filter. Segment-only discovery
    uses the same endpoint and applies the existing deterministic segment classifier.
    When a segment maps to one or more visible Main Activity codes we query those codes
    directly; otherwise we scan the unfiltered official result pages.
    """
    segment = str(segment or "").strip()
    main_activity_code = normalize_main_activity_code(main_activity_code)
    if not segment and not main_activity_code:
        raise ValueError("Choose a target segment or a MoIAT Main Activity")
    if segment and segment not in TARGET_SEGMENTS:
        raise ValueError(f"Unknown target segment: {segment}")
    if main_activity_code and main_activity_code not in MAIN_ACTIVITY_CODES:
        raise ValueError(f"Unknown MoIAT Main Activity code: {main_activity_code}")

    queries: list[str | None]
    if main_activity_code:
        queries = [main_activity_code]
    else:
        candidate_codes = _segment_candidate_activity_codes(segment)
        queries = list(candidate_codes) if candidate_codes else [None]

    results: dict[str, MoIATCompany] = {}
    with _new_session() as session:
        for code in queries:
            page_index = 1
            seen_pages: set[int] = set()
            while True:
                if page_index in seen_pages:
                    raise MoIATDirectoryError(f"MoIAT pagination loop detected at page {page_index}")
                seen_pages.add(page_index)
                page = search_moiat_directory_page(
                    main_activity_code=code or "",
                    page_index=page_index,
                    session=session,
                )
                for company in page.companies:
                    if main_activity_code and not any(
                        normalize_main_activity_code(a.get("isic4_code")) == main_activity_code
                        for a in company.activities
                    ):
                        continue
                    if segment and segment not in company.matched_segments:
                        continue
                    results[company.company_key] = company
                if page.total_pages <= 0 or page.current_page >= page.total_pages:
                    break
                page_index = page.current_page + 1
    return list(results.values())


def load_directory(*, force: bool = False) -> list[MoIATCompany]:
    _, json_path = _cache_paths()
    if not force and json_path.exists():
        try:
            raw = json.loads(json_path.read_text(encoding="utf-8"))
            out = []
            for item in raw:
                out.append(MoIATCompany(
                    company_key=item["company_key"], company_name=item["company_name"],
                    company_name_ar=item.get("company_name_ar", ""), emirate=item.get("emirate", ""),
                    phone=item.get("phone", ""), email=item.get("email", ""),
                    activities=tuple(item.get("activities") or []), products=tuple(item.get("products") or []),
                    matched_segments=tuple(item.get("matched_segments") or []),
                ))
            if out:
                return out
        except Exception:
            pass
    xml_error = None
    try:
        data = download_moiat_xml(force=True)
        return parse_moiat_xml(data)
    except Exception as exc:
        xml_error = str(exc)

    browser_xml_error = None
    if os.getenv("MOIAT_BROWSER_FALLBACK", "true").strip().lower() in {"1", "true", "yes", "y"}:
        try:
            data = download_moiat_browser_xml(force=True)
            return parse_moiat_xml(data)
        except Exception as exc:
            browser_xml_error = str(exc)

    html_error = None
    try:
        # MoIAT's own directory page is the primary HTML fallback when its export
        # endpoints return an HTML error/challenge page or non-XLSX bytes.
        data = download_moiat_html(force=True)
        return _parse_moiat_html(data, expected_count=None)
    except Exception as exc:
        html_error = str(exc)

    # The same official directory exposes Excel as a final transport fallback; company
    # truth still comes exclusively from MoIAT.
    browser_excel_error = None
    if os.getenv("MOIAT_BROWSER_FALLBACK", "true").strip().lower() in {"1", "true", "yes", "y"}:
        try:
            data = download_moiat_browser_excel(force=True)
            rows = parse_moiat_excel(data)
            _, json_path = _cache_paths()
            json_path.parent.mkdir(parents=True, exist_ok=True)
            _write_directory_cache(rows)
            return rows
        except Exception as exc:
            browser_excel_error = str(exc)

    try:
        data = download_moiat_excel(force=True)
        rows = parse_moiat_excel(data)
        _, json_path = _cache_paths()
        json_path.parent.mkdir(parents=True, exist_ok=True)
        _write_directory_cache(rows)
        return rows
    except Exception as exc:
        raise MoIATDirectoryError(
            f"MoIAT XML failed: {xml_error}; browser XML failed: {browser_xml_error}; "
            f"official HTML fallback failed: {html_error}; browser Excel failed: {browser_excel_error}; "
            f"official Excel fallback failed: {exc}"
        ) from exc


def companies_for_segment(segment: str, *, force_refresh: bool = False) -> list[MoIATCompany]:
    if segment not in TARGET_SEGMENTS:
        raise ValueError(f"Unknown target segment: {segment}")
    return [c for c in load_directory(force=force_refresh) if segment in c.matched_segments]


def companies_for_main_activity(code: str, *, force_refresh: bool = False) -> list[MoIATCompany]:
    code = normalize_main_activity_code(code)
    if code not in MAIN_ACTIVITY_CODES:
        raise ValueError(f"Unknown MoIAT Main Activity code: {code or code!r}")
    return [
        c for c in load_directory(force=force_refresh)
        if any(normalize_main_activity_code(a.get("isic4_code")) == code for a in c.activities)
    ]


def companies_for_filters(*, segment: str = "", main_activity_code: str = "", force_refresh: bool = False) -> list[MoIATCompany]:
    segment = str(segment or "").strip()
    code = normalize_main_activity_code(main_activity_code)
    if not segment and not code:
        raise ValueError("Choose a target segment or a MoIAT Main Activity")
    if segment and segment not in TARGET_SEGMENTS:
        raise ValueError(f"Unknown target segment: {segment}")
    if code and code not in MAIN_ACTIVITY_CODES:
        raise ValueError(f"Unknown MoIAT Main Activity code: {code}")
    # Preserve the legacy segment function as the first branch so existing integrations
    # and tests that replace companies_for_segment continue to work without contacting MoIAT.
    if segment and not code:
        return companies_for_segment(segment, force_refresh=force_refresh)
    rows = load_directory(force=force_refresh)
    if segment:
        rows = [c for c in rows if segment in c.matched_segments]
    if code:
        rows = [c for c in rows if any(normalize_main_activity_code(a.get("isic4_code")) == code for a in c.activities)]
    return rows
