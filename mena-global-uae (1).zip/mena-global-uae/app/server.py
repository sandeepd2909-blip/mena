"""Local web UI server for official UAE, US, and UK company directory workflows."""
from __future__ import annotations

import csv
import io
import json
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

_SAVE_LOCK = threading.RLock()
WEB = Path(__file__).resolve().parent.parent / "web"
JOBS: dict[str, dict[str, Any]] = {}
TARGET_SEGMENTS = [
    "Industrial & Building Material Manufacturers",
    "Food & Beverage (F&B) Manufacturers & Distributors",
    "Raw Material & Commodity Wholesalers",
    "Multi-Site 3PL & Warehousing Providers",
    "Industrial Equipment & Spare Parts Distributors",
]
from .moiat_directory import MOIAT_MAIN_ACTIVITIES, MAIN_ACTIVITY_LABELS, MAIN_ACTIVITY_CODES
TARGET_TITLES = [
    "General Manager", "Parts Manager", "Head of Procurement", "Supply Chain Director",
    "Head of Operations", "Warehouse Manager", "Head of Technology / IT", "Commercial Director",
    "CEO", "Head of Trading", "Logistics Manager",
]
ALLOWED_SENIORITY = ["Director", "VP", "C-Suite", "Manager"]


def _load_job(jid: str) -> dict[str, Any] | None:
    job = JOBS.get(jid)
    if job:
        return job
    from .uae_state import read_job
    job = read_job(jid)
    if job:
        JOBS[jid] = job
    return job


def _save_job(job: dict[str, Any]) -> None:
    JOBS[job["id"]] = job
    from .uae_state import write_job, set_last_job
    with _SAVE_LOCK:
        write_job(job)
        set_last_job(job["id"])


class CompanyTimeout(Exception):
    pass


def _run_with_timeout(fn, timeout: float):
    """Run fn() in a daemon thread; raise CompanyTimeout if it exceeds `timeout` seconds."""
    box: dict[str, Any] = {}

    def target() -> None:
        try:
            box["value"] = fn()
        except BaseException as exc:  # noqa: BLE001 - re-raised in the caller
            box["error"] = exc

    t = threading.Thread(target=target, daemon=True)
    t.start()
    t.join(timeout)
    if t.is_alive():
        raise CompanyTimeout(f"timed out after {int(timeout)}s")
    if "error" in box:
        raise box["error"]
    return box["value"]


def _resolve_company_safe(item: dict[str, Any]) -> dict[str, Any]:
    """AI company resolution that can never break people discovery."""
    from .company_resolver import resolve_company
    try:
        return resolve_company(
            item["name"], country=item.get("country") or "United Arab Emirates", emirate=item.get("emirate", ""),
            known_domain=item.get("domain", ""),
        )
    except Exception as exc:  # resolve_company already swallows errors; belt and braces
        return {"status": "error", "registered_name": item["name"], "resolved_name": item["name"], "aliases": [],
                "relationship": "unknown", "is_subsidiary": False, "parent_company": "", "website_domain": "",
                "company_linkedin": "", "confidence": 0.0, "evidence": [], "label": "", "note": str(exc)[:160]}


def _resolution_payload(r: dict[str, Any]) -> dict[str, Any]:
    return {k: r.get(k, "" if k not in {"aliases", "evidence"} else []) for k in (
        "status", "resolved_name", "aliases", "relationship", "is_subsidiary", "parent_company",
        "website_domain", "company_linkedin", "confidence", "evidence", "label", "note")}


def _company_payload(c: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": c["id"],
        "company_key": c["company_key"],
        "name": c["name"],
        "domain": c.get("domain", ""),
        "emirate": c.get("emirate", ""),
        "region": c.get("region", ""),
        "country": c.get("country", "United Arab Emirates"),
        "directory_id": c.get("directory_id", ""),
        "registered_status": c.get("registered_status", ""),
        "source_name": c.get("source_name", ""),
        "ticker": c.get("ticker", ""),
        "matched_segments": c.get("matched_segments", []),
        "main_activity_codes": c.get("main_activity_codes", []),
        "main_activities": c.get("main_activities", []),
        "source_url": c.get("source_url", ""),
        "registry_url": c.get("registry_url", ""),
        "verification_status": c.get("verification_status", ""),
        "company_size": c.get("company_size", ""),
        "company_size_score": float(c.get("company_size_score") or 0),
        "company_size_source": c.get("company_size_source", ""),
        "company_followers": int(c.get("company_followers") or 0),
        "status": c.get("status", "Found"),
        "selected": bool(c.get("selected")),
        "people": c.get("people", []),
        "note": c.get("note", ""),
        "sources_used": int(c.get("sources_used") or 0),
        "warnings": c.get("warnings", []),
        "resolution": c.get("resolution") or {},
    }


def _new_company(raw: dict[str, Any]) -> dict[str, Any]:
    activities = raw.get("activities", []) or []
    country = raw.get("country") or "United Arab Emirates"
    return {
        "id": uuid.uuid4().hex[:12],
        "company_key": raw.get("company_key") or f"{country}:{raw.get('company_name', '')}",
        "name": raw.get("company_name") or raw.get("name") or "Unknown company",
        "domain": raw.get("domain", "") or "",
        "directory_phone": raw.get("phone", "") or "",
        "emirate": raw.get("emirate", "") or "",
        "region": raw.get("region", "") or "",
        "country": country,
        "directory_id": raw.get("directory_id", "") or "",
        "registered_status": raw.get("registered_status", "") or "",
        "source_name": raw.get("source_name", "") or "",
        "ticker": raw.get("ticker", "") or "",
        "matched_segments": raw.get("matched_segments", []),
        "main_activity_codes": sorted({str(a.get("isic4_code") or "")[:2] for a in activities if str(a.get("isic4_code") or "")[:2]}),
        "main_activities": [a for a in activities if a.get("isic4_code") or a.get("activity_en")],
        "source_url": raw.get("source_url", "") or "",
        "registry_url": raw.get("registry_url", "") or "",
        "verification_status": raw.get("verification_status", "") or "",
        "company_size": raw.get("company_size", "") or "",
        "company_size_score": float(raw.get("company_size_score") or 0),
        "company_size_source": raw.get("company_size_source", "") or "",
        "company_followers": int(raw.get("company_followers") or 0),
        "status": "Found", "selected": False, "people": [], "note": raw.get("note", "") or "",
        "sources_used": 0, "warnings": [],
    }


def _job_filter_label(job: dict[str, Any]) -> str:
    code = str(job.get("main_activity_code") or "")
    segment = str(job.get("segment") or "")
    if code and job.get("country", "United Arab Emirates") == "United Arab Emirates":
        return f"{code} | {MAIN_ACTIVITY_LABELS.get(code, code)}"
    return str(job.get("search_query") or segment or job.get("country") or "Company search")


def _is_uae_job(job: dict[str, Any]) -> bool:
    return str(job.get("country") or "United Arab Emirates").strip().casefold() in {"united arab emirates", "uae"}


def _official_directory_batch(job: dict[str, Any], *, offset: int = 0) -> dict[str, Any]:
    from .company_directories import discover_official_companies
    query = str(job.get("search_query") or job.get("segment") or "").strip()
    return discover_official_companies(str(job.get("country") or "United Arab Emirates"), query,
                                       limit=50, offset=offset)


def _job_scope_key(job: dict[str, Any]) -> str:
    code = str(job.get("main_activity_code") or "")
    segment = str(job.get("segment") or "")
    if code and segment:
        return f"activity:{code}|segment:{segment}"
    if code:
        return f"activity:{code}"
    # Keep the legacy segment key unchanged for segment-only discovery/state.
    return segment


def _progress_cb(job: dict[str, Any]):
    def cb(info: dict[str, Any]) -> None:
        info = dict(info or {})
        partial_companies = info.pop("partial_companies", None)
        job["discovery_progress"] = {**info, "target": 50}
        # Surface rows as soon as a source page has been parsed. They remain
        # read-only until discovery finishes, so the final batch stays consistent.
        if isinstance(partial_companies, list):
            job["companies"] = [
                _new_company(item) for item in partial_companies if isinstance(item, dict)
            ]
            job["batch_start"] = 1 if job["companies"] else 0
            job["batch_end"] = len(job["companies"])
            if info.get("total_records") is not None:
                job["total_matches"] = info.get("total_records")
    return cb


def _load_next_thread(job: dict[str, Any]) -> None:
    """Background version of Load Next 50 so the UI can show live progress."""
    try:
        job["stage"] = "discover"
        job["error"] = ""
        job["notice"] = ""
        job["discovery_progress"] = {"page": 0, "total_pages": 0, "found": 0, "skipped": 0, "target": 50}
        job["stage_before_next"] = "discovered"
        ok = _load_next(job)
        if not ok:
            job["notice"] = "No more companies available for this filter."
    except Exception as exc:
        job["error"] = str(exc)
    finally:
        if job.get("stage") == "discover":
            job["stage"] = "discovered"
        _save_job(job)


def _rank_company_batch(companies: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Order visible companies by public size evidence, preserving unknowns at the end."""
    try:
        from .company_size import rank_companies_by_public_size
        return rank_companies_by_public_size(companies)
    except Exception as exc:
        # Size ranking is only a presentation layer; discovery must remain usable if the
        # optional public-size lookups fail. Do not turn a transient search failure into
        # an empty company batch.
        print(f"[Company size] ranking skipped: {type(exc).__name__}: {exc}", flush=True)
        return companies


def _discover_thread(job: dict[str, Any]) -> None:
    from .uae_state import mark_company_served, served_company_keys
    try:
        job["stage"] = "discover"
        _save_job(job)
        if _is_uae_job(job):
            from .moiat_directory import discover_moiat_batch
            scope = _job_scope_key(job)
            served = served_company_keys(scope)
            job["discovery_progress"] = {"page": 0, "total_pages": 0, "found": 0, "skipped": 0, "target": 50}
            batch, cursors, source_total, has_more = discover_moiat_batch(
                segment=str(job.get("segment") or ""), main_activity_code=str(job.get("main_activity_code") or ""),
                cursors=job.get("discovery_cursors") or {}, served_keys=served, limit=50,
                progress=_progress_cb(job),
            )
            job["total_matches"] = source_total if source_total is not None else len(batch)
            job["discovery_cursors"] = cursors
            normalized_batch = [_new_company(c.as_dict() if hasattr(c, "as_dict") else c) for c in batch]
            job["companies"] = _rank_company_batch(normalized_batch)
            job["batch_start"] = (len(served) + 1) if batch else 0
            job["batch_end"] = (len(served) + len(batch)) if batch else 0
            for company in job["companies"]:
                mark_company_served(scope, company["company_key"])
            job["has_next"] = bool(has_more)
            using_web_fallback = any("fallback" in str(c.get("source_name") or "").casefold() for c in job["companies"])
            if using_web_fallback:
                job["source"] = {"name": "Public web search fallback · MoIAT unverified", "dataset": "Source-linked Tavily/Serper search results; industrial-license status not verified",
                    "url": (job["companies"][0].get("source_url") if job["companies"] else "https://il.moiat.gov.ae/en/OpenData/IPLDirectory")}
            else:
                job["source"] = {"name": "UAE Ministry of Industry and Advanced Technology", "dataset": "Industrial Production License Directory",
                    "url": "https://il.moiat.gov.ae/en/OpenData/IPLDirectory", "search_api": "https://il.moiat.gov.ae/en/OpenData/SearchIPLDirectory",
                    "activity_api": "https://il.moiat.gov.ae/en/AjaxRequests/GetMainActivities?LoadOldActivities=true",
                    "pagination": "MoIAT server-side pageIndex; incremental 50-company batches"}
        else:
            result = _official_directory_batch(job, offset=0)
            batch = result["companies"]
            job["total_matches"] = result["total"]
            job["discovery_cursors"] = {"offset": result["next_offset"]}
            job["companies"] = [_new_company(c) for c in batch]
            job["batch_start"] = 1 if batch else 0
            job["batch_end"] = len(batch)
            job["has_next"] = bool(result["has_more"])
            job["source"] = result["source"]
            job["discovery_progress"] = {"page": 1, "total_pages": 0, "found": len(batch), "skipped": 0, "target": 50}
        job["selected_company_ids"] = []
        job["selected_people_ids"] = []
        job["page"] = 1
        job["stage"] = "discovered"
        job["filter_label"] = _job_filter_label(job)
        _save_job(job)
    except Exception as exc:
        job["stage"], job["error"] = "error", str(exc)
        _save_job(job)


def _run_selected_people(job: dict[str, Any], selected_ids: list[str]) -> None:
    """Find target decision-makers for the selected companies, in parallel, with live progress."""
    from .company_resolver import search_aliases
    from .uae_people import find_target_people
    from .uae_state import enrichment_record, stable_person_id
    from .webpeople import register_company_aliases
    selected = set(selected_ids)
    chosen = set(job.get("selected_company_ids", []))
    companies = [c for c in job.get("companies", []) if c.get("id") in chosen]
    for c in companies:
        c["status"] = "Queued"
        c["people"] = []
        c["note"] = ""
    job["people_progress"] = {"done": 0, "total": len(companies), "current": [], "people_found": 0, "failed": 0}
    job["error"] = ""
    _save_job(job)
    prog = job["people_progress"]
    lock = threading.Lock()

    def work(item: dict[str, Any]) -> None:
        try:
            with lock:
                prog["current"].append(item["name"])
            # V7.8.58: first work out which company this really is (trading name, brand, parent group),
            # then run the unchanged people pipeline on that company with the validated aliases.
            item["status"] = "Resolving"
            _save_job(job)
            item["country"] = job.get("country") or "United Arab Emirates"
            resolution = _resolve_company_safe(item)
            item["resolution"] = _resolution_payload(resolution)
            if resolution.get("website_domain") and not item.get("domain"):
                item["domain"] = resolution["website_domain"]
            item["status"] = "Searching"
            _save_job(job)
            aliases = search_aliases(resolution)
            register_company_aliases(item["name"], aliases)
            company_record = {
                "company_name": item["name"],
                "aliases": aliases,
                "country": job.get("country") or "United Arab Emirates",
                "industry": job.get("search_query") or job.get("segment") or MAIN_ACTIVITY_LABELS.get(str(job.get("main_activity_code") or ""), ""),
                "known_domain": item.get("domain", ""),
                "company_linkedin": resolution.get("company_linkedin", ""),
                "parent_company": resolution.get("parent_company", ""),
                "company_relationship": resolution.get("label", ""),
            }
            from .config import settings as _settings
            limit = max(60, int(getattr(_settings, "company_people_timeout_seconds", 420)))
            result = _run_with_timeout(lambda: find_target_people(company_record), limit)
            people = []
            for p in result.get("people", []):
                pid = stable_person_id(p, item["name"])
                previous = enrichment_record(pid)
                p2 = dict(p)
                if p2.get("linkedin_url") and "linkedin.com/in/" not in str(p2["linkedin_url"]).casefold():
                    p2["linkedin_url"] = ""  # company/school/post/job URLs are never a person profile
                p2["person_id"] = pid
                p2["company_relationship"] = resolution.get("label", "")
                p2["selected"] = pid in selected
                p2["status"] = "Already enriched" if previous else "Found"
                if previous and previous.get("phone"):
                    p2["phone"] = previous.get("phone", "")
                    p2["phone_source"] = previous.get("phone_source", "")
                    p2["verification"] = previous.get("verification", "")
                    p2["status"] = "Mobile found"
                people.append(p2)
            item["people"] = people
            item["sources_used"] = int(result.get("sources_used") or 0)
            item["warnings"] = list(result.get("errors") or [])[:6]
            if people:
                item["note"] = ""
            else:
                diag = result.get("diagnostics") or {}
                tried = ", ".join(search_aliases(resolution)[:4]) or item["name"]
                base = (f"Reviewed {item['sources_used']} matching page(s); none produced a verified person. "
                        f"LinkedIn profile candidates passing company-employer checks: "
                        f"{int(diag.get('linkedin_profile_candidates') or 0)}; "
                        f"people extracted: {int(diag.get('raw_people_candidates') or 0)}; "
                        f"people verified: {int(diag.get('verified_people_before_classification') or 0)}. "
                        f"Company names tried: {tried}. ")
                if diag.get("tavily_failures") or diag.get("serper_failures"):
                    base += (f"Search errors: Tavily {diag.get('tavily_failures', 0)}, "
                             f"Serper {diag.get('serper_failures', 0)}. ")
                if diag.get("ai_failures"):
                    base += f"OpenAI errors: {diag.get('ai_last_error', '')[:120]}. "
                item["note"] = (base + "; ".join(item["warnings"][:2])).strip()
            item["status"] = "People found" if people else "No people found"
            with lock:
                prog["people_found"] += len(people)
        except CompanyTimeout as exc:
            item["status"] = "Failed"
            item["note"] = (f"People search {exc}. A search provider is probably slow or out of credits - "
                            "check the server log and SERPER/TAVILY/OPENAI keys, then retry this company.")
            with lock:
                prog["failed"] += 1
        except Exception as exc:
            item["status"] = "Failed"
            item["note"] = f"{type(exc).__name__}: {str(exc)[:300]}"
            with lock:
                prog["failed"] += 1
        finally:
            with lock:
                prog["done"] += 1
                if item["name"] in prog["current"]:
                    prog["current"].remove(item["name"])
            _save_job(job)

    try:
        with ThreadPoolExecutor(max_workers=min(3, max(1, len(companies)))) as pool:
            list(pool.map(work, companies))
    finally:
        job["stage"] = "discovered"
        _save_job(job)


def _mobile_candidates(job: dict[str, Any], requested_ids: list[str]) -> tuple[list[tuple[dict[str, Any], dict[str, Any]]], list[str]]:
    from .identity import linkedin_slug_conflicts_with_name
    from .uae_state import enrichment_record
    wanted = set(requested_ids)
    valid_companies = {c["id"]: c for c in job.get("companies", []) if c.get("id") in set(job.get("selected_company_ids", []))}
    candidates: list[tuple[dict[str, Any], dict[str, Any]]] = []
    skipped: list[str] = []
    for company in valid_companies.values():
        for person in company.get("people", []):
            if person.get("person_id") not in wanted:
                continue
            if not person.get("linkedin_url"):
                skipped.append(person.get("person_id", ""))
                continue
            # Never spend FullEnrich credits on a profile whose URL spells a different person.
            if linkedin_slug_conflicts_with_name(person.get("linkedin_url", ""), person.get("person_name", "")):
                person["status"] = "LinkedIn mismatch"
                person["linkedin_url"] = ""
                skipped.append(person.get("person_id", ""))
                continue
            previous = enrichment_record(person["person_id"])
            if previous:
                previous_status = str(previous.get("status") or "").casefold().replace(" ", "_")
                previous_result = previous.get("result") if isinstance(previous.get("result"), dict) else {}
                provider_status = str(previous_result.get("status") or "").casefold()
                # Failed requests are not successful enrichment. Let people retry after
                # credentials, credits, or a transient provider/network error are fixed.
                retryable = (
                    previous_status in {"failed", "error", "provider_error", "disabled", "invalid_linkedin"}
                    or provider_status in {"error", "disabled", "invalid_linkedin"}
                )
                if not retryable:
                    skipped.append(person.get("person_id", ""))
                    continue
            candidates.append((company, person))
    return candidates, skipped


def _fullenrich_configured() -> bool:
    from .config import settings
    return bool(settings.fullenrich_enabled and settings.fullenrich_api_key)


def _credit_info() -> dict[str, Any]:
    from .config import settings
    from .uae_state import load_state
    from .fullenrich_mobile import provider_status
    state = load_state()
    live = provider_status()
    if live.get("status") == "ok" and isinstance(live.get("remaining_credits"), (int, float)):
        return {
            "remaining_credits": live["remaining_credits"],
            "mobile_cost": int(settings.fullenrich_mobile_cost),
            "source": "FullEnrich live API",
            "provider_status": "ok",
            "provider_message": live.get("message", ""),
        }
    remaining = state.get("fullenrich_remaining_credits")
    if remaining is None:
        remaining = settings.fullenrich_remaining_credits
    return {
        "remaining_credits": remaining,
        "mobile_cost": int(settings.fullenrich_mobile_cost),
        "source": "local estimate" if remaining is not None else "live balance unavailable",
        "provider_status": live.get("status", "unknown"),
        "provider_message": live.get("message", ""),
    }


def _mobile_estimate(job: dict[str, Any], person_ids: list[str]) -> dict[str, Any]:
    from .config import settings
    if not settings.fullenrich_enabled or not settings.fullenrich_api_key:
        raise ValueError("FullEnrich mobile enrichment is not configured")
    candidates, skipped = _mobile_candidates(job, person_ids)
    max_people = int(getattr(settings, "fullenrich_max_people_per_run", 50))
    if len(candidates) > max_people:
        raise ValueError(f"Free-plan protection: select at most {max_people} not-yet-enriched people per mobile run")
    credit = _credit_info()
    if credit.get("provider_status") == "invalid_api_key":
        raise ValueError(credit.get("provider_message") or "FullEnrich API key was rejected")
    if credit.get("provider_status") == "insufficient_credits":
        raise ValueError(credit.get("provider_message") or "FullEnrich reports insufficient credits")
    max_credits = len(candidates) * int(settings.fullenrich_mobile_cost)
    if credit["remaining_credits"] is not None and credit["remaining_credits"] < max_credits:
        raise ValueError(f"Insufficient estimated FullEnrich credits: {credit['remaining_credits']} remaining, {max_credits} maximum required")
    return {
        "selected_people": len(person_ids),
        "people_to_enrich": len(candidates),
        "skipped": len(skipped),
        "requested_enrichment": "Mobile only",
        "estimated_maximum_credits": max_credits,
        "remaining_credits": credit["remaining_credits"],
        "remaining_source": credit["source"],
        "provider_status": credit.get("provider_status", "unknown"),
        "provider_message": credit.get("provider_message", ""),
        "mobile_cost_per_found_number": int(settings.fullenrich_mobile_cost),
    }


def _run_mobile_async(job: dict[str, Any], person_ids: list[str]) -> None:
    from .fullenrich_mobile import enrich_mobile_by_linkedin
    from .uae_state import record_enrichment

    job["mobile_error"] = ""
    job["mobile_progress"] = {"done": 0, "total": 0, "found": 0, "failed": 0}
    candidates, _ = _mobile_candidates(job, person_ids)
    job["stage"] = "mobile_enriching"
    job["mobile_progress"]["total"] = len(candidates)
    _save_job(job)

    by_company: dict[str, list[tuple[dict[str, Any], dict[str, Any]]]] = {}
    for company, person in candidates:
        by_company.setdefault(company["id"], []).append((company, person))

    progress_lock = threading.Lock()

    def process_company(items: list[tuple[dict[str, Any], dict[str, Any]]]) -> None:
        company = items[0][0]
        known_phones = {str(p.get("phone")) for p in company.get("people", []) if p.get("phone")}
        if company.get("directory_phone"):
            known_phones.add(str(company.get("directory_phone")))
        for _, person in items:
            person["status"] = "Enriching"
            person["mobile_error"] = ""
            try:
                result = enrich_mobile_by_linkedin(
                    person.get("linkedin_url", ""),
                    target_name=person.get("person_name", ""),
                    target_company=company.get("name", ""),
                    target_domain=company.get("domain", ""),
                    exclude_phones=frozenset(known_phones),
                )
            except Exception as exc:  # one provider/result failure must not strand the whole job
                result = {
                    "status": "error", "provider": "fullenrich", "phone": "", "email": "",
                    "errors": [f"Unexpected enrichment error: {type(exc).__name__}: {str(exc)[:220]}"],
                    "requested_fields": ["contact.phones"],
                }
            phone = str(result.get("phone") or "")
            errors = result.get("errors") if isinstance(result.get("errors"), list) else []
            person["phone"] = phone
            person["phone_source"] = result.get("phone_source", "")
            person["verification"] = result.get("verification", "")
            person["fullenrich_status"] = result.get("status", "")
            person["mobile_error"] = "; ".join(str(e) for e in errors if e)[:360]
            if phone:
                person["status"] = "Mobile found"
                known_phones.add(phone)
            elif result.get("status") in {"error", "disabled", "invalid_linkedin"}:
                person["status"] = "Failed"
            else:
                person["status"] = "Mobile not found"

            record = {
                "person_id": person.get("person_id", ""),
                "person_name": person.get("person_name", ""),
                "company": company.get("name", ""),
                "linkedin_url": person.get("linkedin_url", ""),
                "status": person["status"],
                "phone": phone,
                "phone_source": person.get("phone_source", ""),
                "verification": person.get("verification", ""),
                "requested_fields": result.get("requested_fields", ["contact.phones"]),
                "result": result,
            }
            try:
                record_enrichment(person["person_id"], record)
            except Exception as exc:
                # Still surface the provider result on the active job, even if disk state fails.
                person["mobile_error"] = (person.get("mobile_error", "") + f"; history save failed: {type(exc).__name__}")[:360]
            with progress_lock:
                prog = job["mobile_progress"]
                prog["done"] = int(prog.get("done", 0)) + 1
                if phone:
                    prog["found"] = int(prog.get("found", 0)) + 1
                if person["status"] == "Failed":
                    prog["failed"] = int(prog.get("failed", 0)) + 1
                _save_job(job)

    try:
        with ThreadPoolExecutor(max_workers=min(3, max(1, len(by_company)))) as pool:
            list(pool.map(process_company, by_company.values()))
    except Exception as exc:
        job["mobile_error"] = f"Mobile enrichment run error: {type(exc).__name__}: {str(exc)[:240]}"
    finally:
        # Do not leave the entire job in a permanent busy state after any unexpected exception.
        job["stage"] = "discovered"
        try:
            _save_job(job)
        except Exception:
            pass


def _load_next(job: dict[str, Any]) -> bool:
    if job.get("stage") in {"people", "mobile_enriching"}:
        return False
    if not _is_uae_job(job):
        offset = int((job.get("discovery_cursors") or {}).get("offset") or 0)
        result = _official_directory_batch(job, offset=offset)
        batch = result["companies"]
        if not batch:
            job["has_next"] = False
            job["total_matches"] = result["total"]
            _save_job(job)
            return False
        page = int(job.get("page") or 1) + 1
        job["discovery_cursors"] = {"offset": result["next_offset"]}
        job["page"] = page
        job["batch_start"] = offset + 1
        job["batch_end"] = offset + len(batch)
        job["companies"] = [_new_company(c) for c in batch]
        job["selected_company_ids"] = []
        job["selected_people_ids"] = []
        job["total_matches"] = result["total"]
        job["has_next"] = bool(result["has_more"])
        job["source"] = result["source"]
        job["stage"] = "discovered"
        _save_job(job)
        return True

    from .moiat_directory import discover_moiat_batch
    from .uae_state import mark_company_served, served_company_keys
    scope = _job_scope_key(job)
    served = served_company_keys(scope)
    batch, cursors, source_total, has_more = discover_moiat_batch(
        segment=str(job.get("segment") or ""), main_activity_code=str(job.get("main_activity_code") or ""),
        cursors=job.get("discovery_cursors") or {}, served_keys=served, limit=50, progress=_progress_cb(job),
    )
    if not batch:
        job["has_next"] = False
        if source_total is not None:
            job["total_matches"] = source_total
        _save_job(job)
        return False
    page = int(job.get("page") or 1) + 1
    start = len(served) + 1
    job["discovery_cursors"] = cursors
    job["page"] = page
    job["batch_start"] = start
    job["batch_end"] = start + len(batch) - 1
    job["companies"] = _rank_company_batch([_new_company(c.as_dict() if hasattr(c, "as_dict") else c) for c in batch])
    job["selected_company_ids"] = []
    job["selected_people_ids"] = []
    if source_total is not None:
        job["total_matches"] = source_total
    for company in job["companies"]:
        mark_company_served(scope, company["company_key"])
    job["has_next"] = bool(has_more)
    job["stage"] = "discovered"
    _save_job(job)
    return True


def _csv_filename(job: dict[str, Any]) -> str:
    import re
    raw = str(job.get("segment") or "") or (f"activity_{job.get('main_activity_code')}" if job.get("main_activity_code") else "export")
    slug = re.sub(r"[^A-Za-z0-9]+", "_", raw).strip("_")[:30] or "export"
    country_value = str(job.get("country") or "United Arab Emirates")
    country = "uae" if country_value.casefold() in {"united arab emirates", "uae"} else country_value.lower().replace(" ", "_")
    return f"{country}_people_{slug}.csv"


def _csv(job: dict[str, Any]) -> bytes:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["segment", "company", "emirate", "person", "title", "seniority", "target_title", "linkedin", "mobile", "status", "verification", "company_relationship"])
    for company in job.get("companies", []):
        for p in company.get("people", []):
            w.writerow([
                _job_filter_label(job), company.get("name", ""), company.get("emirate", ""),
                p.get("person_name", ""), p.get("job_title", ""), p.get("seniority", ""), p.get("target_title", ""),
                p.get("linkedin_url", ""), p.get("phone", ""), p.get("status", ""), p.get("verification", ""),
                (company.get("resolution") or {}).get("label", "") or p.get("company_relationship", ""),
            ])
    return ("\ufeff" + buf.getvalue()).encode("utf-8")


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _send(self, code: int, body: bytes, ctype: str, extra: dict[str, str] | None = None) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, code: int, obj: Any) -> None:
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

    def _body(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) or b"{}"
        obj = json.loads(raw)
        if not isinstance(obj, dict):
            raise ValueError("JSON body must be an object")
        return obj

    # ---- login gate (single credential, see app/auth.py)
    def _secure(self) -> bool:
        return self.headers.get("X-Forwarded-Proto", "").split(",")[0].strip().lower() == "https"

    def _client_ip(self) -> str:
        fwd = self.headers.get("X-Forwarded-For", "").split(",")[0].strip()
        return fwd or self.client_address[0]

    def _redirect(self, where: str, extra: dict[str, str] | None = None) -> None:
        self._send(302, b"", "text/plain", {"Location": where, "Cache-Control": "no-store", **(extra or {})})

    def _handle_login(self) -> None:
        from . import auth
        import time as _time
        ip = self._client_ip()
        wait = auth.locked_for(ip)
        if wait:
            return self._json(429, {"error": f"Too many attempts. Try again in {wait} seconds."})
        try:
            body = self._body()
        except Exception:
            return self._json(400, {"error": "Invalid request."})
        if auth.check_credentials(str(body.get("username") or ""), str(body.get("password") or "")):
            auth.record_success(ip)
            return self._send(200, b'{"ok": true}', "application/json; charset=utf-8",
                              {"Set-Cookie": auth.cookie_header(auth.make_token(), self._secure()), "Cache-Control": "no-store"})
        auth.record_failure(ip)
        _time.sleep(0.4)  # slows down guessing
        return self._json(401, {"error": "Incorrect username or password."})

    def _auth_gate(self, method: str, path: str) -> bool:
        """Return True when the request was fully handled here (login page, redirect or 401)."""
        from . import auth
        if path == "/health":
            return False
        if not auth.enabled():
            if method == "GET" and path == "/login":
                self._redirect("/")
                return True
            return False
        authed = auth.is_authenticated(self.headers.get("Cookie", ""))
        if method == "POST" and path == "/api/login":
            self._handle_login()
            return True
        if method == "POST" and path == "/api/logout":
            self._send(200, b'{"ok": true}', "application/json; charset=utf-8", {"Set-Cookie": auth.clear_cookie_header(self._secure())})
            return True
        if method == "GET" and path == "/login":
            if authed:
                self._redirect("/")
            else:
                self._send(200, (WEB / "login.html").read_bytes(), "text/html; charset=utf-8", {"Cache-Control": "no-store"})
            return True
        if authed:
            return False
        if path.startswith("/api/"):
            self._json(401, {"error": "Not signed in."})
        else:
            self._redirect("/login")
        return True

    def do_GET(self) -> None:
        path = self.path.split("?", 1)[0]
        if self._auth_gate("GET", path):
            return
        if path == "/health":
            return self._json(200, {"ok": True, "service": "mena-global", "version": "7.9.9"})
        if path == "/":
            return self._send(200, (WEB / "index.html").read_bytes(), "text/html; charset=utf-8")
        if path == "/api/mobile/provider-status":
            from .fullenrich_mobile import provider_status
            result = provider_status()
            return self._json(200 if result.get("status") == "ok" else 503, result)
        if path == "/api/meta":
            return self._json(200, {
                "country": "United Arab Emirates",
                "countries": [
                    {"value": "United Arab Emirates", "label": "United Arab Emirates", "directory": "UAE MoIAT", "url": "https://il.moiat.gov.ae/en/OpenData/IPLDirectory", "needs_key": False},
                    {"value": "United States", "label": "United States", "directory": "SEC EDGAR", "url": "https://www.sec.gov/edgar/search/", "needs_key": False},
                    {"value": "United Kingdom", "label": "United Kingdom", "directory": "Companies House", "url": "https://find-and-update.company-information.service.gov.uk/", "needs_key": True},
                    {"value": "Canada", "label": "Canada", "directory": "Canada's Business Registries", "url": "https://ised-isde.canada.ca/cbr-rec/en/", "terms_url": "https://ised-isde.canada.ca/cbr-rec/faq", "needs_key": False, "manual_verification": True},
                ],
                "segments": TARGET_SEGMENTS,
                "main_activities": [{"code": code, "label": label} for code, label in MOIAT_MAIN_ACTIVITIES],
                "titles": TARGET_TITLES,
                "seniority": ALLOWED_SENIORITY,
                "moiat_directory_url": "https://il.moiat.gov.ae/en/OpenData/IPLDirectory",
                "companies_house_configured": bool(__import__("os").getenv("COMPANIES_HOUSE_API_KEY", "").strip()),
                "fullenrich_configured": _fullenrich_configured(),
                "auth": __import__("app.auth", fromlist=["enabled"]).enabled(),
            })
        if path.startswith("/api/jobs/"):
            jid, _, ext = path[len("/api/jobs/"):].partition(".")
            job = _load_job(jid)
            if not job:
                return self._json(404, {"error": "unknown job"})
            if ext == "csv":
                return self._send(200, _csv(job), "text/csv; charset=utf-8", {"Content-Disposition": f'attachment; filename="{_csv_filename(job)}"'})
            return self._json(200, job)
        self._json(404, {"error": "not found"})

    def do_POST(self) -> None:
        path = self.path.split("?", 1)[0]
        if self._auth_gate("POST", path):
            return
        try:
            body = self._body()
        except Exception as exc:
            return self._json(400, {"error": f"invalid JSON: {exc}"})

        if path == "/api/directory-check":
            country = str(body.get("country") or "").strip()
            try:
                from .company_directories import check_directory_connection, DirectoryError
                result = check_directory_connection(country)
                return self._json(200, result)
            except DirectoryError as exc:
                # Keep the response shape stable for the UI; messages never contain credentials.
                return self._json(200, {"ok": False, "country": country, "message": str(exc)})
            except Exception as exc:
                return self._json(200, {"ok": False, "country": country,
                                        "message": f"Directory check failed ({type(exc).__name__}). Check the app log and retry."})

        if path == "/api/run":
            country = str(body.get("country") or "United Arab Emirates").strip()
            segment = str(body.get("segment") or "").strip()
            main_activity_code = str(body.get("main_activity_code") or "").strip()
            search_query = str(body.get("search_query") or "").strip()
            valid_countries = {"United Arab Emirates", "United States", "United Kingdom", "Canada"}
            if country not in valid_countries:
                return self._json(400, {"error": "Choose UAE, United States, United Kingdom, or Canada."})
            if segment and segment not in TARGET_SEGMENTS:
                return self._json(400, {"error": "Invalid target segment"})
            if country == "United Arab Emirates":
                if main_activity_code and main_activity_code not in MAIN_ACTIVITY_CODES:
                    return self._json(400, {"error": "Invalid MoIAT Main Activity code"})
                if not segment and not main_activity_code:
                    return self._json(400, {"error": "Choose a target segment or a MoIAT Main Activity"})
                if search_query:
                    return self._json(400, {"error": "The keyword search field is for US/UK directories. Use the UAE segment or MoIAT activity filter."})
            else:
                main_activity_code = ""
                if not search_query:
                    search_query = segment
                if not search_query:
                    return self._json(400, {"error": "Choose a target segment or enter company/industry keywords."})
            job = {
                "id": uuid.uuid4().hex[:10], "segment": segment, "main_activity_code": main_activity_code,
                "search_query": search_query, "country": country, "stage": "queued", "companies": [],
                "remaining_queue": [], "discovery_cursors": {}, "total_matches": 0, "page": 0, "batch_start": 0,
                "batch_end": 0, "has_next": False, "selected_company_ids": [],
                "selected_people_ids": [], "error": "",
            }
            _save_job(job)
            threading.Thread(target=_discover_thread, args=(job,), daemon=True).start()
            return self._json(200, {"id": job["id"]})

        if path == "/api/selection":
            job = _load_job(str(body.get("job_id") or ""))
            if not job:
                return self._json(404, {"error": "unknown job"})
            company_ids = [str(x) for x in body.get("company_ids", []) if str(x)]
            person_ids = [str(x) for x in body.get("person_ids", []) if str(x)]
            valid_companies = {c["id"] for c in job.get("companies", [])}
            company_ids = [x for x in company_ids if x in valid_companies]
            selected_company_set = set(company_ids)
            valid_people = {p.get("person_id") for c in job.get("companies", []) if c.get("id") in selected_company_set for p in c.get("people", [])}
            person_ids = [x for x in person_ids if x in valid_people]
            job["selected_company_ids"] = company_ids
            job["selected_people_ids"] = person_ids
            for c in job.get("companies", []):
                c["selected"] = c["id"] in selected_company_set
                for p in c.get("people", []):
                    p["selected"] = p.get("person_id") in set(person_ids)
            _save_job(job)
            return self._json(200, {"selected_companies": len(company_ids), "selected_people": len(person_ids)})

        if path == "/api/run-selected":
            job = _load_job(str(body.get("job_id") or ""))
            if not job:
                return self._json(404, {"error": "unknown job"})
            ids = [str(x) for x in body.get("company_ids", []) if str(x)]
            valid = {c["id"] for c in job.get("companies", [])}
            ids = [x for x in ids if x in valid]
            if not ids:
                return self._json(400, {"error": "Select at least one company"})
            job["selected_company_ids"] = ids
            if job.get("stage") in {"people", "mobile_enriching"}:
                return self._json(409, {"error": "A selected-company operation is already in progress"})
            job["stage"] = "people"
            _save_job(job)
            threading.Thread(target=_run_selected_people, args=(job, job.get("selected_people_ids", [])), daemon=True).start()
            return self._json(200, {"id": job["id"], "selected": ids})

        if path == "/api/load-next":
            job = _load_job(str(body.get("job_id") or ""))
            if not job:
                return self._json(404, {"error": "unknown job"})
            if job.get("stage") in {"people", "mobile_enriching", "discover"}:
                return self._json(409, {"error": "Another operation is still running"})
            if not job.get("has_next"):
                return self._json(409, {"error": "No more companies available", "has_next": False})
            job["stage"] = "discover"
            _save_job(job)
            threading.Thread(target=_load_next_thread, args=(job,), daemon=True).start()
            return self._json(200, {"id": job["id"], "started": True})

        if path == "/api/mobile/estimate":
            job = _load_job(str(body.get("job_id") or ""))
            if not job:
                return self._json(404, {"error": "unknown job"})
            try:
                estimate = _mobile_estimate(job, [str(x) for x in body.get("person_ids", []) if str(x)])
                job["mobile_estimate"] = estimate
                _save_job(job)
                return self._json(200, estimate)
            except Exception as exc:
                return self._json(400, {"error": str(exc)})

        if path == "/api/mobile/start":
            job = _load_job(str(body.get("job_id") or ""))
            if not job:
                return self._json(404, {"error": "unknown job"})
            person_ids = [str(x) for x in body.get("person_ids", []) if str(x)]
            try:
                estimate = _mobile_estimate(job, person_ids)
            except Exception as exc:
                return self._json(400, {"error": str(exc)})
            if not person_ids or estimate["people_to_enrich"] == 0:
                return self._json(400, {"error": "No new people are eligible for mobile enrichment"})
            job["selected_people_ids"] = person_ids
            job["mobile_estimate"] = estimate
            _save_job(job)
            threading.Thread(target=_run_mobile_async, args=(job, person_ids), daemon=True).start()
            return self._json(200, {"started": True, "estimate": estimate})

        self._json(404, {"error": "not found"})


def serve(port: int = 8000, host: str = "127.0.0.1") -> None:
    """Run the threaded HTTP server. Use host=0.0.0.0 on cloud hosts."""
    from . import auth
    if not auth.enabled():
        if host not in {"127.0.0.1", "localhost", "::1"}:
            raise RuntimeError("APP_PASSWORD is not set. Set APP_USERNAME and APP_PASSWORD before exposing the app on a network address.")
        print("WARNING: APP_PASSWORD is not set, so the login page is OFF. Set APP_USERNAME and APP_PASSWORD in .env to require sign-in.", flush=True)
    server = ThreadingHTTPServer((host, port), Handler)
    try:
        server.serve_forever()
    finally:
        server.server_close()

# Backward-compatible internal helpers retained for the existing regression suite.
# The active UI does not use these paths; it uses the MoIAT-specific implementations above.
def _discover_job(job: dict) -> None:
    from .discovery import discover_companies
    try:
        job["stage"] = "discover"
        found = discover_companies(job.get("country", "United Arab Emirates"), job.get("industry", ""), int(job.get("max") or 10))
        job["companies"] = [
            {
                "id": uuid.uuid4().hex[:12], "name": c.get("company_name", ""), "domain": c.get("known_domain") or "",
                "status": "queued", "selected": False, "people": [], "note": "", "sources_used": 0, "warnings": [], "diagnostics": {},
            } for c in found
        ]
        job["stage"] = "discovered"
    except Exception as exc:
        job["stage"], job["error"] = "error", str(exc)


def _run_selected(job: dict, selected_ids: list[str]) -> None:
    """Legacy selector helper. Active UAE UI uses _run_selected_people instead."""
    from .hierarchy import build_company_record
    from .webpeople import find_web_people
    selected = set(selected_ids)
    job["selected_ids"] = list(selected_ids)
    companies = [c for c in job.get("companies", []) if c.get("id") in selected]
    if not companies:
        job["selection_error"] = "Select at least one company."
        return
    for item in companies:
        item["status"] = "running"
        item["selected"] = True
        try:
            rec = build_company_record(
                item["name"], country=job.get("country", ""), industry=job.get("industry", ""), domain=item.get("domain", ""),
            )
            res = find_web_people(rec)
            item["people"] = res.get("people", [])
            item["sources_used"] = int(res.get("sources_used") or 0)
            item["warnings"] = list(res.get("errors") or [])[:6]
            item["status"] = "done"
        except Exception as exc:
            item["status"] = "error"
            item["note"] = str(exc)[:200]
    job["stage"] = "discovered"
