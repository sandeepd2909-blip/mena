"""Deterministic identity normalization helpers used across people/company matching.

These helpers do not invent people or contacts. They only generate conservative
string variants so common formatting differences (e.g. ``Al Majdouie`` vs
``Almajdouie``) do not cause an otherwise valid company match to fail.
"""
from __future__ import annotations

import re
import unicodedata
from typing import Any

_GENERIC_COMPANY_WORDS = {
    "the", "company", "co", "corp", "corporation", "inc", "incorporated", "ltd", "limited",
    "llc", "group", "holding", "holdings", "international", "services", "trading", "enterprise",
    "enterprises", "industries", "industry", "solutions", "technologies", "technology",
    "partners", "partner", "management", "investment", "investments",
}

_LEGAL_SUFFIX_PATTERN = re.compile(
    r"(?:\s|[,.()\-/])+(?:l\.?l\.?c\.?|llc|ltd\.?|limited|inc\.?|incorporated|corp\.?|corporation|fze|fzco|fzc|w\.?l\.?l\.?|wll|p\.?j\.?s\.?c\.?|pjsc|s\.?p\.?|sp|s\.?a\.?|sa|est\.?|establishment)$",
    re.I,
)


def _strip_legal_suffixes(value: str) -> str:
    text = re.sub(r"\s+", " ", _text(value)).strip(" ,.;:/-–—()")
    previous = None
    while text and text != previous:
        previous = text
        text = _LEGAL_SUFFIX_PATTERN.sub("", text).strip(" ,.;:/-–—()")
        # UAE company registries sometimes append the legal descriptor before
        # LLC (e.g. "Al Ghurair Poultry - Sole Proprietorship L.L.C."). Keep the
        # original as a variant, but also search/match the underlying brand name.
        text = re.sub(r"\bsole\s+proprietorship\b", " ", text, flags=re.I)
        text = re.sub(r"\bsole\s+proprietor\b", " ", text, flags=re.I)
        text = re.sub(r"\s+", " ", text).strip(" ,.;:/-–—()")
    return text


def _derived_acronym(value: str) -> str:
    words = [w.casefold() for w in re.findall(r"[A-Za-z0-9]+", _strip_legal_suffixes(value))]
    words = [w for w in words if len(w) > 1 and w not in {"and"}]
    if len(words) < 3 or len(words) > 8:
        return ""
    acronym = "".join(w[0] for w in words).upper()
    return acronym if 3 <= len(acronym) <= 7 else ""


def _text(value: Any) -> str:
    return str(value or "").strip()


def normalize_identity(value: Any) -> str:
    text = unicodedata.normalize("NFKD", _text(value)).casefold()
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9\u0600-\u06ff]+", " ", text).strip()


def compact_identity(value: Any) -> str:
    return re.sub(r"[^a-z0-9\u0600-\u06ff]", "", normalize_identity(value))



# V7.8.64: registered MoIAT names often end in descriptors that LinkedIn headlines leave out
# ("Emirates Glass Factory L.L.C." is shown as "Emirates Glass"). These words are removed one by
# one from the END of the name to produce a brand-core variant. A core is only used when it is still
# distinctive (two or more words, or one long non-geographic word).
_TRAILING_DESCRIPTORS = {
    "factory", "factories", "manufacturing", "manufacture", "manufacturers", "mfg", "plant", "plants",
    "products", "product", "industrial", "industries", "industry", "trading", "trade", "establishment",
    "enterprises", "enterprise", "group", "company", "co", "corporation", "corp", "general", "commercial",
    "contracting", "est", "works", "production", "productions", "and", "&", "the", "of",
}
_WEAK_SINGLE_WORDS = {
    "gulf", "emirates", "emirate", "arabian", "arab", "national", "united", "dubai", "abu", "dhabi",
    "sharjah", "ajman", "uae", "middle", "east", "global", "modern", "royal", "golden", "first",
    "new", "al", "international", "universal", "general", "advanced", "premier", "star", "best",
}


def brand_core_variants(company_name: str) -> list[str]:
    """Return progressively shorter brand-core names with trailing descriptor words removed."""
    base = _strip_legal_suffixes(re.sub(r"\s+", " ", _text(company_name)).strip())
    words = base.split()
    out: list[str] = []
    while words and words[-1].casefold().strip(".,&-") in _TRAILING_DESCRIPTORS:
        words = words[:-1]
        while words and words[-1].casefold().strip(".,&-") in {"and", "&", "the", "of", "-"}:
            words = words[:-1]
        if not words:
            break
        tokens = [w for w in re.findall(r"[A-Za-z0-9\u0600-\u06ff]+", " ".join(words))]
        non_al = [t for t in tokens if t.casefold() != "al"]
        if len(non_al) >= 2:
            ok = True
        elif len(non_al) == 1:
            t = non_al[0]
            ok = len(t) >= 6 and t.casefold() not in _WEAK_SINGLE_WORDS
        else:
            ok = False
        if ok:
            out.append(" ".join(words))
    return out


def company_name_variants(company_name: str) -> list[str]:
    """Generate conservative formatting/legal/acronym variants used by public search.

    This does not invent a different company. It handles representations commonly used
    by official registers and LinkedIn, such as ``L.L.C - S.P`` vs ``LLC`` and
    ``International Beverage & Filling Industries`` vs ``IBFI``.
    """
    original = re.sub(r"\s+", " ", _text(company_name)).strip()
    if not original:
        return []

    variants: list[str] = []
    seen: set[str] = set()

    def add(value: str) -> None:
        value = re.sub(r"\s+", " ", _text(value)).strip(" ,;/|-")
        key = value
        if value and key and key not in seen:
            seen.add(key)
            variants.append(value)

    add(original)
    stripped = _strip_legal_suffixes(original)
    add(stripped)
    for core in brand_core_variants(original):
        add(core)

    parts = re.findall(r"[A-Za-z0-9\u0600-\u06ff]+", stripped)
    for i in range(len(parts) - 1):
        if parts[i].casefold() == "al":
            fused = parts[:i] + [parts[i] + parts[i + 1]] + parts[i + 2:]
            add(" ".join(fused))
            fused_lower = parts[:i] + [parts[i] + parts[i + 1].lstrip("A").lstrip("a").lower()] + parts[i + 2:]
            add(" ".join(fused_lower))

    add(re.sub(r"\bAl[-\s]+(?=[A-Za-z])", "Al", stripped, flags=re.I))
    add(re.sub(r"[&]", "and", stripped, flags=re.I))
    acronym = _derived_acronym(stripped)
    if acronym:
        add(acronym)
    add(re.sub(r"\s+", "", stripped))
    return variants[:10] or [original]


def company_match_score(requested: str, candidate: str) -> int:
    """Return a conservative 0-100 lexical match score for company identity."""
    req_norm = normalize_identity(requested)
    cand_norm = normalize_identity(candidate)
    if not req_norm or not cand_norm:
        return 0
    if req_norm == cand_norm or compact_identity(req_norm) == compact_identity(cand_norm):
        return 100

    req_variants = {normalize_identity(v) for v in company_name_variants(requested)}
    cand_variants = {normalize_identity(v) for v in company_name_variants(candidate)}
    if req_variants & cand_variants:
        return 95

    req_tokens = {t for t in req_norm.split() if len(t) > 2 and t not in _GENERIC_COMPANY_WORDS}
    cand_tokens = {t for t in cand_norm.split() if len(t) > 2 and t not in _GENERIC_COMPANY_WORDS}
    if req_tokens and req_tokens.issubset(cand_tokens):
        return 85

    req_compact = compact_identity(req_norm)
    cand_compact = compact_identity(cand_norm)
    if req_compact and cand_compact and (req_compact in cand_compact or cand_compact in req_compact):
        return 75
    return 0


def company_mentioned(company_name: str, text: str) -> bool:
    hay = normalize_identity(text)
    if not hay:
        return False
    hay_compact = compact_identity(text)
    for variant in company_name_variants(company_name):
        norm = normalize_identity(variant)
        if norm and norm in hay:
            return True
        compact = compact_identity(variant)
        if compact and compact in hay_compact:
            return True
    tokens = [t for t in normalize_identity(company_name).split() if len(t) > 2 and t not in _GENERIC_COMPANY_WORDS]
    return len(tokens) >= 1 and any(token in hay.split() for token in tokens)


# ---------------------------------------------------------------------------
# V7.8.56 person-identity helpers (strict LinkedIn profile ownership)
# ---------------------------------------------------------------------------
_PERSON_NOISE = {
    "dr", "eng", "engr", "prof", "mr", "mrs", "ms", "miss", "phd", "mba", "pmp", "cpa", "cfa",
    "sheikh", "sheikha", "shaikh", "hh", "hrh", "capt", "captain", "col", "gen", "msc", "bsc",
}
_PERSON_PARTICLES = {"al", "el", "bin", "ibn", "bint", "de", "van", "von", "la", "le"}

# Transliteration families that routinely differ between registers and LinkedIn.
_TRANSLIT_FAMILIES: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"^(?:moh?amm?[ae]d|muh?amm?[ae]d|mohd|mhd|mohamad|muhamad)$"), "mohammed"),
    (re.compile(r"^ah?m[ae]d$"), "ahmed"),
    (re.compile(r"^abd[ua]l+ah?$"), "abdullah"),
    (re.compile(r"^abd[ue]l?r[ae]h?m[ae]n$"), "abdulrahman"),
    (re.compile(r"^(?:hus+[ae]i?n|hus+ain)$"), "hussein"),
    (re.compile(r"^kh[ae]l[ei]d$"), "khalid"),
    (re.compile(r"^(?:omar|umar)$"), "omar"),
    (re.compile(r"^(?:yous+[eu]f|yus+uf|yous+if)$"), "yousef"),
    (re.compile(r"^(?:sul[ae]i?m[ae]n|sulayman|suleiman|sulaiman)$"), "sulaiman"),
    (re.compile(r"^(?:mus?t[ao]f[ao])$"), "mustafa"),
    (re.compile(r"^(?:ib|eb)r[ae]h?im$"), "ibrahim"),
    (re.compile(r"^has+[ae]n$"), "hassan"),
]


def _canonical_name_token(token: str) -> str:
    tok = normalize_identity(token).replace(" ", "")
    if not tok:
        return ""
    for pattern, canon in _TRANSLIT_FAMILIES:
        if pattern.match(tok):
            return canon
    # Fused article: "almajdouie" == "al majdouie" (symmetric on both sides).
    if tok.startswith("al") and len(tok) - 2 >= 3:
        tok = tok[2:]
    elif tok.startswith("el") and len(tok) - 2 >= 3:
        tok = tok[2:]
    return re.sub(r"(.)\1+", r"\1", tok)  # collapse doubled letters


def person_name_tokens(name: Any) -> list[str]:
    """Canonical comparable tokens of a person's name (honorifics/particles removed)."""
    raw = [t for t in re.findall(r"[^\W\d_]+", unicodedata.normalize("NFKC", _text(name)))]
    out: list[str] = []
    for tok in raw:
        low = normalize_identity(tok).replace(" ", "")
        if not low or low in _PERSON_NOISE or low in _PERSON_PARTICLES:
            continue
        canon = _canonical_name_token(tok)
        if canon:
            out.append(canon)
    return out


def person_names_match(wanted: Any, candidate: Any) -> bool:
    """True when ``candidate`` is plausibly the same person as ``wanted``.

    First and last name must both be present (after transliteration/particle
    normalisation). Middle names may differ. A single-token wanted name is never
    matched, because it cannot identify a person safely.
    """
    a = person_name_tokens(wanted)
    b = person_name_tokens(candidate)
    if len(a) < 2 or len(b) < 2:
        return False
    return a[0] in b and a[-1] in b


def linkedin_slug_tokens(url: Any) -> list[str]:
    m = re.search(r"linkedin\.com/in/([^/?#]+)", _text(url), re.I)
    if not m:
        return []
    slug = m.group(1)
    parts = [p for p in re.split(r"[-_.%]+", slug) if p]
    # Drop LinkedIn's numeric/hex disambiguator suffixes (e.g. 62453518, 1a2b3c4).
    parts = [p for p in parts if not (re.search(r"\d", p) and re.fullmatch(r"[0-9a-fA-F]+", p))]
    return [t for t in (_canonical_name_token(p) for p in parts if p.isalpha()) if t]


def linkedin_slug_matches_name(url: Any, person_name: Any) -> bool:
    """Slug carries both first and last name (handles ``omarkhan`` and ``omar-khan-123``)."""
    want = person_name_tokens(person_name)
    if len(want) < 2:
        return False
    slug = linkedin_slug_tokens(url)
    if not slug:
        return False
    if want[0] in slug and want[-1] in slug:
        return True
    joined = "".join(slug)
    return len(want[0]) >= 3 and len(want[-1]) >= 3 and want[0] in joined and want[-1] in joined


def linkedin_slug_conflicts_with_name(url: Any, person_name: Any) -> bool:
    """True when the slug clearly spells a DIFFERENT person (>=2 name words, none of ours).

    Opaque slugs (ACoAA..., initials, custom words) never conflict - we cannot tell.
    """
    want = person_name_tokens(person_name)
    slug = linkedin_slug_tokens(url)
    if len(want) < 2 or len(slug) < 2:
        return False
    joined = "".join(slug)
    return not any(t in slug or (len(t) >= 3 and t in joined) for t in (want[0], want[-1]))


def linkedin_owner_name(title: Any) -> str:
    """Profile owner's name from a search-result title: ``Name - Role - Company | LinkedIn``."""
    t = re.sub(r"\s*[|\-–—·]\s*LinkedIn.*$", "", _text(title), flags=re.I).strip()
    first = re.split(r"\s+[-–—|·•]\s+", t)[0]
    first = re.split(r",\s+", first)[0]  # "Omar Khan, MBA"
    return first.strip()


def linkedin_profile_owner_matches(url: Any, title: Any, person_name: Any) -> bool:
    """Does the LinkedIn page belong to ``person_name``?

    A name that merely appears inside someone else's profile (recommendations,
    'people also viewed', posts) must NOT count. The owner is read from the result
    title; when the title has no usable two-word name the URL slug decides.
    """
    owner = linkedin_owner_name(title)
    owner_tokens = [t for t in person_name_tokens(owner) if len(t) >= 2]
    if len(owner_tokens) >= 2:
        return person_names_match(person_name, owner)
    return linkedin_slug_matches_name(url, person_name)
