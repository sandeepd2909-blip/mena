from urllib.parse import urlparse
import re

import requests

from .config import settings


def _configured(value: str | None) -> bool:
    value = str(value or "").strip()
    return bool(value) and not value.startswith("PASTE_YOUR_")


def normalize_domain(url: str) -> str:
    try:
        host = urlparse(url).netloc.lower().strip()
    except Exception:
        return ""
    if host.startswith("www."):
        host = host[4:]
    return host


# Provider plan/auth failures should not cause one failing API call per query.
# A Tavily 432/433 is an account-limit response, so fail over once and avoid further
# Tavily network calls until the process restarts (for example, after updating credits).
_DISABLED_PROVIDERS: dict[str, str] = {}


def _http_status(exc: BaseException) -> int | None:
    response = getattr(exc, "response", None)
    status = getattr(response, "status_code", None)
    if status is not None:
        try:
            return int(status)
        except (TypeError, ValueError):
            pass
    match = re.search(r"\b(401|403|429|432|433)\b", str(exc))
    return int(match.group(1)) if match else None


def _tavily_http_message(status: int) -> str:
    if status == 432:
        return "Tavily HTTP 432: plan usage limit exceeded. Tavily is paused for this run; check the Tavily dashboard or use the configured Serper fallback."
    if status == 433:
        return "Tavily HTTP 433: pay-as-you-go usage limit exceeded. Tavily is paused for this run; increase the limit or use the configured Serper fallback."
    if status == 401:
        return "Tavily HTTP 401: API key is missing, invalid, expired, or revoked."
    if status == 403:
        return "Tavily HTTP 403: request is forbidden by the current key/account plan."
    return f"Tavily HTTP {status}: request failed."


def tavily_search(query: str, include_domains=None, max_results=None):
    blocked = _DISABLED_PROVIDERS.get("tavily")
    if blocked:
        raise RuntimeError(blocked)
    if not _configured(getattr(settings, "tavily_api_key", "")):
        raise RuntimeError("TAVILY_API_KEY is missing")
    payload = {
        "api_key": settings.tavily_api_key,
        "query": query,
        "search_depth": settings.search_depth,
        "max_results": max_results or settings.max_search_results,
        "include_answer": False,
        "include_raw_content": True,
    }
    if include_domains:
        payload["include_domains"] = include_domains
    response = requests.post(
        "https://api.tavily.com/search",
        json=payload,
        timeout=settings.request_timeout,
    )
    try:
        response.raise_for_status()
    except requests.HTTPError as exc:
        status = getattr(response, "status_code", None)
        if status in {401, 403, 432, 433}:
            message = _tavily_http_message(int(status))
            if status in {432, 433, 401, 403}:
                _DISABLED_PROVIDERS["tavily"] = message
            raise RuntimeError(message) from exc
        raise
    return response.json().get("results", [])


def serper_search(query: str, include_domains=None, max_results=None):
    """Google Search results through Serper.dev (optional)."""
    if not _configured(getattr(settings, "serper_api_key", "")):
        raise RuntimeError("SERPER_API_KEY is missing")
    q = str(query or "").strip()
    if include_domains:
        domains = [str(d).strip() for d in include_domains if str(d).strip()]
        if domains and not any(f"site:{d}" in q for d in domains):
            if len(domains) == 1:
                q = f"site:{domains[0]} {q}"
            else:
                q = f"({' OR '.join('site:' + d for d in domains)}) {q}"
    # Serper can occasionally stall; keep the fallback bounded so one provider
    # outage does not make a company look as if it has no decision-makers.
    timeout = min(max(int(getattr(settings, "request_timeout", 30)), 5), 12)
    response = requests.post(
        "https://google.serper.dev/search",
        headers={"X-API-KEY": settings.serper_api_key, "Content-Type": "application/json"},
        json={"q": q, "num": max_results or 10},
        timeout=(min(timeout, 5), timeout),
    )
    response.raise_for_status()
    return [
        {"url": x.get("link", ""), "title": x.get("title", ""), "content": x.get("snippet", "")}
        for x in response.json().get("organic", [])
    ]


_SEARCH_DIAGNOSTICS = {"serper_attempts": 0, "serper_failures": 0, "tavily_attempts": 0, "tavily_failures": 0, "last_serper_error": "", "last_tavily_error": ""}

def _primary_search_provider() -> str:
    provider = str(getattr(settings, "search_provider", "tavily") or "tavily").strip().lower()
    return provider if provider in {"tavily", "serper"} else "tavily"


def public_search(query: str, include_domains=None, max_results=None):
    """Use the configured search provider first, then the other configured provider.

    ``SEARCH_PROVIDER`` is authoritative. This prevents a supplied Serper key from
    silently overriding ``SEARCH_PROVIDER=tavily``. Diagnostics are retained so the
    dashboard can explain provider failures instead of presenting a misleading empty result.
    """
    primary = _primary_search_provider()
    order = (primary, "serper" if primary == "tavily" else "tavily")
    failures = []
    # Skip a provider with a known hard quota/auth failure for the remainder of
    # this process. Prefer the other configured provider without repeated 432s.
    ordered_available = [p for p in order if p not in _DISABLED_PROVIDERS]
    if ordered_available:
        order = tuple(ordered_available)
        for p, reason in _DISABLED_PROVIDERS.items():
            failures.append(f"{p}: paused after provider error ({reason})")
    else:
        details = " | ".join(f"{p}: {reason}" for p, reason in _DISABLED_PROVIDERS.items())
        raise RuntimeError(f"No usable public search provider remains. {details}. Update provider credentials/plan and restart the app.")
    for provider in order:
        try:
            if provider == "tavily":
                if not _configured(getattr(settings, "tavily_api_key", "")):
                    raise RuntimeError("TAVILY_API_KEY is missing")
                _SEARCH_DIAGNOSTICS["tavily_attempts"] += 1
                hits = tavily_search(query, include_domains=include_domains, max_results=max_results)
                if hits:
                    return hits
                failures.append("tavily: returned 0 results; trying fallback provider")
                continue
            if not _configured(getattr(settings, "serper_api_key", "")):
                raise RuntimeError("SERPER_API_KEY is missing")
            _SEARCH_DIAGNOSTICS["serper_attempts"] += 1
            hits = serper_search(query, include_domains=include_domains, max_results=max_results)
            if hits:
                return hits
            failures.append("serper: returned 0 results")
        except Exception as exc:
            status = _http_status(exc)
            # Also catch status-coded failures raised by mocks/wrappers around the
            # low-level client so the circuit breaker remains reliable.
            if provider == "tavily" and status in {401, 403, 432, 433}:
                _DISABLED_PROVIDERS["tavily"] = _tavily_http_message(status)
            failures.append(f"{provider}: {type(exc).__name__}: {str(exc)[:220]}")
            if provider == "tavily":
                _SEARCH_DIAGNOSTICS["tavily_failures"] += 1
                _SEARCH_DIAGNOSTICS["last_tavily_error"] = str(exc)[:300]
            else:
                _SEARCH_DIAGNOSTICS["serper_failures"] += 1
                _SEARCH_DIAGNOSTICS["last_serper_error"] = str(exc)[:300]
    detail = " | ".join(failures) or "no provider returned results"
    raise RuntimeError(f"Public search failed for configured providers ({detail}). Check provider connectivity/API keys; this is a search outage, not proof that the company has no decision-makers.")
