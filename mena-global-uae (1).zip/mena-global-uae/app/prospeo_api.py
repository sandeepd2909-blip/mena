"""Prospeo exact LinkedIn -> verified email/mobile enrichment.

Prospeo is the primary contact-enrichment provider in V7.8.34. The caller's
LinkedIn URL is the strongest identity anchor. Company name/domain are also
submitted when available and provider-returned identity/company data are
validated before a contact is surfaced.
"""
from __future__ import annotations

import re
import unicodedata
from typing import Any
from urllib.parse import urlparse

import requests

from .config import settings


class ProspeoAPIError(RuntimeError):
    pass


_GENERIC_LOCALS = {
    "info", "contact", "contactus", "sales", "support", "hello", "admin", "office",
    "enquiries", "enquiry", "inquiries", "inquiry", "mail", "media", "press", "hr",
    "careers", "jobs", "marketing", "service", "customerservice", "webmaster", "noreply",
    "no-reply", "reception", "accounts", "mobile", "phone", "telephone", "tel", "general",
    "business",
}


def _text(value: Any) -> str:
    return str(value or "").strip()


def _norm(value: Any) -> str:
    text = unicodedata.normalize("NFKC", _text(value))
    text = "".join(ch for ch in text if unicodedata.category(ch) not in {"Cf", "Cs"})
    return " ".join(text.casefold().split())


def _host(value: str) -> str:
    try:
        raw = value if "://" in value else f"https://{value}"
        return urlparse(raw).netloc.casefold().removeprefix("www.")
    except Exception:
        return ""


def normalize_linkedin_url(value: str) -> str:
    raw = _text(value)
    if "linkedin.com/in/" not in raw.casefold():
        return ""
    try:
        parsed = urlparse(raw if "://" in raw else f"https://{raw}")
        path = parsed.path.rstrip("/")
        if "/in/" not in path.casefold():
            return ""
        return f"https://www.linkedin.com{path}/"
    except Exception:
        return ""


def _linkedin_key(value: str) -> str:
    url = normalize_linkedin_url(value)
    return _norm(url.rstrip("/")) if url else ""


def configured() -> bool:
    key = _text(getattr(settings, "prospeo_api_key", ""))
    enabled = getattr(settings, "prospeo_enabled", True)
    return bool(enabled and key and not key.startswith("PASTE_YOUR_"))


def _name_match(requested: str, returned: str) -> bool:
    if not returned:
        return True

    def tokens(value: str) -> set[str]:
        return {t for t in re.findall(r"[\wÀ-ÿ]+", value.casefold()) if len(t) > 1}

    want, got = tokens(requested), tokens(returned)
    if not want or not got:
        return True
    if _norm(requested) == _norm(returned):
        return True
    overlap = len(want & got)
    return overlap >= 2 and overlap / max(1, len(want | got)) >= 0.5


def _generic_email(email: str) -> bool:
    local = email.split("@", 1)[0].casefold().replace(".", "").replace("-", "").replace("_", "")
    normalized_generic = {x.replace(".", "") for x in _GENERIC_LOCALS}
    return local in normalized_generic or len(local) <= 1


def _company_fields(payload: dict[str, Any]) -> tuple[str, str]:
    company = payload.get("company") if isinstance(payload.get("company"), dict) else {}
    person = payload.get("person") if isinstance(payload.get("person"), dict) else {}
    company_name = _text(
        company.get("name")
        or company.get("company_name")
        or company.get("legal_name")
        or _current_job_company(person)
    )
    company_domain = _text(
        company.get("website")
        or company.get("company_website")
        or company.get("domain")
        or company.get("company_domain")
    )
    return company_name, company_domain


def _current_job_company(person: dict[str, Any]) -> str:
    history = person.get("job_history")
    if not isinstance(history, list):
        return ""
    for row in history:
        if isinstance(row, dict) and row.get("current") is True:
            value = _text(row.get("company_name"))
            if value:
                return value
    return ""


def _company_domains(company: dict[str, Any]) -> list[str]:
    values: list[str] = []
    for key in ("website", "company_website", "domain", "company_domain"):
        value = _text(company.get(key))
        if value and value not in values:
            values.append(value)
    others = company.get("other_websites")
    if isinstance(others, list):
        for value in others:
            value = _text(value)
            if value and value not in values:
                values.append(value)
    return values


def _select_company_domain(company: dict[str, Any], target_domain: str) -> str:
    domains = _company_domains(company)
    target_host = _host(target_domain)
    if target_host:
        for value in domains:
            if _host(value) == target_host:
                return value
    return domains[0] if domains else ""


def _company_association(
    target_company: str,
    target_domain: str,
    returned_company: str,
    returned_domain: str,
) -> tuple[str, float, str]:
    target = _norm(target_company)
    got = _norm(returned_company)
    target_host = _host(target_domain)
    got_host = _host(returned_domain)

    if target_host and got_host == target_host:
        return "matched", 0.98, "company_domain_match"
    if target and got:
        if target == got:
            return "matched", 0.98, "company_name_exact"
        target_tokens = {t for t in re.findall(r"[\wÀ-ÿ]+", target) if len(t) > 2}
        got_tokens = {t for t in re.findall(r"[\wÀ-ÿ]+", got) if len(t) > 2}
        overlap = len(target_tokens & got_tokens)
        if overlap and overlap / max(1, len(target_tokens | got_tokens)) >= 0.5:
            return "matched", 0.90, "company_name_strong_match"
        return "mismatch", 0.15, "company_name_mismatch"
    if target_host and got_host:
        return "mismatch", 0.25, "company_domain_mismatch"
    return "unknown", 0.55, "provider_company_association_unknown"

def _request(
    linkedin_url: str,
    target_name: str,
    target_company: str,
    target_domain: str,
    *,
    only_verified_email: bool = False,
    only_verified_mobile: bool = False,
    enrich_mobile: bool = False,
) -> dict[str, Any]:
    api_key = _text(getattr(settings, "prospeo_api_key", ""))
    if not api_key:
        raise ProspeoAPIError("PROSPEO_API_KEY is missing")

    url = _text(getattr(settings, "prospeo_base_url", "https://api.prospeo.io")).rstrip("/") + "/enrich-person"
    payload: dict[str, Any] = {
        "data": {
            "linkedin_url": linkedin_url,
        }
    }
    if target_name:
        payload["data"]["full_name"] = target_name
    if target_company:
        payload["data"]["company_name"] = target_company
    if target_domain:
        payload["data"]["company_website"] = target_domain
    if only_verified_email:
        payload["only_verified_email"] = True
    if only_verified_mobile:
        payload["only_verified_mobile"] = True
    elif enrich_mobile:
        payload["enrich_mobile"] = True

    try:
        response = requests.post(
            url,
            headers={"Content-Type": "application/json", "X-KEY": api_key},
            json=payload,
            timeout=int(getattr(settings, "prospeo_timeout", 30)),
        )
    except requests.RequestException as exc:
        raise ProspeoAPIError(f"request_error: {exc}") from exc

    try:
        body = response.json()
    except ValueError as exc:
        raise ProspeoAPIError(f"invalid_json:{response.status_code}") from exc

    if not isinstance(body, dict):
        raise ProspeoAPIError(f"invalid_response:{response.status_code}")
    return body


def _parse_response(
    body: dict[str, Any],
    requested_linkedin: str,
    target_name: str,
    target_company: str,
    target_domain: str,
) -> dict[str, Any]:
    person = body.get("person") if isinstance(body.get("person"), dict) else {}
    company = body.get("company") if isinstance(body.get("company"), dict) else {}
    person_found = bool(person)
    returned_linkedin = normalize_linkedin_url(_text(person.get("linkedin_url")))
    returned_name = _text(person.get("full_name"))
    returned_company = _text(company.get("name") or company.get("company_name") or company.get("legal_name") or _current_job_company(person))
    returned_domain = _select_company_domain(company, target_domain)

    reasons: list[str] = []
    if returned_linkedin and _linkedin_key(returned_linkedin) != _linkedin_key(requested_linkedin):
        reasons.append("returned_linkedin_mismatch")
    if returned_name and target_name and not _name_match(target_name, returned_name):
        reasons.append("name_mismatch")
    hard_identity_ok = not any(x in reasons for x in ("returned_linkedin_mismatch", "name_mismatch"))

    company_status, company_confidence, company_basis = _company_association(
        target_company, target_domain, returned_company, returned_domain
    )
    email_obj = person.get("email") if isinstance(person.get("email"), dict) else {}
    mobile_obj = person.get("mobile") if isinstance(person.get("mobile"), dict) else {}
    email = _text(email_obj.get("email")).casefold()
    mobile = _text(mobile_obj.get("mobile_international") or mobile_obj.get("mobile") or mobile_obj.get("mobile_national"))
    email_verified = _norm(email_obj.get("status")) == "verified"
    mobile_verified = _norm(mobile_obj.get("status")) == "verified"
    target_host = _host(target_domain)

    rejected_emails: list[str] = []
    if email and (_generic_email(email) or not email_verified):
        rejected_emails.append(email)
        email = ""
    elif email and target_host and email.rsplit("@", 1)[-1] != target_host:
        rejected_emails.append(f"company_mismatch_email:{email}")
        email = ""
    elif email and company_status == "mismatch":
        rejected_emails.append(f"company_mismatch_email:{email}")
        email = ""

    rejected_phones: list[str] = []
    if mobile and not mobile_verified:
        rejected_phones.append(f"unverified:{mobile}")
        mobile = ""
    elif mobile and company_status == "mismatch":
        rejected_phones.append(f"company_mismatch_phone:{mobile}")
        mobile = ""
    elif mobile and target_company and company_status == "unknown":
        rejected_phones.append(f"company_association_unknown:{mobile}")
        mobile = ""
    if mobile and not re.sub(r"\D", "", mobile):
        rejected_phones.append(f"invalid:{mobile}")
        mobile = ""

    contact_found = bool(hard_identity_ok and (email or mobile))
    status = "found" if contact_found else ("person_found_no_contact" if person_found and hard_identity_ok else "not_found")
    result = {
        "status": status,
        "provider": "prospeo",
        "actor": "enrich-person",
        "person_found": person_found and hard_identity_ok,
        "email": email if hard_identity_ok else "",
        "phone": mobile if hard_identity_ok else "",
        "email_candidates": [email] if email else [],
        "phone_candidates": [mobile] if mobile else [],
        "rejected_email_candidates": rejected_emails,
        "rejected_phone_candidates": rejected_phones,
        "returned_name": returned_name,
        "returned_company": returned_company,
        "returned_domain": returned_domain,
        "returned_linkedin": returned_linkedin,
        "job_title": _text(person.get("current_job_title") or person.get("headline")),
        "errors": [],
        "identity_confidence": 1.0 if hard_identity_ok and (returned_linkedin or returned_name) else 0.55,
        "identity_reasons": reasons,
        "company_association": company_status,
        "company_association_confidence": company_confidence,
        "company_association_basis": company_basis,
        "company_association_reasons": ([] if company_status != "mismatch" else ["company_or_domain_mismatch"]),
        "email_verified": email_verified,
        "phone_verified": mobile_verified,
        "free_enrichment": bool(body.get("free_enrichment")),
    }
    if body.get("error"):
        result["status"] = status if person_found and hard_identity_ok and not body.get("error_code") else "not_found"
        result["errors"].append(_text(body.get("error_code") or body.get("error_message") or "PROSPEO_ERROR"))
    return result



def enrich_by_linkedin(
    linkedin_url: str,
    *,
    target_name: str = "",
    target_company: str = "",
    target_domain: str = "",
    exclude_phones: frozenset[str] = frozenset(),
) -> dict[str, Any]:
    requested = normalize_linkedin_url(linkedin_url)
    if not requested:
        return {"status": "invalid_linkedin", "provider": "prospeo", "errors": ["invalid_linkedin"], "attempts": []}
    if not configured():
        return {"status": "disabled", "provider": "prospeo", "errors": ["PROSPEO_API_KEY is missing or provider disabled"], "attempts": []}

    attempts: list[dict[str, Any]] = []
    combined = {
        "status": "not_found", "provider": "prospeo", "actor": "enrich-person",
        "person_found": False, "email": "", "phone": "", "email_candidates": [], "phone_candidates": [],
        "rejected_email_candidates": [], "rejected_phone_candidates": [],
        "returned_name": "", "returned_company": "", "returned_domain": "", "returned_linkedin": "", "job_title": "",
        "errors": [], "identity_confidence": 0.0, "identity_reasons": [],
        "company_association": "unknown", "company_association_confidence": 0.0, "company_association_basis": "",
        "company_association_reasons": [], "email_source": "", "phone_source": "", "free_enrichment": False,
    }

    def apply(parsed: dict[str, Any], mode: str) -> None:
        # Keep identity diagnostics even when the provider returns the wrong
        # person, but only mark the person/company as positively matched when
        # the identity check actually passes.
        for key in ("returned_name", "returned_linkedin", "job_title", "identity_confidence", "identity_reasons"):
            if parsed.get(key) not in (None, "", [], {}):
                combined[key] = parsed[key]
        if parsed.get("person_found"):
            combined["person_found"] = True
            for key in (
                "returned_company", "returned_domain", "company_association", "company_association_confidence",
                "company_association_basis", "company_association_reasons",
            ):
                if parsed.get(key) not in (None, "", [], {}):
                    combined[key] = parsed[key]
        combined["free_enrichment"] = combined["free_enrichment"] or bool(parsed.get("free_enrichment"))
        combined["email_candidates"] = list(dict.fromkeys(combined["email_candidates"] + parsed.get("email_candidates", [])))
        combined["phone_candidates"] = list(dict.fromkeys(combined["phone_candidates"] + parsed.get("phone_candidates", [])))
        combined["rejected_email_candidates"] = list(dict.fromkeys(combined["rejected_email_candidates"] + parsed.get("rejected_email_candidates", [])))
        combined["rejected_phone_candidates"] = list(dict.fromkeys(combined["rejected_phone_candidates"] + parsed.get("rejected_phone_candidates", [])))
        if parsed.get("email") and not combined["email"]:
            combined["email"] = parsed["email"]
            combined["email_source"] = f"prospeo:{mode}"
        if parsed.get("phone") and not combined["phone"]:
            digits = re.sub(r"\D", "", parsed["phone"])
            if digits and not any(re.sub(r"\D", "", x)[-8:] == digits[-8:] for x in exclude_phones):
                combined["phone"] = parsed["phone"]
                combined["phone_source"] = f"prospeo:{mode}"
            elif parsed.get("phone"):
                combined["rejected_phone_candidates"].append(f"known_company_number:{parsed['phone']}")
        combined["errors"] = list(dict.fromkeys(combined["errors"] + parsed.get("errors", [])))

    def run_mode(mode: str, **kwargs: Any) -> dict[str, Any] | None:
        try:
            body = _request(requested, target_name, target_company, target_domain, **kwargs)
            parsed = _parse_response(body, requested, target_name, target_company, target_domain)
            attempts.append({
                "mode": mode,
                "status": parsed.get("status"),
                "person_found": bool(parsed.get("person_found")),
                "email": bool(parsed.get("email")),
                "phone": bool(parsed.get("phone")),
                "identity_reasons": parsed.get("identity_reasons", []),
                "company_association": parsed.get("company_association"),
                "company_association_confidence": parsed.get("company_association_confidence"),
                "free_enrichment": bool(parsed.get("free_enrichment")),
                "error": parsed.get("errors", [])[-1:] if parsed.get("errors") else [],
            })
            apply(parsed, mode)
            return parsed
        except ProspeoAPIError as exc:
            attempts.append({"mode": mode, "status": "error", "person_found": False, "error": str(exc)[:500]})
            combined["errors"].append(str(exc)[:500])
            return None

    # 0) Normal enrichment is the identity-first lookup. It must run before
    # restrictive contact modes because verified-email/mobile modes can return
    # NO_MATCH even when Prospeo has a valid person record.
    normal = run_mode("person_enrichment")

    # 1) Verified email lookup only when the normal result did not yield a usable email.
    if not combined["email"]:
        run_mode("verified_email", only_verified_email=True)

    # 2) Optional verified mobile reveal. This can cost more credits, so only run
    # it when explicitly enabled and a usable phone has not already been found.
    want_mobile = bool(getattr(settings, "prospeo_enrich_mobile", True))
    if want_mobile and not combined["phone"]:
        run_mode("verified_mobile", only_verified_mobile=True)

    combined["attempts"] = attempts
    if combined["email"] or combined["phone"]:
        combined["status"] = "found"
    elif combined["person_found"]:
        combined["status"] = "person_found_no_contact"
    else:
        combined["status"] = "not_found"
    return combined

