"""Public company contact discovery from the open web (no Apify, Tavily only).

Finds company-level phone numbers and emails that are publicly published on the
company's own site or on directory pages (e.g. Yellow Pages style listings).
Nothing is guessed or pattern-generated: every value returned was seen on a page
that mentions the company, and carries the URLs it was seen on.
"""
from __future__ import annotations

import csv
import json
import re
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlparse

from .config import settings
from .search import public_search, serper_search, tavily_search
from .identity import company_mentioned, company_match_score
from .tomba_api import (
    TombaAPIError,
    configured as tomba_configured,
    find_by_linkedin as tomba_find_by_linkedin,
    find_phone_by_linkedin as tomba_find_phone_by_linkedin,
    normalize_phone as normalize_tomba_phone,
)
from .apify_contacts import (
    ApifyAPIError,
    enrich_by_linkedin as apify_enrich_by_linkedin,
)
from .fullenrich_mobile import (
    enrich_mobile_by_linkedin as fullenrich_enrich_by_linkedin,
)
from .prospeo_api import (
    ProspeoAPIError,
    enrich_by_linkedin as prospeo_enrich_by_linkedin,
)
from .hunter_api import (
    HunterAPIError,
    configured as hunter_configured,
    domain_search_person,
    enrich_person_by_linkedin,
    find_email_by_linkedin,
    normalize_hunter_phone,
)

_ARABIC_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")

# Candidate phone: optional +/00, then digits with common separators.
_PHONE_RE = re.compile(r"(?<![\w/@.])(?:\+|00)?\(?\d[\d\s().\-–]{6,20}\d(?![\w@])")
_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9\-]+(?:\.[A-Za-z0-9\-]+)*\.[A-Za-z]{2,}")
_DATE_RE = re.compile(r"^\d{4}[-./]\d{1,2}[-./]\d{1,2}$|^\d{1,2}[-./]\d{1,2}[-./]\d{2,4}$")
_BAD_EMAIL_SUFFIX = (".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".css", ".js")
_BAD_EMAIL_DOMAINS = ("example.com", "sentry.io", "wixpress.com", "domain.com", "email.com")

# Words that, just before a number, show it is a phone line (extraction filter only).
_PHONE_CONTEXT = re.compile(r"(tel|phone|call|mobile|whatsapp|contact|hotline|هاتف|جوال|اتصل|تلفون|رقم)", re.I)
_FAX_CONTEXT = re.compile(r"(fax|فاكس)", re.I)

_MAX_TEXT = 60_000


def _ascii_digits(text: str) -> str:
    return (text or "").translate(_ARABIC_DIGITS)


def _norm(text: Any) -> str:
    return re.sub(r"[^a-z0-9\u0600-\u06ff]+", " ", str(text or "").casefold()).strip()


def _host(url: str) -> str:
    try:
        host = urlparse(url if "://" in url else f"https://{url}").netloc.casefold()
    except Exception:
        return ""
    return host.removeprefix("www.")


def extract_phones(text: str) -> list[str]:
    """Return phone numbers found in text, normalised (+ kept when international)."""
    text = _ascii_digits(text)[:_MAX_TEXT]
    found: list[str] = []
    for match in _PHONE_RE.finditer(text):
        raw = match.group(0).strip()
        if _DATE_RE.match(raw.strip("()")):
            continue
        digits = re.sub(r"\D", "", raw)
        if not 8 <= len(digits) <= 15:
            continue
        before = text[max(0, match.start() - 30):match.start()]
        if _FAX_CONTEXT.search(before):
            continue
        international = raw.startswith("+") or raw.startswith("00")
        # Local-format numbers are accepted only when the text says it is a phone line;
        # that avoids treating IDs, prices and reference numbers as phones.
        if not international and not _PHONE_CONTEXT.search(before):
            continue
        if digits.startswith("00") and international:
            digits = digits[2:]
        found.append(("+" + digits) if international else digits)
    return found


def extract_emails(text: str) -> list[str]:
    emails: list[str] = []
    for value in _EMAIL_RE.findall(text or ""):
        value = value.strip(".").casefold()
        if value.endswith(_BAD_EMAIL_SUFFIX):
            continue
        if any(value.endswith("@" + d) or value.endswith("." + d) for d in _BAD_EMAIL_DOMAINS):
            continue
        emails.append(value)
    return emails


def _page_is_about_company(company_name: str, text: str) -> bool:
    """Guard against another company's number, tolerating common name formatting variants."""
    return company_mentioned(company_name, text)


def _phone_key(phone: str) -> str:
    return re.sub(r"\D", "", phone)[-8:]  # same line written locally and with country code


def _search_plan(company: dict[str, Any]) -> list[tuple[str, list[str] | None]]:
    name = str(company.get("company_name") or "").strip()
    country = str(company.get("country") or "").strip()
    domain = _host(str(company.get("known_domain") or ""))
    where = f" {country}" if country else ""
    plan: list[tuple[str, list[str] | None]] = []
    if domain:
        plan.append((f'"{name}" contact us phone email', [domain]))
    plan.append((f'"{name}"{where} contact phone number email', None))
    plan.append((f'"{name}"{where} yellow pages phone', None))
    plan.append((f'"{name}"{where} company directory listing phone', None))
    return plan


def find_company_contacts(
    company: dict[str, Any],
    search: Callable[..., list[dict[str, Any]]] | None = None,
) -> dict[str, Any]:
    """Find public company-level phones and emails.

    Returns {company, country, phones:[{value, sources, official, mentions}],
    emails:[...], pages_checked, pages_used, errors}.
    """
    search = search or tavily_search
    name = str(company.get("company_name") or "").strip()
    domain = _host(str(company.get("known_domain") or ""))
    name_token = _norm(name).replace(" ", "")
    result: dict[str, Any] = {
        "company": name,
        "country": str(company.get("country") or ""),
        "phones": [],
        "emails": [],
        "pages_checked": 0,
        "pages_used": 0,
        "errors": [],
    }
    if not name:
        return result
    if not getattr(settings, "tavily_api_key", "") and not getattr(settings, "serper_api_key", ""):
        result["errors"].append("TAVILY_API_KEY is missing")
        return result

    phones: dict[str, dict[str, Any]] = {}
    emails: dict[str, dict[str, Any]] = {}
    seen_urls: set[str] = set()

    for query, domains in _search_plan(company):
        try:
            hits = search(query, include_domains=domains, max_results=8) or []
        except Exception as exc:  # keep going; one failed query should not end the run
            result["errors"].append(f"{query}: {exc}")
            continue
        for hit in hits:
            if not isinstance(hit, dict):
                continue
            url = str(hit.get("url") or "")
            if not url or url in seen_urls:
                continue
            seen_urls.add(url)
            result["pages_checked"] += 1
            text = " ".join(str(hit.get(k) or "") for k in ("title", "content", "raw_content"))
            if not _page_is_about_company(name, text):
                continue
            host = _host(url)
            official = bool(domain and (host == domain or host.endswith("." + domain))) or (
                not domain and bool(name_token) and name_token[:12] in host.replace("-", "").replace(".", "")
            )
            result["pages_used"] += 1
            for phone in extract_phones(text):
                entry = phones.setdefault(_phone_key(phone), {"value": phone, "sources": [], "official": False, "mentions": 0})
                if phone.startswith("+") and not entry["value"].startswith("+"):
                    entry["value"] = phone  # prefer the international form
                entry["mentions"] += 1
                entry["official"] = entry["official"] or official
                if url not in entry["sources"]:
                    entry["sources"].append(url)
            for email in set(extract_emails(text)):
                entry = emails.setdefault(email, {"value": email, "sources": [], "official": False, "mentions": 0})
                entry["mentions"] += 1
                entry["official"] = entry["official"] or official
                if url not in entry["sources"]:
                    entry["sources"].append(url)

    def rank(entries: dict[str, dict[str, Any]], domain_match: bool = False) -> list[dict[str, Any]]:
        items = list(entries.values())
        for item in items:
            item["sources"] = item["sources"][:5]
            if domain_match:
                item["on_company_domain"] = bool(domain and item["value"].endswith("@" + domain))
        items.sort(key=lambda e: (e.get("on_company_domain", False), e["official"], len(e["sources"]), e["mentions"]), reverse=True)
        return items[:5]

    result["phones"] = rank(phones)
    result["emails"] = rank(emails, domain_match=True)
    return result


def save_company_contacts(contacts: list[dict[str, Any]], output_dir) -> None:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out / "company_contacts.json").write_text(json.dumps(contacts, indent=2, ensure_ascii=False), encoding="utf-8")
    fields = ["company", "country", "phone", "phone_sources", "other_phones", "email", "email_sources", "other_emails", "pages_used"]
    with (out / "company_contacts.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for c in contacts:
            phones, emails = c.get("phones", []), c.get("emails", [])
            writer.writerow({
                "company": c.get("company", ""),
                "country": c.get("country", ""),
                "phone": phones[0]["value"] if phones else "",
                "phone_sources": " | ".join(phones[0]["sources"]) if phones else "",
                "other_phones": " | ".join(p["value"] for p in phones[1:]),
                "email": emails[0]["value"] if emails else "",
                "email_sources": " | ".join(emails[0]["sources"]) if emails else "",
                "other_emails": " | ".join(e["value"] for e in emails[1:]),
                "pages_used": c.get("pages_used", 0),
            })


def format_company_contacts(contact: dict[str, Any]) -> str:
    lines = [f"{contact.get('company', '')}: pages used {contact.get('pages_used', 0)}/{contact.get('pages_checked', 0)}"]
    for label, key in (("Phone", "phones"), ("Email", "emails")):
        items = contact.get(key, [])
        if not items:
            lines.append(f"  {label}: not found publicly")
        for i, item in enumerate(items):
            tag = "official site" if item.get("official") else "directory/other"
            lines.append(f"  {label}{'' if i == 0 else ' (alt)'}: {item['value']}  [{tag}; {len(item['sources'])} source(s)] {item['sources'][0]}")
    for err in contact.get("errors", [])[:3]:
        lines.append(f"  warning: {err}")
    return "\n".join(lines)


def attach_company_contacts(people: list[dict[str, Any]], contacts: list[dict[str, Any]]) -> None:
    """Add company_phone / company_email (best public match) to each person row.

    Company-level values are shown as such; they are never written into the
    person's own phone/email fields, which stay as returned by the provider.
    """
    by_company = {_norm(c.get("company")): c for c in contacts}
    for person in people:
        contact = by_company.get(_norm(person.get("company")), {})
        phones, emails = contact.get("phones", []), contact.get("emails", [])
        person["company_phone"] = phones[0]["value"] if phones else ""
        person["company_email"] = emails[0]["value"] if emails else ""


# ---------------------------------------------------------------------------
# Person-level public contact discovery
# ---------------------------------------------------------------------------

# Role mailboxes belong to the company, not to a named person.
_GENERIC_LOCALS = {
    "info", "contact", "contactus", "sales", "support", "hello", "admin", "office", "enquiries",
    "enquiry", "inquiries", "inquiry", "mail", "media", "press", "hr", "careers", "jobs", "marketing",
    "service", "customerservice", "webmaster", "noreply", "no-reply", "reception", "accounts",
    "mobile", "phone", "telephone", "tel", "general", "business", "enquiry", "enquiries",
}
_NAME_NOISE = {"dr", "eng", "prof", "mr", "mrs", "ms", "phd", "mba", "sheikh", "engr"}


def _name_pattern(person_name: str):
    """Regex for the person's name as it would appear on a page (first ... last)."""
    tokens = [t for t in re.findall(r"[^\W\d_]+", person_name or "") if t.casefold() not in _NAME_NOISE]
    if len(tokens) < 2:
        return None  # a single word is too ambiguous to attribute a contact to
    first, last = re.escape(tokens[0]), re.escape(tokens[-1])
    return re.compile(rf"(?<!\w){first}(?:\W+[^\W\d_]+){{0,2}}\W+{last}(?!\w)", re.IGNORECASE), tokens


def _windows(text: str, pattern, radius: int = 220, limit: int = 10) -> list[str]:
    out = []
    for i, m in enumerate(pattern.finditer(text)):
        if i >= limit:
            break
        out.append(text[max(0, m.start() - radius): m.end() + radius])
    return out


def find_person_contacts(
    person: dict[str, Any],
    company: dict[str, Any],
    search: Callable[..., list[dict[str, Any]]] | None = None,
    exclude_phones: frozenset[str] = frozenset(),
) -> dict[str, Any]:
    """Find a named person's PUBLIC email/phone.

    A value is accepted only if it sits right next to the person's name on a page
    that is about the company. Company switchboard numbers and role mailboxes
    (info@, sales@ ...) are never attributed to the person.
    """
    if search is None:
        # Use the central resilient provider selector: respects SEARCH_PROVIDER,
        # fails over on quota errors and empty result sets, and avoids duplicate
        # per-module search-provider logic.
        search = public_search
    result = {"email": "", "email_source": "", "email_basis": "", "phone": "", "phone_source": "", "errors": [], "provider_attempts": []}
    name = str(person.get("person_name") or "").strip()
    company_name = str(company.get("company_name") or person.get("company") or "").strip()
    domain = _host(str(company.get("known_domain") or ""))
    parsed = _name_pattern(name)
    if not parsed or not company_name:
        return result
    pattern, tokens = parsed

    linkedin_url = str(person.get("linkedin_url") or "").strip()
    # 0) Primary contact provider: FullEnrich exact LinkedIn enrichment.
    # FullEnrich is asynchronous and waterfalls multiple providers. Only its
    # validated target-company results are surfaced; Apify remains the next fallback.
    fullenrich_active = bool(linkedin_url) and bool(getattr(settings, "fullenrich_api_key", "")) and bool(getattr(settings, "fullenrich_enabled", True))
    if fullenrich_active:
        try:
            fullenrich = fullenrich_enrich_by_linkedin(
                linkedin_url,
                target_name=name,
                target_company=company_name,
                target_domain=domain,
                exclude_phones=exclude_phones,
            )
            result["provider_attempts"].append({
                "provider": "fullenrich",
                "status": fullenrich.get("status"),
                "actor": fullenrich.get("actor", "contact/enrich/bulk"),
                "attempts": fullenrich.get("attempts", []),
                "company_association": fullenrich.get("company_association"),
                "company_association_confidence": fullenrich.get("company_association_confidence"),
            })
            # FullEnrich is mobile-only in this version. Never surface an email
            # from FullEnrich, even if a provider response contains one.
            if fullenrich.get("phone") and _phone_key(str(fullenrich["phone"])) not in exclude_phones:
                result.update(phone=fullenrich["phone"], phone_source=fullenrich.get("phone_source") or "fullenrich:phone")
            for err in fullenrich.get("errors", [])[-3:]:
                result["errors"].append(str(err)[:500])
        except Exception as exc:
            result["errors"].append(f"FullEnrich LinkedIn enrichment: {str(exc)[:500]}")
            result["provider_attempts"].append({"provider":"fullenrich","status":"error","error":str(exc)[:500]})

    # 1) First fallback provider: Tomba exact LinkedIn enrichment.
    tomba_active = (
        bool(linkedin_url)
        and bool(getattr(settings, "tomba_enabled", True))
        and tomba_configured()
        and not (result["email"] and result["phone"])
    )
    if tomba_active:
        try:
            tomba = tomba_find_by_linkedin(
                linkedin_url,
                target_name=name,
                target_company=company_name,
                target_domain=domain,
            )
            result["provider_attempts"].append({
                "provider": "tomba",
                "status": tomba.get("status"),
                "actor": "linkedin",
                "email": bool(tomba.get("email")),
                "phone": bool(tomba.get("phone")),
                "score": tomba.get("score"),
                "company": tomba.get("company"),
            })
            if tomba.get("email") and not result["email"]:
                result.update(
                    email=tomba["email"],
                    email_source=(tomba.get("sources") or ["tomba:linkedin"])[0],
                    email_basis="tomba_linkedin_exact",
                )
            tomba_phone = normalize_tomba_phone(tomba.get("phone"))
            if tomba_phone and not result["phone"] and _phone_key(tomba_phone) not in exclude_phones:
                result.update(phone=tomba_phone, phone_source="tomba:linkedin_phone")
            if not result["phone"]:
                phone_result = tomba_find_phone_by_linkedin(linkedin_url)
                for candidate in phone_result.get("phones", []):
                    phone = normalize_tomba_phone(candidate.get("phone"))
                    if not phone or _phone_key(phone) in exclude_phones:
                        continue
                    ptype = str(candidate.get("phone_type") or "").casefold()
                    if ptype and ptype not in {"mobile", "cell", "wireless"}:
                        continue
                    if candidate.get("valid") is False:
                        continue
                    result.update(phone=phone, phone_source="tomba:phone_finder")
                    break
        except TombaAPIError as exc:
            result["errors"].append(f"Tomba LinkedIn enrichment: {str(exc)[:500]}")
            result["provider_attempts"].append({"provider":"tomba","status":"error","error":str(exc)[:500]})

    # 2) Next fallback provider: Prospeo exact LinkedIn enrichment.
    # Prospeo receives the exact LinkedIn URL plus target company data. If it
    # cannot produce a validated target-company contact, we fall through to Apify.
    prospeo_active = (
        bool(linkedin_url)
        and bool(getattr(settings, "prospeo_api_key", ""))
        and bool(getattr(settings, "prospeo_enabled", True))
        and not (result["email"] and result["phone"])
    )
    if prospeo_active:
        try:
            prospeo = prospeo_enrich_by_linkedin(
                linkedin_url,
                target_name=name,
                target_company=company_name,
                target_domain=domain,
                exclude_phones=exclude_phones,
            )
            result["provider_attempts"].append({
                "provider": "prospeo",
                "status": prospeo.get("status"),
                "actor": prospeo.get("actor", "enrich-person"),
                "attempts": prospeo.get("attempts", []),
                "company_association": prospeo.get("company_association"),
                "company_association_confidence": prospeo.get("company_association_confidence"),
            })
            if prospeo.get("email"):
                result.update(
                    email=prospeo["email"],
                    email_source=prospeo.get("email_source") or "prospeo:verified_email",
                    email_basis="prospeo_linkedin_verified",
                )
            if prospeo.get("phone") and _phone_key(str(prospeo["phone"])) not in exclude_phones:
                result.update(phone=prospeo["phone"], phone_source=prospeo.get("phone_source") or "prospeo:verified_mobile")
            for err in prospeo.get("errors", [])[-3:]:
                result["errors"].append(str(err)[:500])
        except ProspeoAPIError as exc:
            result["errors"].append(f"Prospeo LinkedIn enrichment: {str(exc)[:500]}")
            result["provider_attempts"].append({"provider": "prospeo", "status": "error", "error": str(exc)[:500]})

    # 3) Next fallback provider: Apify exact LinkedIn enrichment.
    apify_active = (
        bool(linkedin_url)
        and bool(getattr(settings, "apify_api_token", ""))
        and bool(getattr(settings, "apify_contact_enabled", True))
        and not (result["email"] and result["phone"])
    )
    if apify_active:
        try:
            apify = apify_enrich_by_linkedin(
                linkedin_url,
                target_name=name,
                target_company=company_name,
                target_domain=domain,
                exclude_phones=exclude_phones,
            )
            result["provider_attempts"].append({
                "provider": "apify",
                "status": apify.get("status"),
                "actor": apify.get("actor"),
                "attempts": apify.get("attempts", []),
                "company_association": apify.get("company_association"),
                "company_association_confidence": apify.get("company_association_confidence"),
            })
            if apify.get("email") and not result["email"]:
                result.update(
                    email=apify["email"],
                    email_source=f"apify:{apify.get('actor') or 'linkedin'}",
                    email_basis="apify_linkedin_exact",
                )
            if apify.get("phone") and not result["phone"] and _phone_key(str(apify["phone"])) not in exclude_phones:
                result.update(phone=apify["phone"], phone_source="apify:linkedin")
            elif apify.get("phone") and not result["phone"]:
                result["errors"].append("Apify phone rejected: matches a known company-level phone/switchboard")
            for err in apify.get("errors", [])[-3:]:
                result["errors"].append(str(err)[:500])
        except Exception as exc:
            result["errors"].append(f"Apify LinkedIn enrichment: {str(exc)[:500]}")
            result["provider_attempts"].append({"provider": "apify", "status": "error", "error": str(exc)[:500]})

    hunter_active = bool(linkedin_url) and not (result["email"] and result["phone"]) and hunter_configured()
    if hunter_active and not (result["email"] and result["phone"]):
        try:
            # 1) Primary: exact LinkedIn identity -> Email Finder.
            hunter = find_email_by_linkedin(linkedin_url)
            hunter_company = str(hunter.get("company") or "").strip()
            hunter_domain = str(hunter.get("domain") or "").strip().casefold().removeprefix("www.")
            company_ok = True
            if hunter_company:
                company_ok = company_match_score(company_name, hunter_company) >= 90
            elif domain and hunter_domain:
                company_ok = hunter_domain == domain
            if hunter.get("status") == "found" and company_ok:
                if hunter.get("email"):
                    result.update(email=hunter["email"], email_source=(hunter.get("sources") or [""])[0], email_basis="hunter_linkedin_verified_public")
                phone = normalize_hunter_phone(hunter.get("phone"))
                if phone and _phone_key(phone) not in exclude_phones:
                    result.update(phone=phone, phone_source="hunter:linkedin_email_finder")
            elif hunter.get("status") not in {"not_found", "invalid_linkedin"}:
                result["errors"].append(f"Hunter Email Finder: {hunter.get('status', 'rejected')}")

            # 2) Hunter person enrichment by the exact LinkedIn handle.
            if not result["phone"] or not result["email"]:
                enriched = enrich_person_by_linkedin(linkedin_url)
                enriched_company = str(enriched.get("company") or "").strip()
                enriched_domain = str(enriched.get("domain") or "").strip().casefold().removeprefix("www.")
                enriched_ok = True
                if enriched_company:
                    enriched_ok = company_match_score(company_name, enriched_company) >= 90
                elif domain and enriched_domain:
                    enriched_ok = enriched_domain == domain
                if enriched_ok:
                    if not result["email"] and enriched.get("email"):
                        e = str(enriched["email"]).casefold()
                        if "@" in e and e.split("@", 1)[0] not in _GENERIC_LOCALS and len(e.split("@",1)[0].replace(".","")) > 1:
                            result.update(email=e, email_source="hunter:people_find", email_basis="hunter_linkedin_enrichment")
                    phone = normalize_hunter_phone(enriched.get("phone"))
                    if not result["phone"] and phone and _phone_key(phone) not in exclude_phones:
                        result.update(phone=phone, phone_source="hunter:people_find")

            # 3) Final Hunter-only recovery: search the verified company domain for an exact person row
            #    carrying a complete phone number and/or verified personal email.
            if domain and (not result["phone"] or not result["email"]):
                recovered = domain_search_person(domain, name, linkedin_url=linkedin_url, job_title=str(person.get("job_title") or person.get("title") or "").strip())
                if recovered.get("status") == "found":
                    if not result["email"] and recovered.get("email"):
                        result.update(email=recovered["email"], email_source=(recovered.get("sources") or ["hunter:domain_search"])[0], email_basis="hunter_domain_exact_person")
                    phone = normalize_hunter_phone(recovered.get("phone"))
                    if not result["phone"] and phone and _phone_key(phone) not in exclude_phones:
                        result.update(phone=phone, phone_source="hunter:domain_exact_person")
        except HunterAPIError as exc:
            result["errors"].append(str(exc)[:500])
        result["provider_attempts"].append({
            "provider": "hunter",
            "status": "found" if (result["email_source"].startswith("hunter:") or result["phone_source"].startswith("hunter:")) else "not_found",
            "email": bool(result["email_source"].startswith("hunter:")),
            "phone": bool(result["phone_source"].startswith("hunter:")),
        })

    if result["email"] and result["phone"]:
        return result
    if not (getattr(settings, "tavily_api_key", "") or getattr(settings, "serper_api_key", "")):
        result["errors"].append("No public search provider configured (set TAVILY_API_KEY or SERPER_API_KEY)")
        return result

    from .identity import company_name_variants
    aliases = company_name_variants(company_name)[:4] or [company_name]
    plan: list[tuple[str, list[str] | None]] = []
    for alias in aliases:
        plan.append((f'"{name}" "{alias}" email phone contact', None))
        plan.append((f'site:linkedin.com/in "{name}" "{alias}"', ["linkedin.com"]))
        if domain:
            plan.append((f'"{name}" email phone "{alias}"', [domain]))

    emails: dict[str, tuple[int, str]] = {}
    phones: dict[str, tuple[str, str]] = {}
    seen: set[str] = set()
    for query, domains in plan:
        try:
            hits = search(query, include_domains=domains, max_results=5) or []
        except Exception as exc:
            result["errors"].append(f"{query}: {exc}")
            continue
        for hit in hits:
            if not isinstance(hit, dict):
                continue
            url = str(hit.get("url") or "")
            if not url or url in seen:
                continue
            seen.add(url)
            text = _ascii_digits(" ".join(str(hit.get(k) or "") for k in ("title", "content", "raw_content")))[:_MAX_TEXT]
            host = _host(url)
            on_domain = bool(domain and (host == domain or host.endswith("." + domain)))
            # When Hunter is available for an exact LinkedIn identity, do not let an
            # unrelated directory/Gmail snippet overwrite the provider result.
            if apify_active or hunter_active:
                if not on_domain:
                    continue
            elif not (on_domain or _page_is_about_company(company_name, text)):
                continue
            for window in _windows(text, pattern):
                for email in extract_emails(window):
                    local = email.split("@")[0].casefold()
                    if len(local.replace(".", "")) <= 1 or local in _GENERIC_LOCALS or local.replace(".", "") in _GENERIC_LOCALS:
                        continue
                    score = 1
                    if any(len(t) >= 3 and t.casefold() in local for t in (tokens[0], tokens[-1])):
                        score += 2  # the address itself carries the person's name
                    if domain and email.endswith("@" + domain):
                        score += 1
                    if email not in emails or score > emails[email][0]:
                        emails[email] = (score, url)
                for phone in extract_phones(window):
                    if _phone_key(phone) in exclude_phones:
                        continue  # company switchboard, not this person's line
                    phones.setdefault(_phone_key(phone), (phone, url))

    if emails and not result.get("email"):
        best, (score, url) = max(emails.items(), key=lambda kv: kv[1][0])
        result.update(email=best, email_source=url, email_basis="name_in_address" if score >= 3 else "next_to_name_on_page")
    if phones and not result.get("phone"):
        phone, url = next(iter(phones.values()))
        result.update(phone=phone, phone_source=url)

    result["provider_attempts"].append({
        "provider": "web",
        "status": "found" if (result["email_source"] and not result["email_source"].startswith(("hunter:", "apify:"))) or (result["phone_source"] and not result["phone_source"].startswith(("hunter:", "apify:"))) else "not_found",
        "email": bool(result["email_source"] and not result["email_source"].startswith(("hunter:", "apify:"))),
        "phone": bool(result["phone_source"] and not result["phone_source"].startswith(("hunter:", "apify:"))),
    })
    return result


def enrich_people_public_contacts(
    people: list[dict[str, Any]],
    company_contacts: list[dict[str, Any]],
    search: Callable[..., list[dict[str, Any]]] | None = None,
    max_per_company: int | None = None,
    workers: int | None = None,
) -> dict[str, int]:
    """Fill missing person email/phone from public web pages (most senior first).

    Existing values (e.g. from Apify) are never overwritten. Capped per company
    because each person costs web searches; people arrive sorted by seniority.
    """
    from concurrent.futures import ThreadPoolExecutor

    max_per_company = max_per_company if max_per_company is not None else int(getattr(settings, "max_person_contact_lookups_per_company", 30))
    workers = workers if workers is not None else int(getattr(settings, "person_contact_workers", 4))
    by_company = {_norm(c.get("company")): c for c in company_contacts}
    per_company_count: dict[str, int] = {}
    jobs: list[tuple[dict[str, Any], dict[str, Any], frozenset[str]]] = []
    for person in people:
        key = _norm(person.get("company"))
        if per_company_count.get(key, 0) >= max_per_company:
            continue
        if person.get("business_email") and person.get("phone"):
            continue
        per_company_count[key] = per_company_count.get(key, 0) + 1
        contact = by_company.get(key, {})
        exclude = frozenset(_phone_key(p["value"]) for p in contact.get("phones", []))
        company = {"company_name": person.get("company"), "known_domain": person.get("company_website") or None}
        jobs.append((person, company, exclude))

    stats = {
        "looked_up": len(jobs),
        "emails_found": 0,
        "phones_found": 0,
        "provider_stats": {"apify": {"attempts": 0, "emails": 0, "phones": 0, "errors": 0},
                           "hunter": {"attempts": 0, "emails": 0, "phones": 0, "errors": 0},
                           "web": {"attempts": 0, "emails": 0, "phones": 0, "errors": 0}},
    }
    if not jobs:
        return stats

    def work(job):
        person, company, exclude = job
        return person, find_person_contacts(person, company, search=search, exclude_phones=exclude)

    with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
        found_rows = list(pool.map(work, jobs))

    phone_occurrences: dict[str, int] = {}
    for _person, found in found_rows:
        phone = str(found.get("phone") or "").strip()
        if phone:
            phone_occurrences[_phone_key(phone)] = phone_occurrences.get(_phone_key(phone), 0) + 1

    for _person, found in found_rows:
        for attempt in found.get("provider_attempts", []) or []:
            provider = str(attempt.get("provider") or "").casefold()
            if provider not in stats["provider_stats"]:
                stats["provider_stats"][provider] = {"attempts": 0, "emails": 0, "phones": 0, "errors": 0}
            bucket = stats["provider_stats"][provider]
            bucket["attempts"] += 1
            bucket["emails"] += int(bool(attempt.get("email")))
            bucket["phones"] += int(bool(attempt.get("phone")))
            if attempt.get("status") == "error":
                bucket["errors"] += 1

    for person, found in found_rows:
        person["contact_provider_attempts"] = found.get("provider_attempts", [])
        person["contact_lookup_errors"] = found.get("errors", [])[-5:]
        if found.get("email") and not person.get("business_email"):
            person["business_email"] = found["email"]
            provider_email = str(found.get("email_basis") or "")
            is_provider_email = provider_email.startswith(("hunter_", "tomba_", "apify_"))
            person["email_status"] = "verified_personal_provider" if is_provider_email else "found_public_web"
            person["email_source"] = ("provider:" if is_provider_email else "web:") + str(found.get("email_source") or "")
            stats["emails_found"] += 1
        phone = str(found.get("phone") or "").strip()
        if phone and not person.get("phone") and phone_occurrences.get(_phone_key(phone), 0) == 1:
            person["phone"] = phone
            source = str(found.get("phone_source") or "")
            person["phone_source"] = source if source.startswith(("hunter:", "apify:")) else "web:" + source
            stats["phones_found"] += 1
    return stats
