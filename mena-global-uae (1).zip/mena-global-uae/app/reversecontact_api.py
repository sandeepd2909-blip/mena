"""Reverse Contact phone enrichment via LinkedIn profile URL."""
from __future__ import annotations
import time
from typing import Any
from urllib.parse import urlparse
import requests
from .config import settings

class ReverseContactAPIError(RuntimeError):
    def __init__(self, message: str, status_code: int | None = None, error_code: str = "") -> None:
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code

def _base_url() -> str:
    return str(getattr(settings, "reversecontact_base_url", "https://api.reversecontact.com") or "").rstrip("/")

def _api_key() -> str:
    return str(getattr(settings, "reversecontact_api_key", "") or "").strip()

def _check_key() -> None:
    if not _api_key() or _api_key().startswith("PASTE_YOUR_"):
        raise ReverseContactAPIError("REVERSECONTACT_API_KEY is missing")

def _headers() -> dict[str, str]:
    return {"Authorization": f"Bearer {_api_key()}", "Content-Type": "application/json", "Accept": "application/json"}

def _payload(response: requests.Response) -> dict[str, Any]:
    try:
        obj = response.json()
    except ValueError:
        return {}
    return obj if isinstance(obj, dict) else {}

def _message(response: requests.Response) -> tuple[str, str]:
    body = _payload(response)
    err = body.get("error")
    if isinstance(err, dict):
        msg = err.get("message") or err.get("detail") or err
        code = str(err.get("code") or err.get("errorCode") or "")
    else:
        msg = err or body.get("message") or body.get("errorMessage") or response.text or "HTTP error"
        code = str(body.get("errorCode") or body.get("code") or "")
    return str(msg)[:1200], code.strip()

def normalize_linkedin_url(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    parsed = urlparse(text)
    host = parsed.netloc.casefold().removeprefix("www.")
    path = parsed.path.rstrip("/")
    if host != "linkedin.com":
        return text.rstrip("/").casefold()
    return f"https://linkedin.com{path}".casefold()

def get_reversecontact_usage() -> dict[str, Any]:
    _check_key()
    try:
        response = requests.get(f"{_base_url()}/v2/usage", headers={"Authorization": f"Bearer {_api_key()}", "Accept": "application/json"}, timeout=getattr(settings, "request_timeout", 30))
    except requests.RequestException as exc:
        raise ReverseContactAPIError(f"Reverse Contact usage check failed: {exc}") from exc
    if response.status_code >= 400:
        message, code = _message(response)
        raise ReverseContactAPIError(f"Reverse Contact usage check returned HTTP {response.status_code}: {message}", response.status_code, code)
    body = _payload(response)
    quotas = body.get("quotas") if isinstance(body.get("quotas"), dict) else {}
    workspace = quotas.get("workspace") if isinstance(quotas.get("workspace"), dict) else {}
    credits = workspace.get("credits") if isinstance(workspace.get("credits"), dict) else {}
    minute = workspace.get("minuteRateLimit") if isinstance(workspace.get("minuteRateLimit"), dict) else {}
    return {
        "status": "ready", "http_status": response.status_code,
        "credits_total": credits.get("total"), "credits_used": credits.get("used"), "credits_left": credits.get("left"),
        "minute_limit": minute.get("limit"), "minute_left": minute.get("left"), "response": body,
    }

def _extract_phone_records(value: Any) -> list[dict[str, str]]:
    records: list[dict[str, str]] = []
    def visit(node: Any) -> None:
        if isinstance(node, list):
            for item in node:
                visit(item)
            return
        if not isinstance(node, dict):
            return
        phone = str(node.get("value") or node.get("phone") or node.get("phoneNumber") or node.get("phone_number") or node.get("number") or "").strip()
        kind = str(node.get("type") or node.get("phoneType") or node.get("phone_type") or "").strip()
        if phone:
            records.append({"phone": phone, "phone_type": kind})
        for key in ("result", "data", "phones", "numbers", "phoneNumbers"):
            child = node.get(key)
            if isinstance(child, (list, dict)):
                visit(child)
    visit(value)
    seen: set[tuple[str, str]] = set()
    unique = []
    for item in records:
        key = (item["phone"], item["phone_type"])
        if key not in seen:
            unique.append(item); seen.add(key)
    return unique

def _select_phone(records: list[dict[str, str]]) -> dict[str, str]:
    if not records:
        return {}
    def rank(item: dict[str, str]) -> int:
        kind = item.get("phone_type", "").casefold()
        return 3 if kind == "mobile" else 2 if kind in {"direct", "direct_line", "work_direct"} else 1
    return sorted(records, key=rank, reverse=True)[0]

def _poll(webhook_id: str) -> dict[str, Any]:
    timeout_seconds = max(1, int(getattr(settings, "reversecontact_poll_timeout_seconds", 120)))
    interval = max(1, int(getattr(settings, "reversecontact_poll_interval_seconds", 2)))
    deadline = time.monotonic() + timeout_seconds
    url = f"{_base_url()}/v2/webhooks/{webhook_id}"
    while time.monotonic() < deadline:
        try:
            response = requests.get(url, headers={"Authorization": f"Bearer {_api_key()}", "Accept": "application/json"}, timeout=getattr(settings, "request_timeout", 30))
        except requests.RequestException as exc:
            raise ReverseContactAPIError(f"Reverse Contact polling failed: {exc}") from exc
        if response.status_code == 200:
            body = _payload(response); data = body.get("data")
            if isinstance(data, dict):
                status = str(data.get("status") or "").casefold()
                if status == "succeeded": return body
                if status == "errored":
                    raise ReverseContactAPIError(f"Reverse Contact phone lookup failed: {data.get('errorCode') or data.get('message') or 'unknown error'}", 200, str(data.get("errorCode") or ""))
                time.sleep(interval); continue
            return body
        if response.status_code in {404, 409, 425}:
            time.sleep(interval); continue
        message, code = _message(response)
        raise ReverseContactAPIError(f"Reverse Contact polling returned HTTP {response.status_code}: {message}", response.status_code, code)
    raise ReverseContactAPIError(f"Reverse Contact phone lookup timed out after {timeout_seconds}s", error_code="timeout")

def enrich_phone_by_linkedin(linkedin_url: str) -> dict[str, Any]:
    _check_key()
    normalized = normalize_linkedin_url(linkedin_url)
    if not normalized or "linkedin.com/in/" not in normalized:
        raise ReverseContactAPIError("Invalid LinkedIn profile URL")
    try:
        response = requests.post(f"{_base_url()}/v2/contact/phone", headers=_headers(), json={"url": linkedin_url}, timeout=getattr(settings, "request_timeout", 30))
    except requests.RequestException as exc:
        raise ReverseContactAPIError(f"Reverse Contact phone request failed: {exc}") from exc
    if response.status_code >= 400:
        message, code = _message(response)
        raise ReverseContactAPIError(f"Reverse Contact phone enrichment returned HTTP {response.status_code}: {message}", response.status_code, code)
    trigger = _payload(response)
    data = trigger.get("data") if isinstance(trigger.get("data"), dict) else {}
    webhook_id = str(data.get("webhookId") or trigger.get("webhookId") or "").strip()
    if not webhook_id:
        direct = _select_phone(_extract_phone_records(trigger))
        if direct:
            return {**direct, "reversecontact_status": "found", "reversecontact_webhook_id": "", "reversecontact_credits_consumed": getattr(settings, "reversecontact_phone_cost_credits", 20)}
        raise ReverseContactAPIError("Reverse Contact did not return a webhookId", error_code=str(trigger.get("errorCode") or trigger.get("code") or ""))
    result_payload = _poll(webhook_id)
    result_data = result_payload.get("data")
    selected = _select_phone(_extract_phone_records(result_data))
    if not selected:
        status = "phone-not-found"
        if isinstance(result_data, dict):
            nested_result = result_data.get("result")
            if isinstance(nested_result, dict):
                status = str(
                    nested_result.get("errorCode")
                    or result_data.get("errorCode")
                    or result_data.get("status")
                    or status
                )
            else:
                status = str(result_data.get("errorCode") or result_data.get("status") or status)
        return {"reversecontact_status": status, "reversecontact_webhook_id": webhook_id, "reversecontact_credits_consumed": 0}
    quotas = result_payload.get("quotas") if isinstance(result_payload.get("quotas"), dict) else {}
    consumed = quotas.get("creditsConsumed") if quotas else None
    if consumed is None: consumed = getattr(settings, "reversecontact_phone_cost_credits", 20)
    return {**selected, "reversecontact_status": "found", "reversecontact_webhook_id": webhook_id, "reversecontact_credits_consumed": consumed}

def enrich_phones_by_linkedin(people: list[dict[str, Any]], max_lookups: int | None = None) -> dict[str, dict[str, Any]]:
    _check_key()
    results: dict[str, dict[str, Any]] = {}
    candidates = []
    seen: set[str] = set()
    for person in people:
        key = normalize_linkedin_url(person.get("linkedin_url"))
        if not key or key in seen: continue
        seen.add(key); candidate = dict(person); candidate["linkedin_url"] = person.get("linkedin_url") or key; candidates.append(candidate)
    limit = max_lookups if max_lookups is not None else getattr(settings, "reversecontact_max_lookups_per_run", 3)
    candidates = candidates[:max(0, int(limit))]
    for person in candidates:
        key = normalize_linkedin_url(person.get("linkedin_url"))
        if bool(getattr(settings, "reversecontact_skip_if_insufficient_credits", True)):
            usage = get_reversecontact_usage(); left = usage.get("credits_left"); cost = max(1, int(getattr(settings, "reversecontact_phone_cost_credits", 20)))
            if isinstance(left, (int, float)) and left < cost:
                results[key] = {"reversecontact_status": "insufficient_credits", "reversecontact_credits_left": left}; continue
        try:
            results[key] = enrich_phone_by_linkedin(str(person.get("linkedin_url") or ""))
        except ReverseContactAPIError as exc:
            results[key] = {"reversecontact_status": "provider_error", "reversecontact_error": str(exc)[:1000], "reversecontact_error_code": exc.error_code, "reversecontact_http_status": exc.status_code}
    return results
