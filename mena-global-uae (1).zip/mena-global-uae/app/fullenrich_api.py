"""FullEnrich LinkedIn -> work email/mobile enrichment.

Uses the official asynchronous FullEnrich v2 contact enrichment API. The
LinkedIn URL is the strongest identifier; name/company/domain are supplied
when available and returned identity/company data are validated before a
contact is surfaced.
"""
from __future__ import annotations

import re
import time
import unicodedata
from typing import Any
from urllib.parse import urlparse

import requests

from .config import settings


class FullEnrichAPIError(RuntimeError):
    pass

_GENERIC_LOCALS = {
    "info", "contact", "contactus", "sales", "support", "hello", "admin", "office",
    "enquiries", "enquiry", "inquiries", "inquiry", "mail", "media", "press", "hr",
    "careers", "jobs", "marketing", "service", "customerservice", "webmaster", "noreply",
    "no-reply", "reception", "accounts", "mobile", "phone", "telephone", "tel", "general",
    "business", "help", "team", "enrich",
}


def _text(v: Any) -> str:
    return str(v or "").strip()


def _norm(v: Any) -> str:
    x = unicodedata.normalize("NFKC", _text(v))
    x = "".join(c for c in x if unicodedata.category(c) not in {"Cf", "Cs"})
    return " ".join(x.casefold().split())


def _host(v: str) -> str:
    try:
        raw = v if "://" in v else f"https://{v}"
        return urlparse(raw).netloc.casefold().removeprefix("www.").split(":", 1)[0]
    except Exception:
        return ""


def normalize_linkedin_url(value: str) -> str:
    raw = _text(value)
    if "linkedin.com/in/" not in raw.casefold():
        return ""
    try:
        parsed = urlparse(raw if "://" in raw else f"https://{raw}")
        if "/in/" not in parsed.path.casefold():
            return ""
        return f"https://www.linkedin.com{parsed.path.rstrip('/')}/"
    except Exception:
        return ""


def _linkedin_key(v: str) -> str:
    u = normalize_linkedin_url(v)
    return _norm(u.rstrip("/")) if u else ""


def configured() -> bool:
    key = _text(getattr(settings, "fullenrich_api_key", ""))
    return bool(getattr(settings, "fullenrich_enabled", True) and key and not key.startswith("PASTE_YOUR_"))


def _tokens(v: str) -> set[str]:
    return {x for x in re.findall(r"[\wÀ-ÿ]+", _text(v).casefold()) if len(x) > 1}


def _name_match(want: str, got: str) -> bool:
    if not got or not want:
        return True
    a, b = _tokens(want), _tokens(got)
    if not a or not b:
        return True
    if _norm(want) == _norm(got):
        return True
    overlap = len(a & b)
    return overlap >= 2 and overlap / max(1, len(a | b)) >= 0.5


def _generic_email(email: str) -> bool:
    local = email.split("@", 1)[0].casefold().replace(".", "").replace("-", "").replace("_", "")
    return local in {x.replace(".", "") for x in _GENERIC_LOCALS} or len(local) <= 1


def _walk(obj: Any, key_names: set[str] | None = None):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if key_names is None or k.casefold() in key_names:
                yield k, v
            yield from _walk(v, key_names)
    elif isinstance(obj, list):
        for x in obj:
            yield from _walk(x, key_names)


def _first(obj: Any, keys: set[str]) -> Any:
    for _, v in _walk(obj, keys):
        if v not in (None, "", [], {}):
            return v
    return ""


def _all_strings(obj: Any, keys: set[str]) -> list[str]:
    out=[]
    for _, v in _walk(obj, keys):
        if isinstance(v, str) and v.strip() and v.strip() not in out:
            out.append(v.strip())
        elif isinstance(v, list):
            for x in v:
                if isinstance(x, str) and x.strip() and x.strip() not in out:
                    out.append(x.strip())
                elif isinstance(x, dict):
                    for k in ("email", "address", "value", "number", "phone"):
                        q=_text(x.get(k))
                        if q and q not in out: out.append(q)
        elif isinstance(v, dict):
            for k in ("email", "address", "value", "number", "phone"):
                q=_text(v.get(k))
                if q and q not in out: out.append(q)
    return out


def _company_from_result(data: Any) -> tuple[str, str]:
    company_name = _text(_first(data, {"company_name", "current_company_name"}))
    company_domain = _text(_first(data, {"company_domain", "domain"}))
    website = _text(_first(data, {"company_website", "website"}))
    if website:
        company_domain = _host(website) or company_domain
    return company_name, company_domain


def _company_match(target_company: str, target_domain: str, got_company: str, got_domain: str) -> tuple[str,float,str]:
    th, gh = _host(target_domain), _host(got_domain)
    if th and gh == th:
        return "matched", .98, "company_domain_match"
    if target_company and got_company:
        a,b=_tokens(target_company),_tokens(got_company)
        if _norm(target_company)==_norm(got_company): return "matched", .98, "company_name_exact"
        overlap=len(a&b)
        if overlap and overlap/max(1,len(a|b)) >= .5: return "matched", .90, "company_name_strong_match"
        return "mismatch", .15, "company_name_mismatch"
    if th and gh: return "mismatch", .25, "company_domain_mismatch"
    return "unknown", .55, "provider_company_association_unknown"


def _request(linkedin_url: str, name: str, company: str, domain: str) -> str:
    base=_text(getattr(settings,"fullenrich_base_url","https://app.fullenrich.com/api/v2")).rstrip("/")
    payload={"name": "MENA Opportunity Intelligence Engine", "data":[{
        "first_name": (_text(name).split() or [""])[0],
        "last_name": " ".join((_text(name).split() or [""])[1:]),
        "domain": _host(domain) or _text(domain),
        "company_name": company,
        "linkedin_url": linkedin_url,
        "enrich_fields": ["contact.phones"],
    }]}
    try:
        r=requests.post(base+"/contact/enrich/bulk", headers={"Authorization":f"Bearer {_text(settings.fullenrich_api_key)}","Content-Type":"application/json"}, json=payload, timeout=int(settings.fullenrich_timeout))
    except requests.RequestException as e: raise FullEnrichAPIError(f"request_error: {e}") from e
    try: body=r.json()
    except ValueError as e: raise FullEnrichAPIError(f"invalid_json:{r.status_code}") from e
    if r.status_code >= 400 or not isinstance(body,dict):
        raise FullEnrichAPIError(_text(body.get("message") if isinstance(body,dict) else "FULLENRICH_HTTP_ERROR") or f"HTTP_{r.status_code}")
    eid=_text(body.get("enrichment_id") or body.get("id"))
    if not eid:
        # Some versions may return a data wrapper.
        eid=_text(_first(body,{"enrichment_id"}))
    if not eid: raise FullEnrichAPIError("missing_enrichment_id")
    return eid


def _poll(eid: str) -> dict[str,Any]:
    base=_text(getattr(settings,"fullenrich_base_url","https://app.fullenrich.com/api/v2")).rstrip("/")
    deadline=time.time()+int(getattr(settings,"fullenrich_poll_timeout",180))
    last={}
    while time.time() < deadline:
        try:
            r=requests.get(base+f"/contact/enrich/bulk/{eid}", headers={"Authorization":f"Bearer {_text(settings.fullenrich_api_key)}"}, timeout=int(settings.fullenrich_timeout))
        except requests.RequestException as e: raise FullEnrichAPIError(f"poll_request_error: {e}") from e
        try: body=r.json()
        except ValueError as e: raise FullEnrichAPIError(f"poll_invalid_json:{r.status_code}") from e
        if not isinstance(body,dict): raise FullEnrichAPIError("poll_invalid_response")
        last=body
        status=_norm(_first(body,{"status","enrichment_status","state"}))
        if status in {"finished","completed","complete","success","succeeded"}:
            return body
        if status in {"failed","error","cancelled","canceled"}:
            return body
        # Result data itself is often enough to consider the job finished.
        if _first(body,{"contact_info","profile","work_emails","most_probable_phone","most_probable_email"}):
            return body
        time.sleep(max(1,int(getattr(settings,"fullenrich_poll_interval",5))))
    raise FullEnrichAPIError(f"poll_timeout:{_text(_first(last,{"status","enrichment_status","state"})) or 'unknown'}")


def _parse(body: dict[str,Any], requested_linkedin: str, target_name: str, target_company: str, target_domain: str) -> dict[str,Any]:
    returned_linkedin=_text(_first(body,{"linkedin_url","professional_network_url"}))
    if not returned_linkedin:
        returned_linkedin=_text(_first(body,{"url"}))
    returned_name=_text(_first(body,{"full_name","name"}))
    got_company,got_domain=_company_from_result(body)
    # Prefer the actual professional-network URL and current company when present.
    identity_reasons=[]
    linkedin_exact = bool(returned_linkedin and _linkedin_key(returned_linkedin) == _linkedin_key(requested_linkedin))
    if returned_linkedin and not linkedin_exact:
        identity_reasons.append("returned_linkedin_mismatch")
    # Exact LinkedIn is stronger than a provider display-name anomaly.
    name_mismatch = bool(returned_name and target_name and not _name_match(target_name,returned_name))
    if name_mismatch and not linkedin_exact:
        identity_reasons.append("name_mismatch")
    elif name_mismatch and linkedin_exact:
        identity_reasons.append("provider_name_mismatch_ignored_due_to_exact_linkedin")
    identity_ok=not any(x in {"returned_linkedin_mismatch","name_mismatch"} for x in identity_reasons)
    company_status,company_conf,company_basis=_company_match(target_company,target_domain,got_company,got_domain)
    emails=_all_strings(body,{"work_emails","work_email","most_probable_email","email"})
    phones=_all_strings(body,{"phones","phone","most_probable_phone","mobile_phone","mobile"})
    target_host=_host(target_domain)
    accepted_email=""; rejected_email=[]
    for e in emails:
        e=e.casefold().strip()
        if "@" not in e: continue
        eh=e.rsplit("@",1)[-1]
        if _generic_email(e): rejected_email.append(f"generic_email:{e}"); continue
        # Only accept target-company email when target domain is known. For domain variants
        # such as .com.sa, company association can still validate the provider result.
        if target_host and eh != target_host and company_status != "matched":
            rejected_email.append(f"company_mismatch_email:{e}"); continue
        if company_status == "mismatch": rejected_email.append(f"company_mismatch_email:{e}"); continue
        accepted_email=e; break
    accepted_phone=""; rejected_phone=[]
    if company_status != "mismatch":
        for ph in phones:
            digits=re.sub(r"\D","",ph)
            if len(digits)<8: continue
            accepted_phone=ph; break
    else:
        rejected_phone.extend([f"company_mismatch_phone:{ph}" for ph in phones if re.sub(r"\D","",ph)])
    if not identity_ok:
        accepted_email=""; accepted_phone=""
    result={
        "status":"found" if accepted_email or accepted_phone else ("person_found_no_contact" if identity_ok and (returned_linkedin or returned_name or got_company) else "not_found"),
        "provider":"fullenrich","actor":"contact/enrich/bulk","person_found":bool(identity_ok and (returned_linkedin or returned_name or got_company)),
        "email":accepted_email,"phone":accepted_phone,"email_candidates":emails,"phone_candidates":phones,
        "rejected_email_candidates":rejected_email,"rejected_phone_candidates":rejected_phone,
        "returned_name":returned_name,"returned_company":got_company,"returned_domain":got_domain,"returned_linkedin":normalize_linkedin_url(returned_linkedin),
        "job_title":_text(_first(body,{"job_title","current_job_title","title","headline"})),"errors":[],
        "identity_confidence":1.0 if identity_ok and (returned_linkedin or returned_name) else .55,
        "identity_reasons":identity_reasons,"company_association":company_status,"company_association_confidence":company_conf,
        "company_association_basis":company_basis,"company_association_reasons":([] if company_status!="mismatch" else ["company_or_domain_mismatch"]),
        "email_source":"fullenrich:work_email" if accepted_email else "","phone_source":"fullenrich:phone" if accepted_phone else "",
        "free_enrichment":False,
    }
    return result


def enrich_by_linkedin(linkedin_url:str, *, target_name:str="", target_company:str="", target_domain:str="", exclude_phones:frozenset[str]=frozenset()) -> dict[str,Any]:
    requested=normalize_linkedin_url(linkedin_url)
    if not requested: return {"status":"invalid_linkedin","provider":"fullenrich","errors":["invalid_linkedin"],"attempts":[]}
    if not configured(): return {"status":"disabled","provider":"fullenrich","errors":["FULLENRICH_API_KEY is missing or provider disabled"],"attempts":[]}
    try:
        eid=_request(requested,target_name,target_company,target_domain)
        body=_poll(eid)
        parsed=_parse(body,requested,target_name,target_company,target_domain)
        # FullEnrich is intentionally phone-only for the current application.
        parsed["email"] = ""
        parsed["email_source"] = ""
        parsed["email_candidates"] = []
        if parsed.get("phone"):
            digits=re.sub(r"\D","",parsed["phone"])
            if any(digits[-8:]==re.sub(r"\D","",x)[-8:] for x in exclude_phones):
                parsed["rejected_phone_candidates"].append(f"known_company_number:{parsed['phone']}")
                parsed["phone"]=""; parsed["phone_source"]=""
                if not parsed.get("email"): parsed["status"]="person_found_no_contact"
        parsed["attempts"]=[{"mode":"full_enrich","status":parsed.get("status"),"person_found":parsed.get("person_found"),"email":bool(parsed.get("email")),"phone":bool(parsed.get("phone")),"company_association":parsed.get("company_association"),"company_association_confidence":parsed.get("company_association_confidence")}]
        return parsed
    except FullEnrichAPIError as exc:
        return {"status":"error","provider":"fullenrich","actor":"contact/enrich/bulk","person_found":False,"email":"","phone":"","email_candidates":[],"phone_candidates":[],"rejected_email_candidates":[],"rejected_phone_candidates":[],"errors":[str(exc)[:500]],"attempts":[{"mode":"full_enrich","status":"error","error":str(exc)[:500]}]}
