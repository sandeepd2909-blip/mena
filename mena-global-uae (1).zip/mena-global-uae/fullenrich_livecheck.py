from __future__ import annotations
import argparse, json
from app import fullenrich_api

parser=argparse.ArgumentParser(description="Live FullEnrich LinkedIn enrichment check")
parser.add_argument("--linkedin",required=True)
parser.add_argument("--name",default="")
parser.add_argument("--company",default="")
parser.add_argument("--domain",default="")
a=parser.parse_args()
print("FullEnrich configured:", fullenrich_api.configured())
print("Testing:", a.linkedin)
r=fullenrich_api.enrich_by_linkedin(a.linkedin,target_name=a.name,target_company=a.company,target_domain=a.domain)
print(json.dumps(r,indent=2,ensure_ascii=False))
