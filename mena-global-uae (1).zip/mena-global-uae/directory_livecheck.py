"""Smoke-check the official directory APIs only (no paid lead/contact enrichment providers)."""
from __future__ import annotations

import os
import sys
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(dotenv_path=Path(__file__).resolve().parent / ".env", override=False)

from app.company_directories import DirectoryError, discover_companies_house, discover_sec_companies


def main() -> int:
    failures = 0
    print("Official directory smoke check (no paid enrichment providers are called)\n")
    try:
        result = discover_sec_companies("Industrial & Building Material Manufacturers", limit=3, offset=0)
        print(f"SEC EDGAR: OK — {len(result['companies'])} result(s) in sample; indexed matches={result['total']}")
        for row in result["companies"][:3]:
            print(f"  - {row['company_name']} | {row.get('ticker') or 'no ticker'} | {row['source_url']}")
    except Exception as exc:
        failures += 1
        print(f"SEC EDGAR: FAILED — {type(exc).__name__}: {exc}")

    if not os.getenv("COMPANIES_HOUSE_API_KEY", "").strip():
        print("Companies House: SKIPPED — set COMPANIES_HOUSE_API_KEY in .env to enable its live check")
    else:
        try:
            result = discover_companies_house("building materials", limit=3, offset=0)
            print(f"Companies House: OK — {len(result['companies'])} result(s) in sample; total={result['total']}")
            for row in result["companies"][:3]:
                print(f"  - {row['company_name']} | {row.get('registered_status') or 'status unavailable'} | {row['source_url']}")
        except Exception as exc:
            failures += 1
            print(f"Companies House: FAILED — {type(exc).__name__}: {exc}")

    print("\nUAE MoIAT is exercised by the application's existing directory suite; use the app to test the live UAE flow.")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
