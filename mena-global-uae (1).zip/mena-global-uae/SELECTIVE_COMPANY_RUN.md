# Selective Company Run

1. Start the app as usual.
2. Choose industry, country, and the number of companies.
3. Click **Discover companies**.
4. Discovery stops after producing the requested company list. It does **not** run people/contact enrichment.
5. Tick only the companies you want.
6. Click **Run selected**.
7. Only those selected company IDs are processed by the people/contact enrichment pipeline.

The backend validates selected company IDs, so a UI mistake cannot cause an unrelated discovered company to be processed.
