
# Company & Decision-Maker Intelligence — Multi-Country

Local Python web app for official-directory company discovery, public-source decision-maker research, CSV export, and optional mobile-only FullEnrich enrichment.

## Official company directories

- **United Arab Emirates — MoIAT**: uses the UAE Ministry of Industry and Advanced Technology Industrial Production License Directory and its official search endpoint. Main Activity filtering and the existing 50-company batch workflow are retained.
- **United States — SEC EDGAR**: uses the SEC's public company/ticker directory and EDGAR 10-K filing search index. SEC EDGAR primarily covers SEC registrants/public filers; it is **not** a comprehensive directory of every private US business. No SEC API key is required. The `SEC_USER_AGENT` value should identify your app and a contact email you control.
- **United Kingdom — Companies House**: uses the official Companies House Public Data API. A Companies House REST API key is required. Create one in the [Companies House Developer Hub](https://developer.company-information.service.gov.uk/), then set `COMPANIES_HOUSE_API_KEY` in your private `.env` file.
- **Canada — Canada's Business Registries (manual verification)**: Canadian candidates are discovered from your configured Tavily/Serper public web-search provider, then linked to the official [Canada's Business Registries portal](https://ised-isde.canada.ca/cbr-rec/en/) for manual verification. The portal explicitly prohibits automated tools from searching, copying, or scraping its result pages, so the app does **not** query or scrape the CBR website. Each candidate is clearly marked as unverified until you manually confirm its legal name, status, and registry ID in CBR. This avoids misrepresenting web results as official registry records.

Company names are retrieved from the selected directory or SEC filing index; the app does not ask AI to invent the company list. For US/UK/Canada discovery, use a target segment or a specific company/industry keyword. Canada uses public web-search candidates plus manual registry verification; it is not a live CBR data feed. EDGAR filing search is full-text based, so results should be reviewed for industry fit before outreach.

## UAE discovery performance (V7.9.5)

- The app filters the verified MoIAT JSON snapshot locally when one is available, avoiding several live page requests for every new batch.
- Cached results are served immediately; stale snapshots trigger a guarded background refresh instead of blocking the search.
- On a cold cache, the app continues to use MoIAT's official paginated search while warming the full-directory cache in the background.
- Interactive search, session-seeding, and Main Activity-ID requests use a bounded timeout configured by `MOIAT_SEARCH_TIMEOUT` (default 45 seconds, capped at 90) and retry budget `MOIAT_SEARCH_ATTEMPTS` (default 3). Bulk exports keep the separate `MOIAT_TIMEOUT` setting.
- The UI shows matching records as pages are processed rather than holding all results until the complete 50-company batch is finished.
- The cache is stored under the project-relative `data/moiat/` path by default. A redeploy or recycled cloud instance can lose local cache contents; use a managed persistent disk or shared object store if cross-deploy cache durability is required.

## UAE discovery fallback (V7.9.5)

- A cache that contains no matches for the selected activity no longer short-circuits live MoIAT search.
- If MoIAT returns an error or no parseable rows, the app may use existing Tavily/Serper web search results as a fallback. These are real source-linked search results, not AI-generated names.
- Fallback company cards are explicitly labelled `Web search fallback · MoIAT unverified`; verify each source and confirm industrial-license status separately before treating a company as MoIAT registered.
- The UI includes a UAE directory connection test. MoIAT currently may respond with empty/error payloads; if the primary source is healthy again, MoIAT results remain preferred.
- Live search defaults to a 45-second request timeout and up to 3 attempts. You can adjust `MOIAT_SEARCH_TIMEOUT` and `MOIAT_SEARCH_ATTEMPTS` in `.env` / deployment environment settings.

## Login (single credential)

The app shows a sign-in page when you set one username and password in `.env`:

```
APP_USERNAME=admin
APP_PASSWORD=choose-a-long-password
```

- Everything (pages, API, CSV export) requires sign-in; only `/health` stays public for hosting checks.
- Sessions last 7 days (`SESSION_DAYS`). Changing the password signs everyone out. **Log out** is in the top-right of the app.
- 5 wrong attempts from one address locks it for 60 seconds.
- If `APP_PASSWORD` is empty the login is off, and the app refuses to start on a network address (`--host 0.0.0.0`) until you set it. On Render, add `APP_PASSWORD` in the service's environment settings.
- Use HTTPS when hosting online (Render and Vercel provide it); the cookie is then marked `Secure` automatically.

## Filters (V7.9.8)

Once companies are loaded, use the **Filters** panel above the list:

- **Companies:** search, emirate/region, company size, source quality (official vs web candidates), main activity (UAE), people-search status, ticked-only, sort.
- **LinkedIn:** a single "Has LinkedIn profile" checkbox.
- **Select matching people** ticks eligible people (and their companies) for mobile enrichment; **Export filtered CSV** saves only what is on screen.

Filters apply to the companies already loaded (50 per batch) and reset when you start a new discovery.

## Run on Windows

1. Install Python 3.11 or newer.
2. In PowerShell, open this project folder and run:
   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install -r requirements.txt
   Copy-Item .env.example .env
   notepad .env
   ```
3. Fill in your rotated provider keys in `.env`. The app loads `.env` relative to the project folder, even when launched from a different current working directory. For US directory discovery, review `SEC_USER_AGENT`. For UK directory discovery, fill `COMPANIES_HOUSE_API_KEY` with the REST API key value (not the application name or key name).
4. Start the app:
   ```powershell
   python main.py --ui
   ```
5. Open <http://127.0.0.1:8000>.

Do not commit or share `.env`. It is intentionally not included in this ZIP. API keys previously pasted into chat should be revoked/rotated before use.

## Live directory smoke check

When you select United States or United Kingdom in the UI, click **Test directory connection** below the official-source link. For Canada, click **Open registry verification** to open CBR manually; the app will not send automated searches to that portal. The UK test sends a read-only search request for `tesco`; the US test checks SEC EDGAR. It calls no paid enrichment providers. If the test fails, the UI reports whether the key is missing/rejected, the rate limit was reached, or the network could not reach the official directory.

You can also run the CLI check after configuring `.env`:

```powershell
python directory_livecheck.py
```

To test the configured Canada public-search provider, run the optional bounded check:

```powershell
python canada_search_livecheck.py
```

This makes one search request (and can fall back to the other configured provider), so it may consume a search credit. It never sends a request to Canada's Business Registries. It prints source URLs for a small sample of web candidates; these still need manual CBR verification.

This smoke check makes official-directory requests only. It does not call OpenAI, Tavily, Serper, Apify, Hunter, Tomba, Prospeo, or FullEnrich, and therefore does not consume those providers' paid credits. When the Companies House key is missing, it reports that live UK testing was skipped.

## Existing people and enrichment workflow

The company selection → public-source people discovery → optional mobile enrichment flow remains available for each country. Decision-maker search quality depends on public evidence and search-provider availability; a LinkedIn URL alone is not treated as proof of current employment. Mobile enrichment remains behind its existing confirmation/credit-estimate flow and requests mobile numbers only.

## Tests

Run the offline test suite:

```powershell
python -m pytest -q
```

For this build, run `python -m pytest -q` to rerun the full offline regression suite. Canada-specific tests cover candidate extraction, Canadian-result filtering, cache reuse, manual-registry verification links, route persistence, and refusal to automate CBR search. Provider live tests that require the network or API keys should be run in your own environment using `directory_livecheck.py` and the app's provider-status controls; the sandbox used to prepare this ZIP could not resolve the public API hosts.

## Official API references

- [SEC EDGAR APIs](https://www.sec.gov/search-filings/edgar-application-programming-interfaces)
- [SEC fair-access and developer resources](https://www.sec.gov/about/developer-resources)
- [Companies House API authentication](https://developer.company-information.service.gov.uk/authentication)
- [Companies House company search endpoint](https://developer-specs.company-information.service.gov.uk/companies-house-public-data-api/reference/search/search-companies)
- [Canada's Business Registries search portal](https://ised-isde.canada.ca/cbr-rec/en/)
- [Canada's Business Registries FAQ and data-use restrictions](https://ised-isde.canada.ca/cbr-rec/faq)
- [UAE MoIAT directory](https://il.moiat.gov.ae/en/OpenData/IPLDirectory)


## Cloud deployment

This version supports a persistent Python web service and includes `render.yaml` plus `/health`. See [CLOUD_DEPLOYMENT.md](CLOUD_DEPLOYMENT.md). The current workflow uses background threads, in-memory jobs, and local JSON state, so deploying it unchanged as Vercel Functions is not reliable; Vercel requires durable shared storage and a background job architecture for the full workflow.
