# V7.8.28 Tomba Integration

Tomba is now the primary exact-LinkedIn enrichment provider before Hunter.

Flow:
1. Existing lead LinkedIn URL is sent to Tomba's LinkedIn Finder.
2. Tomba response must match the exact LinkedIn URL when one is returned.
3. Company identity is checked against the requested company/domain.
4. Generic mailbox emails are rejected.
5. Mobile phone data is preferred; invalid/non-mobile results are not automatically attributed as a direct mobile.
6. Tomba's dedicated Phone Finder is used if LinkedIn Finder did not return a usable phone.
7. Existing company switchboard numbers are excluded by the pipeline.
8. Duplicate/shared phone numbers are rejected at the final per-company aggregation stage.
9. Hunter remains as a fallback when Tomba does not provide both contact fields.
10. Public web research remains a fallback after provider enrichment.

Live API testing from the build environment was not possible because outbound DNS/network access to api.tomba.io is unavailable here. The package contains `tomba_live_test.py` for a real local credential test.
## V7.8.37 runtime placement
Tomba is enabled and runs immediately after FullEnrich when an exact LinkedIn identity is available and one or both contacts are still missing. Prospeo and Apify run only while the record remains incomplete. No LinkedIn scraping is performed.

