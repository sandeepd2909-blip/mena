# MoIAT transport notes — V7.8.45

The active UAE discovery path no longer uses the XML/Excel export endpoints. It calls the same official JSON search endpoint used by the Ministry directory page:

- `GetMainActivities?LoadOldActivities=true` for Main Activity UUID resolution
- `SearchIPLDirectory` for company records and server-side pagination

The older XML/Excel/browser-export recovery implementation is retained only for backward-compatible parsing/tests and is not used by the active `_discover_thread` workflow.

The live smoke check is `python -u moiat_livecheck.py`.
