"""Build an offline MoIAT snapshot (data/moiat/directory_all_v2.json).

Run this ON A COMPUTER THAT CAN OPEN https://il.moiat.gov.ae (e.g. your UAE PC), then redeploy.
The app serves discovery from this snapshot with no network call to MoIAT, so Vercel's blocked
datacenter IP no longer matters. Usage:

    python build_moiat_snapshot.py
"""
from __future__ import annotations

import sys

from app.moiat_directory import _cache_paths, _write_directory_cache, load_directory


def main() -> int:
    print("Downloading the official MoIAT directory (can take a few minutes)...", flush=True)
    rows = load_directory(force=True)
    if not rows:
        print("MoIAT returned no records; snapshot not written.", file=sys.stderr)
        return 1
    _write_directory_cache(rows)
    path = _cache_paths()[1]
    print(f"Wrote {len(rows)} official records to {path}")
    print("Now redeploy (vercel --prod). The snapshot is included in the upload.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
