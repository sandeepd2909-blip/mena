from __future__ import annotations

import argparse
import os
from pathlib import Path

from dotenv import load_dotenv

# Load credentials relative to this project, not the shell current directory.
PROJECT_ROOT = Path(__file__).resolve().parent
load_dotenv(dotenv_path=PROJECT_ROOT / ".env", override=False)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Company & Decision-Maker Intelligence — multi-country official directories"
    )
    parser.add_argument("--ui", action="store_true", help="Start the local web UI")
    parser.add_argument("--host", default=os.getenv("HOST", "127.0.0.1"), help="Bind host (cloud hosts typically require 0.0.0.0)")
    parser.add_argument("--port", type=int, default=int(os.getenv("PORT", "8000")), help="UI port (defaults to PORT or 8000)")
    args = parser.parse_args()

    if not args.ui:
        parser.error("use --ui to start the application")

    from app.server import serve

    print(f"Starting Company & Decision-Maker Intelligence on {args.host}:{args.port}", flush=True)
    serve(args.port, host=args.host)


if __name__ == "__main__":
    main()
