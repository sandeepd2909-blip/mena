"""One-query live smoke test for Canadian candidate discovery.

Run after placing valid, rotated TAVILY_API_KEY and/or SERPER_API_KEY values in .env.
This makes one bounded public-web search (and may fall back to the other configured
provider); it never queries or scrapes Canada's Business Registries.
"""
from __future__ import annotations

import sys
from urllib.parse import urlparse

from app.config import settings
from app.search import public_search


def main() -> int:
    available = bool(str(settings.tavily_api_key or "").strip() or str(settings.serper_api_key or "").strip())
    if not available:
        print("SKIPPED: set TAVILY_API_KEY and/or SERPER_API_KEY in your private .env file.")
        return 2
    try:
        results = public_search("Canadian industrial suppliers and manufacturers company websites", max_results=5)
    except Exception as exc:
        print(f"FAILED: public web search did not succeed ({type(exc).__name__}: {str(exc)[:300]})")
        return 1
    filtered = []
    for result in results or []:
        if not isinstance(result, dict):
            continue
        url = str(result.get("url") or result.get("link") or "").strip()
        host = (urlparse(url).hostname or "").casefold().removeprefix("www.")
        if not url.startswith(("https://", "http://")):
            continue
        if host == "ised-isde.canada.ca" or host.endswith(".canadasbusinessregistries.ca") or host == "canadasbusinessregistries.ca":
            continue
        filtered.append((str(result.get("title") or "(untitled)"), url))
    if not filtered:
        print("CONNECTED, BUT NO USABLE CANADIAN WEB RESULTS WERE RETURNED. Try a more specific industry query in the app.")
        return 1
    print(f"PASS: search provider returned {len(filtered)} usable candidate source(s). These are not CBR-verified records.")
    for index, (title, url) in enumerate(filtered, 1):
        print(f"{index}. {title}\n   {url}")
    print("Manual verification portal: https://ised-isde.canada.ca/cbr-rec/en/")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
