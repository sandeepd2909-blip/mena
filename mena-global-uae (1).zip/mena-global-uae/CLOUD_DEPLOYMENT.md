# Cloud deployment note: why local works but Vercel does not

## Recommended deployment for the full application

This app is currently a long-running Python `ThreadingHTTPServer`. Its UI relies on in-process job state, background daemon threads, and local JSON files under `data/uae_state`. That model works on a persistent server process, but it is not a reliable fit for Vercel Functions without an architectural rewrite to use shared persistent storage and a durable background job queue. Vercel Functions have a bounded request duration and are invoked as serverless handlers.

For the current complete workflow, deploy this build as a persistent Python web service (Render or Railway). A `render.yaml` is included. Create a new Render Blueprint from this folder/repository, then enter secrets in Render's Environment section; never put real keys into `render.yaml` or Git. `plan: starter` is specified because the full app runs background threads and should not be expected to sleep like a free service. If changing the plan, verify the chosen hosting tier's limits.

## Environment variables

Set your provider keys in the host dashboard, especially `OPENAI_API_KEY`, `TAVILY_API_KEY`, `SERPER_API_KEY`, `COMPANIES_HOUSE_API_KEY`, and any enrichment credentials you actually use. A missing optional provider key disables that provider; Companies House discovery specifically requires `COMPANIES_HOUSE_API_KEY`. Use fresh rotated keys because keys pasted into chat must be treated as exposed.

## Deploy on Render

1. Put this project in a private Git repository (excluding `.env`).
2. In Render, create a **Blueprint** from the repository so it reads `render.yaml`.
3. Enter secrets in the service's Environment settings.
4. After deploy, check `/health`, then open the service root URL.
5. Test UK via **Test directory connection** before company discovery.

The service now listens on `0.0.0.0` and reads the hosting provider's `PORT`, and includes `/health` for deployment health checks.

## Persistence caveat

The application's current job/state files are stored under `data/uae_state`; container files may be lost when a host redeploys/restarts unless a persistent disk is configured. For durable job history across restarts, attach a persistent disk or move state to a shared database. The serverless Vercel deployment cannot safely depend on this local filesystem or on background threads continuing after a response.
