"""V7.8.64: LinkedIn people shown under a short brand name must match the long registered MoIAT name."""
from app import webpeople as wp
from app.identity import brand_core_variants, company_name_variants


def _hit(name, company, title="General Manager"):
    slug = name.lower().replace(" ", "-")
    return {
        "url": f"https://www.linkedin.com/in/{slug}",
        "title": f"{name} - {title} - {company} | LinkedIn",
        "content": f"Dubai, United Arab Emirates · {title} · {company}",
    }


def _company(name):
    return {"company_name": name, "country": "United Arab Emirates", "aliases": [], "known_domain": ""}


def test_brand_core_drops_trailing_descriptors():
    assert "Emirates Glass" in company_name_variants("Emirates Glass Factory L.L.C.")
    assert "Al Ghurair Foods" in brand_core_variants("Al Ghurair Foods Manufacturing Co LLC")


def test_brand_core_never_reduces_to_weak_single_word():
    assert brand_core_variants("Gulf Trading LLC") == []
    assert brand_core_variants("Emirates Industries LLC") == []


def test_people_found_under_short_brand_name():
    hits = [_hit("Nadia Aziz", "Emirates Glass", "Chief Executive Officer")]
    sources, _ = wp.collect_sources(_company("Emirates Glass Factory L.L.C."), search=lambda q, include_domains=None, max_results=8: hits)
    assert len(sources) == 1 and sources[0]["linkedin"]


def test_other_company_with_shared_first_word_is_still_rejected():
    hits = [_hit("Tom Lee", "Emirates Steel"), _hit("A Bee", "Emirates Airline")]
    sources, _ = wp.collect_sources(_company("Emirates Glass Factory L.L.C."), search=lambda q, include_domains=None, max_results=8: hits)
    assert sources == []
