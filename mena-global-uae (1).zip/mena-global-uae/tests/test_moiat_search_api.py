import json
from types import SimpleNamespace

import app.moiat_directory as md


SEARCH_HTML = r'''
<style>.childTable{width:100%}</style>
<table class="table">
<thead><tr>
<th>Factory Name (En)</th><th>Factory Name (Ar)</th><th>Factory Phone Number</th><th>Factory Email</th><th>Emirate</th><th>Action</th>
</tr></thead>
<tbody>
<tr>
<td>NOBLE FOODSTUFF FACTORY L.L.C</td><td>مصنع نوبل للمواد الغذائية ذ.م.م</td><td>00971563963399</td><td>guruhoonmain2022@gmail.com</td><td>Umm Al Quwain</td><td>View</td>
</tr>
<tr class="collapse"><th colspan="6">Products</th></tr>
<tr class="collapse"><td><table><tr><td>09109990</td><td>Other</td><td>غيرها</td></tr></table></td></tr>
<tr class="collapse"><td><table><tr><td>84224000</td><td>Other packing or wrapping machinery</td><td>آلات</td></tr></table></td></tr>
<tr class="collapse"><th colspan="6">Activities</th></tr>
<tr class="collapse"><td><table><tr><td>1030001</td><td>Fruits and Vegetables Processing and Packaging</td><td>تجهيز</td></tr></table></td></tr>
<tr class="collapse"><td><table><tr><td>1079009</td><td>Spices, Sauces and Condiments Manufacturing</td><td>صناعة</td></tr></table></td></tr>
<tr>
<td>SEA WORLD FISH PROCESSING L.L.C</td><td>سي وورلد لتجهيز الاسماك ش.ذ.م.م</td><td>00971507157722</td><td>hisham.amin@hassani.ae</td><td>Dubai</td><td>View</td>
</tr>
<tr class="collapse"><th colspan="6">Activities</th></tr>
<tr class="collapse"><td><table><tr><td>1020001</td><td>Fish Processing</td><td>تجهيز الاسماك</td></tr></table></td></tr>
</tbody></table>
'''


def _company(name, code):
    return md.MoIATCompany(
        company_key=name.lower(), company_name=name, company_name_ar="", emirate="Dubai", phone="", email="",
        activities=({"isic4_code": code, "activity_en": "Example", "activity_ar": ""},),
        products=(), matched_segments=(),
    )


def test_search_result_parser_extracts_factory_products_and_activities(monkeypatch):
    monkeypatch.setattr(md, "settings", SimpleNamespace(moiat_timeout=5), raising=False)
    rows = md._parse_moiat_search_result(SEARCH_HTML)
    assert [x.company_name for x in rows] == ["NOBLE FOODSTUFF FACTORY L.L.C", "SEA WORLD FISH PROCESSING L.L.C"]
    assert rows[0].emirate == "Umm Al Quwain"
    assert {a["isic4_code"] for a in rows[0].activities} == {"1030001", "1079009"}
    assert {p["hs_code"] for p in rows[0].products} == {"09109990", "84224000"}
    assert md.TARGET_SEGMENTS[1] in rows[0].matched_segments


def test_search_page_uses_server_pagination_and_omits_empty_filters(monkeypatch):
    class Resp:
        status_code = 200
        headers = {"content-type": "application/json"}
        url = "https://il.moiat.gov.ae/en/OpenData/SearchIPLDirectory"

        def raise_for_status(self):
            pass
        def json(self):
            return {"Result": SEARCH_HTML, "TotalPages": 42, "TotalRecords": 411, "CurrentPage": 2, "TotalAmount": 0}
        @property
        def text(self):
            return json.dumps(self.json(), ensure_ascii=False)
        @property
        def content(self):
            return self.text.encode("utf-8")

    class Session:
        def __init__(self):
            self.calls = []
        def get(self, url, params=None, **kwargs):
            self.calls.append((url, dict(params or {}), kwargs))
            return Resp()
        def close(self):
            pass

    sess = Session()
    monkeypatch.setattr(md, "settings", SimpleNamespace(moiat_timeout=5), raising=False)
    page = md.search_moiat_directory_page(main_activity_id="uuid-10", page_index=2, emirate_id="", session=sess)
    assert page.current_page == 2
    assert page.total_pages == 42
    assert page.total_records == 411
    assert len(page.companies) == 2
    search_calls = [c for c in sess.calls if "SearchIPLDirectory" in c[0]]
    assert len(search_calls) == 1
    params = search_calls[0][1]
    assert params == {"pageIndex": 2, "mainActivityId": "uuid-10"}


def test_resolve_main_activity_id_reads_official_text_href(monkeypatch):
    class Resp:
        def raise_for_status(self):
            pass
        def json(self):
            return '[{"text":"10 | Manufacture of food products","href":"uuid-food"},{"text":"11 | Manufacture of beverages","href":"uuid-drinks"}]'

    class Session:
        def get(self, *args, **kwargs):
            return Resp()
        def close(self):
            pass

    md._MAIN_ACTIVITY_ID_CACHE.clear()
    monkeypatch.setattr(md, "settings", SimpleNamespace(moiat_timeout=5), raising=False)
    assert md.resolve_main_activity_id("10", session=Session(), force_refresh=True) == "uuid-food"


def test_discover_moiat_live_paginates_until_total_pages_and_dedupes(monkeypatch):
    calls = []
    pages = {
        1: md.MoIATSearchPage((_company("A", "1000001"), _company("B", "1000002")), 1, 2, 3),
        2: md.MoIATSearchPage((_company("B", "1000002"), _company("C", "1000003")), 2, 2, 3),
    }

    def fake_search(**kwargs):
        calls.append(kwargs["page_index"])
        return pages[kwargs["page_index"]]

    monkeypatch.setattr(md, "search_moiat_directory_page", fake_search)
    result = md.discover_moiat_live(main_activity_code="10")
    assert calls == [1, 2]
    assert [x.company_name for x in result] == ["A", "B", "C"]


def test_segment_candidate_activity_codes_only_uses_visible_main_activity_codes():
    assert md._segment_candidate_activity_codes(md.TARGET_SEGMENTS[0])
    assert md._segment_candidate_activity_codes(md.TARGET_SEGMENTS[1]) == ("10", "11")
    assert md._segment_candidate_activity_codes(md.TARGET_SEGMENTS[2]) == ()


def test_discover_moiat_live_applies_segment_classifier(monkeypatch):
    food = _company("Food Factory", "1000001")
    food = md.MoIATCompany(**{**food.__dict__, "matched_segments": (md.TARGET_SEGMENTS[1],)})
    other = _company("Other Factory", "1000002")
    pages = {1: md.MoIATSearchPage((food, other), 1, 1, 2)}
    monkeypatch.setattr(md, "_segment_candidate_activity_codes", lambda segment: ("10",))
    monkeypatch.setattr(md, "search_moiat_directory_page", lambda **kwargs: pages[kwargs["page_index"]])
    result = md.discover_moiat_live(segment=md.TARGET_SEGMENTS[1])
    assert [x.company_name for x in result] == ["Food Factory"]


def test_live_company_identity_dedupes_same_name_and_emirate_with_changed_contact_fields():
    html1 = SEARCH_HTML.replace("00971563963399", "00971563963399").replace("guruhoonmain2022@gmail.com", "a@example.ae")
    html2 = SEARCH_HTML.replace("00971563963399", "00971550000000").replace("guruhoonmain2022@gmail.com", "b@example.ae")
    a = md._parse_moiat_search_result(html1)[0]
    b = md._parse_moiat_search_result(html2)[0]
    assert a.company_key == b.company_key

def test_discover_moiat_batch_stops_after_50_and_persists_next_page(monkeypatch):
    monkeypatch.setattr(md, "moiat_reachable", lambda force=False: (True, ""))  # V7.9.9: probe is network-only
    # A cold-cache discovery should keep using the live paginated endpoint in this test;
    # the warm-cache worker is covered separately below and must not make network calls.
    monkeypatch.setattr(md, "_start_directory_cache_refresh", lambda: None)
    pages = {
        1: md.MoIATSearchPage(tuple(_company(f"C{i}", "1000001") for i in range(10)), 1, 42, 411),
        2: md.MoIATSearchPage(tuple(_company(f"C{i}", "1000001") for i in range(10, 20)), 2, 42, 411),
        3: md.MoIATSearchPage(tuple(_company(f"C{i}", "1000001") for i in range(20, 30)), 3, 42, 411),
        4: md.MoIATSearchPage(tuple(_company(f"C{i}", "1000001") for i in range(30, 40)), 4, 42, 411),
        5: md.MoIATSearchPage(tuple(_company(f"C{i}", "1000001") for i in range(40, 50)), 5, 42, 411),
    }
    calls=[]
    monkeypatch.setattr(md, "search_moiat_directory_page", lambda **kw: calls.append(kw["page_index"]) or pages[kw["page_index"]])
    rows, cursors, total, more = md.discover_moiat_batch(main_activity_code="10", limit=50)
    assert len(rows) == 50
    assert calls == [1,2,3,4,5]
    assert cursors == {"10": 6}
    assert total == 411
    assert more is True
