from types import SimpleNamespace

from app.reversecontact_api import ReverseContactAPIError, _poll, enrich_phone_by_linkedin, enrich_phones_by_linkedin, normalize_linkedin_url

class FakeResponse:
    def __init__(self, status_code, payload=None, text=""):
        self.status_code=status_code; self._payload=payload or {}; self.text=text
    def json(self): return self._payload

def base_settings():
    return SimpleNamespace(reversecontact_api_key="secret", reversecontact_base_url="https://api.reversecontact.com", request_timeout=30, reversecontact_poll_timeout_seconds=5, reversecontact_poll_interval_seconds=1, reversecontact_phone_cost_credits=20, reversecontact_max_lookups_per_run=3, reversecontact_skip_if_insufficient_credits=True)

def test_normalize_linkedin_url():
    assert normalize_linkedin_url("https://www.linkedin.com/in/Example-Person/") == "https://linkedin.com/in/example-person"

def test_phone_lookup_polls_and_returns_mobile(monkeypatch):
    monkeypatch.setattr("app.reversecontact_api.settings", base_settings())
    monkeypatch.setattr("app.reversecontact_api.requests.post", lambda *a, **k: FakeResponse(200, {"success": True, "data": {"status": "created", "webhookId": "wh-123"}}))
    monkeypatch.setattr("app.reversecontact_api.requests.get", lambda *a, **k: FakeResponse(200, {"success": True, "data": {"status": "succeeded", "result": [{"value": "+966501234567", "type": "mobile"}]}}))
    result=enrich_phone_by_linkedin("https://www.linkedin.com/in/example-person/")
    assert result["phone"]=="+966501234567"
    assert result["phone_type"]=="mobile"
    assert result["reversecontact_status"]=="found"
    assert result["reversecontact_webhook_id"]=="wh-123"

def test_phone_not_found_is_free(monkeypatch):
    monkeypatch.setattr("app.reversecontact_api.settings", base_settings())
    monkeypatch.setattr("app.reversecontact_api.requests.post", lambda *a, **k: FakeResponse(200, {"data": {"webhookId": "wh-1"}}))
    monkeypatch.setattr("app.reversecontact_api.requests.get", lambda *a, **k: FakeResponse(200, {"data": {"status": "succeeded", "result": {"errorCode": "phone-not-found"}}}))
    result=enrich_phone_by_linkedin("https://linkedin.com/in/example-person")
    assert result["reversecontact_status"]=="phone-not-found"
    assert result["reversecontact_credits_consumed"]==0

def test_provider_error_is_non_fatal_for_batch(monkeypatch):
    monkeypatch.setattr("app.reversecontact_api.settings", base_settings())
    monkeypatch.setattr("app.reversecontact_api.requests.get", lambda *a, **k: FakeResponse(200, {"quotas": {"workspace": {"credits": {"left": 100}}}}))
    monkeypatch.setattr("app.reversecontact_api.requests.post", lambda *a, **k: FakeResponse(403, {"errorCode": "PLAN_RESTRICTED", "error": "phone finder unavailable"}))
    result=enrich_phones_by_linkedin([{"linkedin_url": "https://linkedin.com/in/example-person"}])
    item=result["https://linkedin.com/in/example-person"]
    assert item["reversecontact_status"]=="provider_error"
    assert item["reversecontact_http_status"]==403

def test_insufficient_credits_skips_lookup(monkeypatch):
    monkeypatch.setattr("app.reversecontact_api.settings", base_settings())
    calls={"post":0}
    monkeypatch.setattr("app.reversecontact_api.requests.get", lambda *a, **k: FakeResponse(200, {"quotas": {"workspace": {"credits": {"left": 10}}}}))
    monkeypatch.setattr("app.reversecontact_api.requests.post", lambda *a, **k: (calls.__setitem__("post", calls["post"]+1) or FakeResponse(200, {})))
    result=enrich_phones_by_linkedin([{"linkedin_url": "https://linkedin.com/in/example-person"}])
    assert result["https://linkedin.com/in/example-person"]["reversecontact_status"]=="insufficient_credits"
    assert calls["post"]==0

def test_poll_terminal_error_is_raised(monkeypatch):
    monkeypatch.setattr("app.reversecontact_api.settings", base_settings())
    monkeypatch.setattr("app.reversecontact_api.requests.get", lambda *a, **k: FakeResponse(200, {"data": {"status": "errored", "errorCode": "phone-not-found"}}))
    try:
        _poll("wh-1")
    except ReverseContactAPIError as exc:
        assert exc.error_code=="phone-not-found"
    else:
        raise AssertionError("Expected ReverseContactAPIError")
