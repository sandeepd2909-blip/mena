from types import SimpleNamespace

from app import apify_contacts


def _settings(**overrides):
    base = dict(
        apify_api_token="token",
        apify_contact_enabled=True,
        apify_contact_actors=(
            "b2bsearch/bulk-people-enrichment",
            "datablow/linkedin-profile-enrichment",
            "b2bsearch/linkedin-email-finder",
        ),
    )
    base.update(overrides)
    return SimpleNamespace(**base)


def test_datablow_payload_uses_documented_linkedin_shape(monkeypatch):
    monkeypatch.setattr(apify_contacts, "settings", _settings(apify_contact_actors=("datablow/linkedin-profile-enrichment",)))
    payload = apify_contacts.build_input(
        "datablow/linkedin-profile-enrichment",
        "https://www.linkedin.com/in/example-person/",
        "Example Person",
        "acme.ae",
    )
    assert payload["urls"] == ["https://www.linkedin.com/in/example-person/"]
    assert payload["maxItems"] == 1
    assert payload["phoneNumbers"] == []


def test_bulk_payload_contains_profile_csv_and_contacts(monkeypatch):
    monkeypatch.setattr(apify_contacts, "settings", _settings(apify_contact_actors=("b2bsearch/bulk-people-enrichment",)))
    payload = apify_contacts.build_input(
        "b2bsearch/bulk-people-enrichment",
        "https://www.linkedin.com/in/example-person/",
        "Example Person",
        "acme.ae",
    )
    assert payload["contacts"] is True
    assert payload["mustHave"] == []
    assert "profile_url" in payload["csv"]
    assert "example-person" in payload["csv"]


def test_apify_exact_identity_accepts_person_email_and_direct_phone(monkeypatch):
    monkeypatch.setattr(apify_contacts, "settings", _settings(apify_contact_actors=("datablow/linkedin-profile-enrichment",)))
    monkeypatch.setattr(apify_contacts, "run_actor_get_dataset_items", lambda actor, payload: [{
        "fullName": "Sara Al Mansoori",
        "jobTitle": "Chief Information Officer",
        "companyName": "Acme Trading LLC",
        "profileUrl": "https://www.linkedin.com/in/sara-al-mansoori/",
        "emails": ["sara.almansoori@acme.ae"],
        "phones": [{"number": "+971501112222", "sharedBy": 1, "companyLine": False, "type": "mobile"}],
        "employerMatch": True,
    }])
    r = apify_contacts.enrich_by_linkedin(
        "https://linkedin.com/in/sara-al-mansoori",
        target_name="Sara Al Mansoori",
        target_company="Acme Trading",
        target_domain="acme.ae",
    )
    assert r["status"] == "found"
    assert r["email"] == "sara.almansoori@acme.ae"
    assert r["phone"] == "+971501112222"


def test_generic_email_is_rejected_and_next_actor_can_supply_personal_email(monkeypatch):
    monkeypatch.setattr(apify_contacts, "settings", _settings(apify_contact_actors=(
        "datablow/linkedin-profile-enrichment", "b2bsearch/linkedin-email-finder"
    )))
    def fake(actor, payload):
        if actor == "datablow/linkedin-profile-enrichment":
            return [{
                "fullName": "Sara Al Mansoori", "companyName": "Acme Trading",
                "profileUrl": "https://www.linkedin.com/in/sara-al-mansoori/",
                "email": "mobile@acme.ae",
            }]
        return [{
            "fullName": "Sara Al Mansoori", "companyName": "Acme Trading",
            "profileUrl": "https://www.linkedin.com/in/sara-al-mansoori/",
            "email": "sara@acme.ae",
        }]
    monkeypatch.setattr(apify_contacts, "run_actor_get_dataset_items", fake)
    r = apify_contacts.enrich_by_linkedin(
        "https://www.linkedin.com/in/sara-al-mansoori/",
        target_name="Sara Al Mansoori", target_company="Acme Trading", target_domain="acme.ae",
    )
    assert r["email"] == "sara@acme.ae"
    assert [a["status"] for a in r["attempts"]] == ["no_usable_contact", "found"]


def test_shared_and_company_phone_numbers_are_rejected(monkeypatch):
    monkeypatch.setattr(apify_contacts, "settings", _settings(apify_contact_actors=("datablow/linkedin-profile-enrichment",)))
    monkeypatch.setattr(apify_contacts, "run_actor_get_dataset_items", lambda actor, payload: [{
        "fullName": "Omar Khan", "companyName": "Acme Trading",
        "profileUrl": "https://www.linkedin.com/in/omar-khan/",
        "email": "omar@acme.ae",
        "phones": [
            {"number": "+971412345678", "sharedBy": 4, "companyLine": False},
            {"number": "+971498765432", "sharedBy": 1, "companyLine": True},
        ],
    }])
    r = apify_contacts.enrich_by_linkedin(
        "https://www.linkedin.com/in/omar-khan/",
        target_name="Omar Khan", target_company="Acme Trading", target_domain="acme.ae",
    )
    assert r["email"] == "omar@acme.ae"
    assert r["phone"] == ""
    assert len(r["rejected_phone_candidates"]) == 2


def test_wrong_company_and_wrong_linkedin_identity_are_rejected(monkeypatch):
    monkeypatch.setattr(apify_contacts, "settings", _settings(apify_contact_actors=("datablow/linkedin-profile-enrichment", "b2bsearch/linkedin-email-finder")))
    calls = []
    def fake(actor, payload):
        calls.append(actor)
        return [{
            "fullName": "Same Name",
            "companyName": "Wrong Company",
            "profileUrl": "https://www.linkedin.com/in/different-person/",
            "email": "same@wrong.example",
        }]
    monkeypatch.setattr(apify_contacts, "run_actor_get_dataset_items", fake)
    r = apify_contacts.enrich_by_linkedin(
        "https://www.linkedin.com/in/exact-person/",
        target_name="Exact Person", target_company="Acme Trading", target_domain="acme.ae",
    )
    assert r["email"] == ""
    assert r["status"] == "not_found"
    assert calls == ["datablow/linkedin-profile-enrichment", "b2bsearch/linkedin-email-finder"]


def test_known_company_switchboard_is_excluded(monkeypatch):
    monkeypatch.setattr(apify_contacts, "settings", _settings(apify_contact_actors=("datablow/linkedin-profile-enrichment",)))
    monkeypatch.setattr(apify_contacts, "run_actor_get_dataset_items", lambda actor, payload: [{
        "fullName": "Jane Doe", "companyName": "Acme Trading",
        "profileUrl": "https://www.linkedin.com/in/jane-doe/",
        "phones": [{"number": "+971412345678", "sharedBy": 1, "companyLine": False}],
    }])
    r = apify_contacts.enrich_by_linkedin(
        "https://www.linkedin.com/in/jane-doe/", target_name="Jane Doe", target_company="Acme Trading",
        target_domain="acme.ae", exclude_phones=frozenset({"+971412345678"}),
    )
    assert r["phone"] == ""
    assert any(x.startswith("known_company_number") for x in r["rejected_phone_candidates"])


def test_provider_disabled_skips_calls(monkeypatch):
    monkeypatch.setattr(apify_contacts, "settings", _settings(apify_contact_enabled=False))
    called = {"n": 0}
    monkeypatch.setattr(apify_contacts, "run_actor_get_dataset_items", lambda *a, **k: called.__setitem__("n", called["n"] + 1) or [])
    r = apify_contacts.enrich_by_linkedin("https://www.linkedin.com/in/example-person/", target_name="Example Person", target_company="Acme")
    assert r["status"] == "provider_unavailable"
    assert called["n"] == 0


def test_exact_linkedin_is_primary_identity_when_actor_omits_company_and_url(monkeypatch):
    monkeypatch.setattr(apify_contacts, "settings", _settings(apify_contact_actors=(
        "datablow/linkedin-profile-enrichment",
    )))
    monkeypatch.setattr(apify_contacts, "run_actor_get_dataset_items", lambda actor, payload: [{
        "fullName": "Loay Mashabi",
        "jobTitle": "Board Member, Logistics Expert, Aviation",
        "email": "loay@saudiacargo.com",
        "phone": "+966501234567",
    }])
    r = apify_contacts.enrich_by_linkedin(
        "https://www.linkedin.com/in/loay-mashabi/",
        target_name="Loay Mashabi",
        target_company="Saudia Cargo",
        target_domain="saudiacargo.com",
    )
    assert r["status"] == "found"
    assert r["email"] == "loay@saudiacargo.com"
    assert r["phone"] == "+966501234567"
    assert "provider_did_not_echo_company" in r["identity_reasons"]
    assert r["identity_confidence"] == 0.9


def test_b2b_documented_contact_row_is_accepted(monkeypatch):
    monkeypatch.setattr(apify_contacts, "settings", _settings(apify_contact_actors=(
        "b2bsearch/bulk-people-enrichment",
    )))
    monkeypatch.setattr(apify_contacts, "run_actor_get_dataset_items", lambda actor, payload: [{
        "_status": "found",
        "_tier": "contacts",
        "fullName": "Jane Doe",
        "companyName": "Acme",
        "profileUrl": "https://www.linkedin.com/in/jane-doe-example",
        "email": "jane.doe@acme.example",
        "emailType": "work",
        "employerMatch": True,
        "workEmails": ["jane.doe@acme.example"],
        "personalEmails": ["jane@example.com"],
        "phones": [{"number": "+15550100123", "sharedBy": 1, "companyLine": False}],
    }])
    r = apify_contacts.enrich_by_linkedin(
        "https://www.linkedin.com/in/jane-doe-example",
        target_name="Jane Doe",
        target_company="Acme",
        target_domain="acme.example",
    )
    assert r["status"] == "found"
    assert r["email"] == "jane.doe@acme.example"
    assert r["phone"] == "+15550100123"
    assert r["email_source"].startswith("apify:b2bsearch/bulk-people-enrichment")


def test_b2b_no_email_row_is_no_usable_contact_not_identity_rejected(monkeypatch):
    monkeypatch.setattr(apify_contacts, "settings", _settings(apify_contact_actors=(
        "b2bsearch/linkedin-email-finder",
    )))
    monkeypatch.setattr(apify_contacts, "run_actor_get_dataset_items", lambda actor, payload: [{
        "_status": "no_email",
        "fullName": "Jane Doe",
        "companyName": "Acme",
        "jobTitle": "VP Engineering",
        "profileUrl": "https://www.linkedin.com/in/jane-doe-example",
        "_note": "no address on record",
    }])
    r = apify_contacts.enrich_by_linkedin(
        "https://www.linkedin.com/in/jane-doe-example",
        target_name="Jane Doe",
        target_company="Acme",
        target_domain="acme.example",
    )
    assert r["status"] == "not_found"
    assert r["attempts"][0]["status"] == "no_usable_contact"
    assert "identity_rejected" != r["attempts"][0]["status"]


def test_exact_linkedin_and_name_survive_provider_employer_mismatch(monkeypatch):
    monkeypatch.setattr(apify_contacts, "settings", _settings(apify_contact_actors=(
        "b2bsearch/bulk-people-enrichment",
    )))
    monkeypatch.setattr(apify_contacts, "run_actor_get_dataset_items", lambda actor, payload: [{
        "_status": "found",
        "fullName": "Loay Mashabi",
        "companyName": "Saudi Post | SPL",
        "profileUrl": "https://www.linkedin.com/in/loay-mashabi",
        "employerMatch": False,
        "email": "",
    }])
    r = apify_contacts.enrich_by_linkedin(
        "https://www.linkedin.com/in/loay-mashabi/",
        target_name="Loay Mashabi",
        target_company="Saudia Cargo",
        target_domain="saudiacargo.com",
    )
    assert r["status"] == "not_found"
    assert r["attempts"][0]["status"] == "no_usable_contact"
    assert r["identity_reasons"] == []
    assert r["company_association_reasons"] == ["provider_employer_match_false"]
    assert r["company_association"] == "mismatch"
    assert apify_contacts.normalize_linkedin_url(r["returned_linkedin"]) == "https://www.linkedin.com/in/loay-mashabi/"
    assert not any(a["status"] == "identity_rejected" for a in r["attempts"])


def test_employer_mismatch_does_not_block_next_actor_target_company_contact(monkeypatch):
    monkeypatch.setattr(apify_contacts, "settings", _settings(apify_contact_actors=(
        "b2bsearch/bulk-people-enrichment",
        "datablow/linkedin-profile-enrichment",
    )))
    def fake(actor, payload):
        if actor == "b2bsearch/bulk-people-enrichment":
            return [{
                "_status": "found",
                "fullName": "Loay Mashabi",
                "companyName": "Saudi Post | SPL",
                "profileUrl": "https://www.linkedin.com/in/loay-mashabi",
                "employerMatch": False,
            }]
        return [{
            "fullName": "Loay Mashabi",
            "profileUrl": "https://www.linkedin.com/in/loay-mashabi",
            "email": "loay.mashabi@saudiacargo.com",
        }]
    monkeypatch.setattr(apify_contacts, "run_actor_get_dataset_items", fake)
    r = apify_contacts.enrich_by_linkedin(
        "https://www.linkedin.com/in/loay-mashabi/",
        target_name="Loay Mashabi",
        target_company="Saudia Cargo",
        target_domain="saudiacargo.com",
    )
    assert r["status"] == "found"
    assert r["email"] == "loay.mashabi@saudiacargo.com"
    assert [a["status"] for a in r["attempts"]] == ["no_usable_contact", "found"]
    assert r["company_association"] == "unknown"


def test_employer_mismatch_rejects_personal_and_other_company_email(monkeypatch):
    monkeypatch.setattr(apify_contacts, "settings", _settings(apify_contact_actors=(
        "b2bsearch/linkedin-email-finder",
    )))
    monkeypatch.setattr(apify_contacts, "run_actor_get_dataset_items", lambda actor, payload: [{
        "fullName": "Loay Mashabi",
        "companyName": "Saudi Post | SPL",
        "profileUrl": "https://www.linkedin.com/in/loay-mashabi",
        "employerMatch": False,
        "emails": ["mashablo@gmail.com", "loay@naseem.sa", "loay.mashabi@petrogistix.com"],
        "phones": [{"number": "+966501234567", "sharedBy": 1, "companyLine": False}],
    }])
    r = apify_contacts.enrich_by_linkedin(
        "https://www.linkedin.com/in/loay-mashabi/",
        target_name="Loay Mashabi",
        target_company="Saudia Cargo",
        target_domain="saudiacargo.com",
    )
    assert r["email"] == ""
    assert r["phone"] == ""
    assert r["phone_candidates"] == []
    assert r["status"] == "not_found"
    assert set(r["rejected_email_candidates"]) == {
        "company_mismatch_email:mashablo@gmail.com",
        "company_mismatch_email:loay@naseem.sa",
        "company_mismatch_email:loay.mashabi@petrogistix.com",
    }
    assert "company_mismatch_phone:+966501234567" in r["rejected_phone_candidates"]


def test_employer_mismatch_can_accept_requested_company_domain_email(monkeypatch):
    monkeypatch.setattr(apify_contacts, "settings", _settings(apify_contact_actors=(
        "b2bsearch/linkedin-email-finder",
    )))
    monkeypatch.setattr(apify_contacts, "run_actor_get_dataset_items", lambda actor, payload: [{
        "fullName": "Loay Mashabi",
        "companyName": "Saudi Post | SPL",
        "profileUrl": "https://www.linkedin.com/in/loay-mashabi",
        "employerMatch": False,
        "emails": ["loay.mashabi@saudiacargo.com", "mashablo@gmail.com"],
    }])
    r = apify_contacts.enrich_by_linkedin(
        "https://www.linkedin.com/in/loay-mashabi/",
        target_name="Loay Mashabi",
        target_company="Saudia Cargo",
        target_domain="saudiacargo.com",
    )
    assert r["status"] == "found"
    assert r["email"] == "loay.mashabi@saudiacargo.com"
    assert r["rejected_email_candidates"] == []


def test_wrong_linkedin_still_hard_rejects_even_when_name_and_company_match(monkeypatch):
    monkeypatch.setattr(apify_contacts, "settings", _settings(apify_contact_actors=(
        "b2bsearch/bulk-people-enrichment",
    )))
    monkeypatch.setattr(apify_contacts, "run_actor_get_dataset_items", lambda actor, payload: [{
        "fullName": "Jane Doe",
        "companyName": "Acme Trading",
        "profileUrl": "https://www.linkedin.com/in/other-jane",
        "employerMatch": True,
        "email": "jane@acme.ae",
    }])
    r = apify_contacts.enrich_by_linkedin(
        "https://www.linkedin.com/in/jane-doe/",
        target_name="Jane Doe",
        target_company="Acme Trading",
        target_domain="acme.ae",
    )
    assert r["status"] == "not_found"
    assert r["attempts"][0]["status"] == "identity_rejected"
    assert "returned_linkedin_mismatch" in r["identity_reasons"]
