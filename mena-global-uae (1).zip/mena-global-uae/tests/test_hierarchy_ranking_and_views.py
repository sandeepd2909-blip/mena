from types import SimpleNamespace

from app import hierarchy
from app.hierarchy import (
    _ACCEPTED_LEVELS,
    _classify_hierarchy_batch,
    _level_rank,
    build_company_record,
    build_hierarchy_tree,
    format_hierarchy_markdown,
    generate_company_hierarchy,
)


def _settings(**over):
    base = dict(
        apify_api_token="t", apify_lead_actor="code_crafter/leads-finder",
        apify_lead_fallback_actor="", apify_lead_actors=("code_crafter/leads-finder",),
        apify_provider_preflight=False, max_hierarchy_people_per_company=3,
        hierarchy_results_per_query=50, max_hierarchy_queries_per_company=0,
        hierarchy_pool_multiplier=3, openai_api_key="k", tavily_api_key="",
    )
    base.update(over)
    return SimpleNamespace(**base)


def test_rank_is_deterministic_and_lead_is_not_a_level():
    assert _level_rank(_ACCEPTED_LEVELS[0]) == 1
    assert _level_rank("Manager / Product Manager") == len(_ACCEPTED_LEVELS)
    assert "Lead" not in _ACCEPTED_LEVELS  # below the Product Manager cutoff
    assert _level_rank("Lead") == 999


def test_cap_applies_after_classification_so_juniors_cannot_crowd_out_executives(monkeypatch):
    monkeypatch.setattr(hierarchy, "settings", _settings())
    monkeypatch.setattr(hierarchy, "_dynamic_hierarchy_search_terms", lambda c, n: [])
    # Provider returns 6 junior-ish rows first, the CEO and CFO last.
    rows = [{"full_name": f"Jr {i}", "job_title": "Analyst", "company_name": "Acme",
             "linkedin": f"https://www.linkedin.com/in/jr{i}"} for i in range(6)]
    rows += [{"full_name": "The CEO", "job_title": "CEO", "company_name": "Acme", "linkedin": "https://www.linkedin.com/in/ceo"},
             {"full_name": "The CFO", "job_title": "CFO", "company_name": "Acme", "linkedin": "https://www.linkedin.com/in/cfo"}]
    monkeypatch.setattr(hierarchy, "run_actor_get_dataset_items", lambda a, p: rows)

    def classify(company, raw):
        out = {}
        for i, r in enumerate(raw):
            title = r["job_title"]
            if title == "CEO":
                out[str(i)] = {"hierarchy_level": "CEO / President / Founder", "keep": True, "reason": ""}
            elif title == "CFO":
                out[str(i)] = {"hierarchy_level": "C-Suite", "keep": True, "reason": ""}
            else:
                out[str(i)] = {"hierarchy_level": "Below cutoff", "keep": False, "reason": ""}
        return out
    monkeypatch.setattr(hierarchy, "_classify_hierarchy_batch", classify)

    people, errors, diags = generate_company_hierarchy(
        [{"company_name": "Acme", "country": "UAE", "industry": "X", "known_domain": "acme.com"}], None)
    assert [p["person_name"] for p in people] == ["The CEO", "The CFO"]
    assert [p["hierarchy_rank"] for p in people] == [1, 2]
    assert [p["company_people_position"] for p in people] == [1, 2]
    assert diags[0]["filtered_below_product_manager"] == 6


def test_position_restarts_per_company_and_cap_keeps_most_senior(monkeypatch):
    monkeypatch.setattr(hierarchy, "settings", _settings(max_hierarchy_people_per_company=2))
    monkeypatch.setattr(hierarchy, "_dynamic_hierarchy_search_terms", lambda c, n: [])

    def fake_actor(actor, payload):
        name = (payload.get("company_domain") or payload.get("company_keywords"))[0]
        co = "Alpha" if "alpha" in name.casefold() else "Beta"
        return [{"full_name": f"{co} {t}", "job_title": t, "company_name": co,
                 "linkedin": f"https://www.linkedin.com/in/{co}-{t}".replace(" ", "-")}
                for t in ("PM", "VP", "CEO")]
    monkeypatch.setattr(hierarchy, "run_actor_get_dataset_items", fake_actor)
    levels = {"CEO": "CEO / President / Founder", "VP": "VP", "PM": "Manager / Product Manager"}
    monkeypatch.setattr(hierarchy, "_classify_hierarchy_batch", lambda c, raw: {
        str(i): {"hierarchy_level": levels[r["job_title"]], "keep": True, "reason": ""} for i, r in enumerate(raw)})

    people, _, diags = generate_company_hierarchy([
        {"company_name": "Alpha", "known_domain": "alpha.com"},
        {"company_name": "Beta", "known_domain": "beta.com"}], None)
    assert [(p["company"], p["job_title"], p["company_people_position"]) for p in people] == [
        ("Alpha", "CEO", 1), ("Alpha", "VP", 2), ("Beta", "CEO", 1), ("Beta", "VP", 2)]
    assert diags[0]["dropped_by_cap"] == 1  # the PM was cut, not the executives


def test_classification_failure_is_reported_in_errors(monkeypatch):
    monkeypatch.setattr(hierarchy, "settings", _settings())
    monkeypatch.setattr(hierarchy, "_dynamic_hierarchy_search_terms", lambda c, n: [])
    monkeypatch.setattr(hierarchy, "run_actor_get_dataset_items", lambda a, p: [
        {"full_name": "X", "job_title": "CEO", "company_name": "Acme", "linkedin": "https://www.linkedin.com/in/x"}])
    monkeypatch.setattr(hierarchy, "_classify_hierarchy_batch", lambda c, raw: {})
    people, errors, diags = generate_company_hierarchy([{"company_name": "Acme", "known_domain": "acme.com"}], None)
    assert people == [] and errors and "classification" in errors[0]
    assert diags[0]["provider_error_kind"] == "llm_classification_empty"


def test_classifier_chunks_large_pools_and_retries_skipped_people(monkeypatch):
    monkeypatch.setattr(hierarchy, "settings", _settings())
    calls = []

    def fake_chunk(company, rows):
        calls.append(len(rows))
        # First pass skips local id 0 of every chunk; the retry call (size 1 or 2) answers it.
        skip_first = len(rows) > 2   # first pass of a chunk; the retry call is tiny
        return {str(i): {"hierarchy_level": "VP", "hierarchy_rank": 4, "keep": True, "reason": ""}
                for i in range(len(rows)) if not (skip_first and i == 0)}
    monkeypatch.setattr(hierarchy, "_classify_chunk", fake_chunk)
    rows = [{"person_name": f"P{i}"} for i in range(50)]
    result = _classify_hierarchy_batch({"company_name": "Acme"}, rows)
    assert set(result) == {str(i) for i in range(50)}  # nobody lost
    assert max(calls) <= hierarchy._CLASSIFY_CHUNK_SIZE


def test_classifier_rejects_kept_person_without_valid_label(monkeypatch):
    monkeypatch.setattr(hierarchy, "settings", _settings())
    monkeypatch.setattr(hierarchy, "ask_json", lambda s, u: {"people": [
        {"id": "0", "hierarchy_level": "Chief Happiness Wizard", "keep": True},
        {"id": "1", "hierarchy_level": "Director", "keep": True, "hierarchy_rank": 1},
        {"id": "2", "hierarchy_level": "whatever", "keep": False}]})
    out = hierarchy._classify_chunk({"company_name": "Acme"}, [{}, {}, {}])
    assert "0" not in out                      # invalid label -> unclassified (retried upstream)
    assert out["1"]["hierarchy_rank"] == _level_rank("Director")  # model's rank ignored
    assert out["2"]["keep"] is False and out["2"]["hierarchy_rank"] == 999


def test_build_company_record_only_needs_a_name():
    rec = build_company_record("  Acme Corp ", domain="https://www.Acme.com/about")
    assert rec == {"company_name": "Acme Corp", "country": "", "industry": "",
                   "known_domain": "acme.com", "known_linkedin": None}


def test_tree_and_markdown_group_by_level_most_senior_first():
    people = [
        {"company": "Acme", "country": "UAE", "person_name": "Pat", "job_title": "Product Manager",
         "hierarchy_level": "Manager / Product Manager", "hierarchy_rank": 9, "linkedin_url": "https://www.linkedin.com/in/pat/"},
        {"company": "Acme", "country": "UAE", "person_name": "Cy", "job_title": "CEO",
         "hierarchy_level": "CEO / President / Founder", "hierarchy_rank": 1, "linkedin_url": "https://www.linkedin.com/in/cy/"},
    ]
    tree = build_hierarchy_tree(people)
    assert [b["hierarchy_level"] for b in tree[0]["levels"]] == ["CEO / President / Founder", "Manager / Product Manager"]
    md = format_hierarchy_markdown(people)
    assert md.index("Cy") < md.index("Pat") and "https://www.linkedin.com/in/cy/" in md


def _speed_settings(**over):
    values = dict(max_hierarchy_people_per_company=50, hierarchy_pool_multiplier=2,
                  max_hierarchy_queries_per_company=15, hierarchy_results_per_query=15,
                  max_hierarchy_apify_runs_per_company=8, max_hierarchy_profile_lookups=10,
                  hierarchy_parallel_runs=3, apify_lead_fallback_actor="afanasenko/linkedin-profile-api-scraper",
                  tavily_api_key="k")
    values.update(over)
    return _settings(**values)


def test_apify_runs_and_lookups_are_capped(monkeypatch):
    import itertools
    monkeypatch.setattr(hierarchy, "settings", _speed_settings())
    uid = itertools.count()
    counts = {"search": 0, "lookup": 0}

    def fake_actor(actor, payload):
        if payload.get("operationMode") == "lookupByUrl":
            counts["lookup"] += 1
            return []
        counts["search"] += 1
        return [{"full_name": f"P{next(uid)}", "job_title": "M", "company_name": "Acme",
                 "linkedin": f"https://www.linkedin.com/in/p{next(uid)}"} for _ in range(3)]
    monkeypatch.setattr(hierarchy, "run_actor_get_dataset_items", fake_actor)
    monkeypatch.setattr(hierarchy, "public_search", lambda q, include_domains=None, max_results=None: [
        {"url": f"https://www.linkedin.com/in/t{next(uid)}"} for _ in range(10)])
    monkeypatch.setattr(hierarchy, "_dynamic_hierarchy_search_terms", lambda c, n: [f"q{i}" for i in range(n)])
    monkeypatch.setattr(hierarchy, "_classify_hierarchy_batch", lambda c, raw: {})
    generate_company_hierarchy([{"company_name": "Acme", "known_domain": "acme.com"}], None)
    assert counts["search"] <= 8
    assert counts["lookup"] <= 10


def test_stops_early_when_searches_find_nobody_new(monkeypatch):
    monkeypatch.setattr(hierarchy, "settings", _speed_settings(tavily_api_key=""))
    n = {"runs": 0}

    def fake_actor(actor, payload):
        n["runs"] += 1
        # same single person every time -> no new people after the first run
        return [{"full_name": "Same", "job_title": "CEO", "company_name": "Acme",
                 "linkedin": "https://www.linkedin.com/in/same"}]
    monkeypatch.setattr(hierarchy, "run_actor_get_dataset_items", fake_actor)
    monkeypatch.setattr(hierarchy, "_dynamic_hierarchy_search_terms", lambda c, k: [f"q{i}" for i in range(k)])
    monkeypatch.setattr(hierarchy, "_classify_hierarchy_batch", lambda c, raw: {})
    generate_company_hierarchy([{"company_name": "Acme", "known_domain": "acme.com"}], None)
    assert n["runs"] == 3   # 1 productive + 2 stale, then stop (not all 16)
