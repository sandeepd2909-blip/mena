import os
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

# The runnable package includes a private .env. Unit tests must stay offline and must
# never turn real provider credentials into unexpected API calls or credit usage.
os.environ.setdefault("PYTHON_DOTENV_DISABLED", "1")

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


@pytest.fixture(autouse=True)
def disable_real_network_enrichment(monkeypatch):
    """Keep the test suite deterministic even when a runnable .env has real keys.

    Provider-specific tests explicitly monkeypatch their provider settings and can
    enable the provider as needed. Ordinary integration tests must never spend real
    Prospeo/Apify/Hunter/Tomba credits or hang on external DNS/network access.
    """
    from app import prospeo_api, apify_contacts, hunter_api, tomba_api

    monkeypatch.setattr(
        prospeo_api,
        "settings",
        SimpleNamespace(
            prospeo_api_key="",
            prospeo_enabled=False,
            prospeo_base_url="https://api.prospeo.io",
            prospeo_timeout=2,
            prospeo_enrich_mobile=False,
        ),
    )
    monkeypatch.setattr(
        apify_contacts,
        "settings",
        SimpleNamespace(
            apify_api_token="",
            apify_contact_enabled=False,
            apify_contact_actor="b2bsearch/bulk-people-enrichment",
            apify_contact_fallback_actor="datablow/linkedin-profile-enrichment",
            apify_contact_actors=(
                "b2bsearch/bulk-people-enrichment",
                "datablow/linkedin-profile-enrichment",
                "b2bsearch/linkedin-email-finder",
            ),
            apify_timeout_seconds=2,
        ),
    )
    monkeypatch.setattr(
        hunter_api,
        "settings",
        SimpleNamespace(
            hunter_api_key="",
            hunter_timeout=2,
            hunter_max_lookups_per_company=1,
            hunter_phone_match_limit=1,
        ),
    )
    monkeypatch.setattr(
        tomba_api,
        "settings",
        SimpleNamespace(
            tomba_api_key="",
            tomba_secret_key="",
            tomba_timeout=2,
            tomba_enabled=False,
        ),
    )
