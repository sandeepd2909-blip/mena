"""V7.8.58: AI company resolution (subsidiary / trading name) with source-grounded validation."""
from types import SimpleNamespace

from app import company_resolver as cr, server, uae_state, webpeople
from app.webpeople import _linkedin_current_employer_score as score, register_company_aliases

UAE = "United Arab Emirates"
REG = "FRESHLY FOODS TRADING L.L.C"


def _hits():
    return [
        {"url": "https://www.freshly.ae/about", "title": "About Freshly Foods Trading",
         "content": "Freshly Foods Trading LLC, Dubai, UAE, trades as Freshly Fresh and is a wholly owned subsidiary of Al Noor Group."},
        {"url": "https://www.linkedin.com/company/freshly-fresh", "title": "Freshly Fresh | LinkedIn",
         "content": "Freshly Fresh. Food Production. Dubai, United Arab Emirates. Freshly Foods Trading LLC"},
        {"url": "https://nj.example.com/freshly-foods", "title": "Freshly Foods Trading Inc - New Jersey",
         "content": "Freshly Foods Trading Inc is headquartered in Newark, New Jersey, United States. Part of Acme Corp."},
    ]


def _search(q, include_domains=None, max_results=None):
    return _hits()


def _good_ai(system, user):
    if "You check one LinkedIn URL" in system:
        return {"is_company_page": True, "matches_company": True}
    return {"resolved_name": "Freshly Fresh", "aliases": ["Freshly Fresh", "Freshly Fresh FZE"], "relationship": "subsidiary",
            "parent_company": "Al Noor Group", "website_domain": "freshly.ae",
            "company_linkedin": "https://www.linkedin.com/company/freshly-fresh", "uae_entity": True,
            "confidence": 0.9, "evidence_ids": [0, 1], "note": "ok"}


def _resolve(ai, search=_search):
    cr.clear_cache()
    return cr.resolve_company(REG, country=UAE, emirate="Dubai", search=search, ask=ai, use_cache=False)


def test_subsidiary_is_resolved_validated_and_labelled():
    r = _resolve(_good_ai)
    assert r["status"] == "resolved" and r["is_subsidiary"] and r["parent_company"] == "Al Noor Group"
    assert r["resolved_name"] == "Freshly Fresh" and "Freshly Fresh" in r["aliases"]
    assert r["website_domain"] == "freshly.ae" and r["company_linkedin"].endswith("/company/freshly-fresh")
    assert r["label"] == "Operates as Freshly Fresh · Subsidiary of Al Noor Group"
    assert "FZE" not in " ".join(r["aliases"])  # alias not present in any source -> dropped (hallucination guard)


def test_hallucinated_parent_is_dropped():
    r = _resolve(lambda s, u: dict(_good_ai(s, u), parent_company="Totally Invented Holdings"))
    assert not r["is_subsidiary"] and r["parent_company"] == "" and "Invented" not in r["label"]


def test_parent_mentioned_without_ownership_cue_is_dropped():
    hits = [{"url": "https://www.freshly.ae/news", "title": "Freshly Foods Trading",
             "content": "Freshly Foods Trading LLC, Dubai UAE, signed a contract with Al Noor Group last year."}]
    r = _resolve(lambda s, u: dict(_good_ai(s, u), evidence_ids=[0]), search=lambda *a, **k: hits)
    assert not r["is_subsidiary"] and r["parent_company"] == ""


def test_foreign_same_name_company_is_never_a_source_or_parent():
    seen = {}
    def ai(system, user):
        seen["payload"] = user
        return dict(_good_ai(system, user), parent_company="Acme Corp")
    r = _resolve(ai)
    assert "Newark" not in seen["payload"] and "New Jersey" not in seen["payload"]
    assert r["parent_company"] == ""  # Acme Corp only appears in the (filtered-out) New Jersey source


def test_parent_name_never_becomes_a_search_alias_by_default():
    r = _resolve(_good_ai)
    assert "Al Noor Group" not in cr.search_aliases(r)


def test_low_confidence_or_non_uae_falls_back_to_registered_name():
    r = _resolve(lambda s, u: dict(_good_ai(s, u), confidence=0.2))
    assert r["status"] == "unresolved" and r["aliases"] == [] and r["resolved_name"] == REG
    r = _resolve(lambda s, u: dict(_good_ai(s, u), uae_entity=False))
    assert r["status"] == "unresolved" and not r["is_subsidiary"]


def test_ai_or_search_failure_never_raises():
    def boom(*a, **k): raise RuntimeError("openai down")
    assert _resolve(boom)["status"] == "error"
    assert _resolve(_good_ai, search=boom)["status"] == "unresolved"


def test_social_site_is_not_accepted_as_company_website():
    r = _resolve(lambda s, u: dict(_good_ai(s, u), website_domain="linkedin.com"))
    assert r["website_domain"] == ""


def test_resolved_alias_lets_profile_with_trading_name_match_the_company():
    li = {"url": "https://www.linkedin.com/in/sara-ali-9/", "title": "Sara Ali - Procurement Manager - Freshly Fresh | LinkedIn",
          "text": "Sara Ali. Procurement Manager at Freshly Fresh. Dubai, United Arab Emirates"}
    register_company_aliases(REG, [])
    assert score(REG, "Sara Ali", "", li, UAE) == 0           # unknown brand name: not provable
    register_company_aliases(REG, ["Freshly Fresh"])
    assert score(REG, "Sara Ali", "", li, UAE) >= 10          # resolved alias: accepted
    register_company_aliases(REG, [])


def test_foreign_profile_still_rejected_with_resolved_alias():
    li = {"url": "https://www.linkedin.com/in/sara-ali-9/", "title": "Sara Ali - Manager - Freshly Fresh | LinkedIn",
          "text": "Sara Ali. Manager at Freshly Fresh. Newark, New Jersey, United States"}
    register_company_aliases(REG, ["Freshly Fresh"])
    assert score(REG, "Sara Ali", "", li, UAE) == 0
    register_company_aliases(REG, [])


def test_pipeline_runs_on_resolved_company_and_reports_subsidiary(monkeypatch, tmp_path):
    monkeypatch.setattr(uae_state, "BASE", tmp_path / "uae_state")
    monkeypatch.setattr(uae_state, "STATE_FILE", tmp_path / "uae_state" / "state.json")
    resolution = _resolve(_good_ai)
    monkeypatch.setattr(server, "_resolve_company_safe", lambda item: resolution)
    captured = {}
    import app.uae_people as uae_people
    def fake_find(company, search=None):
        captured.update(company)
        return {"people": [{"person_name": "Sara Ali", "job_title": "Procurement Manager", "linkedin_url": "https://www.linkedin.com/in/sara-ali-9/"}],
                "sources_used": 3, "errors": []}
    monkeypatch.setattr(uae_people, "find_target_people", fake_find)
    job = {"id": "j1", "stage": "discovered", "segment": "", "main_activity_code": "10", "selected_company_ids": ["c1"],
           "companies": [{"id": "c1", "name": REG, "domain": "", "emirate": "Dubai", "company_key": "k1", "people": []}]}
    server._run_selected_people(job, [])
    c = job["companies"][0]
    assert captured["company_name"] == REG and captured["aliases"] == ["Freshly Fresh"]
    assert captured["known_domain"] == "freshly.ae"
    assert c["resolution"]["label"] == "Operates as Freshly Fresh · Subsidiary of Al Noor Group"
    assert c["people"][0]["company_relationship"] == c["resolution"]["label"]
    assert "Subsidiary of Al Noor Group" in server._csv(job).decode("utf-8-sig")
    register_company_aliases(REG, [])


def test_linkedin_url_must_be_company_page_confirmed_by_ai():
    # person profile / school / post URLs are never accepted as a company page
    for bad in ("https://www.linkedin.com/in/sara-ali-9/", "https://www.linkedin.com/school/freshly/",
                "https://www.linkedin.com/posts/freshly-fresh_x", ""):
        assert cr.canonical_company_linkedin(bad) == ""
    # AI says it is not this company's page -> not displayed
    def no(system, user):
        if "You check one LinkedIn URL" in system:
            return {"is_company_page": True, "matches_company": False}
        return _good_ai(system, user)
    assert _resolve(no)["company_linkedin"] == ""
    # AI verification failure -> fail closed
    def boom(system, user):
        if "You check one LinkedIn URL" in system:
            raise RuntimeError("down")
        return _good_ai(system, user)
    assert _resolve(boom)["company_linkedin"] == ""
    # model returns a person URL as company_linkedin -> dropped
    assert _resolve(lambda s, u: dict(_good_ai(s, u), company_linkedin="https://www.linkedin.com/in/sara-ali-9/"))["company_linkedin"] == ""
