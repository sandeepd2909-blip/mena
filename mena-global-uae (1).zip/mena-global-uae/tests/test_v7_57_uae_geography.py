"""V7.8.57: only UAE-located people/profiles may be attached to a UAE company."""
from types import SimpleNamespace

from app import webpeople
from app.geo import geo_verdict
from app.webpeople import (
    _linkedin_current_employer_score as score,
    _company_evidence_geo,
    find_person_linkedin,
)

UAE = "United Arab Emirates"
NUITREE = "NUITREE FOOD INDUSTRIES L.L.C"
COMPANY = {"company_name": NUITREE, "country": UAE}

# The exact false positives from the UI: NFI (New Jersey) executives matched via the derived "NFI" acronym.
NFI_NJ = {
    "url": "https://www.linkedin.com/in/ike-brown-1/",
    "title": "Ike Brown - President, Vice-Chairman at NFI | LinkedIn",
    "text": "Ike Brown. President, Vice-Chairman at NFI. Camden, New Jersey, United States. 500+ connections",
}
NFI_NO_LOCATION = {
    "url": "https://www.linkedin.com/in/jordan-brown-2/",
    "title": "Jordan Brown - Co-Founder, Keasy.ai | Partner, NFI Ventures | LinkedIn",
    "text": "Jordan Brown. Co-Founder at NFI. 500+ connections",
}
REAL_UAE = {
    "url": "https://www.linkedin.com/in/sara-ali-9/",
    "title": "Sara Ali - Procurement Manager - Nuitree Food Industries | LinkedIn",
    "text": "Sara Ali. Procurement Manager at Nuitree Food Industries. Dubai, United Arab Emirates",
}


def test_new_jersey_nfi_profile_is_rejected_for_uae_company():
    assert score(NUITREE, "Ike Brown", "", NFI_NJ, UAE) == 0


def test_derived_acronym_without_uae_evidence_is_rejected():
    assert score(NUITREE, "Jordan Brown", "", NFI_NO_LOCATION, UAE) == 0


def test_acronym_with_uae_location_is_accepted():
    ok = dict(NFI_NO_LOCATION, text="Jordan Brown. Co-Founder at NFI. Dubai, United Arab Emirates")
    ok["title"] = "Jordan Brown - Co-Founder - NFI | LinkedIn"
    assert score(NUITREE, "Jordan Brown", "", ok, UAE) >= 10


def test_full_name_uae_profile_is_accepted():
    assert score(NUITREE, "Sara Ali", "Procurement Manager", REAL_UAE, UAE) >= 10


def test_foreign_location_rejects_even_full_company_name():
    foreign = dict(REAL_UAE, text="Sara Ali. Procurement Manager at Nuitree Food Industries. Mumbai, India")
    assert score(NUITREE, "Sara Ali", "", foreign, UAE) == 0


def test_config_default_does_not_require_location_snippet(monkeypatch):
    from app.config import Settings
    monkeypatch.delenv("LINKEDIN_REQUIRE_UAE_EVIDENCE", raising=False)
    assert Settings().linkedin_require_uae_evidence is False


def test_no_location_is_allowed_by_default_but_strict_mode_remains_available(monkeypatch):
    bare = dict(REAL_UAE, text="Sara Ali. Procurement Manager at Nuitree Food Industries.")
    # Normal mode favors recall when the employer and profile owner are clear.
    monkeypatch.setattr(webpeople, "settings", SimpleNamespace(linkedin_require_uae_evidence=False))
    assert score(NUITREE, "Sara Ali", "", bare, UAE) >= 10
    # Operators can still explicitly require a UAE location snippet.
    monkeypatch.setattr(webpeople, "settings", SimpleNamespace(linkedin_require_uae_evidence=True))
    assert score(NUITREE, "Sara Ali", "", bare, UAE) == 0


def test_geo_not_applied_to_non_uae_companies():
    assert score("Acme Co", "Ike Brown", "", dict(NFI_NJ, title="Ike Brown - President - Acme Co | LinkedIn",
                 text="Ike Brown President at Acme Co. New Jersey"), "United States") >= 10


def test_person_named_jordan_is_not_mistaken_for_a_foreign_country():
    assert not geo_verdict(UAE, "Jordan Brown - CEO | LinkedIn", "Jordan Brown, Dubai").foreign_head


def test_person_recovery_accepts_full_company_match_without_location(monkeypatch):
    monkeypatch.setattr(webpeople, "settings", SimpleNamespace(
        linkedin_require_uae_evidence=False,
        profile_recovery_search_queries_per_person=18,
    ))
    hit = {
        "url": "https://www.linkedin.com/in/ike-brown-majan/",
        "title": "Ike Brown - Operations Manager - Nuitree Food Industries | LinkedIn",
        "content": "Ike Brown. Operations Manager at Nuitree Food Industries.",
    }
    found = find_person_linkedin(
        {"person_name": "Ike Brown", "job_title": "Operations Manager"},
        COMPANY,
        search=lambda *args, **kwargs: [hit],
    )
    assert found and found["url"].endswith("/ike-brown-majan/")


def test_find_person_linkedin_only_returns_the_uae_profile():
    uae_ike = {"url": "https://www.linkedin.com/in/ike-brown-uae/",
               "title": "Ike Brown - Manager - Nuitree Food Industries | LinkedIn",
               "content": "Ike Brown. Manager at Nuitree Food Industries. Dubai, United Arab Emirates"}
    nj = {"url": NFI_NJ["url"], "title": NFI_NJ["title"], "content": NFI_NJ["text"]}
    got = find_person_linkedin({"person_name": "Ike Brown", "job_title": ""}, COMPANY, search=lambda *a, **k: [nj, uae_ike])
    assert got and got["url"].endswith("/ike-brown-uae/")
    assert find_person_linkedin({"person_name": "Ike Brown", "job_title": ""}, COMPANY, search=lambda *a, **k: [nj]) is None


def test_web_source_from_abroad_is_not_treated_as_company_evidence():
    nj_page = ("NFI leadership", "NFI is a supply chain company headquartered in Camden, New Jersey, USA.")
    assert not _company_evidence_geo(COMPANY, *nj_page, ["NFI"])
    uae_page = ("Nuitree Food Industries", "Nuitree Food Industries (NFI) is based in Dubai, UAE.")
    assert _company_evidence_geo(COMPANY, *uae_page, ["NFI"])
