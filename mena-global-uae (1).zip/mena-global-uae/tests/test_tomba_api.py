from types import SimpleNamespace
from unittest.mock import patch

from app import tomba_api


def test_normalize_linkedin_url():
    assert tomba_api.normalize_linkedin_url('https://www.linkedin.com/in/alex-maccaw-ab592978/') == 'https://www.linkedin.com/in/alex-maccaw-ab592978'
    assert tomba_api.normalize_linkedin_url('linkedin.com/in/alex') == 'https://www.linkedin.com/in/alex'
    assert tomba_api.normalize_linkedin_url('https://linkedin.com/company/acme') == ''


def test_generic_email_rejected():
    assert tomba_api.normalize_email('info@example.com') == ''
    assert tomba_api.normalize_email('john.doe@acme.com') == 'john.doe@acme.com'


def test_linkedin_result_accepts_exact_identity_and_mobile():
    payload = {
        'data': {
            'email': 'john.doe@acme.com',
            'full_name': 'John Doe',
            'company': 'Acme Logistics LLC',
            'position': 'Chief Executive Officer',
            'linkedin': 'https://www.linkedin.com/in/john-doe',
            'domain': 'acme.com',
            'score': 95,
            'sources': [{'uri': 'https://acme.com/team'}],
            'phone_data': [{'phone_number': '+971501234567', 'phone_type': 'mobile', 'valid': True}],
        }
    }
    with patch.object(tomba_api, '_get', return_value=payload):
        result = tomba_api.find_by_linkedin(
            'https://www.linkedin.com/in/john-doe',
            target_name='John Doe', target_company='Acme Logistics', target_domain='acme.com'
        )
    assert result['status'] == 'found'
    assert result['email'] == 'john.doe@acme.com'
    assert result['phone'] == '+971501234567'
    assert result['phone_type'] == 'mobile'


def test_linkedin_mismatch_rejected():
    payload = {'data': {'full_name': 'Other Person', 'company': 'Acme', 'linkedin': 'https://www.linkedin.com/in/other-person'}}
    with patch.object(tomba_api, '_get', return_value=payload):
        result = tomba_api.find_by_linkedin('https://www.linkedin.com/in/target-person', target_name='Target Person', target_company='Acme')
    assert result['status'] == 'rejected_linkedin_mismatch'


def test_company_mismatch_rejected():
    payload = {'data': {'full_name': 'John Doe', 'company': 'Wrong Company', 'linkedin': 'https://www.linkedin.com/in/john-doe', 'email': 'john@wrong.com'}}
    with patch.object(tomba_api, '_get', return_value=payload):
        result = tomba_api.find_by_linkedin('https://www.linkedin.com/in/john-doe', target_name='John Doe', target_company='Acme Logistics')
    assert result['status'] == 'rejected_company_mismatch'
