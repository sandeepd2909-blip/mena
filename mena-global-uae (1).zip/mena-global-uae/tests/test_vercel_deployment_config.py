import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_vercel_service_uses_container_runtime_and_dockerfile_entrypoint():
    config = json.loads((ROOT / "vercel.json").read_text(encoding="utf-8"))
    service = config["services"]["mena-global"]
    assert service["runtime"] == "container"
    assert service["entrypoint"] == "Dockerfile.vercel"
    assert (ROOT / service["entrypoint"]).is_file()
    assert config["rewrites"][0]["destination"]["service"] == "mena-global"


def test_dockerfile_runs_http_server_on_vercel_port():
    dockerfile = (ROOT / "Dockerfile.vercel").read_text(encoding="utf-8")
    assert "FROM python:3.12-slim" in dockerfile
    assert "main.py --ui --host 0.0.0.0 --port ${PORT:-80}" in dockerfile


def test_secret_files_are_excluded_from_deploy_context():
    vercelignore = (ROOT / ".vercelignore").read_text(encoding="utf-8")
    dockerignore = (ROOT / ".dockerignore").read_text(encoding="utf-8")
    for ignore in (vercelignore, dockerignore):
        assert ".env" in ignore
        assert ".env.local" in ignore


def test_dockerfile_installs_browser_for_moiat_fallback():
    """MoIAT needs a real browser session; the slim Python image has none unless we install it."""
    dockerfile = (ROOT / "Dockerfile.vercel").read_text(encoding="utf-8")
    assert "chromium" in dockerfile and "chromium-driver" in dockerfile
    assert "MOIAT_BROWSER_BINARY=/usr/bin/chromium" in dockerfile
    assert "MOIAT_BROWSER_FALLBACK=true" in dockerfile


def test_configured_browser_binary_is_picked_up(tmp_path, monkeypatch):
    from app import moiat_directory
    fake = tmp_path / "chromium"
    fake.write_text("#!/bin/sh\n")
    monkeypatch.setenv("MOIAT_BROWSER_BINARY", str(fake))
    assert moiat_directory._browser_binary() == ("chrome", str(fake))
