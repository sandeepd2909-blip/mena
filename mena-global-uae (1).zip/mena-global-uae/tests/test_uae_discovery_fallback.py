from types import SimpleNamespace

from app import moiat_directory as md


def _row(name, code, segments=()):
    return md.MoIATCompany(
        company_key=name.casefold(), company_name=name, company_name_ar="", emirate="Dubai",
        phone="", email="", activities=({"isic4_code": code, "activity_en": "Manufacture", "activity_ar": ""},),
        products=(), matched_segments=tuple(segments),
    )


def test_cache_filter_miss_falls_through_to_live_moiat(monkeypatch):
    cached = _row("Old unrelated cache record", "1030001", (md.TARGET_SEGMENTS[1],))
    live = _row("Current materials factory", "2394001", (md.TARGET_SEGMENTS[0],))
    monkeypatch.setattr(md, "_read_cached_directory", lambda: ([cached], False))
    monkeypatch.setattr(md, "_start_directory_cache_refresh", lambda: None)
    monkeypatch.setattr(md, "search_moiat_directory_page", lambda **kw: md.MoIATSearchPage((live,), 1, 1, 1))

    rows, _, total, more = md.discover_moiat_batch(main_activity_code="23", limit=50)

    assert [r.company_name for r in rows] == ["Current materials factory"]
    assert total == 1
    assert more is False


def test_moiat_error_uses_source_linked_search_fallback(monkeypatch):
    monkeypatch.setattr(md, "_read_cached_directory", lambda: None)
    monkeypatch.setattr(md, "_start_directory_cache_refresh", lambda: None)
    monkeypatch.setattr(
        md, "search_moiat_directory_page",
        lambda **kw: (_ for _ in ()).throw(md.MoIATDirectoryError("simulated MoIAT outage")),
    )
    from app import search
    monkeypatch.setattr(search, "public_search", lambda query, max_results=None: [
        {"title": "National Paints | Paint manufacturer", "url": "https://www.nationalpaints.ae/", "content": "Paint manufacturer in Sharjah, UAE serving building and industrial customers."},
        {"title": "Top companies in UAE", "url": "https://example.org/list", "content": "Directory of companies."},
        {"title": "An unrelated company", "url": "https://example.com/company", "content": "Software company based in Canada."},
    ])

    rows, cursors, total, more = md.discover_moiat_batch(segment=md.TARGET_SEGMENTS[0], limit=50)

    assert len(rows) == 1
    assert rows[0]["company_name"] == "National Paints"
    assert rows[0]["source_url"] == "https://www.nationalpaints.ae/"
    assert "MoIAT unverified" in rows[0]["source_name"]
    assert "Confirm MoIAT registration separately" in rows[0]["note"]
    assert total == 1 and not more and not cursors


def test_empty_moiat_results_fall_back_to_grounded_web_candidates(monkeypatch):
    monkeypatch.setattr(md, "_read_cached_directory", lambda: None)
    monkeypatch.setattr(md, "_start_directory_cache_refresh", lambda: None)
    monkeypatch.setattr(md, "search_moiat_directory_page", lambda **kw: md.MoIATSearchPage((), kw["page_index"], 0, 0))
    from app import search
    monkeypatch.setattr(search, "public_search", lambda query, max_results=None: [
        {"title": "FoodCo UAE | Food Manufacturing", "url": "https://foodco.ae/", "content": "Food manufacturing facility in Abu Dhabi, United Arab Emirates."},
    ])

    rows, _, total, more = md.discover_moiat_batch(segment=md.TARGET_SEGMENTS[1], limit=50)

    assert len(rows) == 1
    assert rows[0]["company_name"] == "FoodCo UAE"
    assert rows[0]["emirate"] == "Abu Dhabi"
    assert total == 1 and not more


def test_uae_connection_check_tests_actual_moiat_endpoint(monkeypatch):
    monkeypatch.setattr(md, "moiat_reachable", lambda force=False: (True, ""))  # V7.9.9: probe is network-only
    from app import company_directories as dirs
    monkeypatch.setattr(md, "search_moiat_directory_page", lambda **kw: md.MoIATSearchPage((_row("MoIAT Factory", "1030001"),), 1, 2, 12))
    result = dirs.check_directory_connection("United Arab Emirates")
    assert result["ok"] is True
    assert result["sample_count"] == 1
    assert result["total"] == 12
    assert "MoIAT" in result["source"]
