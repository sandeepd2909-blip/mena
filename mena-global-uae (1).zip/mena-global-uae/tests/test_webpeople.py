from types import SimpleNamespace

from app import webcontacts, webpeople
from app.webpeople import canonical_linkedin, collect_sources, find_person_linkedin, find_web_people, verify_person

COMPANY = {"company_name": "Acme Trading", "country": "UAE", "known_domain": "acme.ae"}

TEAM = {"url": "https://www.acme.ae/team", "title": "Acme Trading leadership",
        "content": "Acme Trading leadership. Sara Al Mansoori, Chief Executive Officer. Email: sara.mansoori@acme.ae "
                   "Mobile +971 50 111 2222. " + "x " * 500 + "Omar Khan, CFO. omar.khan@acme.ae"}
LI = {"url": "https://ae.linkedin.com/in/omar-khan-123?trk=x", "title": "Omar Khan - Chief Financial Officer - Acme Trading | LinkedIn",
      "content": "Omar Khan. Chief Financial Officer at Acme Trading. Dubai"}
OTHER = {"url": "https://news.example/zeta", "title": "Zeta", "content": "Sara Al Mansoori joins Zeta Corp. sara@zeta.com"}


def _env(monkeypatch):
    s = SimpleNamespace(tavily_api_key="k", serper_api_key="", search_provider="tavily", max_person_contact_lookups_per_company=30, person_contact_workers=2,
                        search_depth="basic", max_search_results=5, linkedin_require_uae_evidence=False)
    monkeypatch.setattr(webcontacts, "settings", s)
    monkeypatch.setattr(webpeople, "settings", s)


def fake_search(query, include_domains=None, max_results=None):
    return [TEAM, LI, OTHER]


def test_canonical_linkedin():
    assert canonical_linkedin("https://ae.linkedin.com/in/omar-khan-123?trk=x") == "https://www.linkedin.com/in/omar-khan-123/"
    assert canonical_linkedin("https://www.linkedin.com/company/acme/") == ""


def test_pages_about_other_companies_are_dropped(monkeypatch):
    _env(monkeypatch)
    sources, _ = collect_sources(COMPANY, search=fake_search)
    assert {s["url"] for s in sources} == {TEAM["url"], LI["url"]}
    assert sources[0]["official"]  # official site first


def test_ai_invented_values_are_rejected(monkeypatch):
    _env(monkeypatch)
    sources, _ = collect_sources(COMPANY, search=fake_search)
    raw = {"person_name": "Sara Al Mansoori", "job_title": "CEO", "source_ids": [0],
           "linkedin_url": "https://www.linkedin.com/in/made-up-sara/",   # not in any source
           "email": "sara@invented.com", "phone": "+971 55 000 0000"}   # not in text
    row = verify_person(raw, sources, COMPANY)
    assert row["linkedin_url"] == ""
    assert row["business_email"] == "sara.mansoori@acme.ae"   # taken from the page, not from the AI
    assert row["phone"] == "+971501112222"


def test_person_not_on_any_page_is_rejected(monkeypatch):
    _env(monkeypatch)
    sources, _ = collect_sources(COMPANY, search=fake_search)
    assert verify_person({"person_name": "Nobody Real", "source_ids": [0]}, sources, COMPANY) is None
    assert verify_person({"person_name": "Madonna", "source_ids": [0]}, sources, COMPANY) is None


def test_linkedin_taken_from_profile_hit_and_far_contacts_not_attributed(monkeypatch):
    _env(monkeypatch)
    sources, _ = collect_sources(COMPANY, search=fake_search)
    row = verify_person({"person_name": "Omar Khan", "job_title": "CFO", "source_ids": [1]}, sources, COMPANY)
    assert row["linkedin_url"] == "https://www.linkedin.com/in/omar-khan-123/"


def test_end_to_end_with_mocked_ai(monkeypatch):
    _env(monkeypatch)
    extract = lambda c, s: [
        {"person_name": "Sara Al Mansoori", "job_title": "Chief Executive Officer", "source_ids": [0]},
        {"person_name": "Omar Khan", "job_title": "CFO", "source_ids": [0, 1]},
        {"person_name": "Intern Person", "job_title": "Intern", "source_ids": [0]},   # not on page -> rejected
    ]
    classify = lambda c, rows: {
        str(i): {"keep": True, "hierarchy_level": "CEO / President / Founder" if "Sara" in r["person_name"] else "C-Suite",
                 "hierarchy_rank": 1 if "Sara" in r["person_name"] else 2}
        for i, r in enumerate(rows)}
    res = find_web_people(COMPANY, search=fake_search, extract=extract, classify=classify, enrich=False)
    names = [p["person_name"] for p in res["people"]]
    assert names == ["Sara Al Mansoori", "Omar Khan"]
    omar = res["people"][1]
    assert omar["linkedin_url"].endswith("/omar-khan-123/") and omar["business_email"] == "omar.khan@acme.ae"


def test_linkedin_fallback_handles_company_spacing_variant(monkeypatch):
    _env(monkeypatch)
    row = {"person_name": "Omar Al Majdouie", "job_title": "Chief Executive Officer"}
    company = {"company_name": "Al Majdouie", "country": "Saudi Arabia", "known_domain": "almajdouie.com"}
    calls = []
    hits = [{
        "url": "https://www.linkedin.com/in/omar-almajdouie/",
        "title": "Omar Al Majdouie - Chief Executive Officer - Almajdouie | LinkedIn",
        "content": "Omar Al Majdouie. Chief Executive Officer at Almajdouie, Saudi Arabia.",
    }]
    def search(query, include_domains=None, max_results=None):
        calls.append(query)
        return hits if "Almajdouie" in query else []
    cand = find_person_linkedin(row, company, search=search, pick=lambda *args: hits[0])
    assert cand and cand["url"].endswith("/omar-almajdouie/")
    assert any("Almajdouie" in q for q in calls)


def test_linkedin_enrichment_uses_google_provider_when_available(monkeypatch):
    _env(monkeypatch)
    monkeypatch.setattr(webpeople.settings, "serper_api_key", "google-key", raising=False)
    monkeypatch.setattr(webpeople.settings, "search_provider", "serper", raising=False)
    google_calls = []
    def fake_serper(query, include_domains=None, max_results=None):
        google_calls.append((query, include_domains))
        return [{
            "url": "https://www.linkedin.com/in/omar-khan-123/",
            "title": "Omar Khan - CFO - Acme Trading | LinkedIn",
            "content": "Omar Khan, CFO at Acme Trading. Dubai, United Arab Emirates. Email omar.khan@acme.ae. Mobile +971 50 111 2222",
        }]
    monkeypatch.setattr(webpeople, "serper_search", fake_serper)
    row = {"person_name": "Omar Khan", "job_title": "CFO", "linkedin_url": "", "business_email": "", "phone": ""}
    stats = webpeople.enrich_linkedin_and_contacts([row], COMPANY, frozenset())
    assert stats["profiles_found"] == 1
    assert row["linkedin_url"].endswith("/omar-khan-123/")
    assert google_calls


def test_profile_contacts_do_not_copy_switchboard_or_generic_mailbox(monkeypatch):
    _env(monkeypatch)
    row = {"person_name": "Omar Khan", "job_title": "CFO", "linkedin_url": ""}
    company = {"company_name": "Acme Trading", "country": "UAE", "known_domain": "acme.ae"}
    cand = {
        "url": "https://www.linkedin.com/in/omar-khan-123/",
        "content": "Omar Khan, CFO at Acme Trading. Contact info@acme.ae or +971 4 123 4567",
    }
    stats = webpeople.enrich_linkedin_and_contacts([row], company, frozenset({"41234567"}), search=lambda *a, **k: [])
    assert stats["profiles_found"] == 0


def test_shared_company_phone_is_removed_from_all_people(monkeypatch):
    _env(monkeypatch)
    rows = [
        {"person_name": "Sara Al Mansoori", "phone": "+966138198111"},
        {"person_name": "Omar Al Majdouie", "phone": "+966138198111"},
    ]
    assert webpeople._remove_shared_company_phone_numbers(rows) == 2
    assert all(not row["phone"] for row in rows)


def test_linkedin_profile_fallback_keeps_person_when_ai_extract_is_empty(monkeypatch):
    _env(monkeypatch)
    from app.webpeople import find_web_people

    company = {
        "company_name": "Panda Retail Company – Savola Group",
        "country": "Saudi Arabia",
        "industry": "Retail",
        "known_domain": "panda.com.sa",
    }
    hit = {
        "url": "https://sa.linkedin.com/in/abdullah-al-sabban-62453518",
        "title": "Abdullah Al-Sabban - Panda Retail Company – Savola Group | LinkedIn",
        "content": "Abdullah Al-Sabban\nPanda Retail Company – Savola Group\nEnterprise leader, board member, and CEO advisor with over 28 years of experience.",
    }

    def fake_search(query, include_domains=None, max_results=None):
        return [hit]

    def fake_classify(company, rows):
        return {str(i): {"hierarchy_level": "C-Suite", "hierarchy_rank": 2, "keep": True} for i, _ in enumerate(rows)}

    result = find_web_people(
        company,
        search=fake_search,
        extract=lambda company, sources: [],
        classify=fake_classify,
        enrich=False,
    )
    assert len(result["people"]) == 1
    person = result["people"][0]
    assert person["person_name"] == "Abdullah Al-Sabban"
    assert person["linkedin_url"].endswith("/abdullah-al-sabban-62453518/")
    assert result["diagnostics"]["linkedin_profile_candidates"] == 1


def test_profile_without_location_is_kept_when_current_employer_is_verified(monkeypatch):
    _env(monkeypatch)
    company = {
        "company_name": "MAJAN FOOD INDUSTRIES L.L.C",
        "country": "United Arab Emirates",
        "industry": "Food Manufacturing",
        "known_domain": "majan.example",
    }
    hit = {
        "url": "https://www.linkedin.com/in/sara-ali-majan/",
        "title": "Sara Ali - Procurement Manager - Majan Food Industries LLC | LinkedIn",
        "content": "Sara Ali. Procurement Manager at Majan Food Industries LLC.",
    }

    result = find_web_people(
        company,
        search=lambda *args, **kwargs: [hit],
        extract=lambda company, sources: [],
        classify=lambda company, rows: {
            str(i): {"keep": True, "hierarchy_level": "Manager", "hierarchy_rank": 3}
            for i, _ in enumerate(rows)
        },
        enrich=False,
    )
    assert result["people"]
    assert result["people"][0]["person_name"] == "Sara Ali"
    assert result["people"][0]["linkedin_url"] == "https://www.linkedin.com/in/sara-ali-majan/"


def test_unrelated_linkedin_profile_is_rejected_even_when_name_is_in_source(monkeypatch):
    _env(monkeypatch)
    company = {
        "company_name": "MAJAN FOOD INDUSTRIES L.L.C",
        "country": "United Arab Emirates",
        "known_domain": "",
    }
    sources = [{
        "url": "https://www.linkedin.com/in/angel-de-los-reyes-266967a4/",
        "title": "Angel de Los Reyes - Nestlé | LinkedIn",
        "text": "Angel de Los Reyes\nNestlé\nUnited Arab Emirates",
        "official": False,
        "linkedin": True,
    }]
    raw = {"person_name": "Angel de Los Reyes", "job_title": "Manager", "source_ids": [0]}
    assert verify_person(raw, sources, company) is None


def test_linkedin_profile_is_accepted_when_target_company_is_explicit(monkeypatch):
    _env(monkeypatch)
    company = {
        "company_name": "MAJAN FOOD INDUSTRIES L.L.C",
        "country": "United Arab Emirates",
        "known_domain": "",
    }
    sources = [{
        "url": "https://www.linkedin.com/in/example-majan/",
        "title": "Example Person - Production Manager - Majan Food Industries LLC | LinkedIn",
        "text": "Example Person\nProduction Manager at Majan Food Industries LLC\nDubai, UAE",
        "official": False,
        "linkedin": True,
    }]
    raw = {"person_name": "Example Person", "job_title": "Production Manager", "source_ids": [0]}
    row = verify_person(raw, sources, company)
    assert row is not None
    assert row["linkedin_url"].endswith("/example-majan/")


def test_verified_people_are_retained_without_ai_classification(monkeypatch):
    _env(monkeypatch)
    monkeypatch.setattr(webpeople, "_ai_extract", lambda company, sources: [{
        "person_name": "A Person",
        "job_title": "Product Manager",
        "source_ids": [0],
    }])
    monkeypatch.setattr(webpeople, "find_company_contacts", lambda *a, **k: {})
    monkeypatch.setattr(webpeople, "collect_sources", lambda *a, **k: ([{
        "url": "https://majan.example/team",
        "title": "Majan Food Industries LLC - Team",
        "text": "A Person, Product Manager, Majan Food Industries LLC",
        "official": True, "linkedin": False,
    }], []))
    result = find_web_people(
        {"company_name": "Majan Food Industries LLC", "country": "UAE", "known_domain": "majan.example"},
        search=lambda *a, **k: [],
        classify=lambda company, rows: {},
        enrich=False,
    )
    assert [p["person_name"] for p in result["people"]] == ["A Person"]
    assert result["people"][0]["hierarchy_level"] == "Unclassified"



def test_majan_like_company_run_keeps_broad_roles_and_rejects_nestle_profile(monkeypatch):
    _env(monkeypatch)
    company = {
        "company_name": "MAJAN FOOD INDUSTRIES L.L.C",
        "country": "United Arab Emirates",
        "industry": "Food & Beverage",
        "known_domain": "majan.example",
    }
    hits = [
        {
            "url": "https://www.linkedin.com/in/majan-ceo/",
            "title": "A CEO - Chief Executive Officer - Majan Food Industries LLC | LinkedIn",
            "content": "A CEO\nChief Executive Officer at Majan Food Industries LLC\nDubai",
        },
        {
            "url": "https://www.linkedin.com/in/majan-production/",
            "title": "B Manager - Production Manager - Majan Food Industries LLC | LinkedIn",
            "content": "B Manager\nProduction Manager at Majan Food Industries LLC\nDubai",
        },
        {
            "url": "https://www.linkedin.com/in/majan-quality/",
            "title": "C Manager - Quality Manager - Majan Food Industries LLC | LinkedIn",
            "content": "C Manager\nQuality Manager at Majan Food Industries LLC\nDubai",
        },
        {
            "url": "https://www.linkedin.com/in/majan-product/",
            "title": "D Manager - Product Manager - Majan Food Industries LLC | LinkedIn",
            "content": "D Manager\nProduct Manager at Majan Food Industries LLC\nDubai",
        },
        {
            "url": "https://www.linkedin.com/in/angel-de-los-reyes-266967a4/",
            "title": "Angel de Los Reyes - Nestlé | LinkedIn",
            "content": "Angel de Los Reyes\nNestlé\nUnited Arab Emirates",
        },
    ]

    def search(query, include_domains=None, max_results=None):
        return hits

    def extract(company, sources):
        return [
            {"person_name": "A CEO", "job_title": "Chief Executive Officer", "source_ids": [0]},
            {"person_name": "B Manager", "job_title": "Production Manager", "source_ids": [1]},
            {"person_name": "C Manager", "job_title": "Quality Manager", "source_ids": [2]},
            {"person_name": "D Manager", "job_title": "Product Manager", "source_ids": [3]},
            {"person_name": "Angel de Los Reyes", "job_title": "Manager", "source_ids": [4]},
        ]

    def classify(company, rows):
        levels = {
            "A CEO": ("CEO / President / Founder", 1),
            "B Manager": ("Manager / Product Manager", 9),
            "C Manager": ("Manager / Product Manager", 9),
            "D Manager": ("Manager / Product Manager", 9),
        }
        return {
            str(i): {"hierarchy_level": levels[r["person_name"]][0], "hierarchy_rank": levels[r["person_name"]][1], "keep": True}
            for i, r in enumerate(rows) if r["person_name"] in levels
        }

    result = find_web_people(company, search=search, extract=extract, classify=classify, enrich=False)
    names = [p["person_name"] for p in result["people"]]
    assert names == ["A CEO", "B Manager", "C Manager", "D Manager"]
    assert all(p["company"] == company["company_name"] for p in result["people"])


def test_ibfi_legal_name_resolves_to_linkedin_people(monkeypatch):
    _env(monkeypatch)
    company = {
        "company_name": "INTERNATIONAL BEVERAGE & FILLING INDUSTRIES L.L.C - S.P",
        "country": "United Arab Emirates",
        "industry": "Food & Beverage",
        "known_domain": "stardrinks.com",
    }
    hits = [{
        "url": "https://www.linkedin.com/in/mohy-eladawy/",
        "title": "Mohy Eladawy - General Manager - International Beverage & Filling Industries LLC | LinkedIn",
        "content": "Mohy Eladawy\nGeneral Manager at International Beverage & Filling Industries LLC (IBFI)\nSharjah, UAE",
    }, {
        "url": "https://www.linkedin.com/in/example-cfo/",
        "title": "Example CFO - CFO - IBFI | LinkedIn",
        "content": "Example CFO\nCFO at IBFI\nSharjah, UAE",
    }]
    def search(query, include_domains=None, max_results=None):
        return hits
    def classify(company, rows):
        return {str(i): {"hierarchy_level": "C-Suite" if "CFO" in r["job_title"] else "General Manager / Managing Director", "hierarchy_rank": 2 if "CFO" in r["job_title"] else 5, "keep": True} for i, r in enumerate(rows)}
    result = find_web_people(company, search=search, extract=lambda c, s: [], classify=classify, enrich=False)
    names = [p["person_name"] for p in result["people"]]
    assert names == ["Example CFO", "Mohy Eladawy"]
    assert result["people"][0]["linkedin_url"].endswith("/example-cfo/")



def test_wrong_current_employer_profile_is_rejected_even_when_target_company_is_mentioned():
    _env(monkeypatch := __import__("pytest").MonkeyPatch())
    try:
        company = {"company_name": "International Beverage & Filling Industries L.L.C - S.P", "country": "United Arab Emirates", "known_domain": "stardrinks.com"}
        source = {
            "url": "https://www.linkedin.com/in/wrong-person/",
            "title": "Wrong Person - CEO - Another Beverage Company | LinkedIn",
            "text": "Wrong Person\nCEO at Another Beverage Company\nPreviously worked with International Beverage & Filling Industries LLC\nSharjah, UAE",
        }
        row = {"person_name": "Wrong Person", "job_title": "CEO"}
        from app.webpeople import _linkedin_current_employer_score
        assert _linkedin_current_employer_score(company["company_name"], row["person_name"], row["job_title"], source) < 10
    finally:
        monkeypatch.undo()


def test_same_name_profiles_are_rejected_when_evidence_ties():
    from app.webpeople import _select_verified_linkedin_candidate
    company = {"company_name": "International Beverage & Filling Industries L.L.C - S.P", "country": "United Arab Emirates"}
    row = {"person_name": "Mohammed Ali", "job_title": "Director"}
    candidates = [
        {"url": "https://www.linkedin.com/in/mohammed-ali-1/", "title": "Mohammed Ali - Director - IBFI | LinkedIn", "text": "Mohammed Ali\nDirector at IBFI"},
        {"url": "https://www.linkedin.com/in/mohammed-ali-2/", "title": "Mohammed Ali - Director - IBFI | LinkedIn", "text": "Mohammed Ali\nDirector at IBFI"},
    ]
    assert _select_verified_linkedin_candidate(row, company, candidates) is None


def test_exact_current_company_profile_wins_over_same_name_other_company():
    from app.webpeople import _select_verified_linkedin_candidate
    company = {"company_name": "International Beverage & Filling Industries L.L.C - S.P", "country": "United Arab Emirates"}
    row = {"person_name": "Mohammed Ali", "job_title": "Director"}
    candidates = [
        {"url": "https://www.linkedin.com/in/mohammed-ali-other/", "title": "Mohammed Ali - Director - Another Beverage Company | LinkedIn", "text": "Mohammed Ali\nDirector at Another Beverage Company"},
        {"url": "https://www.linkedin.com/in/mohammed-ali-ibfi/", "title": "Mohammed Ali - Director - International Beverage & Filling Industries LLC | LinkedIn", "text": "Mohammed Ali\nDirector at International Beverage & Filling Industries LLC (IBFI)\nSharjah, UAE"},
    ]
    selected = _select_verified_linkedin_candidate(row, company, candidates)
    assert selected is not None
    assert selected["url"].endswith("/mohammed-ali-ibfi/")
