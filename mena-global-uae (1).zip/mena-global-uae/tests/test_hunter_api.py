from types import SimpleNamespace
import app.hunter_api as ha


def _settings(monkeypatch):
    monkeypatch.setattr(ha, "settings", SimpleNamespace(hunter_api_key="key", hunter_timeout=10))

class Resp:
    def __init__(self, status=200, body=None): self.status_code=status; self._body=body or {}; self.text=""
    def json(self): return self._body


def test_normalize_linkedin_handle():
    assert ha.normalize_linkedin_handle("https://www.linkedin.com/in/jane-doe/") == "jane-doe"
    assert ha.normalize_linkedin_handle("linkedin.com/in/jane-doe") == "jane-doe"
    assert ha.normalize_linkedin_handle("https://linkedin.com/company/acme") == ""


def test_hunter_finder_accepts_only_valid_publicly_sourced_email(monkeypatch):
    _settings(monkeypatch)
    body={"data":{"email":"jane.doe@acme.com","score":96,"company":"Acme Trading","domain":"acme.com","verification":{"status":"valid"},"sources":[{"uri":"https://www.acme.com/team/jane"}],"phone_number":"+971501112222"}}
    monkeypatch.setattr(ha.requests, "get", lambda *a, **k: Resp(200, body))
    r=ha.find_email_by_linkedin("https://www.linkedin.com/in/jane-doe")
    assert r["status"]=="found" and r["email"]=="jane.doe@acme.com" and r["phone"]=="+971501112222"


def test_hunter_rejects_generic_email(monkeypatch):
    _settings(monkeypatch)
    body={"data":{"email":"info@acme.com","verification":{"status":"valid"},"sources":[{"uri":"https://www.acme.com/contact"}]}}
    monkeypatch.setattr(ha.requests, "get", lambda *a, **k: Resp(200, body))
    assert ha.find_email_by_linkedin("https://www.linkedin.com/in/jane-doe")["status"]=="rejected_generic"


def test_hunter_rejects_unsourced_email(monkeypatch):
    _settings(monkeypatch)
    body={"data":{"email":"jane.doe@acme.com","verification":{"status":"valid"},"sources":[]}}
    monkeypatch.setattr(ha.requests, "get", lambda *a, **k: Resp(200, body))
    assert ha.find_email_by_linkedin("https://www.linkedin.com/in/jane-doe")["status"]=="rejected_no_public_source"


def test_hunter_rejects_nonvalid_verification(monkeypatch):
    _settings(monkeypatch)
    body={"data":{"email":"jane.doe@acme.com","verification":{"status":"accept_all"},"sources":[{"uri":"https://x.example/a"}]}}
    monkeypatch.setattr(ha.requests, "get", lambda *a, **k: Resp(200, body))
    assert ha.find_email_by_linkedin("https://www.linkedin.com/in/jane-doe")["status"]=="rejected_verification"


def test_hunter_http_error_is_safe(monkeypatch):
    _settings(monkeypatch)
    body={"errors":[{"id":"unauthorized","code":401,"details":"bad key"}]}
    monkeypatch.setattr(ha.requests, "get", lambda *a, **k: Resp(401, body))
    try:
        ha.hunter_account()
    except ha.HunterAPIError as exc:
        assert exc.status_code == 401
        assert "bad key" in str(exc)
    else:
        raise AssertionError("expected HunterAPIError")


def test_normalize_hunter_phone_rejects_partial_numbers():
    assert ha.normalize_hunter_phone("+96611525") == ""
    assert ha.normalize_hunter_phone("+966501234567") == "+966501234567"


def test_domain_search_person_matches_exact_linkedin_and_name(monkeypatch):
    _settings(monkeypatch)
    body={"data":{"emails":[{
        "value":"jane.doe@acme.com", "first_name":"Jane", "last_name":"Doe",
        "position":"CEO", "phone_number":"+971501112222",
        "linkedin":"jane-doe", "confidence":97,
        "verification":{"status":"valid"},
        "sources":[{"uri":"https://acme.com/team/jane"}]
    }]}}
    monkeypatch.setattr(ha.requests, "get", lambda *a, **k: Resp(200, body))
    r=ha.domain_search_person("acme.com", "Jane Doe", "https://linkedin.com/in/jane-doe", "CEO")
    assert r["status"] == "found"
    assert r["email"] == "jane.doe@acme.com"
    assert r["phone"] == "+971501112222"


def test_domain_search_person_rejects_same_company_wrong_person(monkeypatch):
    _settings(monkeypatch)
    body={"data":{"emails":[{
        "value":"john@acme.com", "first_name":"John", "last_name":"Smith",
        "position":"CEO", "phone_number":"+971501112222",
        "linkedin":"john-smith", "confidence":99, "verification":{"status":"valid"}
    }]}}
    monkeypatch.setattr(ha.requests, "get", lambda *a, **k: Resp(200, body))
    r=ha.domain_search_person("acme.com", "Jane Doe", "https://linkedin.com/in/jane-doe", "CEO")
    assert r["status"] == "not_found"
