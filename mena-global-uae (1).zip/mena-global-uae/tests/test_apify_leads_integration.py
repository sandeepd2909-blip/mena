from app.leads import _apify_location, _extract_emails, _extract_linkedin, _extract_phone, _extract_name


def test_apify_location_normalizes_uae():
    assert _apify_location("United Arab Emirates") == "united arab emirates"
    assert _apify_location("UAE") == "united arab emirates"


def test_current_actor_output_aliases_are_supported():
    item = {
        "full_name": "Example Person",
        "email": "person@example.com",
        "mobile_number": "+971500000000",
        "linkedin": "https://www.linkedin.com/in/example",
    }
    assert _extract_name(item) == "Example Person"
    assert _extract_emails(item) == ["person@example.com"]
    assert _extract_phone(item) == "+971500000000"
    assert _extract_linkedin(item).endswith("/example")


def test_middle_east_country_aliases_are_normalized():
    from app.leads import _apify_location, _apify_supported_location
    assert _apify_location("UAE") == "united arab emirates"
    assert _apify_location("KSA") == "saudi arabia"
    assert _apify_location("Türkiye") == "turkey"
    assert _apify_supported_location("Lebanon") == "lebanon"
    assert _apify_supported_location("Jordan") == "jordan"
    assert _apify_supported_location("Palestine") == ""


def test_build_lead_does_not_require_linkedin():
    from app.leads import _build_lead
    raw = {
        "full_name": "Example Person",
        "email": "person@example.com",
        "company_name": "Example Logistics",
    }
    lead = _build_lead(
        {**{
            "company_name": "Example Logistics",
            "country": "Saudi Arabia",
            "industry": "Logistics",
            "known_domain": "example.com",
        }},
        {"opportunity": "Operations software", "opportunity_id": "O001", "signal_id": "P001"},
        {"opportunity_id": "O001", "target_role": "Head of Operations", "target_confidence": 0.8},
        raw,
        None,
        '"Example Logistics" "Head of Operations"',
    )
    assert lead is not None
    assert lead["business_email"] == "person@example.com"
    assert lead["linkedin_url"] == ""


def test_generate_leads_accepts_result_without_linkedin(monkeypatch):
    from types import SimpleNamespace
    from app.leads import generate_leads
    fake_settings = SimpleNamespace(
        apify_api_token="real-token",
        apify_lead_actor="code_crafter/leads-finder",
        apify_enrich_actor="datablow/linkedin-profile-enrichment",
        apify_leads_per_keyword=2,
        max_lead_targets_per_company=2,
        max_leads_per_company=3,
        enable_apify_enrichment=False,
        apify_provider_preflight=False,
    )
    monkeypatch.setattr("app.leads.settings", fake_settings)
    monkeypatch.setattr("app.leads.generate_lead_target_batch", lambda company, opportunities: [{**{
        "company_name": company["company_name"],
        "opportunity_id": "O001",
        "target_role": "Head of Operations",
        "role_keywords": ["Head of Operations", "COO"],
        "target_confidence": 0.8,
    }}])
    monkeypatch.setattr("app.leads.run_actor_get_dataset_items", lambda actor_id, run_input: [{
        "full_name": "Example Person",
        "email": "person@example.com",
        "company_name": "Example Logistics",
    }])
    company = {"company_name": "Example Logistics", "country": "Qatar", "industry": "Logistics", "known_domain": "example.com"}
    opportunity = {"company_name": "Example Logistics", "opportunity_id": "O001", "opportunity": "Operations software"}
    validations = [{"opportunity_id": "O001", "validation_status": "supported_hypothesis"}]
    targets, leads, errors, diagnostics = generate_leads([company], [opportunity], validations, [])
    assert errors == []
    assert len(leads) == 1
    assert leads[0]["person_name"] == "Example Person"
    assert diagnostics[0]["records_received"] == 1
    assert diagnostics[0]["usable_leads"] == 1


def test_zero_records_are_reported_as_no_match(monkeypatch):
    from types import SimpleNamespace
    from app.leads import generate_leads
    fake_settings = SimpleNamespace(
        apify_api_token="real-token",
        apify_lead_actor="code_crafter/leads-finder",
        apify_enrich_actor="datablow/linkedin-profile-enrichment",
        max_lead_targets_per_company=2,
        max_leads_per_company=3,
        enable_apify_enrichment=False,
        apify_provider_preflight=False,
    )
    monkeypatch.setattr("app.leads.settings", fake_settings)
    monkeypatch.setattr("app.leads.generate_lead_target_batch", lambda company, opportunities: [{
        "company_name": company["company_name"],
        "opportunity_id": "O001",
        "target_role": "Head of Operations",
        "role_keywords": ["Head of Operations"],
        "target_confidence": 0.8,
    }])
    monkeypatch.setattr("app.leads.run_actor_get_dataset_items", lambda actor_id, run_input: [])
    company = {"company_name": "Example Logistics", "country": "Kuwait", "industry": "Logistics", "known_domain": "example.com"}
    opportunity = {"company_name": "Example Logistics", "opportunity_id": "O001", "opportunity": "Operations software"}
    validations = [{"opportunity_id": "O001", "validation_status": "supported_hypothesis"}]
    targets, leads, errors, diagnostics = generate_leads([company], [opportunity], validations, [])
    assert targets
    assert leads == []
    assert errors == []
    assert diagnostics[0]["status"] == "no_match"


def test_afanasenko_actor_input_uses_search_lead_mode(monkeypatch):
    from types import SimpleNamespace
    from app.leads import _build_apify_inputs_for_actor
    fake_settings = SimpleNamespace(
        max_leads_per_company=5,
        apify_lead_actor="code_crafter/leads-finder",
    )
    monkeypatch.setattr("app.leads.settings", fake_settings)
    payload, location = _build_apify_inputs_for_actor(
        "afanasenko/linkedin-profile-api-scraper",
        {"company_name": "DP World", "country": "United Arab Emirates", "known_domain": "dpworld.com"},
        ["Head of Terminal Operations"],
    )
    assert payload["operationMode"] == "searchLead"
    assert payload["searchLeadCompanyUrls"] == ["dpworld.com"]
    assert payload["searchLeadJobTitle"] == "Head of Terminal Operations"
    assert payload["countryFilter"] == "United Arab Emirates"
    assert location == "united arab emirates"


def test_provider_error_row_triggers_fallback_actor_and_is_reported(monkeypatch):
    from types import SimpleNamespace
    from app.leads import generate_leads
    fake_settings = SimpleNamespace(
        apify_api_token="real-token",
        apify_lead_actor="code_crafter/leads-finder",
        apify_lead_fallback_actor="afanasenko/linkedin-profile-api-scraper",
        apify_enrich_actor="datablow/linkedin-profile-enrichment",
        apify_leads_per_keyword=2,
        max_lead_targets_per_company=2,
        max_leads_per_company=2,
        enable_apify_enrichment=False,
        apify_provider_preflight=False,
    )
    monkeypatch.setattr("app.leads.settings", fake_settings)
    monkeypatch.setattr(
        "app.leads.generate_lead_target_batch",
        lambda company, opportunities: [{
            "company_name": company["company_name"],
            "opportunity_id": "O001",
            "target_role": "Head of Operations",
            "role_keywords": ["Head of Operations"],
            "target_confidence": 0.8,
        }],
    )

    calls = []

    def fake_actor(actor_id, run_input):
        calls.append((actor_id, run_input))
        if actor_id == fake_settings.apify_lead_actor:
            return [{"error": "An error occurred while processing your request. Please try again or contact support."}]
        if run_input.get("operationMode") == "companyLookup":
            return [{
                "entity_type": "company",
                "company_name": "Example Logistics",
                "linkedin_url": "https://www.linkedin.com/company/example-logistics/",
            }]
        return [{
            "fullName": "Example Person",
            "jobTitle": "Head of Operations",
            "company": "Example Logistics",
            "linkedinUrl": "https://www.linkedin.com/in/example-person",
            "email": "person@examplelogistics.com",
            "phone": "+971501234567",
        }]

    monkeypatch.setattr("app.leads.run_actor_get_dataset_items", fake_actor)
    company = {"company_name": "Example Logistics", "country": "United Arab Emirates", "industry": "Logistics", "known_domain": "examplelogistics.com"}
    opportunity = {"company_name": "Example Logistics", "opportunity_id": "O001", "opportunity": "Operations software"}
    validations = [{"opportunity_id": "O001", "validation_status": "supported_hypothesis"}]

    targets, leads, errors, diagnostics = generate_leads([company], [opportunity], validations, [])
    assert targets
    assert errors == []
    assert len(leads) == 1
    assert leads[0]["person_name"] == "Example Person"
    assert diagnostics[0]["fallback_actor"] == fake_settings.apify_lead_fallback_actor
    assert fake_settings.apify_lead_fallback_actor in diagnostics[0]["actors_attempted"]
    assert diagnostics[0]["status"] == "fallback_success"
    assert leads[0]["source_actor"] == fake_settings.apify_lead_fallback_actor
    assert "error occurred" in diagnostics[0]["provider_error"].lower()


def test_provider_error_value_is_extractable():
    from app.leads import _provider_error_from_items
    items = [{"error": "Provider temporarily failed"}]
    assert _provider_error_from_items(items) == "Provider temporarily failed"


def test_fallback_actor_company_resolution_uses_documented_search_lead_input(monkeypatch):
    from types import SimpleNamespace
    from app.leads import generate_leads

    fake_settings = SimpleNamespace(
        apify_api_token="real-token",
        apify_lead_actor="code_crafter/leads-finder",
        apify_lead_fallback_actor="afanasenko/linkedin-profile-api-scraper",
        apify_enrich_actor="datablow/linkedin-profile-enrichment",
        apify_leads_per_keyword=2,
        max_lead_targets_per_company=1,
        max_leads_per_company=2,
        enable_apify_enrichment=False,
        apify_provider_preflight=False,
    )
    monkeypatch.setattr("app.leads.settings", fake_settings)
    monkeypatch.setattr("app.leads.generate_lead_target_batch", lambda company, opportunities: [{
        "company_name": company["company_name"],
        "opportunity_id": "O001",
        "target_role": "Head of Operations",
        "role_keywords": ["Head of Operations"],
        "target_confidence": 0.8,
    }])

    calls = []

    def fake_actor(actor_id, run_input):
        calls.append((actor_id, run_input))
        if actor_id == fake_settings.apify_lead_actor:
            return [{"error": "free Apify plan cannot run this Actor via API"}]
        if run_input.get("operationMode") == "companyLookup":
            return [{
                "entity_type": "company",
                "company_name": "Example Logistics",
                "linkedin_url": "https://www.linkedin.com/company/example-logistics/",
            }]
        return [{
            "full_name": "Example Person",
            "job_title": "Head of Operations",
            "company": "Example Logistics",
            "linkedin_url": "https://www.linkedin.com/in/example-person/",
            "email": "person@example.com",
        }]

    monkeypatch.setattr("app.leads.run_actor_get_dataset_items", fake_actor)
    company = {"company_name": "Example Logistics", "country": "United Arab Emirates", "industry": "Logistics", "known_domain": "example.com"}
    opportunity = {"company_name": "Example Logistics", "opportunity_id": "O001", "opportunity": "Operations software"}
    validations = [{"opportunity_id": "O001", "validation_status": "supported_hypothesis"}]

    targets, leads, errors, diagnostics = generate_leads([company], [opportunity], validations, [])
    assert errors == []
    assert len(leads) == 1
    assert leads[0]["source_actor"] == fake_settings.apify_lead_fallback_actor
    assert any(
        call[0] == fake_settings.apify_lead_fallback_actor
        and call[1].get("operationMode") == "searchLead"
        and call[1]["searchLeadCompanyUrls"] == ["https://www.linkedin.com/company/example-logistics/"]
        for call in calls
    )
    assert diagnostics[0]["status"] == "fallback_success"
    assert len(diagnostics[0]["actor_results"]) == 2


def test_afanasenko_fallback_tries_role_variants_without_country_filter(monkeypatch):
    from types import SimpleNamespace
    from app.leads import _discover_with_actor

    fake_settings = SimpleNamespace(max_leads_per_company=2)
    monkeypatch.setattr("app.leads.settings", fake_settings)
    calls = []

    def fake_actor(actor_id, run_input):
        calls.append(run_input)
        if run_input.get("searchLeadJobTitle") == "CIO":
            return [{
                "entity_type": "profile",
                "full_name": "Example CIO",
                "job_title": "CIO",
                "company_name": "Example Health Group",
                "linkedin_url": "https://www.linkedin.com/in/example-cio",
            }]
        return []

    monkeypatch.setattr("app.leads.run_actor_get_dataset_items", fake_actor)
    company = {
        "company_name": "Example Health Group",
        "country": "Saudi Arabia",
        "known_domain": "examplehealth.com",
        "known_linkedin": "https://www.linkedin.com/company/example-health-group/",
    }
    targets = [{
        "company_name": "Example Health Group",
        "target_role": "Chief Information Officer / VP Digital Health",
        "role_keywords": ["Chief Information Officer", "CIO", "VP Digital Health"],
    }]
    items, meta = _discover_with_actor("afanasenko/linkedin-profile-api-scraper", company, targets)
    assert items
    assert any(call.get("searchLeadJobTitle") == "CIO" for call in calls)
    assert all("countryFilter" not in call for call in calls if call.get("operationMode") == "searchLead")
    assert meta["company_urls"]


def test_test_lead_provider_returns_provider_diagnostics(monkeypatch):
    from types import SimpleNamespace
    from app.leads import test_lead_provider

    fake_settings = SimpleNamespace(
        apify_api_token="real-token",
        apify_lead_actor="code_crafter/leads-finder",
        apify_lead_fallback_actor="afanasenko/linkedin-profile-api-scraper",
        apify_lead_actors=("afanasenko/linkedin-profile-api-scraper",),
        apify_provider_preflight=False,
        max_leads_per_company=2,
    )
    monkeypatch.setattr("app.leads.settings", fake_settings)
    monkeypatch.setattr("app.leads.run_actor_get_dataset_items", lambda actor_id, run_input: [{
        "full_name": "Example Person",
        "job_title": "CIO",
        "company_name": "Example Health Group",
        "linkedin_url": "https://www.linkedin.com/in/example-person",
        "email": "person@example.com",
    }] if run_input.get("operationMode") == "searchLead" else [])
    result = test_lead_provider(
        "Example Health Group",
        "Saudi Arabia",
        "CIO",
        "https://www.linkedin.com/company/example-health-group/",
    )
    assert result["status"] == "success"
    assert result["leads_found"] == 1
    assert result["contacts"][0]["name"] == "Example Person"


def test_afanasenko_recovery_uses_search_company_when_lead_search_is_empty(monkeypatch):
    from app import leads

    calls = []

    def fake_run(actor_id, payload):
        calls.append(payload)
        if payload.get("operationMode") == "searchCompany":
            return [{
                "entity_type": "company",
                "company_name": "Dr. Sulaiman AL Habib Medical Group",
                "linkedin_url": "https://www.linkedin.com/company/drsulaiman-alhabib-medical-group/",
            }]
        return []

    monkeypatch.setattr(leads, "run_actor_get_dataset_items", fake_run)
    company = {
        "company_name": "Dr. Sulaiman Al Habib Medical Group",
        "country": "Saudi Arabia",
        "known_domain": "hmg.com",
        "known_linkedin": "https://www.linkedin.com/company/drsulaiman-alhabib-medical-group",
    }
    targets = [{"target_role": "Chief Digital Officer", "role_keywords": ["Chief Digital Officer"]}]
    items, meta = leads._discover_with_actor("afanasenko/linkedin-profile-api-scraper", company, targets)
    assert items == []
    assert any(x.get("operationMode") == "searchCompany" for x in calls)
    assert any(x.get("operationMode") == "searchLead" and x.get("searchLeadJobTitle") == "" and x.get("searchLeadCompanyUrls") == ["https://www.linkedin.com/company/drsulaiman-alhabib-medical-group/"] for x in calls)
    assert any(x.rstrip("/") == "https://www.linkedin.com/company/drsulaiman-alhabib-medical-group" for x in meta["company_urls"])
