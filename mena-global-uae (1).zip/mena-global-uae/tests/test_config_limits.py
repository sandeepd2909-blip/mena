from app.config import Settings

def test_lead_limit_settings_exist(monkeypatch):
    monkeypatch.setenv("MAX_LEAD_TARGETS_PER_COMPANY", "3")
    monkeypatch.setenv("MAX_LEADS_PER_COMPANY", "10")
    s = Settings()
    assert s.max_lead_targets_per_company == 3
    assert s.max_leads_per_company == 10


def test_apify_timeout_setting_exists(monkeypatch):
    monkeypatch.setenv("APIFY_TIMEOUT_SECONDS", "300")
    from app.config import Settings
    s = Settings()
    assert s.apify_timeout_seconds == 300


def test_reversecontact_settings_exist(monkeypatch):
    monkeypatch.setenv("REVERSECONTACT_MAX_LOOKUPS_PER_RUN", "3")
    monkeypatch.setenv("REVERSECONTACT_PHONE_COST_CREDITS", "20")
    monkeypatch.setenv("REVERSECONTACT_POLL_TIMEOUT_SECONDS", "120")
    cfg = Settings()
    assert cfg.reversecontact_max_lookups_per_run == 3
    assert cfg.reversecontact_phone_cost_credits == 20
    assert cfg.reversecontact_poll_timeout_seconds == 120


def test_hierarchy_limit_settings_exist(monkeypatch):
    monkeypatch.setenv("MAX_HIERARCHY_PEOPLE_PER_COMPANY", "50")
    monkeypatch.setenv("HIERARCHY_RESULTS_PER_QUERY", "15")
    monkeypatch.setenv("MAX_HIERARCHY_QUERIES_PER_COMPANY", "15")
    from app.config import Settings
    cfg = Settings()
    assert cfg.max_hierarchy_people_per_company == 50
    assert cfg.hierarchy_results_per_query == 15
    assert cfg.max_hierarchy_queries_per_company == 15
