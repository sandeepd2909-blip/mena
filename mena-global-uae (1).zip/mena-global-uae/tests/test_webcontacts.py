from types import SimpleNamespace

from app import webcontacts
from app.webcontacts import (
    attach_company_contacts, extract_emails, extract_phones, find_company_contacts, save_company_contacts,
)


def test_extract_phones_international_local_and_false_positives():
    text = ("Call us: +971 4 123 4567. Mobile 050 123 4567. Fax: +971 4 999 0000. "
            "Order 20240512 ref 123456789012345678. Founded 2024-05-12. Price 1,200,000. "
            "هاتف ٠١١٢٣٤٥٦٧٨ ")
    phones = extract_phones(text)
    assert "+97141234567" in phones
    assert "0501234567" in phones            # local number accepted only because of 'Mobile'
    assert "+97149990000" not in phones      # fax excluded
    assert not any("2024" in p for p in phones)
    assert "0112345678" in phones            # Arabic-Indic digits normalised


def test_local_number_without_phone_context_is_rejected():
    assert extract_phones("Invoice number 0501234567 was issued") == []


def test_extract_emails_filters_junk():
    got = extract_emails("info@acme.com, logo@2x.png, x@sentry.io, Sales@Acme.com.")
    assert got == ["info@acme.com", "sales@acme.com"]


def _run(monkeypatch, pages, company=None, key="k"):
    monkeypatch.setattr(webcontacts, "settings", SimpleNamespace(tavily_api_key=key))
    def fake_search(query, include_domains=None, max_results=None):
        return pages(query, include_domains)
    company = company or {"company_name": "Acme Trading", "country": "UAE", "known_domain": "acme.ae"}
    return find_company_contacts(company, search=fake_search)


def test_official_and_directory_pages_merge_and_wrong_company_ignored(monkeypatch):
    def pages(query, domains):
        if domains:
            return [{"url": "https://www.acme.ae/contact", "title": "Contact Acme Trading",
                     "content": "Acme Trading. Tel: +971 4 123 4567 Email info@acme.ae"}]
        return [
            {"url": "https://yellow.example/acme-trading", "title": "Acme Trading LLC - Dubai",
             "content": "Acme Trading Phone 04 123 4567 mail: info@acme.ae, hello@gmail.com"},
            {"url": "https://yellow.example/other", "title": "Zeta Foods",
             "content": "Zeta Foods Phone: +971 4 555 0000 zeta@zeta.com"},
        ]
    r = _run(monkeypatch, pages)
    assert [p["value"] for p in r["phones"]] == ["+97141234567"]      # local form merged into +971 form
    assert r["phones"][0]["official"] and len(r["phones"][0]["sources"]) == 2
    assert r["emails"][0]["value"] == "info@acme.ae" and r["emails"][0]["on_company_domain"]
    assert all("zeta" not in e["value"] for e in r["emails"])         # other company's page ignored
    assert r["pages_checked"] == 3 and r["pages_used"] == 2


def test_nothing_found_returns_empty_not_guesses(monkeypatch):
    r = _run(monkeypatch, lambda q, d: [{"url": "https://x.com/a", "title": "Acme Trading", "content": "About us"}])
    assert r["phones"] == [] and r["emails"] == []


def test_search_error_is_reported_and_missing_key(monkeypatch):
    monkeypatch.setattr(webcontacts, "settings", SimpleNamespace(tavily_api_key="k"))
    def boom(*a, **k): raise RuntimeError("rate limited")
    r = find_company_contacts({"company_name": "Acme"}, search=boom)
    assert r["errors"] and r["phones"] == []
    r = _run(monkeypatch, lambda q, d: [], key="")
    assert r["errors"] == ["TAVILY_API_KEY is missing"]


def test_attach_and_save(tmp_path):
    contacts = [{"company": "Acme Trading", "country": "UAE", "pages_used": 1,
                 "phones": [{"value": "+97141234567", "sources": ["u"], "official": True, "mentions": 1}],
                 "emails": [{"value": "info@acme.ae", "sources": ["u"], "official": True, "mentions": 1}]}]
    people = [{"company": "Acme Trading", "phone": "", "business_email": ""}, {"company": "Other"}]
    attach_company_contacts(people, contacts)
    assert people[0]["company_phone"] == "+97141234567" and people[0]["phone"] == ""  # person fields untouched
    assert people[1]["company_phone"] == ""
    save_company_contacts(contacts, tmp_path)
    assert "+97141234567" in (tmp_path / "company_contacts.csv").read_text(encoding="utf-8-sig")


def test_hunter_enrichment_precedes_public_web(monkeypatch):
    monkeypatch.setattr(webcontacts, "settings", SimpleNamespace(tavily_api_key="key", serper_api_key="", max_person_contact_lookups_per_company=30, person_contact_workers=2))
    monkeypatch.setattr(webcontacts, "hunter_configured", lambda: True)
    monkeypatch.setattr(webcontacts, "find_email_by_linkedin", lambda url: {"status":"found","email":"sara@acme.ae","sources":["https://acme.ae/team/sara"],"company":"Acme Trading","domain":"acme.ae","phone":"+971501112222"})
    called={"web":False}
    def fake_search(*a, **k): called["web"]=True; return []
    r=webcontacts.find_person_contacts({"person_name":"Sara Al Mansoori","company":"Acme Trading","linkedin_url":"https://linkedin.com/in/sara"},{"company_name":"Acme Trading","known_domain":"acme.ae"},search=fake_search)
    assert r["email"]=="sara@acme.ae" and r["phone"]=="+971501112222"
    assert called["web"] is False


def test_shared_hunter_phone_is_rejected_across_people(monkeypatch):
    monkeypatch.setattr(webcontacts, "settings", SimpleNamespace(tavily_api_key="key", serper_api_key="", max_person_contact_lookups_per_company=30, person_contact_workers=2))
    monkeypatch.setattr(webcontacts, "hunter_configured", lambda: True)
    monkeypatch.setattr(webcontacts, "find_email_by_linkedin", lambda url: {"status":"found","email":("a@acme.ae" if url.endswith('/a') else "b@acme.ae"),"sources":["https://acme.ae/team"],"company":"Acme","domain":"acme.ae","phone":"+971501111111"})
    people=[
        {"person_name":"Sara Al Mansoori","company":"Acme","company_website":"acme.ae","linkedin_url":"https://linkedin.com/in/a","business_email":"","phone":""},
        {"person_name":"Omar Khan","company":"Acme","company_website":"acme.ae","linkedin_url":"https://linkedin.com/in/b","business_email":"","phone":""},
    ]
    stats=webcontacts.enrich_people_public_contacts(people,[{"company":"Acme","phones":[]}],max_per_company=2,workers=2)
    assert stats["emails_found"] == 2
    assert people[0]["phone"] == "" and people[1]["phone"] == ""


def test_hunter_people_enrichment_recovers_phone_when_email_finder_has_none(monkeypatch):
    monkeypatch.setattr(webcontacts, "settings", SimpleNamespace(tavily_api_key="key", serper_api_key="", max_person_contact_lookups_per_company=30, person_contact_workers=2))
    monkeypatch.setattr(webcontacts, "hunter_configured", lambda: True)
    monkeypatch.setattr(webcontacts, "find_email_by_linkedin", lambda url: {"status":"not_found"})
    monkeypatch.setattr(webcontacts, "enrich_person_by_linkedin", lambda url: {"status":"found","company":"Acme Trading","domain":"acme.ae","email":"","phone":"+971501112222"})
    monkeypatch.setattr(webcontacts, "domain_search_person", lambda *a, **k: {"status":"not_found"})
    r=webcontacts.find_person_contacts({"person_name":"Sara Al Mansoori","company":"Acme Trading","linkedin_url":"https://linkedin.com/in/sara"},{"company_name":"Acme Trading","known_domain":"acme.ae"},search=lambda *a,**k: [])
    assert r["email"] == "" and r["phone"] == "+971501112222"


def test_hunter_partial_phone_is_not_returned(monkeypatch):
    monkeypatch.setattr(webcontacts, "settings", SimpleNamespace(tavily_api_key="key", serper_api_key="", max_person_contact_lookups_per_company=30, person_contact_workers=2))
    monkeypatch.setattr(webcontacts, "hunter_configured", lambda: True)
    monkeypatch.setattr(webcontacts, "find_email_by_linkedin", lambda url: {"status":"found","email":"","company":"Acme Trading","domain":"acme.ae","phone":"+96611525"})
    monkeypatch.setattr(webcontacts, "enrich_person_by_linkedin", lambda url: {"status":"found","company":"Acme Trading","domain":"acme.ae","email":"","phone":"+96611525"})
    monkeypatch.setattr(webcontacts, "domain_search_person", lambda *a, **k: {"status":"not_found"})
    r=webcontacts.find_person_contacts({"person_name":"Sara Al Mansoori","company":"Acme Trading","linkedin_url":"https://linkedin.com/in/sara"},{"company_name":"Acme Trading","known_domain":"acme.ae"},search=lambda *a,**k: [])
    assert r["phone"] == ""


def test_hunter_identity_does_not_accept_unrelated_gmail_from_directory(monkeypatch):
    monkeypatch.setattr(webcontacts, "settings", SimpleNamespace(tavily_api_key="key", serper_api_key="", max_person_contact_lookups_per_company=30, person_contact_workers=2))
    monkeypatch.setattr(webcontacts, "hunter_configured", lambda: True)
    monkeypatch.setattr(webcontacts, "find_email_by_linkedin", lambda url: {"status":"not_found"})
    monkeypatch.setattr(webcontacts, "enrich_person_by_linkedin", lambda url: {"status":"not_found"})
    monkeypatch.setattr(webcontacts, "domain_search_person", lambda *a, **k: {"status":"not_found"})
    page={"url":"https://directory.example/person","title":"Dr. Sulaiman Al Habib","content":"Dr. Sulaiman Al Habib Chairman samazizalhabib@gmail.com +96611525"}
    r=webcontacts.find_person_contacts({"person_name":"sulaiman alhabib","company":"Acme Trading","linkedin_url":"https://linkedin.com/in/sulaiman"},{"company_name":"Acme Trading","known_domain":"acme.ae"},search=lambda *a,**k: [page])
    assert r["email"] == "" and r["phone"] == ""
