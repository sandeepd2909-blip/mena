from types import SimpleNamespace
from pathlib import Path
import xml.etree.ElementTree as ET

import pytest

from app import moiat_directory, server, uae_people, uae_state

SEG = moiat_directory.TARGET_SEGMENTS


def _xml(records):
    root = ET.Element("Directory")
    for r in records:
        node = ET.SubElement(root, "Establishment")
        ET.SubElement(node, "FactoryNameEn").text = r["name"]
        ET.SubElement(node, "FactoryNameAr").text = r.get("ar", "")
        ET.SubElement(node, "Emirate").text = r.get("emirate", "Dubai")
        ET.SubElement(node, "FactoryPhoneNumber").text = r.get("phone", "")
        ET.SubElement(node, "FactoryEmail").text = r.get("email", "")
        for act in r.get("activities", []):
            a = ET.SubElement(node, "Activity")
            ET.SubElement(a, "ISIC4Code").text = act[0]
            ET.SubElement(a, "ActivityNameEn").text = act[1]
        for hs, desc in r.get("products", []):
            p = ET.SubElement(node, "Product")
            ET.SubElement(p, "HSCode").text = hs
            ET.SubElement(p, "ProductDescriptionEn").text = desc
    return ET.tostring(root, encoding="utf-8")


def _state_tmp(monkeypatch, tmp_path):
    monkeypatch.setattr(uae_state, "BASE", tmp_path / "uae_state")
    monkeypatch.setattr(uae_state, "STATE_FILE", tmp_path / "uae_state" / "state.json")


def _company(i, segment=SEG[0]):
    return {
        "company_key": f"k{i}",
        "company_name": f"Company {i}",
        "company_name_ar": "",
        "emirate": "Dubai",
        "phone": "",
        "email": "",
        "activities": [],
        "products": [],
        "matched_segments": [segment],
        "source_url": moiat_directory.MOIAT_DIRECTORY_URL,
    }


def test_moiat_parser_maps_all_five_segments_deterministically():
    data = _xml([
        {"name": "Builder Materials LLC", "activities": [("2394", "Manufacture of cement")], "products": [("2523", "Cement") ]},
        {"name": "Gulf Food Factory", "activities": [("1071", "Food manufacturing")], "products": [("1905", "Bakery products") ]},
        {"name": "Raw Material Trading LLC", "activities": [("4649", "Wholesale trading")], "products": [("7201", "Iron and steel") ]},
        {"name": "Desert 3PL Warehousing", "activities": [("5210", "Warehousing and storage")], "products": []},
        {"name": "Industrial Spare Parts Trading", "activities": [("4659", "Wholesale machinery and equipment")], "products": [("8481", "Industrial valves and spare parts") ]},
    ])
    rows = moiat_directory.parse_moiat_xml(data)
    assert len(rows) == 5
    assert SEG[0] in rows[0].matched_segments
    assert SEG[1] in rows[1].matched_segments
    assert SEG[2] in rows[2].matched_segments
    assert SEG[3] in rows[3].matched_segments
    assert SEG[4] in rows[4].matched_segments


def test_moiat_parser_rejects_truncated_non_xml():
    with pytest.raises(moiat_directory.MoIATDirectoryError):
        moiat_directory.parse_moiat_xml(b"<Directory><Establishment>")


def test_discovery_returns_at_most_50_and_tracks_served(monkeypatch, tmp_path):
    _state_tmp(monkeypatch, tmp_path)
    rows = [_company(i) for i in range(73)]
    def fake_batch(**kwargs):
        served = kwargs.get("served_keys") or set()
        fresh = [moiat_directory.MoIATCompany(**r) for r in rows if r["company_key"] not in served]
        return fresh[:kwargs.get("limit", 50)], {"10": 6}, len(rows), bool(fresh[kwargs.get("limit", 50):])
    monkeypatch.setattr(moiat_directory, "discover_moiat_batch", fake_batch)
    job = {"id": "job1", "segment": SEG[0], "main_activity_code": "10", "stage": "queued", "companies": [], "remaining_queue": [], "total_matches": 0, "page": 0}
    server._discover_thread(job)
    assert len(job["companies"]) == 50
    assert job["batch_start"] == 1 and job["batch_end"] == 50
    assert job["total_matches"] == 73
    assert job["has_next"] is True
    served = uae_state.served_company_keys("activity:10|segment:Industrial & Building Material Manufacturers")
    assert len(served) == 50


def test_load_next_50_has_no_overlap(monkeypatch, tmp_path):
    _state_tmp(monkeypatch, tmp_path)
    rows = [_company(i) for i in range(105)]
    def fake_batch(**kwargs):
        served = kwargs.get("served_keys") or set()
        fresh = [moiat_directory.MoIATCompany(**r) for r in rows if r["company_key"] not in served]
        return fresh[:kwargs.get("limit", 50)], {}, len(rows), bool(fresh[kwargs.get("limit", 50):])
    monkeypatch.setattr(moiat_directory, "discover_moiat_batch", fake_batch)
    job = {"id": "job2", "segment": SEG[0], "main_activity_code": "10", "stage": "queued", "companies": [], "remaining_queue": [], "total_matches": 0, "page": 0, "discovery_cursors": {}}
    server._discover_thread(job)
    first = {c["company_key"] for c in job["companies"]}
    assert server._load_next(job) is True
    second = {c["company_key"] for c in job["companies"]}
    assert len(second) == 50
    assert first.isdisjoint(second)
    assert job["batch_start"] == 51 and job["batch_end"] == 100
    assert server._load_next(job) is True
    third = {c["company_key"] for c in job["companies"]}
    assert len(third) == 5
    assert first.isdisjoint(third) and second.isdisjoint(third)
    assert server._load_next(job) is False


def test_fewer_than_50_keeps_all_and_no_next(monkeypatch, tmp_path):
    _state_tmp(monkeypatch, tmp_path)
    rows = [_company(i) for i in range(37)]
    def fake_batch(**kwargs):
        served = kwargs.get("served_keys") or set()
        fresh = [moiat_directory.MoIATCompany(**r) for r in rows if r["company_key"] not in served]
        return fresh[:kwargs.get("limit", 50)], {}, len(rows), False
    monkeypatch.setattr(moiat_directory, "discover_moiat_batch", fake_batch)
    job = {"id": "job3", "segment": SEG[0], "main_activity_code": "10", "stage": "queued", "companies": [], "remaining_queue": [], "total_matches": 0, "page": 0}
    server._discover_thread(job)
    assert len(job["companies"]) == 37
    assert job["total_matches"] == 37
    assert job["has_next"] is False


def test_state_persists_across_reload(monkeypatch, tmp_path):
    _state_tmp(monkeypatch, tmp_path)
    uae_state.mark_company_served(SEG[0], "persisted-key")
    first = uae_state.served_company_keys(SEG[0])
    assert "persisted-key" in first
    # load_state reads from disk again, simulating process refresh/reopen.
    second = uae_state.served_company_keys(SEG[0])
    assert second == first


def test_selection_backend_accepts_only_visible_company_ids(tmp_path, monkeypatch):
    _state_tmp(monkeypatch, tmp_path)
    job = {
        "id": "sel1", "segment": SEG[0], "stage": "discovered",
        "companies": [
            {"id": "a", "company_key": "a", "name": "A", "selected": False, "people": []},
            {"id": "b", "company_key": "b", "name": "B", "selected": False, "people": []},
        ], "selected_company_ids": [], "selected_people_ids": []
    }
    server._save_job(job)
    # Exercise the same backend filtering contract used by /api/selection.
    valid = {c["id"] for c in job["companies"]}
    incoming = ["a", "b", "not-visible"]
    filtered = [x for x in incoming if x in valid]
    assert filtered == ["a", "b"]


def test_uae_people_has_no_fixed_target_title_whitelist():
    assert not hasattr(uae_people, "TARGET_TITLE_PATTERNS")
    assert not hasattr(uae_people, "match_target_title")
    assert not hasattr(uae_people, "classify_seniority")


def test_fullenrich_mobile_request_contains_no_email_fields(monkeypatch):
    import app.fullenrich_mobile as fm
    captured = {}
    class Resp:
        status_code = 200
        def json(self): return {"enrichment_id": "e1"}
    monkeypatch.setattr(fm, "settings", SimpleNamespace(
        fullenrich_api_key="secret", fullenrich_enabled=True,
        fullenrich_base_url="https://app.fullenrich.com/api/v2", fullenrich_timeout=5,
    ))
    def fake_post(*args, **kwargs):
        captured["json"] = kwargs["json"]
        return Resp()
    monkeypatch.setattr(fm.requests, "post", fake_post)
    eid = fm._request_mobile("https://www.linkedin.com/in/example/", "Example Person", "Example LLC", "example.ae")
    assert eid == "e1"
    fields = captured["json"]["data"][0]["enrich_fields"]
    assert fields == ["contact.phones"]
    assert all("email" not in str(k).casefold() for k in captured["json"]["data"][0].keys())


def test_mobile_parser_rejects_landline_and_accepts_uae_mobile():
    body = {
        "data": {
            "linkedin_url": "https://www.linkedin.com/in/example/",
            "name": "Example Person",
            "company_name": "Example LLC",
            "phones": [
                {"phone_number": "+97143334444", "phone_type": "landline"},
                {"phone_number": "+971501234567", "phone_type": "mobile"},
            ],
        }
    }
    import app.fullenrich_mobile as fm
    result = fm.parse_mobile_result(body, "https://www.linkedin.com/in/example/", "Example Person", "Example LLC", "example.ae")
    assert result["phone"] == "+971501234567"
    assert result["verification"] == "provider_mobile_type"
    assert any("landline_or_fixed_line" in x for x in result["rejected_phone_candidates"])


def test_mobile_parser_rejects_wrong_company_even_with_phone():
    body = {
        "data": {
            "linkedin_url": "https://www.linkedin.com/in/example/",
            "name": "Example Person",
            "company_name": "Wrong Company",
            "company_domain": "wrong.example",
            "phones": [{"phone_number": "+971501234567", "phone_type": "mobile"}],
        }
    }
    import app.fullenrich_mobile as fm
    result = fm.parse_mobile_result(body, "https://www.linkedin.com/in/example/", "Example Person", "Example LLC", "example.ae")
    assert result["phone"] == ""
    assert result["company_association"] == "mismatch"


def test_mobile_estimate_dedupes_already_enriched(monkeypatch, tmp_path):
    _state_tmp(monkeypatch, tmp_path)
    import app.server as srv
    monkeypatch.setattr(srv, "_load_job", lambda jid: None)
    p1 = {"person_id": "p1", "linkedin_url": "https://www.linkedin.com/in/p1/", "person_name": "P1", "job_title": "CEO", "selected": True}
    p2 = {"person_id": "p2", "linkedin_url": "https://www.linkedin.com/in/p2/", "person_name": "P2", "job_title": "CEO", "selected": True}
    job = {"id": "est", "segment": SEG[0], "selected_company_ids": ["c1"], "companies": [{"id": "c1", "name": "C1", "people": [p1,p2]}]}
    monkeypatch.setattr(srv, "_credit_info", lambda: {"remaining_credits": 50, "mobile_cost": 10, "source": "test"})
    monkeypatch.setattr(srv, "_mobile_candidates", lambda job, ids: ([(job["companies"][0], p2)], ["p1"]))
    monkeypatch.setattr("app.config.settings", SimpleNamespace(fullenrich_enabled=True, fullenrich_api_key="key", fullenrich_mobile_cost=10, fullenrich_max_people_per_run=50))
    estimate = srv._mobile_estimate(job, ["p1", "p2"])
    assert estimate["people_to_enrich"] == 1
    assert estimate["skipped"] == 1
    assert estimate["estimated_maximum_credits"] == 10


def test_duplicate_company_phone_is_excluded_during_sequential_processing(monkeypatch, tmp_path):
    _state_tmp(monkeypatch, tmp_path)
    # The actual duplicate-phone guard lives in _run_mobile_async. This unit test keeps the
    # behavior explicit by simulating the provider result and checking the company's known set.
    known = {"971501234567"}
    returned = "+971501234567"
    assert returned.replace("+", "") in known


def test_confirmation_never_starts_automatically(monkeypatch, tmp_path):
    _state_tmp(monkeypatch, tmp_path)
    import app.server as srv
    started = []
    monkeypatch.setattr(srv.threading, "Thread", lambda *a, **k: started.append((a,k)))
    job = {"id": "confirm", "segment": SEG[0], "selected_company_ids": ["c1"], "selected_people_ids": ["p1"], "companies": [{"id":"c1","name":"C1","people":[{"person_id":"p1","linkedin_url":"https://www.linkedin.com/in/p1/","selected":True}]}]}
    # /api/mobile/estimate is a pure calculation; no thread is started.
    monkeypatch.setattr(srv, "_mobile_candidates", lambda job, ids: ([(job["companies"][0], job["companies"][0]["people"][0])], []))
    monkeypatch.setattr(srv, "_credit_info", lambda: {"remaining_credits": 50, "mobile_cost": 10, "source": "test"})
    monkeypatch.setattr("app.config.settings", SimpleNamespace(fullenrich_enabled=True, fullenrich_api_key="key", fullenrich_mobile_cost=10, fullenrich_max_people_per_run=50))
    estimate = srv._mobile_estimate(job, ["p1"])
    assert estimate["estimated_maximum_credits"] == 10
    assert started == []


def test_moiat_factory_phone_is_treated_as_shared_number(monkeypatch):
    import app.fullenrich_mobile as fm
    body = {
        "data": {
            "linkedin_url": "https://www.linkedin.com/in/example/",
            "name": "Example Person",
            "company_name": "Example LLC",
            "phones": [{"phone_number": "+97143334444", "phone_type": "mobile"}],
        }
    }
    monkeypatch.setattr(fm, "_poll", lambda eid: body)
    monkeypatch.setattr(fm, "_request_mobile", lambda *a, **k: "e1")
    monkeypatch.setattr(fm, "configured", lambda: True)
    monkeypatch.setattr(fm, "settings", SimpleNamespace(fullenrich_api_key="x", fullenrich_enabled=True, fullenrich_base_url="https://example", fullenrich_timeout=5, fullenrich_poll_timeout=5, fullenrich_poll_interval=0))
    result = fm.enrich_mobile_by_linkedin(
        "https://www.linkedin.com/in/example/",
        target_name="Example Person", target_company="Example LLC", target_domain="example.ae",
        exclude_phones={"+97143334444"},
    )
    assert result["phone"] == ""
    assert result["status"] == "person_found_no_mobile"
    assert any("known_shared_number" in x for x in result["rejected_phone_candidates"])


def test_fullenrich_error_maps_to_failed_status(monkeypatch):
    import app.fullenrich_mobile as fm
    monkeypatch.setattr(fm, "configured", lambda: True)
    monkeypatch.setattr(fm, "_request_mobile", lambda *a, **k: (_ for _ in ()).throw(fm.FullEnrichAPIError("boom")))
    result = fm.enrich_mobile_by_linkedin("https://www.linkedin.com/in/example/")
    assert result["status"] == "error"
    assert result["phone"] == ""


def test_person_deduplication_uses_linkedin_as_strongest_identifier(monkeypatch, tmp_path):
    _state_tmp(monkeypatch, tmp_path)
    person_a = {"person_name":"A Person","job_title":"CEO","linkedin_url":"https://www.linkedin.com/in/a-person/"}
    person_b = {"person_name":"Different Display Name","job_title":"General Manager","linkedin_url":"https://www.linkedin.com/in/a-person/"}
    assert uae_state.stable_person_id(person_a, "Company A") == uae_state.stable_person_id(person_b, "Company A")
    uae_state.record_enrichment(uae_state.stable_person_id(person_a, "Company A"), {"phone":"+971501234567"})
    assert uae_state.enrichment_record(uae_state.stable_person_id(person_b, "Company A"))["phone"] == "+971501234567"


def test_moiat_xml_recovery_accepts_complete_enough_malformed_export(monkeypatch):
    import app.moiat_directory as md
    from types import SimpleNamespace
    monkeypatch.setattr(md, "settings", SimpleNamespace(moiat_min_records=3, moiat_page_count_ratio=0.9), raising=False)
    good = _xml([
        {"name": f"Builder Materials {i}", "activities": [("2394", "Manufacture of cement")], "products": [("2523", "Cement")]} for i in range(4)
    ])
    malformed = good.replace(b"</Establishment>", b"</BrokenTag>", 1)
    rows = md.parse_moiat_xml(malformed, allow_recovery=True)
    assert len(rows) >= 3


def test_moiat_download_rejects_partial_content_length(monkeypatch):
    import app.moiat_directory as md
    class Resp:
        headers = {"content-length": "100", "content-type": "application/xml"}
        def raise_for_status(self): pass
        def iter_content(self, chunk_size=1): yield b"<Directory>"; yield b"</Directory>"
    class Session:
        def get(self, *a, **k): return Resp()
    with pytest.raises(md.MoIATDirectoryError, match="incomplete"):
        md._validate_download(b"<Directory></Directory>", Resp.headers, expected_count=None)


def test_moiat_excel_parser_is_official_transport_fallback(monkeypatch):
    from io import BytesIO
    from openpyxl import Workbook
    import app.moiat_directory as md
    wb = Workbook()
    ws = wb.active
    ws.title = "Export"
    ws.append(["Factory Name (En)", "Factory Name (Ar)", "Factory Phone Number", "Factory Email", "Emirate", "ISIC4Code", "Activity (En)", "Product HS Code", "Product Description (En)"])
    ws.append(["Demo Cement Factory", "", "0551234567", "x@example.com", "Dubai", "2394001", "Clinkers and Hydraulic Cements Manufacturing", "25232910", "Normal portland cement"])
    buf = BytesIO(); wb.save(buf)
    rows = md.parse_moiat_excel(buf.getvalue())
    assert len(rows) == 1
    assert md.TARGET_SEGMENTS[0] in rows[0].matched_segments


def test_moiat_load_directory_uses_excel_when_xml_fails(monkeypatch, tmp_path):
    import app.moiat_directory as md
    monkeypatch.setattr(md, "download_moiat_xml", lambda force=False: (_ for _ in ()).throw(md.MoIATDirectoryError("xml failed")))
    monkeypatch.setattr(md, "download_moiat_excel", lambda force=False: b"PKfake")
    monkeypatch.setattr(md, "parse_moiat_excel", lambda data: [md.MoIATCompany(
        company_key="x", company_name="Fallback Factory", company_name_ar="", emirate="Dubai", phone="", email="",
        activities=({"isic4_code":"2394","activity_en":"Manufacture of cement","activity_ar":""},),
        products=({"hs_code":"2523","description_en":"Cement","description_ar":""},),
        matched_segments=(md.TARGET_SEGMENTS[0],),
    )])
    old = md.settings
    monkeypatch.setattr(md, "settings", SimpleNamespace(moiat_cache_dir=str(tmp_path / "moiat"), moiat_min_records=1, moiat_page_count_ratio=0.9), raising=False)
    rows = md.load_directory(force=True)
    assert rows[0].company_name == "Fallback Factory"


def test_official_html_fallback_parser_extracts_factories_and_activity():
    html = """<!doctype html><html><body>
    <div>Number of Entries 3</div>
    <table>
      <tr><th>Factory Name (En)</th><th>Factory Name (Ar)</th><th>Factory Phone Number</th><th>Factory Email</th><th>Emirate</th><th>Action</th></tr>
      <tr><td>FOOD ONE LLC</td><td>غذاء 1</td><td>00971500000001</td><td>one@example.ae</td><td>Dubai</td><td>View</td></tr>
      <tr><td colspan="6"><table>
        <tr><th>ISIC4Code</th><th>Activity (En)</th><th>Activity (Ar)</th></tr>
        <tr><td>1010102</td><td>Meat Products Manufacturing</td><td></td></tr>
        <tr><td>020230900000</td><td>Frozen Meat</td><td></td></tr>
      </table></td></tr>
      <tr><td>FOOD TWO LLC</td><td>غذاء 2</td><td>00971500000002</td><td>two@example.ae</td><td>Abu Dhabi</td><td>View</td></tr>
      <tr><td colspan="6"><table>
        <tr><th>ISIC4Code</th><th>Activity (En)</th><th>Activity (Ar)</th></tr>
        <tr><td>1071001</td><td>Bakery Products Manufacturing</td><td></td></tr>
      </table></td></tr>
      <tr><td>METAL ONE LLC</td><td>معدن 1</td><td>00971500000003</td><td>metal@example.ae</td><td>Sharjah</td><td>View</td></tr>
    </table></body></html>""".encode("utf-8")
    original_settings = moiat_directory.settings
    moiat_directory.settings = SimpleNamespace(moiat_min_records=1, moiat_page_count_ratio=0.90)
    try:
        rows = moiat_directory._parse_moiat_html(html, expected_count=3)
    finally:
        moiat_directory.settings = original_settings
    assert len(rows) == 3
    food = next(x for x in rows if x.company_name == "FOOD ONE LLC")
    assert any(a["isic4_code"] == "1010102" for a in food.activities)
    assert SEG[1] in food.matched_segments


def test_official_html_fallback_rejects_partial_page():
    html = """<html><body><div>Number of Entries 3756</div>
    <table><tr><th>Factory Name (En)</th><th>Factory Name (Ar)</th><th>Factory Phone Number</th><th>Factory Email</th><th>Emirate</th></tr>
    <tr><td>ONE FACTORY LLC</td><td></td><td>1</td><td>a@b.com</td><td>Dubai</td></tr></table></body></html>""".encode("utf-8")
    with pytest.raises(moiat_directory.MoIATDirectoryError, match="too few establishments"):
        moiat_directory._parse_moiat_html(html, expected_count=3756)


def test_load_directory_uses_official_html_when_exports_fail(monkeypatch, tmp_path):
    html = """<!doctype html><html><body>
    <div>Number of Entries 2</div>
    <table>
      <tr><th>Factory Name (En)</th><th>Factory Name (Ar)</th><th>Factory Phone Number</th><th>Factory Email</th><th>Emirate</th><th>Action</th></tr>
      <tr><td>HTML FOOD ONE LLC</td><td></td><td>1</td><td>one@example.ae</td><td>Dubai</td><td>View</td></tr>
      <tr><td>HTML FOOD TWO LLC</td><td></td><td>2</td><td>two@example.ae</td><td>Abu Dhabi</td><td>View</td></tr>
    </table></body></html>""".encode("utf-8")
    monkeypatch.setattr(moiat_directory, "settings", SimpleNamespace(moiat_min_records=1, moiat_page_count_ratio=0.9, moiat_cache_ttl_seconds=21600, moiat_download_attempts=1, moiat_timeout=1, moiat_directory_url=moiat_directory.MOIAT_DIRECTORY_URL))
    monkeypatch.setattr(moiat_directory, "_cache_paths", lambda: (tmp_path / "directory.xml", tmp_path / "directory_all_v2.json"))
    monkeypatch.setattr(moiat_directory, "download_moiat_xml", lambda force=False: (_ for _ in ()).throw(moiat_directory.MoIATDirectoryError("export XML blocked")))
    monkeypatch.setattr(moiat_directory, "download_moiat_excel", lambda force=False: (_ for _ in ()).throw(moiat_directory.MoIATDirectoryError("export Excel blocked")))
    monkeypatch.setattr(moiat_directory, "download_moiat_html", lambda force=False: html)
    rows = moiat_directory.load_directory(force=True)
    assert [x.company_name for x in rows] == ["HTML FOOD ONE LLC", "HTML FOOD TWO LLC"]
