from app.webpeople import _company_query_variants, find_web_people


def test_company_query_aliases_are_dynamic():
    variants = _company_query_variants({"company_name": "BinDawood Holding (BinDawood / Danube)"})
    assert "BinDawood Holding (BinDawood / Danube)" in variants
    assert "BinDawood" in variants
    assert "Danube" in variants


def test_web_people_does_not_hide_verified_people_when_ai_classification_is_empty():
    company = {
        "company_name": "Al Majdouie",
        "country": "Saudi Arabia",
        "industry": "Logistics",
        "known_domain": "almajdouie.com",
    }

    def search(*args, **kwargs):
        return [{
            "url": "https://www.almajdouie.com/leadership",
            "title": "Jane Doe - Chief Executive Officer - Almajdouie",
            "content": "Jane Doe is Chief Executive Officer at Almajdouie.",
            "raw_content": "",
        }]

    def extract(company, sources):
        return [{
            "person_name": "Jane Doe",
            "job_title": "Chief Executive Officer",
            "linkedin_url": "",
            "email": "",
            "phone": "",
            "source_ids": [0],
        }]

    result = find_web_people(
        company,
        search=search,
        extract=extract,
        classify=lambda company, rows: {},
        enrich=False,
    )
    assert len(result["people"]) == 1
    assert result["people"][0]["person_name"] == "Jane Doe"
    assert result["people"][0]["hierarchy_level"] == "Unclassified"
    assert result["people"][0]["hierarchy_classification_status"] == "unclassified"
