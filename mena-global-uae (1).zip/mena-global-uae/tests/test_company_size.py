from types import SimpleNamespace

from app import company_size


def test_parse_linkedin_company_size():
    parsed = company_size._parse_employee_size("International Beverage & Filling Industries LLC | Company size 201-500 employees")
    assert parsed and parsed[0] == "201-500" and parsed[2] == 4


def test_rank_companies_largest_first(monkeypatch):
    companies = [
        {"id": "small", "name": "Small Co"},
        {"id": "large", "name": "Large Co"},
        {"id": "unknown", "name": "Unknown Co"},
    ]
    monkeypatch.setattr(company_size, "settings", SimpleNamespace(company_size_lookup_workers=2, company_size_max_lookups_per_batch=50))
    def fake_lookup(company):
        return {"company_size": "201-500", "company_size_score": 350, "company_size_band_rank": 4, "company_followers": 1000} if company["id"] == "large" else ({"company_size": "11-50", "company_size_score": 30, "company_size_band_rank": 2, "company_followers": 100} if company["id"] == "small" else {})
    monkeypatch.setattr(company_size, "lookup_company_size", fake_lookup)
    ranked = company_size.rank_companies_by_public_size(companies)
    assert [x["id"] for x in ranked] == ["large", "small", "unknown"]
