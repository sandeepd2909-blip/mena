from pathlib import Path
from app.moiat_directory import (
    MOIAT_MAIN_ACTIVITIES,
    MAIN_ACTIVITY_CODES,
    MoIATCompany,
    companies_for_filters,
    normalize_main_activity_code,
)


def _company(key, code, name=None):
    return MoIATCompany(
        company_key=key,
        company_name=name or f"Company {key}",
        company_name_ar="",
        emirate="Dubai",
        phone="",
        email="",
        activities=({"isic4_code": code, "activity_en": "Test activity", "activity_ar": ""},),
        products=(),
        matched_segments=(),
    )


def test_main_activity_catalog_matches_requested_codes():
    assert len(MOIAT_MAIN_ACTIVITIES) == 31
    assert MAIN_ACTIVITY_CODES[0] == "01"
    assert "10" in MAIN_ACTIVITY_CODES
    assert "38" in MAIN_ACTIVITY_CODES
    assert "39" in MAIN_ACTIVITY_CODES


def test_main_activity_code_normalization():
    assert normalize_main_activity_code("10") == "10"
    assert normalize_main_activity_code("10.01") == "10"
    assert normalize_main_activity_code("ISIC 23 - Manufacture") == "23"
    assert normalize_main_activity_code(28.0) == "28"


def test_filter_can_use_main_activity_without_segment(monkeypatch):
    rows = [_company("a", "10.11"), _company("b", "23.99"), _company("c", "38")]
    monkeypatch.setattr("app.moiat_directory.load_directory", lambda force=False: rows)
    result = companies_for_filters(main_activity_code="23")
    assert [x.company_key for x in result] == ["b"]


def test_filter_can_intersect_segment_and_main_activity(monkeypatch):
    rows = [
        _company("a", "10.11"),
        MoIATCompany(
            company_key="b", company_name="Food Building Co", company_name_ar="", emirate="Dubai",
            phone="", email="", activities=({"isic4_code":"10.11","activity_en":"Manufacture of food products","activity_ar":""},),
            products=(), matched_segments=("Food & Beverage (F&B) Manufacturers & Distributors",),
        ),
    ]
    monkeypatch.setattr("app.moiat_directory.load_directory", lambda force=False: rows)
    result = companies_for_filters(segment="Food & Beverage (F&B) Manufacturers & Distributors", main_activity_code="10")
    assert [x.company_key for x in result] == ["b"]


def test_direct_activity_filter_is_not_dependent_on_segment_match(monkeypatch):
    rows = [_company("raw", "20.00")]
    monkeypatch.setattr("app.moiat_directory.load_directory", lambda force=False: rows)
    assert companies_for_filters(main_activity_code="20")[0].company_key == "raw"
