from pathlib import Path

from app import moiat_directory


def test_browser_export_returns_payload(monkeypatch, tmp_path):
    payload = b"<fake-export>"
    monkeypatch.setattr(moiat_directory, "_download_moiat_export_with_browser", lambda *a, **k: payload)
    got = moiat_directory._download_moiat_export_with_browser("https://example", ".xml", max_seconds=1)
    assert got == payload


def test_browser_binary_can_be_configured(monkeypatch, tmp_path):
    fake = tmp_path / "chrome.exe"
    fake.write_bytes(b"x")
    monkeypatch.setenv("MOIAT_BROWSER_BINARY", str(fake))
    kind, path = moiat_directory._browser_binary()
    assert kind == "chrome"
    assert Path(path) == fake


def test_browser_fetch_decodes_same_origin_payload(monkeypatch):
    import base64, json

    payload = b"<Industrials><Factory><FactoryName>Example Factory</FactoryName></Factory></Industrials>"
    encoded = base64.b64encode(payload).decode()

    class FakeDriver:
        def execute_async_script(self, script, url):
            return json.dumps({
                "ok": True,
                "status": 200,
                "content_type": "application/xml",
                "final_url": url,
                "body_b64": encoded,
            })

    result = moiat_directory._browser_fetch(FakeDriver(), "https://example/export", 10)
    assert result == (payload, "application/xml", 200)


def _install_fake_selenium(monkeypatch, driver_factory):
    import sys
    import types

    class Options:
        def __init__(self):
            self.binary_location = None
        def add_argument(self, *args):
            pass
        def add_experimental_option(self, *args):
            pass

    class ChromeOptions(Options):
        pass

    class EdgeOptions(Options):
        pass

    class TimeoutException(Exception):
        pass

    class WebDriverException(Exception):
        pass

    webdriver = types.ModuleType("selenium.webdriver")
    webdriver.ChromeOptions = ChromeOptions
    webdriver.EdgeOptions = EdgeOptions
    webdriver.Chrome = driver_factory
    webdriver.Edge = driver_factory

    exceptions = types.ModuleType("selenium.common.exceptions")
    exceptions.TimeoutException = TimeoutException
    exceptions.WebDriverException = WebDriverException

    common = types.ModuleType("selenium.common")
    common.exceptions = exceptions

    selenium = types.ModuleType("selenium")
    selenium.webdriver = webdriver
    selenium.common = common

    monkeypatch.setitem(sys.modules, "selenium", selenium)
    monkeypatch.setitem(sys.modules, "selenium.webdriver", webdriver)
    monkeypatch.setitem(sys.modules, "selenium.common", common)
    monkeypatch.setitem(sys.modules, "selenium.common.exceptions", exceptions)


def test_browser_export_uses_selenium_manager_without_local_binary(monkeypatch):
    class FakeDriver:
        def set_page_load_timeout(self, value):
            self.page_timeout = value

        def set_script_timeout(self, value):
            self.script_timeout = value

        def get(self, url):
            self.url = url

        def quit(self):
            self.quit_called = True

    fake_driver = FakeDriver()
    monkeypatch.setattr(moiat_directory, "_browser_binary", lambda: (None, None))
    _install_fake_selenium(monkeypatch, lambda options: fake_driver)
    monkeypatch.setattr(
        moiat_directory,
        "_browser_fetch",
        lambda driver, url, timeout: (b"<xml />", "application/xml", 200),
    )

    assert moiat_directory._download_moiat_export_with_browser(
        "https://example/export", ".xml", max_seconds=30
    ) == b"<xml />"


def test_browser_export_rejects_html_payload(monkeypatch):
    class FakeDriver:
        def set_page_load_timeout(self, value):
            pass

        def set_script_timeout(self, value):
            pass

        def get(self, url):
            pass

        def quit(self):
            pass

    monkeypatch.setattr(moiat_directory, "_browser_binary", lambda: (None, None))
    _install_fake_selenium(monkeypatch, lambda options: FakeDriver())
    monkeypatch.setattr(
        moiat_directory,
        "_browser_fetch",
        lambda driver, url, timeout: (b"<!doctype html><html></html>", "text/html", 200),
    )

    try:
        moiat_directory._download_moiat_export_with_browser(
            "https://example/export", ".xml", max_seconds=30
        )
    except moiat_directory.MoIATDirectoryError as exc:
        assert "returned HTML" in str(exc)
    else:
        raise AssertionError("Expected HTML response to be rejected")


def test_browser_xml_page_source_fallback(monkeypatch):
    class FakeDriver:
        page_source = "<?xml version='1.0'?><Industrials><Factory><FactoryName>Example</FactoryName></Factory></Industrials>"
        def set_page_load_timeout(self, value):
            pass
        def set_script_timeout(self, value):
            pass
        def get(self, url):
            pass
        def quit(self):
            pass

    monkeypatch.setattr(moiat_directory, "_browser_binary", lambda: (None, None))
    _install_fake_selenium(monkeypatch, lambda options: FakeDriver())
    monkeypatch.setattr(moiat_directory, "_browser_fetch", lambda *a, **k: None)

    got = moiat_directory._download_moiat_export_with_browser(
        "https://example/export", ".xml", max_seconds=30
    )
    assert got.startswith(b"<?xml")
