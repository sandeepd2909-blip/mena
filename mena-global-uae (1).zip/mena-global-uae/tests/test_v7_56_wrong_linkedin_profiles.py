"""V7.8.56 regression: wrong LinkedIn profile -> wrong FullEnrich number."""
from app.identity import (
    linkedin_profile_owner_matches, linkedin_slug_conflicts_with_name,
    person_names_match,
)
from app.webpeople import (
    _linkedin_current_employer_score as score,
    _select_verified_linkedin_candidate as select,
    find_person_linkedin,
)
from app.fullenrich_mobile import parse_mobile_result

CO = "Acme Trading LLC"
NAME = "Omar Khan"
ROLE = "Chief Financial Officer"
COMPANY = {"company_name": CO, "country": "United Arab Emirates"}


def S(url, title, text):
    return score(CO, NAME, ROLE, {"url": url, "title": title, "text": text})


def test_name_only_mentioned_in_someone_elses_profile_is_rejected():
    assert S("https://www.linkedin.com/in/sara-ali-77/", "Sara Ali - HR Manager - Acme Trading | LinkedIn",
             "Sara Ali HR Manager at Acme Trading. Recommendation: Omar Khan, Chief Financial Officer at Acme Trading.") == 0


def test_people_also_viewed_is_rejected():
    assert S("https://www.linkedin.com/in/john-smith-5/", "John Smith - Engineer - Siemens | LinkedIn",
             "John Smith Engineer at Siemens. People also viewed: Omar Khan Chief Financial Officer at Acme Trading") == 0


def test_former_employee_with_other_current_headline_is_rejected():
    assert S("https://www.linkedin.com/in/omar-khan-9/", "Omar Khan - CFO - Gulf Foods | LinkedIn",
             "Experience\nCFO at Gulf Foods 2020 - Present\nFinance Manager at Acme Trading LLC 2014 - 2019 Chief Financial Officer") == 0


def test_former_marker_only_mention_is_rejected():
    assert S("https://www.linkedin.com/in/omar-khan-9/", "Omar Khan | LinkedIn",
             "Omar Khan. Formerly Chief Financial Officer at Acme Trading LLC. Dubai") == 0


def test_substring_inside_another_word_is_not_employer_evidence():
    assert S("https://www.linkedin.com/in/omar-khan-9/", "Omar Khan - Director - Pacme Trading Group | LinkedIn",
             "Omar Khan Director at Pacme Trading Group") == 0


def test_exact_current_employer_is_accepted():
    assert S("https://www.linkedin.com/in/omar-khan-123/", "Omar Khan - Chief Financial Officer - Acme Trading | LinkedIn",
             "Omar Khan Chief Financial Officer at Acme Trading Dubai") >= 10


def test_dated_present_role_without_headline_company_is_accepted():
    assert S("https://www.linkedin.com/in/omar-khan-123/", "Omar Khan | LinkedIn",
             "Omar Khan. Experience: Chief Financial Officer at Acme Trading LLC Jan 2021 - Present") >= 10


def test_transliteration_and_al_prefix_match():
    assert person_names_match("Mohammed Al Majdouie", "Muhammad AlMajdouie, MBA")
    assert not person_names_match("Omar Khan", "Omar Hassan")
    assert linkedin_profile_owner_matches("https://www.linkedin.com/in/omarkhan/", "LinkedIn", NAME)


def test_slug_conflict_detection():
    assert linkedin_slug_conflicts_with_name("https://www.linkedin.com/in/sara-ali-77/", NAME)
    assert not linkedin_slug_conflicts_with_name("https://www.linkedin.com/in/omar-khan-123/", NAME)
    assert not linkedin_slug_conflicts_with_name("https://www.linkedin.com/in/ACoAAB1234/", NAME)


def test_same_name_two_current_matches_is_never_guessed():
    c = [{"url": f"https://www.linkedin.com/in/omar-khan-{i}/", "title": "Omar Khan - Chief Financial Officer - Acme Trading | LinkedIn",
          "text": "Omar Khan Chief Financial Officer at Acme Trading"} for i in (1, 2)]
    assert select({"person_name": NAME, "job_title": ROLE}, COMPANY, c) is None


def test_find_person_linkedin_returns_only_the_owners_profile():
    hits = [
        {"url": "https://www.linkedin.com/in/sara-ali-77/", "title": "Sara Ali - HR Manager - Acme Trading | LinkedIn",
         "content": "Recommendation from Omar Khan, Chief Financial Officer at Acme Trading"},
        {"url": "https://www.linkedin.com/in/omar-khan-123/", "title": "Omar Khan - Chief Financial Officer - Acme Trading | LinkedIn",
         "content": "Omar Khan Chief Financial Officer at Acme Trading. Dubai, United Arab Emirates"},
    ]
    got = find_person_linkedin({"person_name": NAME, "job_title": ROLE}, COMPANY, search=lambda *a, **k: hits)
    assert got and got["url"].endswith("/omar-khan-123/")
    only_wrong = find_person_linkedin({"person_name": NAME, "job_title": ROLE}, COMPANY, search=lambda *a, **k: hits[:1])
    assert only_wrong is None


# ---- FullEnrich result validation -------------------------------------------------------------
URL = "https://www.linkedin.com/in/omar-khan-123/"


def _body(profile, echo=True):
    body = {"id": "x", "name": "MENA UAE Prospecting Engine", "status": "FINISHED",
            "data": [{"contact_info": {"most_probable_phone": {"number": "+971501234567", "region": "AE"}},
                      "profile": profile}]}
    if echo:
        body["data"][0]["input"] = {"first_name": "Omar", "last_name": "Khan", "company_name": "Acme Trading",
                                    "domain": "acme.ae", "linkedin_url": URL}
    return body


def test_fullenrich_rejects_phone_when_profile_belongs_to_a_different_person_even_if_url_matches():
    r = parse_mobile_result(_body({"full_name": "Sara Ali", "linkedin_url": URL}), URL, NAME, "Acme Trading", "acme.ae")
    assert r["phone"] == "" and "name_mismatch" in r["identity_reasons"]


def test_fullenrich_does_not_treat_our_own_request_echo_as_proof():
    # Provider returned a different employer; the echoed input company/domain must not mask it.
    r = parse_mobile_result(_body({"full_name": "Omar Khan", "linkedin_url": URL, "company_name": "Other Co", "company_domain": "other.com"}),
                            URL, NAME, "Acme Trading", "acme.ae")
    assert r["phone"] == "" and r["company_association"] == "mismatch"


def test_fullenrich_batch_name_is_not_read_as_person_name():
    r = parse_mobile_result(_body({"full_name": "Omar Khan", "linkedin_url": URL, "company_name": "Acme Trading"}),
                            URL, NAME, "Acme Trading", "acme.ae")
    assert r["returned_name"] == "Omar Khan" and r["phone"] == "+971501234567"


def test_fullenrich_accepts_transliteration_difference():
    r = parse_mobile_result(_body({"full_name": "Muhammad Ali", "linkedin_url": URL, "company_name": "Acme Trading"}),
                            URL, "Mohammed Ali", "Acme Trading", "acme.ae")
    assert r["phone"] == "+971501234567"
