import threading
from types import SimpleNamespace

from app import server, uae_state


def _state_tmp(monkeypatch, tmp_path):
    monkeypatch.setattr(uae_state, "BASE", tmp_path / "uae_state")
    monkeypatch.setattr(uae_state, "STATE_FILE", tmp_path / "uae_state" / "state.json")


def test_concurrent_enrichment_records_are_never_lost(monkeypatch, tmp_path):
    """Regression: unlocked load->modify->save dropped records (25/150 kept), re-exposing paid lookups."""
    _state_tmp(monkeypatch, tmp_path)

    def worker(k):
        for i in range(20):
            uae_state.record_enrichment(f"p{k}_{i}", {"phone": "x"})
            uae_state.set_last_job(f"job{k}")
            uae_state.mark_company_served("scope", f"c{k}_{i}")

    threads = [threading.Thread(target=worker, args=(k,)) for k in range(6)]
    [t.start() for t in threads]
    [t.join() for t in threads]
    state = uae_state.load_state()
    assert len(state["enrichment_history"]) == 120
    assert len(state["served_company_keys"]["scope"]) == 120


def test_csv_filename_and_segment_column_for_main_activity_runs():
    job = {"segment": "", "main_activity_code": "10", "companies": [
        {"name": "ACME LLC", "emirate": "Dubai", "people": [{"person_name": "A B", "job_title": "GM"}]}
    ]}
    assert server._csv_filename(job) == "uae_people_activity_10.csv"
    text = server._csv(job).decode("utf-8-sig").splitlines()
    assert text[1].startswith("10 | ")  # segment column shows the Main Activity label, not blank

    seg = {"segment": "Food & Beverage (F&B) Manufacturers & Distributors", "companies": []}
    name = server._csv_filename(seg)
    assert name.endswith(".csv") and all(ch.isalnum() or ch in "_." for ch in name)


def test_meta_reports_real_fullenrich_configuration(monkeypatch):
    import app.config as config
    monkeypatch.setattr(config, "settings", SimpleNamespace(fullenrich_enabled=True, fullenrich_api_key=""))
    assert server._fullenrich_configured() is False
    monkeypatch.setattr(config, "settings", SimpleNamespace(fullenrich_enabled=True, fullenrich_api_key="k"))
    assert server._fullenrich_configured() is True
