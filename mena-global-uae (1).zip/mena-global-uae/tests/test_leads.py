from pathlib import Path
from types import SimpleNamespace

from app.leads import _build_lead, _company_match, generate_leads, save_lead_outputs


COMPANY = {
    "company_name": "Example Logistics",
    "country": "United Arab Emirates",
    "industry": "Logistics",
    "known_domain": "examplelogistics.com",
}

OPPORTUNITY = {
    "company_name": "Example Logistics",
    "country": "United Arab Emirates",
    "industry": "Logistics",
    "opportunity_id": "O001",
    "signal_id": "P001",
    "signal_status": "suggested",
    "opportunity": "Terminal operations orchestration software",
}

TARGET = {
    "company_name": "Example Logistics",
    "opportunity_id": "O001",
    "target_department": "Operations",
    "target_role": "Head of Operations",
    "role_keywords": ["Head of Operations", "COO"],
    "why_this_person": "This role owns operational workflows relevant to the opportunity.",
    "why_this_company": "The company has a supplied opportunity in terminal operations.",
    "target_confidence": 0.84,
}


def test_company_match_exact_and_missing_provider_company():
    assert _company_match("Example Logistics", "Example Logistics", "") == (True, "provider_company_exact")
    assert _company_match("Example Logistics", "", "examplelogistics.com") == (True, "provider_website_name_match")
    assert _company_match("Example Logistics", "Different Logistics", "different.com")[0] is False


def test_build_lead_normalizes_enrichment_fields():
    raw = {
        "userLink": "https://www.linkedin.com/in/example-person/",
        "description": "COO",
        "emails": ["person@examplelogistics.com"],
    }
    enrichment = {
        "full_name": "Example Person",
        "headline": "Chief Operating Officer",
        "company_name": "Example Logistics",
        "companyWebsite": "https://examplelogistics.com",
        "company_linkedin": "https://www.linkedin.com/company/example-logistics",
        "email_company_verified": True,
        "phone": "+971-1-234-5678",
    }
    lead = _build_lead(COMPANY, OPPORTUNITY, TARGET, raw, enrichment, '"Example Logistics" "Head of Operations"')
    assert lead is not None
    assert lead["person_name"] == "Example Person"
    assert lead["job_title"] == "Chief Operating Officer"
    assert lead["business_email"] == "person@examplelogistics.com"
    assert lead["email_status"] == "verified"
    assert lead["phone"] == "+971-1-234-5678"
    assert lead["linkedin_url"].endswith("example-person/")
    assert lead["matched_opportunity_id"] == "O001"


def test_build_lead_preserves_apify_phone_without_reversecontact():
    raw = {
        "userLink": "https://www.linkedin.com/in/example-person/",
        "fullName": "Example Person",
        "jobTitle": "Chief Operating Officer",
        "companyName": "Example Logistics",
        "phone": "+971501234567",
        "emails": ["person@examplelogistics.com"],
    }
    lead = _build_lead(COMPANY, OPPORTUNITY, TARGET, raw, None, '"Example Logistics" "Head of Operations"')
    assert lead is not None
    assert lead["phone"] == "+971501234567"
    assert lead["phone_source"] == "discovery"
    assert lead["business_email"] == "person@examplelogistics.com"
    assert lead["email_source"] == "discovery"
    assert lead["enrichment_provider"] == ""


def test_mismatched_provider_company_is_dropped():
    raw = {
        "userLink": "https://www.linkedin.com/in/other-person/",
        "emails": ["other@different.com"],
        "companyName": "Different Logistics",
    }
    assert _build_lead(COMPANY, OPPORTUNITY, TARGET, raw, None, '"Example Logistics" "COO"') is None


def test_generate_leads_uses_company_specific_queries_and_reversecontact_enrichment(monkeypatch):

    fake_settings = SimpleNamespace(
        apify_api_token="real-token",
        apify_lead_actor="code_crafter/leads-finder",
        apify_lead_fallback_actor="afanasenko/linkedin-profile-api-scraper",
        apify_lead_actors=(),
        apify_provider_preflight=False,
        apify_leads_per_keyword=2,
        max_lead_targets_per_company=2,
        max_leads_per_company=3,
        reversecontact_api_key="real-reversecontact-token",
        reversecontact_max_lookups_per_run=3,
        reversecontact_phone_cost_credits=20,
        reversecontact_skip_if_insufficient_credits=True,
    )
    monkeypatch.setattr("app.leads.settings", fake_settings)
    monkeypatch.setattr("app.leads.generate_lead_target_batch", lambda company, opportunities: [dict(TARGET)])
    calls = []

    def fake_actor(actor_id, run_input):
        calls.append((actor_id, run_input))
        return [{
            "keyword": '"Example Logistics" "Head of Operations"',
            "userLink": "https://www.linkedin.com/in/example-person/",
            "emails": [],
        }]

    monkeypatch.setattr("app.leads.run_actor_get_dataset_items", fake_actor)
    monkeypatch.setattr("app.leads.enrich_phones_by_linkedin", lambda people: {
        "https://linkedin.com/in/example-person": {
            "phone": "+9711234567",
            "phone_type": "mobile",
            "reversecontact_status": "found",
            "reversecontact_webhook_id": "wh-001",
            "reversecontact_credits_consumed": 20,
        }
    })
    validations = [{"opportunity_id": "O001", "validation_status": "supported_hypothesis"}]
    targets, leads, errors, diagnostics = generate_leads([COMPANY], [OPPORTUNITY], validations, [])

    assert len(targets) == 1
    assert len(leads) == 1
    assert errors == []
    assert diagnostics[0]["status"] == "success"
    assert calls[0][0] == fake_settings.apify_lead_actor
    assert calls[0][1]["contact_location"] == ["united arab emirates"]
    assert calls[0][1]["contact_job_title"] == ["Head of Operations", "COO"]
    assert leads[0]["phone"] == "+9711234567"
    assert leads[0]["phone_source"] == "reversecontact"
    assert leads[0]["email_status"] == "not_found"
    assert leads[0]["email_source"] == ""
    assert leads[0]["enrichment_provider"] == "reversecontact"
    assert leads[0]["reversecontact_phone_type"] == "mobile"


def test_missing_apify_token_still_returns_role_plan(monkeypatch):
    fake_settings = SimpleNamespace(
        apify_api_token="PASTE_YOUR_APIFY_TOKEN_HERE",
        max_lead_targets_per_company=2,
    )
    monkeypatch.setattr("app.leads.settings", fake_settings)
    monkeypatch.setattr("app.leads.generate_lead_target_batch", lambda company, opportunities: [dict(TARGET)])
    targets, leads, errors, diagnostics = generate_leads([COMPANY], [OPPORTUNITY], [], [])
    assert len(targets) == 1
    assert leads == []
    assert "APIFY_API_TOKEN is missing" in errors
    assert diagnostics == []


def test_csv_schema_for_phase_7_1(tmp_path: Path):
    lead = {
        "lead_id": "L001",
        "company": "Example Logistics",
        "country": "United Arab Emirates",
        "industry": "Logistics",
        "matched_opportunity": "Terminal operations orchestration software",
        "matched_opportunity_id": "O001",
        "matched_signal_id": "P001",
        "matched_pattern_id": "",
        "opportunity_validation_status": "supported_hypothesis",
        "target_department": "Operations",
        "target_role": "Head of Operations",
        "person_name": "Example Person",
        "job_title": "COO",
        "business_email": "person@examplelogistics.com",
        "email_status": "verified",
        "email_source": "discovery",
        "phone": "+9711234567",
        "phone_source": "reversecontact",
        "linkedin_url": "https://www.linkedin.com/in/example-person/",
        "company_website": "examplelogistics.com",
        "company_linkedin": "https://www.linkedin.com/company/example-logistics",
        "provider_company_name": "Example Logistics",
        "location": "Dubai",
        "why_this_person": "Relevant operations owner.",
        "why_this_company": "Relevant supplied opportunity.",
        "lead_match_basis": "provider_company_exact",
        "target_query": '"Example Logistics" "Head of Operations"',
        "lead_confidence": 0.84,
        "source_actor": "code_crafter/leads-finder",
        "enrichment_provider": "reversecontact",
        "reversecontact_phone_type": "mobile",
        "reversecontact_status": "found",
        "reversecontact_webhook_id": "wh-001",
        "reversecontact_error": "",
        "reversecontact_http_status": "",
        "reversecontact_credits_consumed": 20,
    }
    save_lead_outputs([COMPANY], [TARGET], [lead], [], tmp_path)
    header = (tmp_path / "lead_generation.csv").read_text(encoding="utf-8-sig").splitlines()[0]
    for field in ["company", "matched_opportunity", "person_name", "business_email", "email_status", "email_source", "phone", "phone_source", "linkedin_url", "enrichment_provider", "reversecontact_phone_type", "reversecontact_status", "reversecontact_webhook_id", "why_this_person", "lead_confidence"]:
        assert field in header
    assert (tmp_path / "lead_generation.json").exists()


def test_insufficient_validation_is_excluded_before_targeting(monkeypatch):
    fake_settings = SimpleNamespace(
        apify_api_token="PASTE_YOUR_APIFY_TOKEN_HERE",
        max_lead_targets_per_company=2,
    )
    monkeypatch.setattr("app.leads.settings", fake_settings)
    called = {"value": False}
    def fake_target(company, opportunities):
        called["value"] = True
        return []
    monkeypatch.setattr("app.leads.generate_lead_target_batch", fake_target)
    validations = [{"opportunity_id": "O001", "validation_status": "insufficient_support"}]
    targets, leads, errors, diagnostics = generate_leads([COMPANY], [OPPORTUNITY], validations, [])
    assert targets == []
    assert leads == []
    assert errors == []
    assert called["value"] is False
    assert diagnostics == []
