from types import SimpleNamespace

from app import prospeo_api


def _settings(**kwargs):
    base = dict(
        prospeo_api_key="key",
        prospeo_enabled=True,
        prospeo_base_url="https://api.prospeo.io",
        prospeo_timeout=5,
        prospeo_enrich_mobile=True,
    )
    base.update(kwargs)
    return SimpleNamespace(**base)


def _amin_response():
    return {
        "error": False,
        "free_enrichment": False,
        "person": {
            "full_name": "Amin AL-Nasser",
            "linkedin_url": "https://www.linkedin.com/in/amin-al-nasser-5b5a3824b/",
            "current_job_title": "Low Carbon Hydrogen Business",
            "email": {"status": "VERIFIED", "revealed": True, "email": "amin.nasser@aramco.com"},
            "mobile": {"status": "UNAVAILABLE", "revealed": False, "mobile": None},
        },
        "company": {"name": "aramco", "domain": "aramco.com"},
    }


def test_prospeo_verified_email_accepts_exact_linkedin_and_target_domain(monkeypatch):
    monkeypatch.setattr(prospeo_api, "settings", _settings(prospeo_enrich_mobile=False))
    monkeypatch.setattr(prospeo_api, "requests", SimpleNamespace(post=lambda *a, **k: SimpleNamespace(status_code=200, json=lambda: _amin_response())))
    r = prospeo_api.enrich_by_linkedin(
        "https://www.linkedin.com/in/amin-al-nasser-5b5a3824b/",
        target_name="Amin Al Nasser",
        target_company="Saudi Aramco",
        target_domain="aramco.com",
    )
    assert r["status"] == "found"
    assert r["email"] == "amin.nasser@aramco.com"
    assert r["phone"] == ""
    assert r["company_association"] == "matched"
    assert r["identity_reasons"] == []


def test_prospeo_rejects_mismatched_company_contacts(monkeypatch):
    monkeypatch.setattr(prospeo_api, "settings", _settings(prospeo_enrich_mobile=False))
    body = {
        "error": False,
        "person": {
            "full_name": "Loay Mashabi",
            "linkedin_url": "https://www.linkedin.com/in/loay-mashabi/",
            "email": {"status": "VERIFIED", "revealed": True, "email": "mashablo@gmail.com"},
            "mobile": {"status": "VERIFIED", "revealed": True, "mobile_international": "+966501234567"},
        },
        "company": {"name": "Saudi Post | SPL", "domain": "splonline.com.sa"},
    }
    monkeypatch.setattr(prospeo_api, "requests", SimpleNamespace(post=lambda *a, **k: SimpleNamespace(status_code=200, json=lambda: body)))
    r = prospeo_api.enrich_by_linkedin(
        "https://www.linkedin.com/in/loay-mashabi/",
        target_name="Loay Mashabi",
        target_company="Saudia Cargo",
        target_domain="saudiacargo.com",
    )
    assert r["status"] == "person_found_no_contact"
    assert r["person_found"] is True
    assert r["email"] == ""
    assert r["phone"] == ""
    assert "company_mismatch_email:mashablo@gmail.com" in r["rejected_email_candidates"]
    assert "company_mismatch_phone:+966501234567" in r["rejected_phone_candidates"]


def test_prospeo_wrong_linkedin_is_identity_reject(monkeypatch):
    monkeypatch.setattr(prospeo_api, "settings", _settings(prospeo_enrich_mobile=False))
    body = {
        "error": False,
        "person": {
            "full_name": "Amin Al Nasser",
            "linkedin_url": "https://www.linkedin.com/in/someone-else/",
            "email": {"status": "VERIFIED", "revealed": True, "email": "amin.nasser@aramco.com"},
        },
        "company": {"name": "aramco", "domain": "aramco.com"},
    }
    monkeypatch.setattr(prospeo_api, "requests", SimpleNamespace(post=lambda *a, **k: SimpleNamespace(status_code=200, json=lambda: body)))
    r = prospeo_api.enrich_by_linkedin(
        "https://www.linkedin.com/in/amin-al-nasser-5b5a3824b/",
        target_name="Amin Al Nasser",
        target_company="Saudi Aramco",
        target_domain="aramco.com",
    )
    assert r["status"] == "not_found"
    assert r["email"] == ""
    assert "returned_linkedin_mismatch" in r["identity_reasons"]


def test_prospeo_mobile_requires_target_company_association(monkeypatch):
    monkeypatch.setattr(prospeo_api, "settings", _settings(prospeo_enrich_mobile=False))
    body = {
        "error": False,
        "person": {
            "full_name": "Amin Al Nasser",
            "linkedin_url": "https://www.linkedin.com/in/amin-al-nasser-5b5a3824b/",
            "mobile": {"status": "VERIFIED", "revealed": True, "mobile_international": "+966500000000"},
        },
        "company": {"name": "Saudi Aramco", "domain": "aramco.com"},
    }
    monkeypatch.setattr(prospeo_api, "requests", SimpleNamespace(post=lambda *a, **k: SimpleNamespace(status_code=200, json=lambda: body)))
    r = prospeo_api.enrich_by_linkedin(
        "https://www.linkedin.com/in/amin-al-nasser-5b5a3824b/",
        target_name="Amin Al Nasser",
        target_company="Saudi Aramco",
        target_domain="aramco.com",
    )
    assert r["phone"] == "+966500000000"
    assert r["status"] == "found"


def test_webcontact_waterfall_prospeo_then_apify(monkeypatch):
    from app import webcontacts

    monkeypatch.setattr(webcontacts, "settings", SimpleNamespace(
        tavily_api_key="key", serper_api_key="", max_person_contact_lookups_per_company=5,
        person_contact_workers=1, prospeo_api_key="key", prospeo_enabled=True,
        apify_api_token="token", apify_contact_enabled=True,
        apify_contact_actors=("b2bsearch/bulk-people-enrichment",),
    ))
    monkeypatch.setattr(webcontacts, "prospeo_enrich_by_linkedin", lambda *a, **k: {"status":"not_found", "errors":[], "attempts":[]})
    monkeypatch.setattr(webcontacts, "apify_enrich_by_linkedin", lambda *a, **k: {
        "status":"found", "actor":"b2bsearch/bulk-people-enrichment", "email":"amin.nasser@aramco.com", "phone":"", "errors":[], "attempts":[]
    })
    monkeypatch.setattr(webcontacts, "hunter_configured", lambda: False)
    result = webcontacts.find_person_contacts(
        {"person_name":"Amin Al Nasser", "company":"Saudi Aramco", "linkedin_url":"https://www.linkedin.com/in/amin-al-nasser-5b5a3824b/"},
        {"company_name":"Saudi Aramco", "known_domain":"aramco.com"},
        search=lambda *a, **k: [],
    )
    assert result["email"] == "amin.nasser@aramco.com"
    assert [x["provider"] for x in result["provider_attempts"][:2]] == ["prospeo", "apify"]
    assert result["email_basis"] == "apify_linkedin_exact"


def test_webcontact_prospeo_success_skips_apify(monkeypatch):
    from app import webcontacts

    monkeypatch.setattr(webcontacts, "settings", SimpleNamespace(
        tavily_api_key="key", serper_api_key="", max_person_contact_lookups_per_company=5,
        person_contact_workers=1, prospeo_api_key="key", prospeo_enabled=True,
        apify_api_token="token", apify_contact_enabled=True,
        apify_contact_actors=("b2bsearch/bulk-people-enrichment",),
    ))
    monkeypatch.setattr(webcontacts, "prospeo_enrich_by_linkedin", lambda *a, **k: {
        "status":"found", "actor":"enrich-person", "email":"amin.nasser@aramco.com", "phone":"+966500000000", "errors":[], "attempts":[]
    })
    monkeypatch.setattr(webcontacts, "apify_enrich_by_linkedin", lambda *a, **k: (_ for _ in ()).throw(AssertionError("Apify must not run after complete Prospeo success")))
    result = webcontacts.find_person_contacts(
        {"person_name":"Amin Al Nasser", "company":"Saudi Aramco", "linkedin_url":"https://www.linkedin.com/in/amin-al-nasser-5b5a3824b/"},
        {"company_name":"Saudi Aramco", "known_domain":"aramco.com"},
        search=lambda *a, **k: [],
    )
    assert result["email"] == "amin.nasser@aramco.com"
    assert result["phone"] == "+966500000000"
    assert result["email_basis"] == "prospeo_linkedin_verified"



def _amin_normal_response():
    return {
        "error": False,
        "free_enrichment": True,
        "person": {
            "person_id": "aaaaf29a2219288702bf4efb",
            "first_name": "Amin",
            "last_name": "Al-Nasser",
            "full_name": "Amin Al-Nasser",
            "linkedin_url": "https://www.linkedin.com/in/amin-al-nasser-5b5a3824b",
            "current_job_title": "Director Hydrogen Business",
            "headline": "Low Carbon Hydrogen Business",
            "job_history": [{"title": "Director Hydrogen Business", "company_name": "aramco", "current": True}],
            "mobile": {"status": "UNAVAILABLE", "revealed": None, "mobile": None},
            "email": {"status": "UNAVAILABLE", "revealed": None, "email": None},
        },
        "company": {
            "name": "aramco",
            "website": "https://aramco.com",
            "domain": "aramcoasia.com",
            "other_websites": [],
        },
    }


def test_prospeo_normal_enrichment_finds_person_without_contact(monkeypatch):
    monkeypatch.setattr(prospeo_api, "settings", _settings(prospeo_enrich_mobile=False))
    calls = []
    def post(*args, **kwargs):
        calls.append(kwargs["json"])
        return SimpleNamespace(status_code=200, json=lambda: _amin_normal_response())
    monkeypatch.setattr(prospeo_api, "requests", SimpleNamespace(post=post))
    r = prospeo_api._parse_response(
        _amin_normal_response(),
        "https://www.linkedin.com/in/amin-al-nasser-5b5a3824b/",
        "Amin Al Nasser", "Saudi Aramco", "aramco.com"
    )
    assert r["status"] == "person_found_no_contact"
    assert r["person_found"] is True
    assert r["company_association"] == "matched"
    assert r["returned_domain"] == "https://aramco.com"


def test_prospeo_calls_normal_before_restricted_modes(monkeypatch):
    monkeypatch.setattr(prospeo_api, "settings", _settings(prospeo_enrich_mobile=False))
    payloads = []
    responses = [
        _amin_normal_response(),
        {"error": False, "error_code": "NO_MATCH"},
    ]
    def post(*args, **kwargs):
        payloads.append(kwargs["json"])
        return SimpleNamespace(status_code=200, json=lambda: responses[min(len(payloads)-1, len(responses)-1)])
    monkeypatch.setattr(prospeo_api, "requests", SimpleNamespace(post=post))
    r = prospeo_api.enrich_by_linkedin(
        "https://www.linkedin.com/in/amin-al-nasser-5b5a3824b/",
        target_name="Amin Al Nasser", target_company="Saudi Aramco", target_domain="aramco.com"
    )
    assert payloads[0]["data"]["linkedin_url"].endswith("amin-al-nasser-5b5a3824b/")
    assert "only_verified_email" not in payloads[0]
    assert len(payloads) == 2
    assert payloads[1].get("only_verified_email") is True
    assert r["person_found"] is True
    assert r["status"] == "person_found_no_contact"


def test_prospeo_normal_verified_contact_skips_extra_email_call(monkeypatch):
    monkeypatch.setattr(prospeo_api, "settings", _settings(prospeo_enrich_mobile=False))
    body = _amin_normal_response()
    body["person"]["email"] = {"status": "VERIFIED", "revealed": True, "email": "amin.nasser@aramco.com"}
    payloads = []
    monkeypatch.setattr(prospeo_api, "requests", SimpleNamespace(post=lambda *a, **k: (payloads.append(k["json"]) or SimpleNamespace(status_code=200, json=lambda: body))))
    r = prospeo_api.enrich_by_linkedin(
        "https://www.linkedin.com/in/amin-al-nasser-5b5a3824b/",
        target_name="Amin Al Nasser", target_company="Saudi Aramco", target_domain="aramco.com"
    )
    assert r["status"] == "found"
    assert r["email"] == "amin.nasser@aramco.com"
    assert len(payloads) == 1
    assert "only_verified_email" not in payloads[0]


def test_prospeo_normal_mobile_then_verified_mobile(monkeypatch):
    monkeypatch.setattr(prospeo_api, "settings", _settings(prospeo_enrich_mobile=True))
    normal = _amin_normal_response()
    mobile = _amin_normal_response()
    mobile["person"]["email"] = {"status": "VERIFIED", "revealed": True, "email": "amin.nasser@aramco.com"}
    mobile["person"]["mobile"] = {"status": "VERIFIED", "revealed": True, "mobile_international": "+966501234567"}
    payloads = []
    responses = [normal, {"error": False, "error_code": "NO_MATCH"}, mobile]
    def post(*args, **kwargs):
        payloads.append(kwargs["json"])
        idx=min(len(payloads)-1, len(responses)-1)
        return SimpleNamespace(status_code=200, json=lambda body=responses[idx]: body)
    monkeypatch.setattr(prospeo_api, "requests", SimpleNamespace(post=post))
    r = prospeo_api.enrich_by_linkedin(
        "https://www.linkedin.com/in/amin-al-nasser-5b5a3824b/",
        target_name="Amin Al Nasser", target_company="Saudi Aramco", target_domain="aramco.com"
    )
    assert len(payloads) == 3
    assert payloads[2].get("only_verified_mobile") is True
    assert r["status"] == "found"
    assert r["email"] == "amin.nasser@aramco.com"
    assert r["phone"] == "+966501234567"


def test_prospeo_no_match_does_not_erase_prior_person_identity(monkeypatch):
    monkeypatch.setattr(prospeo_api, "settings", _settings(prospeo_enrich_mobile=False))
    responses = [_amin_normal_response(), {"error": False, "error_code": "NO_MATCH"}]
    i = {"n": 0}
    def post(*a, **k):
        body=responses[min(i["n"], 1)]; i["n"] += 1
        return SimpleNamespace(status_code=200, json=lambda: body)
    monkeypatch.setattr(prospeo_api, "requests", SimpleNamespace(post=post))
    r = prospeo_api.enrich_by_linkedin(
        "https://www.linkedin.com/in/amin-al-nasser-5b5a3824b/",
        target_name="Amin Al Nasser", target_company="Saudi Aramco", target_domain="aramco.com"
    )
    assert r["returned_name"] == "Amin Al-Nasser"
    assert r["returned_company"] == "aramco"
    assert r["company_association"] == "matched"
