"""V7.9.9: UAE discovery must fail over fast when MoIAT blocks/drops the host (Vercel datacenter IP)."""
import os
import socket
import tempfile
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from unittest import mock

os.environ.setdefault("NO_PROXY", "127.0.0.1")
os.environ.setdefault("no_proxy", "127.0.0.1")

from app import moiat_directory as md
import app.search as search
from app.config import settings

SEG = md.TARGET_SEGMENTS[0]
FAKE_HITS = [{"url": "https://acme-steel.ae/", "title": "Acme Steel Industries | UAE manufacturer",
              "content": "Steel building materials manufacturer in Dubai, UAE"}]


def _blackhole():
    srv = socket.socket(); srv.bind(("127.0.0.1", 0)); srv.listen(50)
    conns = []
    def run():
        while True:
            try:
                conns.append(srv.accept()[0])  # accept and never answer
            except OSError:
                return
    threading.Thread(target=run, daemon=True).start()
    return srv, srv.getsockname()[1]


def _forbidden():
    class H(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(403); self.end_headers(); self.wfile.write(b"Access Denied")
        def log_message(self, *a): pass
    srv = HTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, srv.server_address[1]


class BlockedHost(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.started = []
        self.patches = [
            mock.patch.object(md, "_cache_paths", lambda: (self.tmp / "d.xml", self.tmp / "d.json")),
            mock.patch.object(md, "_REACH_STATE", {"checked_at": 0.0, "ok": None, "reason": ""}),
            mock.patch.object(md, "_start_directory_cache_refresh", lambda: self.started.append(1)),
        ]
        for p in self.patches: p.start()
        self._old = {k: getattr(settings, k, None) for k in ("moiat_probe_connect_timeout", "moiat_probe_read_timeout", "moiat_directory_url")}
        object.__setattr__(settings, "moiat_probe_connect_timeout", 2)
        object.__setattr__(settings, "moiat_probe_read_timeout", 3)

    def tearDown(self):
        for p in self.patches: p.stop()
        for k, v in self._old.items(): object.__setattr__(settings, k, v)

    def point(self, port):
        base = f"http://127.0.0.1:{port}/en/OpenData/IPLDirectory"
        object.__setattr__(settings, "moiat_directory_url", base)
        for name, val in (("MOIAT_DIRECTORY_URL", base), ("MOIAT_SEARCH_URL", base + "/Search")):
            p = mock.patch.object(md, name, val); p.start(); self.patches.append(p)

    def _fallback_case(self, server):
        _, port = server(); self.point(port)
        with mock.patch.object(search, "public_search", lambda q, **k: FAKE_HITS):
            t0 = time.monotonic()
            batch, cur, total, more = md.discover_moiat_batch(segment=SEG)
        self.assertLess(time.monotonic() - t0, 15)
        self.assertTrue(batch and "fallback" in batch[0]["source_name"].lower())
        self.assertEqual(self.started, [])  # heavy background Chromium refresh never started

    def test_black_holed_host_falls_back_in_seconds(self):
        self._fallback_case(_blackhole)

    def test_403_host_falls_back_in_seconds(self):
        self._fallback_case(_forbidden)

    def test_blocked_and_no_search_keys_gives_actionable_error_fast(self):
        _, port = _blackhole(); self.point(port)
        def boom(q, **k): raise RuntimeError("TAVILY_API_KEY is missing")
        with mock.patch.object(search, "public_search", boom):
            t0 = time.monotonic()
            with self.assertRaises(md.MoIATDirectoryError) as cm:
                md.discover_moiat_batch(segment=SEG)
        self.assertLess(time.monotonic() - t0, 15)
        self.assertIn("MOIAT_PROXY_URL", str(cm.exception)); self.assertIn("snapshot", str(cm.exception))

    def test_snapshot_served_without_any_network(self):
        _, port = _blackhole(); self.point(port)
        co = md.MoIATCompany(company_key="k", company_name="Snap Co", company_name_ar="", emirate="Dubai",
                             phone="", email="", activities=({"isic4_code": "23", "isic4_name": "x"},),
                             products=(), matched_segments=(SEG,), source_url=md.MOIAT_DIRECTORY_URL)
        md._write_directory_cache([co])
        t0 = time.monotonic()
        batch, *_ = md.discover_moiat_batch(main_activity_code="23")
        self.assertLess(time.monotonic() - t0, 3)
        self.assertEqual(batch[0].company_name, "Snap Co")

    def test_reachable_host_still_uses_live_path(self):
        class H(BaseHTTPRequestHandler):
            def do_GET(self):
                self.send_response(200); self.end_headers(); self.wfile.write(b"<html>ok</html>")
            def log_message(self, *a): pass
        srv = HTTPServer(("127.0.0.1", 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
        self.point(srv.server_address[1])
        ok, _ = md.moiat_reachable(force=True)
        self.assertTrue(ok)


if __name__ == "__main__":
    unittest.main()
