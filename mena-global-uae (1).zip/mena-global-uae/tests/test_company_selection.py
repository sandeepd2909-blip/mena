import threading
import time

from app import server


def test_discovery_only_does_not_call_people(monkeypatch):
    calls = []
    monkeypatch.setattr(
        "app.discovery.discover_companies",
        lambda country, industry, maximum: [
            {"company_name": "Alpha Logistics", "known_domain": "alpha.example"},
            {"company_name": "Beta Logistics", "known_domain": "beta.example"},
        ],
    )
    monkeypatch.setattr("app.webpeople.find_web_people", lambda rec: calls.append(rec) or {"people": []})

    job = {"id": "x", "industry": "Logistics", "country": "Saudi Arabia", "max": 2, "stage": "queued", "companies": [], "error": ""}
    server._discover_job(job)

    assert job["stage"] == "discovered"
    assert len(job["companies"]) == 2
    assert all(c["status"] == "queued" for c in job["companies"])
    assert calls == []


def test_selected_run_only_processes_selected_company(monkeypatch):
    processed = []
    monkeypatch.setattr(
        "app.hierarchy.build_company_record",
        lambda name, **kwargs: {"name": name},
    )
    def fake_people(rec):
        processed.append(rec["name"])
        return {"people": [], "sources_used": 1, "errors": [], "diagnostics": {}}
    monkeypatch.setattr("app.webpeople.find_web_people", fake_people)

    job = {
        "id": "x", "industry": "Logistics", "country": "Saudi Arabia", "max": 2,
        "stage": "discovered", "companies": [
            {"id": "a", "name": "Alpha", "domain": "a.example", "status": "queued", "selected": False, "people": [], "warnings": [], "diagnostics": {}},
            {"id": "b", "name": "Beta", "domain": "b.example", "status": "queued", "selected": False, "people": [], "warnings": [], "diagnostics": {}},
        ], "error": "",
    }
    server._run_selected(job, ["b"])

    assert processed == ["Beta"]
    assert job["companies"][0]["status"] == "queued"
    assert job["companies"][1]["status"] == "done"
    assert job["selected_ids"] == ["b"]


def test_invalid_selection_does_not_process_anything(monkeypatch):
    processed = []
    monkeypatch.setattr("app.webpeople.find_web_people", lambda rec: processed.append(rec))
    job = {"stage": "discovered", "companies": [{"id": "a"}]}
    server._run_selected(job, ["missing"])
    assert processed == []
    assert "selection_error" in job
