from types import SimpleNamespace

from app import webcontacts
from app.webcontacts import enrich_people_public_contacts, find_person_contacts


def _s(monkeypatch, key="k"):
    monkeypatch.setattr(webcontacts, "settings", SimpleNamespace(
        tavily_api_key=key, max_person_contact_lookups_per_company=30, person_contact_workers=2))


COMPANY = {"company_name": "Acme Trading", "known_domain": "acme.ae"}
PERSON = {"person_name": "Dr. Sara Al Mansoori", "company": "Acme Trading"}


def test_email_and_phone_next_to_name_are_attributed(monkeypatch):
    _s(monkeypatch)
    page = {"url": "https://www.acme.ae/team", "title": "Acme Trading team",
            "content": "Acme Trading leadership. Sara Al Mansoori, CEO. Email: sara.mansoori@acme.ae  Mobile +971 50 111 2222. "
                       + "x " * 400 + "Other person Omar K, CFO omar@acme.ae +971 50 999 8888"}
    r = find_person_contacts(PERSON, COMPANY, search=lambda q, include_domains=None, max_results=None: [page])
    assert r["email"] == "sara.mansoori@acme.ae" and r["email_basis"] == "name_in_address"
    assert r["phone"] == "+971501112222"          # not the CFO's number far from her name
    assert r["email_source"] == "https://www.acme.ae/team"


def test_switchboard_and_role_mailboxes_are_never_attributed(monkeypatch):
    _s(monkeypatch)
    page = {"url": "https://dir.example/acme", "title": "Acme Trading",
            "content": "Acme Trading: Sara Al Mansoori CEO. Reach us info@acme.ae or +971 4 123 4567"}
    exclude = frozenset({"41234567"})
    r = find_person_contacts(PERSON, COMPANY, search=lambda *a, **k: [page], exclude_phones=exclude)
    assert r["email"] == "" and r["phone"] == ""


def test_page_must_be_about_the_company_and_mention_the_person(monkeypatch):
    _s(monkeypatch)
    other_company = {"url": "https://x.com/1", "title": "Zeta", "content": "Sara Al Mansoori at Zeta: sara@zeta.com"}
    no_name = {"url": "https://x.com/2", "title": "Acme Trading", "content": "Acme Trading mail boss@acme.ae +971 50 123 4567"}
    r = find_person_contacts(PERSON, COMPANY, search=lambda *a, **k: [other_company, no_name])
    assert r["email"] == "" and r["phone"] == ""


def test_single_word_names_are_not_searched(monkeypatch):
    _s(monkeypatch)
    called = []
    r = find_person_contacts({"person_name": "Madonna"}, COMPANY, search=lambda *a, **k: called.append(1) or [])
    assert r["email"] == "" and not called


def test_enrich_fills_only_missing_values_and_marks_source(monkeypatch):
    _s(monkeypatch)
    page = {"url": "https://www.acme.ae/team", "title": "Acme Trading",
            "content": "Acme Trading: Sara Al Mansoori sara.m@acme.ae +971 50 111 2222; Omar Khan omar.khan@acme.ae"}
    monkeypatch.setattr(webcontacts, "public_search", lambda q, include_domains=None, max_results=None: [page])
    people = [
        {"person_name": "Sara Al Mansoori", "company": "Acme Trading", "company_website": "acme.ae", "business_email": "", "phone": ""},
        {"person_name": "Omar Khan", "company": "Acme Trading", "company_website": "acme.ae", "business_email": "apify@acme.ae", "phone": ""},
    ]
    stats = enrich_people_public_contacts(people, [{"company": "Acme Trading", "phones": []}])
    assert people[0]["business_email"] == "sara.m@acme.ae"
    assert people[0]["email_source"].startswith("web:https://www.acme.ae")
    assert people[1]["business_email"] == "apify@acme.ae"      # Apify value untouched
    assert stats["looked_up"] == 2


def test_enrich_respects_per_company_cap(monkeypatch):
    _s(monkeypatch)
    monkeypatch.setattr(webcontacts, "public_search", lambda *a, **k: [])
    people = [{"person_name": f"First{i} Last{i}", "company": "Acme", "business_email": "", "phone": ""} for i in range(10)]
    assert enrich_people_public_contacts(people, [], max_per_company=3)["looked_up"] == 3


def test_markdown_shows_email_phone_or_not_found():
    from app.hierarchy import format_hierarchy_markdown
    md = format_hierarchy_markdown([
        {"company": "Acme", "person_name": "Sara", "job_title": "CEO", "hierarchy_level": "CEO / President / Founder",
         "hierarchy_rank": 1, "linkedin_url": "https://www.linkedin.com/in/s/", "business_email": "s@acme.ae", "phone": ""}])
    assert "Email   : s@acme.ae" in md and "Phone   : not publicly found" in md


def test_company_name_variant_is_accepted_for_public_contact_search(monkeypatch):
    _s(monkeypatch)
    company = {"company_name": "Al Majdouie", "known_domain": "almajdouie.com"}
    person = {"person_name": "Omar Khan", "company": "Al Majdouie"}
    page = {"url": "https://www.almajdouie.com/team", "title": "Almajdouie",
            "content": "Almajdouie leadership: Omar Khan, CFO. Email omar.khan@almajdouie.com"}
    r = find_person_contacts(person, company, search=lambda q, include_domains=None, max_results=None: [page])
    assert r["email"] == "omar.khan@almajdouie.com"


def test_mobile_and_single_character_mailboxes_are_not_person_emails(monkeypatch):
    _s(monkeypatch)
    page = {"url": "https://dir.example/acme", "title": "Acme Trading",
            "content": "Acme Trading: Sara Al Mansoori CEO. mobile@acme.ae or o@acme.ae"}
    r = find_person_contacts(PERSON, COMPANY, search=lambda *a, **k: [page])
    assert r["email"] == ""
