from app.discovery import discover_companies


def test_discovery_module_is_callable():
    assert callable(discover_companies)
