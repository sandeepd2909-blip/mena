import threading
import time

from app import uae_people
from types import SimpleNamespace
from app.server import CompanyTimeout, _run_with_timeout


def test_linkedin_recovery_is_parallel_and_time_boxed(monkeypatch):
    rows = [{"person_name": f"Person {i}", "job_title": "Manager"} for i in range(24)]
    monkeypatch.setattr(uae_people, "find_web_people", lambda c, search=None, enrich=False: {"people": rows, "sources_used": 1})
    seen = set()

    def slow_lookup(row, company, search=None, pick=None):
        seen.add(threading.get_ident())
        time.sleep(0.3)
        return {"url": f"https://www.linkedin.com/in/{row['person_name'].replace(' ', '-').lower()}/", "probable": False}

    monkeypatch.setattr(uae_people, "find_person_linkedin", slow_lookup)
    monkeypatch.setattr(uae_people, "settings", SimpleNamespace(max_people_per_company=75, linkedin_recovery_workers=8, linkedin_recovery_budget_seconds=30))
    t0 = time.monotonic()
    out = uae_people.find_target_people({"company_name": "Acme"})
    elapsed = time.monotonic() - t0
    assert elapsed < 24 * 0.3 / 3          # sequential would take 7.2s
    assert len(seen) > 1
    assert all(p["linkedin_url"] for p in out["people"]) and len(out["people"]) == 24


def test_slow_lookups_never_block_the_company(monkeypatch):
    rows = [{"person_name": f"P{i}", "job_title": "CEO"} for i in range(5)]
    monkeypatch.setattr(uae_people, "find_web_people", lambda c, search=None, enrich=False: {"people": rows, "sources_used": 1})
    monkeypatch.setattr(uae_people, "find_person_linkedin", lambda *a, **k: time.sleep(0.25))
    monkeypatch.setattr(uae_people, "settings", SimpleNamespace(max_people_per_company=75, linkedin_recovery_workers=8, linkedin_recovery_budget_seconds=10))
    real = uae_people.as_completed
    monkeypatch.setattr(uae_people, "as_completed", lambda fs, timeout=None: real(fs, timeout=0.05))
    t0 = time.monotonic()
    out = uae_people.find_target_people({"company_name": "Acme"})
    assert time.monotonic() - t0 < 5
    assert len(out["people"]) == 5            # still shown, just without LinkedIn URLs


def test_company_timeout_helper():
    assert _run_with_timeout(lambda: 7, 2) == 7
    try:
        _run_with_timeout(lambda: time.sleep(5), 0.2)
        assert False
    except CompanyTimeout:
        pass
