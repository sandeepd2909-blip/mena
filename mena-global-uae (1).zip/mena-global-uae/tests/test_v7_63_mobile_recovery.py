from types import SimpleNamespace

import pytest

from app import server, uae_state


def _person():
    return {
        "person_id": "p1",
        "person_name": "Example Person",
        "job_title": "Operations Director",
        "linkedin_url": "https://www.linkedin.com/in/example-person/",
        "status": "Failed",
    }


def _job(person=None):
    p = person or _person()
    return {
        "id": "job1",
        "stage": "discovered",
        "selected_company_ids": ["c1"],
        "companies": [{"id": "c1", "name": "Example LLC", "domain": "", "people": [p]}],
    }


def test_failed_mobile_lookup_is_retryable(monkeypatch):
    from app.identity import linkedin_slug_conflicts_with_name
    monkeypatch.setattr(uae_state, "enrichment_record", lambda _pid: {
        "status": "Failed",
        "result": {"status": "error", "errors": ["temporary provider timeout"]},
    })
    candidates, skipped = server._mobile_candidates(_job(), ["p1"])
    assert len(candidates) == 1
    assert skipped == []


def test_completed_mobile_lookup_is_still_skipped(monkeypatch):
    monkeypatch.setattr(uae_state, "enrichment_record", lambda _pid: {
        "status": "Mobile not found",
        "result": {"status": "person_found_no_mobile"},
    })
    candidates, skipped = server._mobile_candidates(_job(), ["p1"])
    assert candidates == []
    assert skipped == ["p1"]


def test_fullenrich_poll_waits_for_terminal_status_even_if_partial_profile_exists(monkeypatch):
    import app.fullenrich_mobile as fm
    bodies = [
        {"status": "PROCESSING", "data": [{"profile": {"full_name": "Example Person"}}]},
        {"status": "FINISHED", "data": [{"contact_info": {"most_probable_phone": {"number": "+971501234567", "line_type": "MOBILE"}}}]},
    ]

    class Response:
        status_code = 200
        def __init__(self, body): self.body = body
        def json(self): return self.body

    monkeypatch.setattr(fm, "settings", SimpleNamespace(
        fullenrich_api_key="test-key", fullenrich_base_url="https://example.test/api/v2",
        fullenrich_timeout=5, fullenrich_poll_timeout=20, fullenrich_poll_interval=1,
    ))
    calls = []
    def fake_get(*args, **kwargs):
        calls.append(1)
        return Response(bodies.pop(0))
    monkeypatch.setattr(fm.requests, "get", fake_get)
    monkeypatch.setattr(fm.time, "sleep", lambda *_: None)
    result = fm._poll("test-enrichment-id")
    assert result["status"] == "FINISHED"
    assert len(calls) == 2


def test_fullenrich_poll_surfaces_provider_job_failure(monkeypatch):
    import app.fullenrich_mobile as fm

    class Response:
        status_code = 200
        def json(self): return {"status": "FAILED", "message": "provider waterfall failed"}

    monkeypatch.setattr(fm, "settings", SimpleNamespace(
        fullenrich_api_key="test-key", fullenrich_base_url="https://example.test/api/v2",
        fullenrich_timeout=5, fullenrich_poll_timeout=20, fullenrich_poll_interval=1,
    ))
    monkeypatch.setattr(fm.requests, "get", lambda *a, **k: Response())
    with pytest.raises(fm.FullEnrichAPIError, match="FAILED.*provider waterfall failed"):
        fm._poll("test-enrichment-id")


def test_fullenrich_payload_omits_empty_domain(monkeypatch):
    import app.fullenrich_mobile as fm
    captured = {}

    class Response:
        status_code = 200
        def json(self): return {"enrichment_id": "e1"}

    monkeypatch.setattr(fm, "settings", SimpleNamespace(
        fullenrich_api_key="test-key", fullenrich_enabled=True,
        fullenrich_base_url="https://example.test/api/v2", fullenrich_timeout=5,
    ))
    monkeypatch.setattr(fm.requests, "post", lambda *a, **kw: (captured.update(kw) or Response()))
    assert fm._request_mobile("https://www.linkedin.com/in/example-person/", "Example Person", "Example LLC", "") == "e1"
    contact = captured["json"]["data"][0]
    assert "domain" not in contact
    assert contact["enrich_fields"] == ["contact.phones"]


def test_mobile_parser_does_not_accept_phone_without_provider_identity():
    from app.fullenrich_mobile import parse_mobile_result
    body = {
        "status": "FINISHED",
        "data": [{"contact_info": {"most_probable_phone": {"number": "+971501234567", "line_type": "MOBILE"}}}],
    }
    result = parse_mobile_result(body, "https://www.linkedin.com/in/example-person/", "Example Person", "Example LLC", "")
    assert result["phone"] == ""
    assert result["status"] == "not_found"
    assert "identity_unconfirmed_by_provider" in result["identity_reasons"]


def test_provider_status_reports_invalid_api_key_without_exposing_it(monkeypatch):
    import app.fullenrich_mobile as fm

    class Response:
        status_code = 401
        def json(self): return {"message": "invalid key"}

    monkeypatch.setattr(fm, "settings", SimpleNamespace(
        fullenrich_enabled=True, fullenrich_api_key="very-secret-test-key",
        fullenrich_base_url="https://example.test/api/v2", fullenrich_timeout=5,
    ))
    monkeypatch.setattr(fm.requests, "get", lambda *a, **kw: Response())
    status = fm.provider_status()
    assert status["status"] == "invalid_api_key"
    assert "very-secret-test-key" not in str(status)


def test_unexpected_mobile_exception_does_not_leave_job_stuck(monkeypatch):
    import app.fullenrich_mobile as fm
    person = _person()
    company = {"id": "c1", "name": "Example LLC", "domain": "", "people": [person]}
    job = {"id": "mobilefail", "stage": "mobile_enriching", "companies": [company], "mobile_progress": {}}
    monkeypatch.setattr(server, "_mobile_candidates", lambda _j, _ids: ([(company, person)], []))
    monkeypatch.setattr(server, "_save_job", lambda _j: None)
    monkeypatch.setattr(fm, "enrich_mobile_by_linkedin", lambda *a, **kw: (_ for _ in ()).throw(RuntimeError("synthetic timeout")))
    saved = []
    monkeypatch.setattr(uae_state, "record_enrichment", lambda _pid, record: saved.append(record))
    server._run_mobile_async(job, ["p1"])
    assert job["stage"] == "discovered"
    assert person["status"] == "Failed"
    assert "synthetic timeout" in person["mobile_error"]
    assert saved and saved[0]["status"] == "Failed"
