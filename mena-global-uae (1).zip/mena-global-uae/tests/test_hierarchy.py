from types import SimpleNamespace

from app.hierarchy import generate_company_hierarchy


def test_generate_company_hierarchy_uses_dynamic_queries_and_requires_linkedin(monkeypatch):
    fake_settings = SimpleNamespace(
        apify_api_token="real-token",
        apify_lead_actor="code_crafter/leads-finder",
        apify_lead_fallback_actor="afanasenko/linkedin-profile-api-scraper",
        apify_lead_actors=("afanasenko/linkedin-profile-api-scraper",),
        apify_provider_preflight=False,
        max_hierarchy_people_per_company=10,
        hierarchy_results_per_query=5,
        max_hierarchy_queries_per_company=3,
        openai_api_key="real-openai",
        tavily_api_key="",
    )
    monkeypatch.setattr("app.hierarchy.settings", fake_settings)
    monkeypatch.setattr("app.hierarchy._resolve_afanasenko_company_urls", lambda actor_id, company: (
        ["https://sa.linkedin.com/company/example-logistics/"], [], []
    ))
    monkeypatch.setattr("app.hierarchy._dynamic_hierarchy_search_terms", lambda company, max_queries: ["Executive Leadership", "Product"])
    monkeypatch.setattr("app.hierarchy._classify_hierarchy_batch", lambda company, rows: {
        "0": {"hierarchy_level": "CEO / President / Founder", "hierarchy_rank": 1, "keep": True, "reason": "top executive"},
        "1": {"hierarchy_level": "Manager / Product Manager", "hierarchy_rank": 9, "keep": True, "reason": "product manager"},
    })

    rows = [
        {"full_name": "A CEO", "job_title": "President & CEO", "company": "Example Logistics", "linkedin_url": "https://www.linkedin.com/in/a"},
        {"full_name": "B PM", "job_title": "Group Product Manager", "company": "Example Logistics", "linkedin_url": "https://www.linkedin.com/in/b"},
        {"full_name": "No Link", "job_title": "Director", "company": "Example Logistics"},
    ]
    calls = []

    def fake_actor(actor_id, payload):
        calls.append(payload)
        return rows

    monkeypatch.setattr("app.hierarchy.run_actor_get_dataset_items", fake_actor)

    company = {"company_name": "Example Logistics", "country": "UAE", "industry": "Logistics", "known_domain": "example.com"}
    people, errors, diagnostics = generate_company_hierarchy([company], None)
    assert errors == []
    assert [p["person_name"] for p in people] == ["A CEO", "B PM"]
    assert all(p["linkedin_url"].startswith("https://www.linkedin.com/in/") for p in people)
    assert diagnostics[0]["dynamic_queries"] == ["Executive Leadership", "Product"]
    assert calls[0]["operationMode"] == "searchLead"
    assert calls[0]["searchLeadJobTitle"] == ""
    assert diagnostics[0]["missing_linkedin_url"] > 0


def test_companywide_search_does_not_embed_static_role_list(monkeypatch):
    fake_settings = SimpleNamespace(
        apify_api_token="real-token",
        apify_lead_actor="afanasenko/linkedin-profile-api-scraper",
        apify_lead_fallback_actor="",
        apify_lead_actors=("afanasenko/linkedin-profile-api-scraper",),
        apify_provider_preflight=False,
        max_hierarchy_people_per_company=2,
        hierarchy_results_per_query=2,
        max_hierarchy_queries_per_company=0,
        openai_api_key="real-openai",
        tavily_api_key="",
    )
    monkeypatch.setattr("app.hierarchy.settings", fake_settings)
    monkeypatch.setattr("app.hierarchy._resolve_afanasenko_company_urls", lambda actor_id, company: (
        ["https://www.linkedin.com/company/example/"], [], []
    ))
    monkeypatch.setattr("app.hierarchy._dynamic_hierarchy_search_terms", lambda company, max_queries: [])
    monkeypatch.setattr("app.hierarchy._classify_hierarchy_batch", lambda company, rows: {})

    payloads = []
    monkeypatch.setattr("app.hierarchy.run_actor_get_dataset_items", lambda actor_id, payload: payloads.append(payload) or [])
    generate_company_hierarchy([{"company_name": "Example", "country": "UAE", "industry": "Software"}], None)
    assert payloads
    assert payloads[0]["searchLeadJobTitle"] == ""


def test_company_url_resolver_normalizes_regional_linkedin_host(monkeypatch):
    from app.leads import _company_linkedin_candidates_from_items
    rows = [{"linkedin_url": "https://sa.linkedin.com/company/example-logistics", "entity_type": "organization", "company_name": "Example Logistics"}]
    assert _company_linkedin_candidates_from_items(rows, "Example Logistics") == [
        "https://www.linkedin.com/company/example-logistics/"
    ]


def test_code_crafter_hierarchy_uses_native_input_and_extracts_linkedin(monkeypatch):
    from types import SimpleNamespace
    from app.hierarchy import generate_company_hierarchy

    fake_settings = SimpleNamespace(
        apify_api_token="real-token",
        apify_lead_actor="code_crafter/leads-finder",
        apify_lead_fallback_actor="afanasenko/linkedin-profile-api-scraper",
        apify_lead_actors=("code_crafter/leads-finder",),
        apify_provider_preflight=False,
        max_hierarchy_people_per_company=10,
        hierarchy_results_per_query=5,
        max_hierarchy_queries_per_company=2,
        openai_api_key="real-openai",
        tavily_api_key="",
    )
    monkeypatch.setattr("app.hierarchy.settings", fake_settings)
    monkeypatch.setattr("app.hierarchy._dynamic_hierarchy_search_terms", lambda company, max_queries: ["CFO OR Finance Director", "Product Manager"])
    monkeypatch.setattr("app.hierarchy._classify_hierarchy_batch", lambda company, rows: {
        str(i): {"hierarchy_level": "C-Suite" if i == 0 else "Manager / Product Manager", "hierarchy_rank": 2 if i == 0 else 9, "keep": True, "reason": "test"}
        for i in range(len(rows))
    })

    calls = []
    def fake_actor(actor_id, payload):
        calls.append((actor_id, payload))
        if payload.get("contact_job_title"):
            return [{
                "full_name": "Example CFO",
                "job_title": "CFO",
                "linkedin": "https://www.linkedin.com/in/example-cfo",
                "company_name": "Example Health Group",
                "company_domain": "examplehealth.com",
            }, {
                "full_name": "Example Product",
                "job_title": "Product Manager",
                "linkedin": "https://www.linkedin.com/in/example-product",
                "company_name": "Example Health Group",
            }]
        return [{
            "full_name": "Example CFO",
            "job_title": "CFO",
            "linkedin": "https://www.linkedin.com/in/example-cfo",
            "company_name": "Example Health Group",
        }]

    monkeypatch.setattr("app.hierarchy.run_actor_get_dataset_items", fake_actor)
    company = {
        "company_name": "Example Health Group",
        "country": "Saudi Arabia",
        "industry": "Healthcare",
        "known_domain": "examplehealth.com",
    }
    people, errors, diagnostics = generate_company_hierarchy([company], None)
    assert errors == []
    assert {p["linkedin_url"] for p in people} == {
        "https://www.linkedin.com/in/example-cfo/",
        "https://www.linkedin.com/in/example-product/",
    }
    assert all(p["linkedin_url"].startswith("https://www.linkedin.com/in/") for p in people)
    assert any(call[1].get("company_domain") == ["examplehealth.com"] for call in calls)
    assert all("operationMode" not in call[1] for call in calls)
    assert diagnostics[0]["actor_results"][0]["contact_records"] > 0



def test_code_crafter_normalizes_contact_location_to_actor_enum():
    from app.hierarchy import _hierarchy_provider_inputs

    company = {
        "company_name": "Example Health Group",
        "country": "Saudi Arabia",
        "known_domain": "examplehealth.com",
    }
    inputs = _hierarchy_provider_inputs(
        "code_crafter/leads-finder", company, "CEO OR President", 10, []
    )
    assert inputs[0][0]["contact_location"] == ["saudi arabia"]


def test_code_crafter_omits_unsupported_contact_location():
    from app.hierarchy import _hierarchy_provider_inputs

    company = {
        "company_name": "Example Health Group",
        "country": "Atlantis",
        "known_domain": "examplehealth.com",
    }
    inputs = _hierarchy_provider_inputs(
        "code_crafter/leads-finder", company, "CEO", 10, []
    )
    assert "contact_location" not in inputs[0][0]

def test_extraction_supports_nested_provider_records_and_current_aliases():
    from app.leads import _extract_company_name, _extract_job_title, _extract_linkedin, _extract_name
    item = {
        "profile": {
            "fullName": "Nested Person",
            "currentTitle": "Product Manager",
            "linkedinProfileUrl": "https://www.linkedin.com/in/nested-person",
            "currentCompany": {"name": "Nested Health Group"},
        }
    }
    assert _extract_name(item) == "Nested Person"
    assert _extract_job_title(item) == "Product Manager"
    assert _extract_linkedin(item).endswith("/nested-person")
    assert _extract_company_name(item) == "Nested Health Group"
