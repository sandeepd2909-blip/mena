from types import SimpleNamespace
from unittest.mock import patch

from app import fullenrich_api, tomba_api, webcontacts


def test_fullenrich_exact_linkedin_overrides_provider_name_anomaly_and_accepts_maaden_email():
    body = {
        "data": {
            "linkedin_url": "https://www.linkedin.com/in/musaad-garawi-1088908a/",
            "name": "MENA Opportunity Intelligence Engine",
            "company_name": "Ma'aden (Saudi Arabian Mining Company)",
            "company_website": "https://maaden.com.sa",
            "job_title": "Vice President, Project Engineering & Innovation",
            "work_emails": ["garawim@maaden.com.sa"],
            "phones": ["+966500123456"],
        }
    }
    # _parse walks arbitrary wrappers, so this is the same shape returned by the live API.
    result = fullenrich_api._parse(
        body,
        "https://www.linkedin.com/in/musaad-garawi-1088908a/",
        "Musaad Garawi",
        "Ma'aden (Saudi Arabian Mining Company)",
        "maaden.com",
    )
    assert result["status"] == "found"
    assert result["person_found"] is True
    assert result["email"] == "garawim@maaden.com.sa"
    assert result["phone"] == "+966500123456"
    assert "provider_name_mismatch_ignored_due_to_exact_linkedin" in result["identity_reasons"]


def test_fullenrich_wrong_linkedin_still_rejects_contacts():
    body = {
        "data": {
            "linkedin_url": "https://www.linkedin.com/in/someone-else/",
            "name": "Musaad Garawi",
            "company_name": "Ma'aden",
            "company_domain": "maaden.com.sa",
            "work_emails": ["garawim@maaden.com.sa"],
            "phones": ["+966500123456"],
        }
    }
    result = fullenrich_api._parse(
        body,
        "https://www.linkedin.com/in/musaad-garawi-1088908a/",
        "Musaad Garawi",
        "Ma'aden",
        "maaden.com",
    )
    assert result["email"] == ""
    assert result["phone"] == ""
    assert result["person_found"] is False
    assert "returned_linkedin_mismatch" in result["identity_reasons"]


def test_fullenrich_wrong_company_rejects_email_and_phone():
    body = {
        "data": {
            "linkedin_url": "https://www.linkedin.com/in/musaad-garawi-1088908a/",
            "name": "Musaad Garawi",
            "company_name": "Past Employer LLC",
            "company_domain": "past-employer.example",
            "work_emails": ["musaad@past-employer.example"],
            "phones": ["+966500123456"],
        }
    }
    result = fullenrich_api._parse(
        body,
        "https://www.linkedin.com/in/musaad-garawi-1088908a/",
        "Musaad Garawi",
        "Ma'aden",
        "maaden.com",
    )
    assert result["company_association"] == "mismatch"
    assert result["email"] == ""
    assert result["phone"] == ""
    assert any(x.startswith("company_mismatch_email:") for x in result["rejected_email_candidates"])
    assert any(x.startswith("company_mismatch_phone:") for x in result["rejected_phone_candidates"])


def test_tomba_accepts_documented_array_data_and_verified_email():
    payload = {
        "data": [
            {
                "full_name": "Other Person",
                "company": "Wrong Company",
                "linkedin": "https://www.linkedin.com/in/other-person/",
                "email": "other@wrong.example",
            },
            {
                "full_name": "Musaad Garawi",
                "company": "Ma'aden",
                "linkedin": "https://www.linkedin.com/in/musaad-garawi-1088908a/",
                "domain": "maaden.com.sa",
                "email": "garawim@maaden.com.sa",
                "verification": {"status": "valid"},
                "phone_data": [{"phone_number": "+966500123456", "phone_type": "mobile", "valid": True}],
                "score": 96,
            },
        ]
    }
    with patch.object(tomba_api, "_get", return_value=payload):
        result = tomba_api.find_by_linkedin(
            "https://www.linkedin.com/in/musaad-garawi-1088908a/",
            target_name="Musaad Garawi",
            target_company="Ma'aden",
            target_domain="maaden.com",
        )
    assert result["status"] == "found"
    assert result["email"] == "garawim@maaden.com.sa"
    assert result["phone"] == "+966500123456"


def _provider_settings(**overrides):
    base = dict(
        tavily_api_key="key", serper_api_key="", max_person_contact_lookups_per_company=30,
        person_contact_workers=1,
        fullenrich_api_key="full", fullenrich_enabled=True,
        tomba_api_key="ta_test", tomba_secret_key="ts_test", tomba_enabled=True,
        prospeo_api_key="", prospeo_enabled=False,
        apify_api_token="", apify_contact_enabled=False,
    )
    base.update(overrides)
    return SimpleNamespace(**base)


def test_provider_waterfall_uses_tomba_after_fullenrich_and_stops_when_complete(monkeypatch):
    monkeypatch.setattr(webcontacts, "settings", _provider_settings())
    monkeypatch.setattr(webcontacts, "tomba_configured", lambda: True)
    monkeypatch.setattr(webcontacts, "fullenrich_enrich_by_linkedin", lambda *a, **k: {
        "status": "person_found_no_contact", "email": "", "phone": "", "errors": [], "attempts": [],
    })
    monkeypatch.setattr(webcontacts, "tomba_find_by_linkedin", lambda *a, **k: {
        "status": "found", "email": "musaad@maaden.com.sa", "phone": "+966500123456", "sources": ["tomba"],
        "score": 96, "company": "Ma'aden",
    })
    monkeypatch.setattr(webcontacts, "tomba_find_phone_by_linkedin", lambda *a, **k: (_ for _ in ()).throw(AssertionError("Phone Finder should not run when LinkedIn Finder already returned a phone")))
    monkeypatch.setattr(webcontacts, "prospeo_enrich_by_linkedin", lambda *a, **k: (_ for _ in ()).throw(AssertionError("Prospeo must not run after complete Tomba success")))
    monkeypatch.setattr(webcontacts, "apify_enrich_by_linkedin", lambda *a, **k: (_ for _ in ()).throw(AssertionError("Apify must not run after complete Tomba success")))
    monkeypatch.setattr(webcontacts, "hunter_configured", lambda: False)

    result = webcontacts.find_person_contacts(
        {"person_name": "Musaad Garawi", "company": "Ma'aden", "linkedin_url": "https://www.linkedin.com/in/musaad-garawi-1088908a/"},
        {"company_name": "Ma'aden", "known_domain": "maaden.com"},
        search=lambda *a, **k: [],
    )
    assert result["email"] == "musaad@maaden.com.sa"
    assert result["phone"] == "+966500123456"
    assert result["email_basis"] == "tomba_linkedin_exact"
    assert [x["provider"] for x in result["provider_attempts"][:2]] == ["fullenrich", "tomba"]


def test_tomba_partial_result_falls_through_to_apify(monkeypatch):
    monkeypatch.setattr(webcontacts, "settings", _provider_settings(apify_api_token="token", apify_contact_enabled=True, apify_contact_actors=("actor",)))
    monkeypatch.setattr(webcontacts, "tomba_configured", lambda: True)
    monkeypatch.setattr(webcontacts, "fullenrich_enrich_by_linkedin", lambda *a, **k: {
        "status": "person_found_no_contact", "email": "", "phone": "", "errors": [], "attempts": [],
    })
    monkeypatch.setattr(webcontacts, "tomba_find_by_linkedin", lambda *a, **k: {
        "status": "found", "email": "musaad@maaden.com.sa", "phone": "", "sources": ["tomba"],
        "score": 96, "company": "Ma'aden",
    })
    monkeypatch.setattr(webcontacts, "tomba_find_phone_by_linkedin", lambda *a, **k: {"status": "not_found", "phones": []})
    monkeypatch.setattr(webcontacts, "apify_enrich_by_linkedin", lambda *a, **k: {
        "status": "found", "actor": "actor", "email": "", "phone": "+966500123456", "errors": [], "attempts": [],
    })
    monkeypatch.setattr(webcontacts, "hunter_configured", lambda: False)

    result = webcontacts.find_person_contacts(
        {"person_name": "Musaad Garawi", "company": "Ma'aden", "linkedin_url": "https://www.linkedin.com/in/musaad-garawi-1088908a/"},
        {"company_name": "Ma'aden", "known_domain": "maaden.com"},
        search=lambda *a, **k: [],
    )
    assert result["email"] == "musaad@maaden.com.sa"
    assert result["phone"] == "+966500123456"
    assert [x["provider"] for x in result["provider_attempts"][:3]] == ["fullenrich", "tomba", "apify"]


def test_tomba_phone_matching_known_switchboard_is_rejected(monkeypatch):
    monkeypatch.setattr(webcontacts, "settings", _provider_settings(fullenrich_enabled=False))
    monkeypatch.setattr(webcontacts, "tomba_find_by_linkedin", lambda *a, **k: {
        "status": "found", "email": "", "phone": "+966138198111", "sources": ["tomba"], "score": 95, "company": "Ma'aden",
    })
    monkeypatch.setattr(webcontacts, "tomba_find_phone_by_linkedin", lambda *a, **k: {"status": "found", "phones": [{"phone": "+966138198111", "phone_type": "mobile", "valid": True}]})
    monkeypatch.setattr(webcontacts, "hunter_configured", lambda: False)

    result = webcontacts.find_person_contacts(
        {"person_name": "Musaad Garawi", "company": "Ma'aden", "linkedin_url": "https://www.linkedin.com/in/musaad-garawi-1088908a/"},
        {"company_name": "Ma'aden", "known_domain": "maaden.com"},
        search=lambda *a, **k: [],
        exclude_phones=frozenset({webcontacts._phone_key("+966138198111")}),
    )
    assert result["phone"] == ""
