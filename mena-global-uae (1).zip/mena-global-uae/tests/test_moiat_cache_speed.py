import json
import time
from types import SimpleNamespace

import app.moiat_directory as md


def _company(name, code, segment=()):
    return md.MoIATCompany(
        company_key=name.casefold(), company_name=name, company_name_ar="", emirate="Dubai",
        phone="", email="",
        activities=({"isic4_code": code, "activity_en": "Manufacture of food products", "activity_ar": ""},),
        products=(), matched_segments=tuple(segment),
    )

def test_cache_first_discovery_avoids_live_pages_and_paginates(monkeypatch, tmp_path):
    cache_dir = tmp_path / "moiat"
    monkeypatch.setattr(md, "settings", SimpleNamespace(
        moiat_cache_dir=str(cache_dir), moiat_cache_ttl_seconds=21600, moiat_search_timeout=10, moiat_search_attempts=2,
    ), raising=False)
    cache_dir.mkdir(parents=True)
    rows = [_company(f"Food {i}", "1030001", (md.TARGET_SEGMENTS[1],)) for i in range(3)]
    md._write_directory_cache(rows)
    monkeypatch.setattr(md, "search_moiat_directory_page", lambda **kw: (_ for _ in ()).throw(AssertionError("live MoIAT page should not be called")))
    monkeypatch.setattr(md, "_start_directory_cache_refresh", lambda: None)

    first, cursor, total, more = md.discover_moiat_batch(segment=md.TARGET_SEGMENTS[1], limit=2)
    assert [x.company_name for x in first] == ["Food 0", "Food 1"]
    assert total == 3 and more is True and cursor["__moiat_cache_offset__"] == 2
    second, cursor2, total2, more2 = md.discover_moiat_batch(
        segment=md.TARGET_SEGMENTS[1], cursors=cursor, limit=2,
    )
    assert [x.company_name for x in second] == ["Food 2"]
    assert total2 == 3 and more2 is False and cursor2["__moiat_cache_mode__"] == 1

def test_stale_cache_is_served_while_refresh_is_requested(monkeypatch, tmp_path):
    monkeypatch.setattr(md, "moiat_reachable", lambda force=False: (True, ""))  # V7.9.9: probe is network-only
    cache_dir = tmp_path / "moiat"
    monkeypatch.setattr(md, "settings", SimpleNamespace(
        moiat_cache_dir=str(cache_dir), moiat_cache_ttl_seconds=1, moiat_search_timeout=10, moiat_search_attempts=2,
    ), raising=False)
    cache_dir.mkdir(parents=True)
    md._write_directory_cache([_company("Cached Food", "1030001", (md.TARGET_SEGMENTS[1],))])
    _, path = md._cache_paths()
    old = time.time() - 10
    import os
    os.utime(path, (old, old))
    refreshed = []
    monkeypatch.setattr(md, "_start_directory_cache_refresh", lambda: refreshed.append(True))
    batch, _, total, _ = md.discover_moiat_batch(segment=md.TARGET_SEGMENTS[1], limit=50)
    assert [x.company_name for x in batch] == ["Cached Food"]
    assert total == 1
    assert refreshed == [True]

def test_live_search_publishes_partial_matches_after_each_page(monkeypatch, tmp_path):
    monkeypatch.setattr(md, "moiat_reachable", lambda force=False: (True, ""))  # V7.9.9: probe is network-only
    monkeypatch.setattr(md, "_cache_paths", lambda: (tmp_path / "directory.xml", tmp_path / "directory_all_v2.json"))
    monkeypatch.setattr(md, "_read_cached_directory", lambda: None)
    monkeypatch.setattr(md, "_start_directory_cache_refresh", lambda: None)
    pages = {
        1: md.MoIATSearchPage((_company("First", "1030001", (md.TARGET_SEGMENTS[1],)),), 1, 2, 2),
        2: md.MoIATSearchPage((_company("Second", "1030002", (md.TARGET_SEGMENTS[1],)),), 2, 2, 2),
    }
    monkeypatch.setattr(md, "search_moiat_directory_page", lambda **kw: pages[kw["page_index"]])
    updates = []
    batch, _, _, more = md.discover_moiat_batch(segment=md.TARGET_SEGMENTS[1], limit=2, progress=updates.append)
    assert [x.company_name for x in batch] == ["First", "Second"]
    assert len(updates) == 2
    assert [x["company_name"] for x in updates[0]["partial_companies"]] == ["First"]
    assert [x["company_name"] for x in updates[1]["partial_companies"]] == ["First", "Second"]
    assert more is False
