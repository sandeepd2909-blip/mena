from types import SimpleNamespace

from app.apify_api import run_actor_get_dataset_items


def test_apify_request_uses_bearer_header_and_actor_path(monkeypatch):
    settings = SimpleNamespace(
        apify_api_token="secret-token",
        apify_timeout_seconds=123,
    )
    monkeypatch.setattr("app.apify_api.settings", settings)
    seen = {}

    class Response:
        status_code = 200
        def json(self):
            return [{"full_name": "Example Person"}]

    def fake_post(url, headers, data, timeout):
        seen.update({"url": url, "headers": headers, "data": data, "timeout": timeout})
        return Response()

    monkeypatch.setattr("app.apify_api.requests.post", fake_post)
    result = run_actor_get_dataset_items("code_crafter/leads-finder", {"keywords": ["COO"]})
    assert result == [{"full_name": "Example Person"}]
    assert "Authorization" in seen["headers"]
    assert seen["headers"]["Authorization"] == "Bearer secret-token"
    assert "code_crafter~leads-finder" in seen["url"]
    assert seen["timeout"] == 123
