from app.identity import company_name_variants, company_match_score


def test_legal_suffix_and_dynamic_acronym_variants():
    name = "INTERNATIONAL BEVERAGE & FILLING INDUSTRIES L.L.C - S.P"
    variants = company_name_variants(name)
    assert "INTERNATIONAL BEVERAGE & FILLING INDUSTRIES" in variants
    assert "IBFI" in variants
    assert company_match_score(name, "International Beverage & Filling Industries LLC") >= 85
    assert company_match_score(name, "IBFI") >= 95


def test_sole_proprietorship_legal_form_generates_base_brand_alias():
    from app.identity import company_name_variants
    variants = company_name_variants("Al Ghurair Poultry - Sole Proprietorship L.L.C.")
    assert "Al Ghurair Poultry" in variants
