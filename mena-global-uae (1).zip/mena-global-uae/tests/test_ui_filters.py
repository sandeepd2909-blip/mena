"""Browser test for the results filters in web/index.html.

Skipped automatically when Playwright (and a Chromium build) is not installed:
    python -m pip install playwright && python -m playwright install chromium
"""
from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

import pytest

pw = pytest.importorskip("playwright.sync_api")

ROOT = Path(__file__).resolve().parents[1]


def _person(pid, name, title, sen, linkedin=True, status="Found", phone="", target=""):
    return {"person_id": pid, "person_name": name, "job_title": title, "seniority": sen, "target_title": target,
            "linkedin_url": f"https://www.linkedin.com/in/{name.lower().replace(' ', '-')}" if linkedin else "",
            "phone": phone, "status": status, "verification": "", "selected": False}


def _company(i, name, emirate, size, score, status="Found", people=None, source="MoIAT", acts=("10",), country="United Arab Emirates", verification=""):
    return {"id": f"c{i}", "company_key": f"k{i}", "name": name, "domain": "", "emirate": emirate, "region": "",
            "country": country, "directory_id": "", "registered_status": "", "source_name": source, "ticker": "",
            "matched_segments": [], "main_activity_codes": list(acts), "main_activities": [{"isic4_code": a + "10", "activity_en": "Food products"} for a in acts],
            "source_url": "", "registry_url": "", "verification_status": verification, "company_size": size, "company_size_score": score,
            "company_size_source": "", "company_followers": 0, "status": status, "selected": False, "people": people or [],
            "note": "", "sources_used": 0, "warnings": [], "resolution": {}}


JOB = {
    "id": "filtertest1", "stage": "discovered", "country": "United Arab Emirates", "segment": "Food", "main_activity_code": "",
    "search_query": "", "page": 1, "batch_start": 1, "batch_end": 6, "total_matches": 6, "has_next": False,
    "selected_company_ids": [], "selected_people_ids": [], "error": "", "notice": "",
    "companies": [
        _company(1, "Alpha Foods", "Dubai", "1,001-5,000", 900, "People found", [
            _person("p1", "Ahmed Khan", "Chief Executive Officer", "CEO / President / Founder"),
            _person("p2", "Sara Ali", "Head of Procurement", "Director", target="Head of Procurement"),
            _person("p3", "Omar Nasser", "Finance Director", "Director", linkedin=False)]),
        _company(2, "Beta Plastics", "Sharjah", "51-200", 125, "People found", [
            _person("p4", "Lina Haddad", "Operations Manager", "Manager", status="Mobile found", phone="+971500000000"),
            _person("p5", "Karim Saeed", "Logistics Manager", "Manager")]),
        _company(3, "Gamma Steel", "Dubai", "11-50", 30, "No people found"),
        _company(4, "Delta Trading", "Abu Dhabi", "", 0, "Found", source="Web search fallback", verification="Not verified"),
        _company(5, "Epsilon Dairy", "Ajman", "201-500", 350, "Failed", acts=("10", "46")),
        _company(6, "Zeta Packaging", "Sharjah", "501-1,000", 750, "Found"),
    ],
}


@pytest.fixture(scope="module")
def server(tmp_path_factory):
    work = tmp_path_factory.mktemp("filters")
    jobs = work / "data" / "uae_state" / "jobs"
    jobs.mkdir(parents=True)
    (jobs / f"{JOB['id']}.json").write_text(json.dumps(JOB), encoding="utf-8")
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    env = {**{k: v for k, v in os.environ.items() if k != "APP_PASSWORD"}, "PYTHONPATH": str(ROOT)}
    code = f"from app.server import serve; serve({port})"
    proc = subprocess.Popen([sys.executable, "-c", code], cwd=work, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    url = f"http://127.0.0.1:{port}"
    for _ in range(100):
        try:
            urllib.request.urlopen(url + "/api/meta", timeout=1); break
        except Exception:
            time.sleep(0.1)
    yield url
    proc.terminate(); proc.wait(5)


@pytest.fixture()
def page(server):
    with pw.sync_playwright() as p:
        try:
            browser = p.chromium.launch(args=["--no-sandbox"])
        except Exception as exc:  # browser binary not installed
            pytest.skip(f"Chromium not available: {exc}")
        pg = browser.new_page(viewport={"width": 1400, "height": 1000})
        errors = []
        pg.on("pageerror", lambda e: errors.append(str(e)))
        pg.add_init_script(f"localStorage.setItem('global_company_job_id','{JOB['id']}')")
        pg.goto(server)
        pg.wait_for_selector(".co")
        yield pg
        assert errors == [], errors
        browser.close()


def names(pg):
    return [t.strip() for t in pg.locator(".co .cn").all_inner_texts()]


def test_options_built_from_data(page):
    assert page.locator("#fRegion option").all_inner_texts()[1:] == ["Dubai (2)", "Sharjah (2)", "Abu Dhabi (1)", "Ajman (1)"]
    assert "Unknown (1)" in page.locator("#fSize option").all_inner_texts()
    assert page.locator("#fRegionLabel").text_content() == "Emirate"
    assert "Showing 6 of 6" in page.locator("#fcount").inner_text()


def test_company_filters(page):
    page.select_option("#fRegion", "Dubai"); assert names(page) == ["Alpha Foods", "Gamma Steel"]
    page.select_option("#fSize", "1–50"); assert names(page) == ["Gamma Steel"]
    page.click("#fClear"); assert len(names(page)) == 6
    page.select_option("#fSize", "1,001+"); assert names(page) == ["Alpha Foods"]
    page.click("#fClear")
    page.select_option("#fSource", "web"); assert names(page) == ["Delta Trading"]
    page.select_option("#fSource", "official"); assert "Delta Trading" not in names(page) and len(names(page)) == 5
    page.click("#fClear")
    page.select_option("#fActivity", "46"); assert names(page) == ["Epsilon Dairy"]
    page.click("#fClear")
    page.select_option("#fStatus", "has"); assert names(page) == ["Alpha Foods", "Beta Plastics"]
    page.select_option("#fStatus", "failed"); assert names(page) == ["Epsilon Dairy"]
    page.select_option("#fStatus", "new"); assert names(page) == ["Delta Trading", "Zeta Packaging"]
    page.click("#fClear")
    page.fill("#q", "plast"); assert names(page) == ["Beta Plastics"]
    page.fill("#q", "food products"); assert len(names(page)) == 6  # matches the activity text too
    page.fill("#q", "nomatch"); assert page.locator("#emptyReset").count() == 1
    page.click("#emptyReset"); assert len(names(page)) == 6


def test_combined_filters_and_sort(page):
    page.select_option("#fRegion", "Sharjah"); page.select_option("#fSort", "size")
    assert names(page) == ["Zeta Packaging", "Beta Plastics"]
    page.select_option("#fSort", "name"); assert names(page) == ["Beta Plastics", "Zeta Packaging"]
    page.click("#fClear"); page.select_option("#fSort", "people"); assert names(page)[:2] == ["Alpha Foods", "Beta Plastics"]


def test_linkedin_filter(page):
    page.check("#fLinkedin")
    assert names(page) == ["Alpha Foods", "Beta Plastics"]  # companies with no people drop out
    assert "2 of 3 people" in page.locator(".co").first.inner_text()  # Omar has no LinkedIn profile
    page.click('[data-toggle="c1"]')
    joined = " ".join(page.locator(".people table tr").all_inner_texts())
    assert "Sara Ali" in joined and "Ahmed Khan" in joined and "Omar Nasser" not in joined
    page.uncheck("#fLinkedin"); assert len(names(page)) == 6
    # the removed people filters are really gone
    for gone in ("#fTitle", "#fDept", "#fMobile", "#fSeniority"):
        assert page.locator(gone).count() == 0


def test_select_shown_and_matching_people(page):
    page.select_option("#fRegion", "Sharjah")
    assert "Select shown (2)" in page.locator("#selAll").inner_text()
    page.click("#selAll"); assert page.locator(".cpick:checked").count() == 2
    page.click("#selAll"); assert page.locator(".cpick:checked").count() == 0
    page.click("#fClear")
    page.check("#fLinkedin"); page.click("#fSelPeople")
    # eligible = LinkedIn + no mobile yet: Ahmed, Sara, Karim (Lina already has a mobile, Omar has no LinkedIn)
    # and their companies are ticked too, because the server only enriches people at ticked companies
    assert page.locator(".cpick:checked").count() == 2
    assert "3 people selected" in page.locator("#tb").inner_text()
    page.click("#fClear")


def test_export_filtered_csv(page):
    page.select_option("#fRegion", "Sharjah")
    assert page.locator("#fExport").is_visible()
    with page.expect_download() as d:
        page.click("#fExport")
    text = Path(d.value.path()).read_text(encoding="utf-8-sig")
    assert text.splitlines()[0].startswith('"company","country"')
    assert "Lina Haddad" in text and "Karim Saeed" in text and "Ahmed Khan" not in text
    page.click("#fClear"); assert not page.locator("#fExport").is_visible()
