"""Regression tests for decision-maker discovery from differently formatted search result titles."""
import pytest

from app import webpeople


COMPANY = {
    "company_name": "BUILDING MATERIALS 4 U LTD.",
    "country": "United Arab Emirates",
    "known_domain": "",
    "aliases": [],
}


@pytest.mark.parametrize(
    "separator,title",
    [
        (" - ", "John Smith - Managing Director - Building Materials 4 U | LinkedIn"),
        (" – ", "John Smith – Managing Director – Building Materials 4 U | LinkedIn"),
        (" — ", "John Smith — Managing Director — Building Materials 4 U | LinkedIn"),
        (" | ", "John Smith | Managing Director | Building Materials 4 U | LinkedIn"),
    ],
)
def test_profile_title_delimiters_recover_verified_decision_maker(monkeypatch, separator, title):
    # This exact case matters: real search engines emit all of these delimiters.
    hit = {
        "url": "https://www.linkedin.com/in/john-smith-123/",
        "title": title,
        "content": "John Smith. Managing Director at Building Materials 4 U. Dubai, United Arab Emirates.",
        "raw_content": "",
    }

    result = webpeople.find_web_people(
        COMPANY,
        search=lambda *args, **kwargs: [hit],
        extract=lambda company, sources: [],  # deterministic LinkedIn fallback must work without AI
        classify=lambda company, rows: {},
        enrich=False,
    )

    assert len(result["people"]) == 1
    person = result["people"][0]
    assert person["person_name"] == "John Smith"
    assert person["job_title"] == "Managing Director"
    assert person["linkedin_url"] == "https://www.linkedin.com/in/john-smith-123/"
    assert person["linkedin_confidence"] == "verified"


def test_search_budget_includes_general_leadership_searches():
    plan = webpeople._search_plan(COMPANY)
    assert len(plan) <= 14
    # Don't spend the entire default query budget on site:linkedin.com/in queries.
    assert any(domains is None for _query, domains in plan)
    assert any(domains == ["linkedin.com"] for _query, domains in plan)


def test_unrelated_or_former_employer_profile_stays_rejected(monkeypatch):
    hit = {
        "url": "https://www.linkedin.com/in/john-smith-123/",
        "title": "John Smith – Managing Director – Other Supplier | LinkedIn",
        "content": "John Smith. Formerly Managing Director at Building Materials 4 U. Now works at Other Supplier in Dubai.",
        "raw_content": "",
    }
    result = webpeople.find_web_people(
        COMPANY,
        search=lambda *args, **kwargs: [hit],
        extract=lambda company, sources: [],
        classify=lambda company, rows: {},
        enrich=False,
    )
    assert result["people"] == []


def test_86_matching_pages_still_recover_profile_using_em_dash(monkeypatch):
    """Reproduce the user's page-count symptom and ensure a valid person isn't dropped."""
    company = dict(COMPANY)
    people_hit = {
        "url": "https://www.linkedin.com/in/john-smith-123/",
        "title": "John Smith — Managing Director — Building Materials 4 U | LinkedIn",
        "content": "John Smith. Managing Director at Building Materials 4 U. Dubai, United Arab Emirates.",
        "raw_content": "",
    }
    pages = [
        {
            "url": f"https://building-materials4u.example/about-{i}",
            "title": f"Building Materials 4 U Ltd. company information page {i}",
            "content": "Building Materials 4 U Ltd. supplies construction materials.",
            "raw_content": "",
        }
        for i in range(85)
    ] + [people_hit]
    monkeypatch.setattr(webpeople, "find_company_contacts", lambda *args, **kwargs: {})

    result = webpeople.find_web_people(
        company,
        search=lambda *args, **kwargs: pages,
        extract=lambda company, sources: [],
        classify=lambda company, rows: {},
        enrich=False,
    )

    assert result["sources_used"] == 86
    assert result["diagnostics"]["linkedin_profile_candidates"] == 1
    assert [p["person_name"] for p in result["people"]] == ["John Smith"]
