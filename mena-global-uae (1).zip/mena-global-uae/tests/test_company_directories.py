from __future__ import annotations

import os

import pytest

from app import company_directories as dirs


class FakeResponse:
    def __init__(self, payload, status_code=200):
        self._payload = payload
        self.status_code = status_code
        self.content = b"{}"

    def json(self):
        return self._payload


def clear_cache():
    dirs._CACHE.clear()
    dirs._CANADA_RESULTS_CACHE.clear()


def test_normalise_sec_tickers_exchange_shape():
    data = {"fields": ["cik", "name", "ticker", "exchange"],
            "data": [[18230, "CATERPILLAR INC", "CAT", "NYSE"]]}
    rows = dirs._normalise_sec_rows(data)
    assert rows == [{"cik": "0000018230", "name": "CATERPILLAR INC", "ticker": "CAT", "exchange": "NYSE"}]


def test_sec_discovery_uses_official_sources_and_paginates(monkeypatch):
    clear_cache()
    calls = []

    def fake_get(url, **kwargs):
        calls.append((url, kwargs))
        if url == dirs.SEC_TICKERS_URL:
            return FakeResponse({"fields": ["cik", "name", "ticker", "exchange"], "data": [
                [18230, "CATERPILLAR INC", "CAT", "NYSE"],
                [12345, "GENERIC SOFTWARE LTD", "GSL", "Nasdaq"],
            ]})
        return FakeResponse({"hits": {"hits": [{"_source": {"entity_name": "CATERPILLAR INC", "ciks": ["18230"], "display_names": ["CATERPILLAR INC"]}}]}})

    monkeypatch.setattr(dirs.requests, "get", fake_get)
    result = dirs.discover_sec_companies("Industrial & Building Material Manufacturers", limit=1, offset=0)
    assert result["companies"]
    assert result["companies"][0]["company_name"] == "CATERPILLAR INC"
    assert result["companies"][0]["country"] == "United States"
    assert result["companies"][0]["source_url"].startswith("https://www.sec.gov/")
    assert calls and all("User-Agent" in item[1]["headers"] for item in calls)
    assert result["next_offset"] == 1


def test_companies_house_requires_key(monkeypatch):
    monkeypatch.delenv("COMPANIES_HOUSE_API_KEY", raising=False)
    with pytest.raises(dirs.DirectoryError, match="COMPANIES_HOUSE_API_KEY"):
        dirs.discover_companies_house("building materials")


def test_companies_house_normalises_records_and_pagination(monkeypatch):
    clear_cache()
    monkeypatch.setenv("COMPANIES_HOUSE_API_KEY", "test-key")
    calls = []

    def fake_get(url, **kwargs):
        calls.append((url, kwargs))
        return FakeResponse({"total_results": 2, "items": [{
            "title": "EXAMPLE MATERIALS LIMITED", "company_number": "01234567", "company_status": "active",
            "address_snippet": "Birmingham, England", "links": {"company_profile": "/company/01234567"}
        }]})

    monkeypatch.setattr(dirs.requests, "get", fake_get)
    result = dirs.discover_companies_house("building materials", limit=1, offset=0)
    c = result["companies"][0]
    assert c["company_key"] == "CH:01234567"
    assert c["country"] == "United Kingdom"
    assert c["registered_status"] == "active"
    assert c["source_url"].endswith("/company/01234567")
    assert result["has_more"] is True
    assert calls[0][1]["auth"] == ("test-key", "")


def test_dispatcher_rejects_unknown_country():
    with pytest.raises(dirs.DirectoryError, match="Unsupported"):
        dirs.discover_official_companies("Atlantis", "industrial")


def test_canada_discovery_uses_web_search_and_links_manual_registry_verification(monkeypatch):
    clear_cache()
    calls = []
    def fake_search(query, include_domains=None, max_results=None):
        calls.append(query)
        return [
            {"title": "North Shore Packaging | Canadian packaging manufacturer", "url": "https://northshorepackaging.ca/", "content": "Packaging manufacturer in British Columbia, Canada."},
            {"title": "Maple Industrial Supply - Canada", "url": "https://mapleindustrial.example/about-canada", "content": "Industrial supplier based in Toronto, Ontario."},
            {"title": "Search Canada's Business Registries", "url": "https://ised-isde.canada.ca/cbr-rec/en/", "content": "Registry search result"},
            {"title": "CBC News: Canadian industry", "url": "https://www.cbc.ca/news/business/canada", "content": "Canadian business news"},
        ]
    monkeypatch.setattr("app.search.public_search", fake_search)
    result = dirs.discover_official_companies("Canada", "Industrial & Building Material Manufacturers", limit=50, offset=0)
    assert len(calls) == 3
    assert [c["company_name"] for c in result["companies"]] == ["North Shore Packaging", "Maple Industrial Supply"]
    assert result["total"] == 2
    first = result["companies"][0]
    assert first["country"] == "Canada"
    assert first["domain"] == "northshorepackaging.ca"
    assert first["source_url"] == "https://northshorepackaging.ca/"
    assert first["registry_url"] == dirs.CANADA_REGISTRY_URL
    assert first["verification_status"] == "Not verified in Canada's Business Registries"
    assert result["source"]["name"] == "Canadian company discovery via public web search"
    assert result["source"]["verification_url"] == dirs.CANADA_REGISTRY_URL


def test_canada_discovery_paginates_cached_results_without_extra_search(monkeypatch):
    clear_cache()
    calls = []
    hits = [
        {"title": f"Canadian Supplier {i} | Industrial products", "url": f"https://supplier{i}.ca/", "content": "Canadian company serving Ontario, Canada."}
        for i in range(1, 5)
    ]
    def fake_search(query, include_domains=None, max_results=None):
        calls.append(query)
        return hits
    monkeypatch.setattr("app.search.public_search", fake_search)
    first = dirs.discover_canadian_companies("industrial supply", limit=2, offset=0)
    call_count = len(calls)
    second = dirs.discover_canadian_companies("industrial supply", limit=2, offset=2)
    assert len(first["companies"]) == 2
    assert len(second["companies"]) == 2
    assert first["companies"][0]["company_key"] != second["companies"][0]["company_key"]
    assert len(calls) == call_count
    assert second["has_more"] is False


def test_canada_manual_connection_check_never_queries_registry():
    result = dirs.check_directory_connection("Canada")
    assert result["ok"] is False
    assert "No automated request was made" in result["message"]
    assert result["url"] == dirs.CANADA_REGISTRY_URL


def test_uk_connection_check_uses_small_read_only_companies_house_search(monkeypatch):
    calls = []

    def fake_discover(query, *, limit=50, offset=0):
        calls.append((query, limit, offset))
        return {"companies": [{"company_name": "TESCO PLC"}], "total": 123, "has_more": True}

    monkeypatch.setattr(dirs, "discover_companies_house", fake_discover)
    result = dirs.check_directory_connection("United Kingdom")
    assert result["ok"] is True
    assert result["source"] == "Companies House"
    assert result["sample_count"] == 1
    assert result["total"] == 123
    assert calls == [("tesco", 1, 0)]


def test_us_connection_check_uses_sec_adapter(monkeypatch):
    calls = []

    def fake_discover(query, *, limit=50, offset=0):
        calls.append((query, limit, offset))
        return {"companies": [{"company_name": "CATERPILLAR INC"}], "total": 1}

    monkeypatch.setattr(dirs, "discover_sec_companies", fake_discover)
    result = dirs.check_directory_connection("United States")
    assert result["ok"] is True
    assert result["source"] == "SEC EDGAR"
    assert calls == [("Caterpillar", 1, 0)]


def test_companies_house_auth_failure_has_actionable_message(monkeypatch):
    clear_cache()
    monkeypatch.setenv("COMPANIES_HOUSE_API_KEY", "invalid-key")

    def unauthorized(url, **kwargs):
        return FakeResponse({"error": "not authorized"}, status_code=401)

    monkeypatch.setattr(dirs.requests, "get", unauthorized)
    with pytest.raises(dirs.DirectoryError, match="HTTP 401.*REST API key"):
        dirs.discover_companies_house("tesco", limit=1)


def test_companies_house_rate_limit_has_actionable_message(monkeypatch):
    clear_cache()
    monkeypatch.setenv("COMPANIES_HOUSE_API_KEY", "test-key-rate-limit")

    def rate_limited(url, **kwargs):
        return FakeResponse({"error": "rate limited"}, status_code=429)

    monkeypatch.setattr(dirs.requests, "get", rate_limited)
    with pytest.raises(dirs.DirectoryError, match="rate limit.*429"):
        dirs.discover_companies_house("tesco", limit=1)
