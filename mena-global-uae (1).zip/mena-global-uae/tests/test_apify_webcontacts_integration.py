from types import SimpleNamespace

from app import webcontacts


def _settings():
    return SimpleNamespace(
        tavily_api_key="key",
        serper_api_key="",
        max_person_contact_lookups_per_company=30,
        person_contact_workers=1,
        apify_api_token="token",
        apify_contact_enabled=True,
        apify_contact_actors=("datablow/linkedin-profile-enrichment",),
    )


def test_apify_wins_and_hunter_is_not_called_when_both_contacts_found(monkeypatch):
    monkeypatch.setattr(webcontacts, "settings", _settings())
    monkeypatch.setattr(webcontacts, "apify_enrich_by_linkedin", lambda *a, **k: {
        "status": "found", "actor": "datablow/linkedin-profile-enrichment",
        "email": "sara@acme.ae", "phone": "+971501112222", "errors": [],
        "attempts": [{"actor": "datablow/linkedin-profile-enrichment", "status": "found", "email": True, "phone": True}],
    })
    monkeypatch.setattr(webcontacts, "hunter_configured", lambda: (_ for _ in ()).throw(AssertionError("Hunter must not run")))
    result = webcontacts.find_person_contacts(
        {"person_name": "Sara Al Mansoori", "company": "Acme Trading", "linkedin_url": "https://www.linkedin.com/in/sara-al-mansoori/"},
        {"company_name": "Acme Trading", "known_domain": "acme.ae"}, search=lambda *a, **k: [],
    )
    assert result["email"] == "sara@acme.ae"
    assert result["phone"] == "+971501112222"
    assert result["email_basis"] == "apify_linkedin_exact"


def test_apify_miss_falls_through_to_hunter(monkeypatch):
    monkeypatch.setattr(webcontacts, "settings", _settings())
    monkeypatch.setattr(webcontacts, "apify_enrich_by_linkedin", lambda *a, **k: {
        "status": "not_found", "actor": "datablow/linkedin-profile-enrichment", "errors": [], "attempts": [],
    })
    monkeypatch.setattr(webcontacts, "hunter_configured", lambda: True)
    monkeypatch.setattr(webcontacts, "find_email_by_linkedin", lambda url: {
        "status": "found", "email": "omar@acme.ae", "sources": ["u"],
        "company": "Acme Trading", "domain": "acme.ae", "phone": "+971501113333",
    })
    monkeypatch.setattr(webcontacts, "enrich_person_by_linkedin", lambda url: {"status": "not_found"})
    monkeypatch.setattr(webcontacts, "domain_search_person", lambda *a, **k: {"status": "not_found"})
    result = webcontacts.find_person_contacts(
        {"person_name": "Omar Khan", "company": "Acme Trading", "linkedin_url": "https://www.linkedin.com/in/omar-khan/"},
        {"company_name": "Acme Trading", "known_domain": "acme.ae"}, search=lambda *a, **k: [],
    )
    assert result["email"] == "omar@acme.ae"
    assert result["phone"] == "+971501113333"
    assert result["email_basis"] == "hunter_linkedin_verified_public"


def test_apify_phone_is_never_allowed_to_overwrite_company_switchboard(monkeypatch):
    monkeypatch.setattr(webcontacts, "settings", _settings())
    monkeypatch.setattr(webcontacts, "apify_enrich_by_linkedin", lambda *a, **k: {
        "status": "found", "actor": "datablow/linkedin-profile-enrichment",
        "email": "", "phone": "+971412345678", "errors": [], "attempts": [],
    })
    monkeypatch.setattr(webcontacts, "hunter_configured", lambda: False)
    result = webcontacts.find_person_contacts(
        {"person_name": "Jane Doe", "company": "Acme Trading", "linkedin_url": "https://www.linkedin.com/in/jane-doe/"},
        {"company_name": "Acme Trading", "known_domain": "acme.ae"}, search=lambda *a, **k: [],
        exclude_phones=frozenset({webcontacts._phone_key("+971412345678")}),
    )
    assert result["phone"] == ""
