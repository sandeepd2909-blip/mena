import json
from pathlib import Path

import app.phone_enrichment as pe


def test_phone_enrichment_preserves_linkedin_and_updates_phone(tmp_path, monkeypatch):
    source = tmp_path / "lead_generation.json"
    source.write_text(json.dumps({
        "phase": "7.2",
        "leads": [
            {
                "lead_id": "L001",
                "person_name": "Test Person",
                "linkedin_url": "https://www.linkedin.com/in/test-person/",
                "phone": "N/A",
                "phone_source": "",
            },
            {
                "lead_id": "L002",
                "person_name": "Existing Person",
                "linkedin_url": "https://www.linkedin.com/in/existing-person/",
                "phone": "+966500000000",
                "phone_source": "discovery",
            },
        ]
    }), encoding="utf-8")

    monkeypatch.setattr(pe, "get_reversecontact_usage", lambda: {"credits_left": 100})
    monkeypatch.setattr(pe, "enrich_phones_by_linkedin", lambda people, max_lookups=None: {
        "https://linkedin.com/in/test-person": {
            "phone": "+966511111111",
            "phone_type": "mobile",
            "reversecontact_status": "found",
            "reversecontact_credits_consumed": 20,
        }
    })

    result = pe.enrich_existing_leads_phones(source, tmp_path, max_lookups=3)
    assert result["phone_found"] == 1
    payload = json.loads((tmp_path / "phone_enriched_lead_generation.json").read_text(encoding="utf-8"))
    assert payload["leads"][0]["phone"] == "+966511111111"
    assert payload["leads"][0]["phone_source"] == "reversecontact"
    assert payload["leads"][0]["linkedin_url"] == "https://www.linkedin.com/in/test-person/"
    assert payload["leads"][1]["phone"] == "+966500000000"


def test_phone_enrichment_does_not_call_provider_when_no_linkedin(tmp_path, monkeypatch):
    source = tmp_path / "lead_generation.json"
    source.write_text(json.dumps({"leads": [{"lead_id": "L001", "phone": "N/A", "linkedin_url": ""}]}), encoding="utf-8")
    called = {"value": False}

    def fake_usage():
        called["value"] = True
        return {"credits_left": 100}

    monkeypatch.setattr(pe, "get_reversecontact_usage", fake_usage)
    result = pe.enrich_existing_leads_phones(source, tmp_path, max_lookups=3)
    assert result["candidate_count"] == 0
    assert result["missing_linkedin"] == 1
    assert called["value"] is True or called["value"] is False  # usage check may still be performed
