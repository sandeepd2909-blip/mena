from types import SimpleNamespace

from app import search


def test_search_provider_tavily_is_primary_even_when_serper_is_configured(monkeypatch):
    monkeypatch.setattr(search, "settings", SimpleNamespace(search_provider="tavily", tavily_api_key="t", serper_api_key="s", search_depth="advanced", max_search_results=5, request_timeout=5))
    monkeypatch.setattr(search, "tavily_search", lambda *a, **k: [{"url": "tavily"}])
    monkeypatch.setattr(search, "serper_search", lambda *a, **k: [{"url": "serper"}])
    assert search.public_search("q")[0]["url"] == "tavily"


def test_search_provider_serper_can_be_selected_explicitly(monkeypatch):
    monkeypatch.setattr(search, "settings", SimpleNamespace(search_provider="serper", tavily_api_key="t", serper_api_key="s"))
    monkeypatch.setattr(search, "tavily_search", lambda *a, **k: [{"url": "tavily"}])
    monkeypatch.setattr(search, "serper_search", lambda *a, **k: [{"url": "serper"}])
    assert search.public_search("q")[0]["url"] == "serper"


def test_tavily_quota_error_switches_to_serper_and_is_circuit_broken(monkeypatch):
    from requests import HTTPError
    from types import SimpleNamespace

    monkeypatch.setattr(search, "settings", SimpleNamespace(search_provider="tavily", tavily_api_key="t", serper_api_key="s", search_depth="advanced", max_search_results=5, request_timeout=5))
    search._DISABLED_PROVIDERS.clear()
    calls = {"tavily": 0, "serper": 0}

    class Response:
        status_code = 432
        def raise_for_status(self):
            raise HTTPError("432 Client Error")

    def fake_post(*args, **kwargs):
        calls["tavily"] += 1
        return Response()

    def fake_serper(*args, **kwargs):
        calls["serper"] += 1
        return [{"url": "serper-result"}]

    monkeypatch.setattr(search.requests, "post", fake_post)
    monkeypatch.setattr(search, "serper_search", fake_serper)
    # Tavily's low-level implementation classifies the 432 then public_search fails over.
    result = search.public_search("query")
    assert result[0]["url"] == "serper-result"
    assert calls == {"tavily": 1, "serper": 1}
    # A subsequent query must not make another Tavily request.
    assert search.public_search("query 2")[0]["url"] == "serper-result"
    assert calls == {"tavily": 1, "serper": 2}
    search._DISABLED_PROVIDERS.clear()


def test_tavily_432_is_reported_as_plan_limit(monkeypatch):
    from requests import HTTPError
    class Response:
        status_code = 432
        def raise_for_status(self):
            raise HTTPError("432 Client Error")
    response = Response()
    monkeypatch.setattr(search.requests, "post", lambda *a, **k: response)
    monkeypatch.setattr(search, "settings", SimpleNamespace(search_provider="tavily", tavily_api_key="t", serper_api_key="", search_depth="advanced", max_search_results=5, request_timeout=5))
    search._DISABLED_PROVIDERS.clear()
    try:
        search.tavily_search("query")
    except RuntimeError as exc:
        assert "plan usage limit exceeded" in str(exc)
    else:
        raise AssertionError("expected Tavily quota error")
    finally:
        search._DISABLED_PROVIDERS.clear()


def test_empty_tavily_results_trigger_serper_fallback(monkeypatch):
    monkeypatch.setattr(search, "settings", SimpleNamespace(search_provider="tavily", tavily_api_key="t", serper_api_key="s", search_depth="advanced", max_search_results=5, request_timeout=5))
    search._DISABLED_PROVIDERS.clear()
    monkeypatch.setattr(search, "tavily_search", lambda *a, **k: [])
    monkeypatch.setattr(search, "serper_search", lambda *a, **k: [{"url": "serper-result"}])
    assert search.public_search("query")[0]["url"] == "serper-result"
