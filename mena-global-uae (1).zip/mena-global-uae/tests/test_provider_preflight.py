from types import SimpleNamespace

from app.apify_api import get_apify_actor_data, get_apify_user_data, preflight_apify


def test_get_user_data_uses_bearer(monkeypatch):
    fake_settings = SimpleNamespace(apify_api_token="secret-token", request_timeout=9)
    monkeypatch.setattr("app.apify_api.settings", fake_settings)
    seen = {}

    class Response:
        status_code = 200
        text = ""
        def json(self):
            return {"data": {"username": "example", "plan": {"id": "free"}}}

    def fake_get(url, headers, timeout):
        seen.update({"url": url, "headers": headers, "timeout": timeout})
        return Response()

    monkeypatch.setattr("app.apify_api.requests.get", fake_get)
    data = get_apify_user_data()
    assert data["plan"]["id"] == "free"
    assert seen["url"].endswith("/v2/users/me")
    assert seen["headers"]["Authorization"] == "Bearer secret-token"


def test_get_actor_data_uses_api_actor_path(monkeypatch):
    fake_settings = SimpleNamespace(apify_api_token="secret-token", request_timeout=9)
    monkeypatch.setattr("app.apify_api.settings", fake_settings)
    seen = {}

    class Response:
        status_code = 200
        text = ""
        def json(self):
            return {"data": {"id": "abc", "isPublic": True, "isDeprecated": False, "actorPermissionLevel": "LIMITED_PERMISSIONS"}}

    def fake_get(url, headers, timeout):
        seen.update({"url": url, "headers": headers, "timeout": timeout})
        return Response()

    monkeypatch.setattr("app.apify_api.requests.get", fake_get)
    data = get_apify_actor_data("owner/actor")
    assert data["id"] == "abc"
    assert "owner~actor" in seen["url"]


def test_preflight_reports_account_and_actor_metadata(monkeypatch):
    fake_settings = SimpleNamespace(apify_api_token="secret-token", request_timeout=9)
    monkeypatch.setattr("app.apify_api.settings", fake_settings)

    monkeypatch.setattr(
        "app.apify_api.get_apify_user_data",
        lambda: {"plan": {"id": "free"}, "username": "example"},
    )
    monkeypatch.setattr(
        "app.apify_api.get_apify_actor_data",
        lambda actor_id: {
            "id": "actor-id",
            "name": actor_id.split("/")[-1],
            "isPublic": True,
            "isDeprecated": False,
            "actorPermissionLevel": "LIMITED_PERMISSIONS",
            "notice": "NONE",
        },
    )

    result = preflight_apify(["owner/actor", "owner/actor"])
    assert result["status"] == "ready"
    assert result["account"]["plan"] == "free"
    assert len(result["actors"]) == 1
    assert result["actors"][0]["status"] == "ok"
