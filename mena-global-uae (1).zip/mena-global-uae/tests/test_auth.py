"""Single-credential login: HTTP-level security tests plus a real-browser sign-in flow."""
from __future__ import annotations

import http.client
import json
import threading
import time
from http.server import ThreadingHTTPServer

import pytest

from app import auth
from app.server import Handler, serve

USER, PASSWORD = "boss", "correct horse battery staple"


@pytest.fixture()
def srv(monkeypatch):
    monkeypatch.setenv("APP_USERNAME", USER)
    monkeypatch.setenv("APP_PASSWORD", PASSWORD)
    monkeypatch.delenv("SESSION_SECRET", raising=False)
    monkeypatch.setattr(time, "sleep", lambda s: None)  # skip the anti-guessing delay in tests
    auth.reset_state()
    httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    yield httpd.server_address[1]
    httpd.shutdown(); httpd.server_close(); auth.reset_state()


def call(port, method, path, body=None, headers=None):
    c = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
    h = dict(headers or {})
    data = None
    if body is not None:
        data = json.dumps(body); h["Content-Type"] = "application/json"
    c.request(method, path, data, h)
    r = c.getresponse(); raw = r.read(); c.close()
    return r.status, dict((k.lower(), v) for k, v in r.getheaders()), raw


def login(port, user=USER, pw=PASSWORD, headers=None):
    return call(port, "POST", "/api/login", {"username": user, "password": pw}, headers)


def cookie_of(headers):
    return headers["set-cookie"].split(";")[0]


def test_everything_is_protected_when_signed_out(srv):
    s, h, _ = call(srv, "GET", "/"); assert s == 302 and h["location"] == "/login"
    for path in ("/api/meta", "/api/jobs/abc", "/api/jobs/abc.csv", "/api/mobile/provider-status"):
        assert call(srv, "GET", path)[0] == 401, path
    for path in ("/api/run", "/api/selection", "/api/run-selected", "/api/mobile/start", "/api/directory-check"):
        assert call(srv, "POST", path, {})[0] == 401, path
    assert call(srv, "GET", "/health")[0] == 200  # health check stays public for the host
    s, _, body = call(srv, "GET", "/login"); assert s == 200 and b"Sign in" in body


def test_wrong_credentials_rejected(srv):
    for u, p in [(USER, "nope"), ("admin", PASSWORD), ("", ""), (USER, PASSWORD + " "), (USER.upper(), PASSWORD)]:
        s, h, _ = login(srv, u, p)
        assert s == 401 and "set-cookie" not in h, (u, p)
    other = {"X-Forwarded-For": "198.51.100.7"}  # fresh address, so the lockout from above does not apply
    assert call(srv, "POST", "/api/login", {"username": USER}, other)[0] == 401  # missing password
    assert call(srv, "GET", "/api/meta")[0] == 401


def test_login_session_and_logout(srv):
    s, h, _ = login(srv); assert s == 200
    sc = h["set-cookie"]; assert "HttpOnly" in sc and "SameSite=Lax" in sc and "Secure" not in sc
    ck = {"Cookie": cookie_of(h)}
    assert call(srv, "GET", "/", headers=ck)[0] == 200
    s, _, body = call(srv, "GET", "/api/meta", headers=ck); assert s == 200 and json.loads(body)["auth"] is True
    s, h2, _ = call(srv, "GET", "/login", headers=ck); assert s == 302 and h2["location"] == "/"  # already signed in
    s, h3, _ = call(srv, "POST", "/api/logout", {}, ck); assert s == 200 and "Max-Age=0" in h3["set-cookie"]


def test_secure_flag_behind_https_proxy(srv):
    _, h, _ = login(srv, headers={"X-Forwarded-Proto": "https"}); assert "Secure" in h["set-cookie"]


def test_forged_and_expired_tokens_rejected(srv):
    token = auth.make_token()
    assert auth.valid_token(token)
    assert not auth.valid_token(token[:-4] + "AAAA")            # tampered signature
    assert not auth.valid_token("garbage") and not auth.valid_token("")
    assert not auth.valid_token(token, now=time.time() + 8 * 86400)  # expired (default 7 days)
    assert call(srv, "GET", "/api/meta", headers={"Cookie": f"{auth.COOKIE}={token}x"})[0] == 401


def test_token_invalid_after_password_change(srv, monkeypatch):
    token = auth.make_token(); assert auth.valid_token(token)
    monkeypatch.setenv("APP_PASSWORD", "a different password")
    assert not auth.valid_token(token)


def test_lockout_after_five_failures(srv):
    for _ in range(5):
        assert login(srv, USER, "bad")[0] == 401
    s, _, body = login(srv, USER, PASSWORD)  # even the right password is refused while locked
    assert s == 429 and b"Too many attempts" in body
    # a different client address is unaffected
    assert login(srv, headers={"X-Forwarded-For": "203.0.113.9"})[0] == 200


def test_success_clears_failure_counter(srv):
    for _ in range(4):
        login(srv, USER, "bad")
    assert login(srv)[0] == 200
    for _ in range(4):
        login(srv, USER, "bad")
    assert login(srv)[0] == 200  # counter was reset, so no lockout yet


def test_login_disabled_without_password_on_localhost(monkeypatch):
    monkeypatch.delenv("APP_PASSWORD", raising=False)
    httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    try:
        port = httpd.server_address[1]
        assert call(port, "GET", "/")[0] == 200
        s, h, _ = call(port, "GET", "/login"); assert s == 302 and h["location"] == "/"
        assert json.loads(call(port, "GET", "/api/meta")[2])["auth"] is False
    finally:
        httpd.shutdown(); httpd.server_close()


def test_refuses_to_start_open_on_network_address(monkeypatch):
    monkeypatch.delenv("APP_PASSWORD", raising=False)
    with pytest.raises(RuntimeError, match="APP_PASSWORD"):
        serve(0, host="0.0.0.0")


def test_default_username_is_admin(monkeypatch):
    monkeypatch.delenv("APP_USERNAME", raising=False); monkeypatch.setenv("APP_PASSWORD", "x")
    assert auth.check_credentials("admin", "x") and not auth.check_credentials("root", "x")


# ------------------------------------------------------------------ browser flow
def test_browser_sign_in_and_out(srv):
    pw = pytest.importorskip("playwright.sync_api")
    with pw.sync_playwright() as p:
        try:
            browser = p.chromium.launch(args=["--no-sandbox"])
        except Exception as exc:
            pytest.skip(f"Chromium not available: {exc}")
        page = browser.new_page()
        errors = []; page.on("pageerror", lambda e: errors.append(str(e)))
        base = f"http://127.0.0.1:{srv}"
        page.goto(base + "/")                       # signed out -> sent to the login page
        page.wait_for_url("**/login"); assert page.locator("#go").is_visible()
        page.fill("#u", USER); page.fill("#p", "wrong"); page.click("#go")
        page.wait_for_selector("#err.on"); assert "Incorrect" in page.locator("#err").inner_text()
        assert page.locator("#p").input_value() == ""   # password field cleared after a failure
        page.fill("#p", PASSWORD); page.click("#show"); assert page.locator("#p").get_attribute("type") == "text"
        page.click("#go")
        page.wait_for_url(base + "/"); page.wait_for_selector("#go")  # main app loaded
        page.wait_for_selector("#logout", state="visible")
        page.reload(); page.wait_for_selector("#logout", state="visible")  # session survives a reload
        page.click("#logout"); page.wait_for_url("**/login")
        page.goto(base + "/"); page.wait_for_url("**/login")               # and is really gone
        assert errors == [], errors
        browser.close()
