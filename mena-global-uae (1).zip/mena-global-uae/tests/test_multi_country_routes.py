from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

from app import server


def _request(url, *, method="GET", payload=None):
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, method=method, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=3) as response:
            return response.status, json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        return exc.code, json.loads(exc.read().decode("utf-8"))


def test_meta_lists_official_directory_connectors(monkeypatch):
    monkeypatch.setenv("PYTHON_DOTENV_DISABLED", "1")
    httpd = ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    try:
        code, meta = _request(f"http://127.0.0.1:{httpd.server_port}/api/meta")
        assert code == 200
        country_sources = {x["value"]: x["directory"] for x in meta["countries"]}
        assert country_sources["United Arab Emirates"] == "UAE MoIAT"
        assert country_sources["United States"] == "SEC EDGAR"
        assert country_sources["United Kingdom"] == "Companies House"
        assert country_sources["Canada"] == "Canada's Business Registries"
    finally:
        httpd.shutdown()
        httpd.server_close()


def test_us_discovery_route_runs_official_adapter_and_keeps_job_country(monkeypatch):
    server.JOBS.clear()
    monkeypatch.setattr(server, "_save_job", lambda job: server.JOBS.__setitem__(job["id"], job))

    def fake_batch(job, *, offset=0):
        batch = [] if offset else [{
            "company_key": "SEC:0000001234", "company_name": "Example Industrial Inc.", "country": "United States",
            "region": "NYSE", "directory_id": "0000001234", "ticker": "EXI", "source_name": "SEC EDGAR",
            "source_url": "https://www.sec.gov/edgar/browse/?CIK=1234", "note": "SEC EDGAR filing-index match",
        }]
        return {"companies": batch, "total": 1, "has_more": False, "next_offset": len(batch),
                "source": {"name": "SEC EDGAR", "dataset": "test", "url": "https://www.sec.gov/edgar/search/"}}

    monkeypatch.setattr(server, "_official_directory_batch", fake_batch)
    httpd = ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    try:
        base = f"http://127.0.0.1:{httpd.server_port}"
        code, response = _request(base + "/api/run", method="POST", payload={
            "country": "United States", "segment": "Industrial & Building Material Manufacturers"
        })
        assert code == 200
        jid = response["id"]
        deadline = time.time() + 3
        job = None
        while time.time() < deadline:
            code, job = _request(base + f"/api/jobs/{jid}")
            if job.get("stage") not in {"queued", "discover"}:
                break
            time.sleep(0.02)
        assert job["stage"] == "discovered"
        assert job["country"] == "United States"
        assert job["source"]["name"] == "SEC EDGAR"
        assert job["companies"][0]["name"] == "Example Industrial Inc."
        assert job["companies"][0]["ticker"] == "EXI"
    finally:
        httpd.shutdown()
        httpd.server_close()


def test_canada_discovery_route_runs_search_adapter_and_keeps_country(monkeypatch):
    server.JOBS.clear()
    monkeypatch.setattr(server, "_save_job", lambda job: server.JOBS.__setitem__(job["id"], job))

    def fake_batch(job, *, offset=0):
        batch = [] if offset else [{
            "company_key": "CAWEB:example.ca", "company_name": "Example Canadian Supply", "country": "Canada",
            "domain": "example.ca", "region": "Ontario", "source_name": "Public web search (candidate)",
            "source_url": "https://example.ca/", "registry_url": "https://ised-isde.canada.ca/cbr-rec/en/",
            "verification_status": "Not verified in Canada's Business Registries",
            "note": "Manual registry verification required.",
        }]
        return {"companies": batch, "total": 1, "has_more": False, "next_offset": len(batch),
                "source": {"name": "Canadian company discovery via public web search", "url": "https://ised-isde.canada.ca/cbr-rec/en/"}}

    monkeypatch.setattr(server, "_official_directory_batch", fake_batch)
    httpd = ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    try:
        base = f"http://127.0.0.1:{httpd.server_port}"
        code, response = _request(base + "/api/run", method="POST", payload={
            "country": "Canada", "search_query": "industrial suppliers"
        })
        assert code == 200
        jid = response["id"]
        deadline = time.time() + 3
        job = None
        while time.time() < deadline:
            code, job = _request(base + f"/api/jobs/{jid}")
            if job.get("stage") not in {"queued", "discover"}:
                break
            time.sleep(0.02)
        assert job["stage"] == "discovered"
        assert job["country"] == "Canada"
        assert job["source"]["name"] == "Canadian company discovery via public web search"
        assert job["companies"][0]["country"] == "Canada"
        assert job["companies"][0]["registry_url"].startswith("https://ised-isde.canada.ca/cbr-rec/")
        assert "Not verified" in job["companies"][0]["verification_status"]
    finally:
        httpd.shutdown()
        httpd.server_close()


def test_run_route_rejects_unknown_country(monkeypatch):
    server.JOBS.clear()
    monkeypatch.setattr(server, "_save_job", lambda job: server.JOBS.__setitem__(job["id"], job))
    httpd = ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    try:
        code, body = _request(f"http://127.0.0.1:{httpd.server_port}/api/run", method="POST", payload={
            "country": "Atlantis", "search_query": "manufacturing"
        })
        assert code == 400
        assert "Choose UAE" in body["error"]
    finally:
        httpd.shutdown()
        httpd.server_close()


def test_directory_check_route_returns_actionable_missing_key_message(monkeypatch):
    monkeypatch.delenv("COMPANIES_HOUSE_API_KEY", raising=False)
    httpd = ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    try:
        code, body = _request(f"http://127.0.0.1:{httpd.server_port}/api/directory-check", method="POST", payload={
            "country": "United Kingdom"
        })
        assert code == 200
        assert body["ok"] is False
        assert "COMPANIES_HOUSE_API_KEY" in body["message"]
    finally:
        httpd.shutdown()
        httpd.server_close()


def test_directory_check_route_returns_success_shape(monkeypatch):
    from app import company_directories
    monkeypatch.setattr(company_directories, "check_directory_connection", lambda country: {
        "ok": True, "country": country, "source": "Companies House", "sample_count": 1,
        "total": 123, "message": "Connected to Companies House successfully."
    })
    httpd = ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    try:
        code, body = _request(f"http://127.0.0.1:{httpd.server_port}/api/directory-check", method="POST", payload={
            "country": "United Kingdom"
        })
        assert code == 200
        assert body["ok"] is True
        assert body["sample_count"] == 1
    finally:
        httpd.shutdown()
        httpd.server_close()
