from pathlib import Path


def test_bundled_env_enables_tomba_without_exposing_credentials():
    root = Path(__file__).parents[1]
    # Real secrets live only in the user's local .env (never shipped); fall back to the template.
    env = root / ".env"
    if not env.exists():
        env = root / ".env.example"
    text = env.read_text(encoding="utf-8")
    assert "TOMBA_ENABLED=true" in text
    assert "TOMBA_API_KEY=" in text and "TOMBA_SECRET_KEY=" in text
    assert "TOMBA_TIMEOUT=180" in text
